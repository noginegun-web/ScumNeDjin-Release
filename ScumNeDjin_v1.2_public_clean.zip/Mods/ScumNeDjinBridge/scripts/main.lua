PRODUCT_DIR = "ScumNeDjin"
BRIDGE_DIR = "nedjin_bridge"
CONFIG_STEM = "nedjin"
COMMAND_FILE = BRIDGE_DIR .. "\\command.json"
RESULT_FILE = BRIDGE_DIR .. "\\result.json"
HEARTBEAT_FILE = BRIDGE_DIR .. "\\heartbeat.json"
LOG_FILE = BRIDGE_DIR .. "\\" .. CONFIG_STEM .. ".log"
STATE_DIR = PRODUCT_DIR .. "\\state"
CONFIG_DIR = PRODUCT_DIR .. "\\configs"
CONFIG_LIVE_DIR = STATE_DIR .. "\\configs"
LANG_DIR = PRODUCT_DIR .. "\\lang"
CHAT_STATE_FILE = STATE_DIR .. "\\chat.json"
ECONOMY_STATE_FILE = STATE_DIR .. "\\economy.json"
ACTION_STATE_FILE = STATE_DIR .. "\\action-log.json"
ITEM_CATALOG_FILE = PRODUCT_DIR .. "\\web\\spawnable-items.json"
ITEM_ACTOR_MAP_FILE = PRODUCT_DIR .. "\\data\\es_actor_map.json"
SERVER_LOG_FILE = "..\\..\\Saved\\Logs\\SCUM.log"
SCUM_SAVE_LOG_DIR = "..\\..\\Saved\\SaveFiles\\Logs"
DEFAULT_WELCOME_ITEMS_SPEC = "Bamboo_Hat_02|1;Beijing_Shoes_04|1;Tang_pants_04|1;Tang_shirt_04|1;Apple_2|1;BeefRavioli|1;CannedGoulash|1;Emergency_bandage_Big|1"

function mkdir(path)
  os.execute('mkdir "' .. path .. '" >nul 2>nul')
end

function readAll(path)
  local livePath = tostring(path or "") .. ".live"
  local f = io.open(livePath, "rb") or io.open(path, "rb")
  if not f then return nil end
  local text = f:read("*a")
  f:close()
  return text
end

function writeAll(path, text)
  local f = io.open(path, "wb")
  if not f then
    f = io.open(tostring(path or "") .. ".live", "wb")
  end
  if not f then return false end
  f:write(text or "")
  f:close()
  return true
end

function removeFile(path)
  pcall(function() os.remove(tostring(path or "")) end)
  pcall(function() os.remove(tostring(path or "") .. ".live") end)
end

STATE_ARRAY_CACHE = STATE_ARRAY_CACHE or {}
STATE_WRITE_QUEUE = STATE_WRITE_QUEUE or {}
STATE_WRITE_QUEUE_PENDING = STATE_WRITE_QUEUE_PENDING or {}
STATE_WRITE_QUEUE_MAX = STATE_WRITE_QUEUE_MAX or 4000

function normalizeJsonArrayText(text, maxBytes)
  local value = tostring(text or "[]"):gsub("^%s+", ""):gsub("%s+$", "")
  value = value:gsub("^\239\187\191", "")
  local limit = math.max(1024, tonumber(maxBytes) or 1048576)
  if value == "" or value:sub(1, 1) ~= "[" or value:sub(-1) ~= "]" or #value > limit then
    return "[]"
  end
  return value
end

function loadStateArrayCache(path, maxBytes, forceReload)
  local limit = math.max(1024, tonumber(maxBytes) or 1048576)
  local cache = STATE_ARRAY_CACHE[path]
  local nowClock = os.clock()
  if cache ~= nil and not forceReload then
    cache.maxBytes = math.max(tonumber(cache.maxBytes) or 0, limit)
    if cache.dirty or (nowClock - (cache.loadedAt or 0)) <= 0.75 then
      return cache
    end
  end
  local text = normalizeJsonArrayText(readAll(path) or "[]", limit)
  local rows = {}
  for object in text:gmatch("%b{}") do table.insert(rows, object) end
  cache = {
    path = path,
    rows = rows,
    maxBytes = limit,
    approxBytes = #text,
    dirty = false,
    loadedAt = nowClock
  }
  STATE_ARRAY_CACHE[path] = cache
  return cache
end

function queueStateFlushPath(path)
  local cleanPath = tostring(path or "")
  if cleanPath == "" then return false end
  if STATE_WRITE_QUEUE_PENDING[cleanPath] then return true end
  if #(STATE_WRITE_QUEUE or {}) >= STATE_WRITE_QUEUE_MAX then
    local removed = table.remove(STATE_WRITE_QUEUE, 1)
    if removed ~= nil then STATE_WRITE_QUEUE_PENDING[removed] = nil end
  end
  table.insert(STATE_WRITE_QUEUE, cleanPath)
  STATE_WRITE_QUEUE_PENDING[cleanPath] = true
  return true
end

function flushStateArrayCache(path)
  local cleanPath = tostring(path or "")
  if cleanPath == "" then return false end
  local cache = STATE_ARRAY_CACHE[cleanPath]
  if cache == nil then return true end
  local rows = cache.rows or {}
  local limit = math.max(1024, tonumber(cache.maxBytes) or 1048576)
  local text = "[" .. table.concat(rows, ",") .. "]"
  while #text > limit and #rows > 1 do
    table.remove(rows, 1)
    text = "[" .. table.concat(rows, ",") .. "]"
  end
  if #text > limit then
    local last = rows[#rows] or "{}"
    rows = { last }
    text = "[" .. last .. "]"
  end
  cache.rows = rows
  cache.approxBytes = #text
  local okWrite = writeAll(cleanPath, text)
  if okWrite then
    cache.dirty = false
    cache.loadedAt = os.clock()
  end
  return okWrite
end

function appendJsonArray(path, recordJson, maxBytes)
  local cleanPath = tostring(path or "")
  if cleanPath == "" then return false end
  local limit = math.max(1024, tonumber(maxBytes) or 1048576)
  local cache = loadStateArrayCache(cleanPath, limit, false)
  local rows = cache.rows or {}
  local record = tostring(recordJson or "{}")
  local nextSize = (tonumber(cache.approxBytes) or 2) + #record + ((#rows > 0) and 1 or 0)
  if nextSize > limit then
    rows = { record }
    cache.approxBytes = #record + 2
  else
    table.insert(rows, record)
    cache.approxBytes = nextSize
  end
  cache.rows = rows
  cache.maxBytes = limit
  cache.dirty = true
  cache.loadedAt = os.clock()
  queueStateFlushPath(cleanPath)
  return true
end

function readTail(path, maxBytes)
  local f = io.open(path, "rb")
  if not f then return nil end
  local size = f:seek("end", 0)
  if size == nil then
    f:close()
    return nil
  end
  local limit = math.max(0, tonumber(maxBytes) or 0)
  local start = 0
  if limit > 0 and size > limit then start = size - limit end
  f:seek("set", start)
  local text = f:read("*a")
  f:close()
  if text == nil then return nil end
  if start > 0 then
    local cut = text:find("[\r\n]")
    if cut ~= nil then text = text:sub(cut + 1) end
  end
  return text
end

LOG_ROTATE_MAX_BYTES = LOG_ROTATE_MAX_BYTES or (512 * 1024)
LOG_LAST_TEXT = LOG_LAST_TEXT or nil
LOG_REPEAT_COUNT = LOG_REPEAT_COUNT or 0

function rotateLogIfNeeded()
  local f = io.open(LOG_FILE, "rb")
  if not f then return end
  local size = f:seek("end", 0) or 0
  f:close()
  if size < LOG_ROTATE_MAX_BYTES then return end
  pcall(function() os.remove(LOG_FILE .. ".1") end)
  pcall(function() os.rename(LOG_FILE, LOG_FILE .. ".1") end)
end

function appendLogLine(line)
  rotateLogIfNeeded()
  local f = io.open(LOG_FILE, "ab")
  if f then
    f:write(os.date("!%Y-%m-%dT%H:%M:%SZ") .. " " .. tostring(line) .. "\n")
    f:close()
  end
end

function appendLog(text)
  if touchHeartbeat ~= nil then touchHeartbeat(false) end
  local line = tostring(text)
  if LOG_LAST_TEXT == line then
    LOG_REPEAT_COUNT = (LOG_REPEAT_COUNT or 0) + 1
    if LOG_REPEAT_COUNT == 2 or LOG_REPEAT_COUNT == 5 or LOG_REPEAT_COUNT == 10 or LOG_REPEAT_COUNT == 25 or LOG_REPEAT_COUNT == 50 or (LOG_REPEAT_COUNT % 100) == 0 then
      appendLogLine("previous message repeated " .. tostring(LOG_REPEAT_COUNT) .. " times: " .. line)
    end
    return
  end
  if LOG_LAST_TEXT ~= nil and (LOG_REPEAT_COUNT or 0) > 1 then
    appendLogLine("previous message final repeat count " .. tostring(LOG_REPEAT_COUNT) .. ": " .. tostring(LOG_LAST_TEXT))
  end
  LOG_LAST_TEXT = line
  LOG_REPEAT_COUNT = 1
  appendLogLine(line)
end

ADMIN_VERBOSE_LOGS = ADMIN_VERBOSE_LOGS or false

function appendAdminVerboseLog(text)
  if ADMIN_VERBOSE_LOGS then appendLog(text) end
end

function jsonEscape(value)
  local s = tostring(value or "")
  s = s:gsub("\\", "\\\\")
  s = s:gsub('"', '\\"')
  s = s:gsub("\r", "\\r")
  s = s:gsub("\n", "\\n")
  s = s:gsub("\t", "\\t")
  return s
end

function js(value)
  return '"' .. jsonEscape(value) .. '"'
end

function nowUtc()
  return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

lastHeartbeatTouch = 0

touchHeartbeat = function(force)
  local now = os.time()
  if not force and now == lastHeartbeatTouch then return end
  lastHeartbeatTouch = now
writeAll(HEARTBEAT_FILE, '{"utc":' .. js(nowUtc()) .. ',"bridge":"ScumNeDjinBridge"}')
end

function appendChatEvent(message, name, steamId, channel, source)
  local record = '{"type":"chat","timestampUtc":' .. js(nowUtc()) ..
    ',"message":' .. js(message) ..
    ',"name":' .. js(name or "") ..
    ',"steamId":' .. js(steamId or "") ..
    ',"channel":' .. js(channel or "") ..
    ',"source":' .. js(source or "ue4ss") .. '}'
  enqueueStateWrite(CHAT_STATE_FILE, record, 2 * 1024 * 1024)
end

function appendEconomyEvent(message, name, steamId, amount, currency, okFlag)
  local record = '{"type":"economy","timestampUtc":' .. js(nowUtc()) ..
    ',"message":' .. js(message) ..
    ',"name":' .. js(name or "") ..
    ',"steamId":' .. js(steamId or "") ..
    ',"amount":' .. tostring(tonumber(amount) or 0) ..
    ',"currency":' .. js(currency or "Normal") ..
    ',"ok":' .. (okFlag and "true" or "false") .. '}'
  enqueueStateWrite(ECONOMY_STATE_FILE, record, 1024 * 1024)
end

function appendActionEvent(action, okFlag, targetInfo, message, detailsJson)
  local info = targetInfo or {}
  local details = tostring(detailsJson or "{}")
  if details == "" or (details:sub(1, 1) ~= "{" and details:sub(1, 1) ~= "[") then
    details = js(details)
  end
  local record = '{"type":"action","timestampUtc":' .. js(nowUtc()) ..
    ',"action":' .. js(action or "") ..
    ',"ok":' .. (okFlag and "true" or "false") ..
    ',"steamId":' .. js(info.steam or info.steamId or "") ..
    ',"name":' .. js(info.name or "") ..
    ',"runtimeKey":' .. js(info.runtimeKey or "") ..
    ',"userProfileId":' .. js(info.userProfileId or "") ..
    ',"message":' .. js(message or "") ..
    ',"details":' .. details .. '}'
  LAST_ACTION_EVENT_JSON = record
  if action == "deliver_item" or action == "deliver_items_batch" or action == "spawn_vehicle" or action == "vehicle_rental_created" or action == "change_money_execute" or action == "change_fame_execute" or action == "set_fame_execute" or action == "set_skill" then
    LAST_DELIVERY_EVENT_JSON = record
  end
  enqueueStateWrite(ACTION_STATE_FILE, record, 4 * 1024 * 1024)
end

local function extractString(text, key)
  local pat = '"' .. key .. '"%s*:%s*"(.-)"'
  local value = text:match(pat)
  if not value then return nil end
  value = value:gsub('\\"', '"'):gsub("\\\\", "\\"):gsub("\\n", "\n"):gsub("\\r", "\r"):gsub("\\t", "\t")
  return value
end

local function extractNumber(text, key)
  local raw = text:match('"' .. key .. '"%s*:%s*([%-%.%d]+)')
  return tonumber(raw)
end

local function extractStringAny(text, keys)
  for _, key in ipairs(keys or {}) do
    local value = extractString(text, key)
    if value ~= nil and value ~= "" then return value end
  end
  return nil
end

local function extractNumberAny(text, keys, fallback)
  for _, key in ipairs(keys or {}) do
    local value = extractNumber(text, key)
    if value ~= nil then return value end
  end
  return fallback
end

local function extractBool(text, key, fallback)
  local raw = tostring(text or ""):match('"' .. key .. '"%s*:%s*(true)') or tostring(text or ""):match('"' .. key .. '"%s*:%s*(false)')
  if raw == "true" then return true end
  if raw == "false" then return false end
  local textValue = extractString(text or "", key)
  if textValue ~= nil then
    local normalized = tostring(textValue):lower()
    if normalized == "true" or normalized == "1" or normalized == "yes" then return true end
    if normalized == "false" or normalized == "0" or normalized == "no" then return false end
  end
  return fallback
end

local function extractBoolAny(text, keys, fallback)
  for _, key in ipairs(keys or {}) do
    local value = extractBool(text, key, nil)
    if value ~= nil then return value end
  end
  return fallback
end

DEFAULT_LANGUAGE = "ru"
SUPPORTED_LANGUAGES = { ru = true, en = true }
LANGUAGE_STATE_FILE = STATE_DIR .. "\\player-languages.json"
PERMISSION_STATE_FILE = STATE_DIR .. "\\permissions.json"
DEFAULT_LANGUAGE_FILES = {
  ru = [[{
  "helpPrefix": "Команды",
  "helpLanguageHint": "Игровые команды вводятся на английском, ответы сервера показываются на русском.",
  "hello": "Привет, {name}. Система сервера работает.",
  "playerFallback": "игрок",
  "languageUsage": "Переключение языка в игре отключено.",
  "languageChanged": "Переключение языка в игре отключено.",
  "languageUnknown": "Переключение языка в игре отключено."
}]],
  en = [[{
  "helpPrefix": "Команды",
  "helpLanguageHint": "Игровые команды вводятся на английском, ответы сервера показываются на русском.",
  "hello": "Привет, {name}. Система сервера работает.",
  "playerFallback": "игрок",
  "languageUsage": "Переключение языка в игре отключено.",
  "languageChanged": "Переключение языка в игре отключено.",
  "languageUnknown": "Переключение языка в игре отключено."
}]]
}

local function normalizeLanguage(value)
  local text = tostring(value or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if text == "rus" or text == "russian" or text == "ru-ru" or text == "рус" or text == "русский" then return "ru" end
  if text == "eng" or text == "english" or text == "en-us" or text == "en-gb" then return "en" end
  if SUPPORTED_LANGUAGES[text] == true then return text end
  return ""
end

local function ensureLanguageDefaults()
  mkdir(LANG_DIR)
  for lang, text in pairs(DEFAULT_LANGUAGE_FILES) do
    local path = LANG_DIR .. "\\" .. lang .. ".json"
    if readAll(path) == nil then writeAll(path, text) end
  end
end

local function configuredDefaultLanguage()
  local config = configText(CONFIG_STEM)
  local lang = normalizeLanguage(extractStringAny(config, { "DefaultLanguage", "defaultLanguage", "Language", "language" }) or "")
  if lang == "" then lang = DEFAULT_LANGUAGE end
  return lang
end

local function playerLanguage(info)
  return DEFAULT_LANGUAGE
end

local function languageMessage(lang, key)
  local normalized = normalizeLanguage(lang)
  if normalized == "" then normalized = configuredDefaultLanguage() end
  local text = readAll(LANG_DIR .. "\\" .. normalized .. ".json") or ""
  local message = extractString(text, key)
  if message ~= nil and message ~= "" then return message end
  if normalized ~= DEFAULT_LANGUAGE then
    message = extractString(readAll(LANG_DIR .. "\\" .. DEFAULT_LANGUAGE .. ".json") or "", key)
    if message ~= nil and message ~= "" then return message end
  end
  return nil
end

local function applyVars(message, vars)
  local out = tostring(message or "")
  for key, value in pairs(vars or {}) do
    out = out:gsub("{" .. tostring(key) .. "}", tostring(value or ""))
  end
  return out
end

local function tr(info, key, fallback, vars)
  return applyVars(languageMessage(playerLanguage(info), key) or fallback or key, vars)
end

local function rememberPlayerLanguage(info, language)
  local lang = normalizeLanguage(language)
  if lang == "" then return false end
  local record = '{"utc":' .. js(nowUtc()) ..
    ',"steamId":' .. js((info or {}).steam or (info or {}).steamId or "") ..
    ',"name":' .. js((info or {}).name or "") ..
    ',"userProfileId":' .. js((info or {}).userProfileId or (info or {}).serverUserProfileId or "") ..
    ',"language":' .. js(lang) .. '}'
  return appendJsonArray(LANGUAGE_STATE_FILE, record, 512 * 1024)
end

local function safeGet(obj, key)
  if obj == nil then return nil end
  local ok, value = pcall(function() return obj[key] end)
  if ok then return value end
  return nil
end

local function safeCall(obj, method, ...)
  if obj == nil then return false, "object missing" end
  local fn = safeGet(obj, method)
  if fn == nil then return false, method .. " missing" end
  local ok, result = pcall(function(...) return obj[method](obj, ...) end, ...)
  if ok then return true, result end
  return false, tostring(result)
end

local function findFirst(names)
  for _, name in ipairs(names) do
    local ok, obj = pcall(function() return FindFirstOf(name) end)
    if ok and obj ~= nil and isValidObject(obj) then return obj, name end
  end
  return nil, nil
end

local function findAll(names)
  local out = {}
  local seen = {}
  for _, name in ipairs(names) do
    local ok, arr = pcall(function() return FindAllOf(name) end)
    if ok and arr ~= nil then
      for _, obj in pairs(arr) do
        local key = ""
        if obj ~= nil and isValidObject(obj) then
          pcall(function()
            local addr = obj:GetAddress()
            if addr ~= nil and addr ~= 0 then key = tostring(addr) end
          end)
          if key == "" then key = tostring(obj) end
        end
        if obj ~= nil and key ~= "" and not seen[key] then
          seen[key] = true
          table.insert(out, obj)
        end
      end
    end
  end
  return out
end

local function firstProp(obj, keys)
  for _, key in ipairs(keys) do
    local value = safeGet(obj, key)
    if value ~= nil then return value end
  end
  return nil
end

isValidObject = function(obj)
  if obj == nil then return false end
  local ok, valid = pcall(function() return obj:IsValid() end)
  if ok then return valid == true end
  return false
end

local function playerRpcChannel(pc)
  if pc == nil then return nil end
  local ok, rpc = pcall(function() return pc:GetPlayerRpcChannel() end)
  if ok and rpc ~= nil and isValidObject(rpc) then return rpc end
  rpc = firstProp(pc, {"PlayerRpcChannel", "_playerRpcChannel", "playerRpcChannel"})
  if rpc ~= nil and isValidObject(rpc) then return rpc end
  local channels = findAll({"PlayerRpcChannel", "ConZPlayerRpcChannel"})
  if #channels == 1 and isValidObject(channels[1]) then return channels[1] end
  return nil
end

local function kismetSystemLibrary()
  local kismet = nil
  pcall(function() kismet = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end)
  if kismet ~= nil and isValidObject(kismet) then return kismet end
  return findFirst({"KismetSystemLibrary"})
end

local function objectKey(obj)
  if obj == nil then return "" end
  local ok, addr = pcall(function() return obj:GetAddress() end)
  if ok and addr ~= nil and addr ~= 0 then return tostring(addr) end
  ok, addr = pcall(function() return tostring(obj) end)
  if ok and addr ~= nil then return tostring(addr) end
  return ""
end

local function invalidRuntimeText(text)
  local s = tostring(text or "")
  local lower = s:lower()
  return lower == "" or
    lower == "unknown" or
    lower:find("fstring:", 1, true) ~= nil or
    lower:find("uobject:", 1, true) ~= nil or
    lower:find("uscriptstruct:", 1, true) ~= nil or
    lower:find("userdata:", 1, true) ~= nil or
    lower:find("fname:", 1, true) ~= nil or
    lower:find("function:", 1, true) ~= nil
end

local function looksLikeSteamId(text)
  local s = tostring(text or "")
  return s:match("^%d+$") ~= nil and #s >= 15 and #s <= 20
end

local function cleanText(text)
  if text == nil then return "" end
  text = tostring(text)
  text = text:gsub("^%s+", ""):gsub("%s+$", "")
  if text == "" then return "" end
  if invalidRuntimeText(text) then return "" end
  if text:match("^0x[%x]+$") then return "" end
  return text
end

local function ueString(text)
  local value = tostring(text or "")
  if type(FString) == "function" then
    local ok, fstr = pcall(function() return FString(value) end)
    if ok and fstr ~= nil then return fstr end
  end
  return value
end

local function valueText(value)
  if value == nil then return "" end
  local kind = type(value)
  if kind == "string" or kind == "number" then return cleanText(value) end
  local ok, text = pcall(function() return tostring(value) end)
  if ok then return cleanText(text) end
  return ""
end

local function paramText(param)
  if param == nil then return "" end
  local ok, value = pcall(function()
    if type(param) == "userdata" and param.get ~= nil then return param:get() end
    return param
  end)
  if not ok then value = param end
  local text = valueText(value)
  if text ~= "" then return text end
  ok, text = pcall(function() return value:ToString() end)
  if ok then return cleanText(text) end
  return ""
end

local function propText(obj, keys)
  for _, key in ipairs(keys) do
    local text = valueText(safeGet(obj, key))
    if text ~= "" then return text end
  end
  return ""
end

local function propNumber(obj, keys)
  for _, key in ipairs(keys) do
    local value = safeGet(obj, key)
    if type(value) == "number" then return value end
  end
  return nil
end

local function dbIdText(value)
  if value == nil then return "" end
  local ok, unwrapped = pcall(function()
    if type(value) == "userdata" and value.get ~= nil then return value:get() end
    return value
  end)
  if ok then value = unwrapped end

  local direct = valueText(value)
  if direct:match("^%d+$") then return direct end

  local raw = safeGet(value, "Value") or safeGet(value, "value") or safeGet(value, "_value")
  if type(raw) == "number" then return tostring(math.floor(raw)) end
  raw = valueText(raw)
  if raw:match("^%d+$") then return raw end

  local printed = ""
  pcall(function() printed = tostring(value) end)
  local fromValue = printed:match("Value%s*=%s*(%d+)") or printed:match("Value%s*:%s*(%d+)")
  if fromValue ~= nil then return fromValue end
  return ""
end

local function gameModeRoot()
  return findFirst({"BP_ConZGameMode_C", "ConZGameMode", "GameMode"})
end

local function gameStateRoot()
  local gm = gameModeRoot()
  local gs = firstProp(gm, {"GameState", "GameStateClass"})
  if gs ~= nil and isValidObject(gs) then return gs end
  return findFirst({"BP_ConZGameState_C", "ConZGameState", "GameState"})
end

local function worldRoot()
  local gm = gameModeRoot()
  if gm ~= nil then return gm end
  return gameStateRoot()
end

local function vectorOf(actor)
  if actor == nil or not isValidObject(actor) then return 0, 0, 0 end
  local ok, loc = pcall(function() return actor:K2_GetActorLocation() end)
  if not ok or loc == nil then return 0, 0, 0 end
  return tonumber(loc.X or loc.x or 0) or 0, tonumber(loc.Y or loc.y or 0) or 0, tonumber(loc.Z or loc.z or 0) or 0
end

local function ownerController(ps)
  local owner = firstProp(ps, {"Owner", "PlayerController", "Controller", "OwningController"})
  if owner ~= nil and isValidObject(owner) then return owner end
  return nil
end

local function pawnFor(pc, ps)
  local pawn = firstProp(pc, {"Pawn", "PawnPrivate", "AcknowledgedPawn", "Character", "Prisoner"})
  if pawn ~= nil and isValidObject(pawn) then return pawn end
  pawn = firstProp(ps, {"Pawn", "PawnPrivate", "Character", "Prisoner"})
  if pawn ~= nil and isValidObject(pawn) then return pawn end
  return nil
end

local function objectDbId(obj, methods, props)
  if obj == nil then return "" end
  for _, method in ipairs(methods or {}) do
    local okCall, value = safeCall(obj, method)
    if okCall then
      local text = dbIdText(value)
      if text ~= "" and text ~= "0" then return text end
    end
  end
  for _, prop in ipairs(props or {}) do
    local text = dbIdText(safeGet(obj, prop))
    if text ~= "" and text ~= "0" then return text end
  end
  return ""
end

local function controllerInfo(pc, ps, source)
  if ps == nil then ps = firstProp(pc, {"PlayerState", "PlayerStatePrivate"}) end
  local pawn = pawnFor(pc, ps)
  local rpc = playerRpcChannel(pc)
  local name = propText(ps, {"PlayerNamePrivate", "PlayerName"})
  if name == "" then name = propText(pc, {"PlayerName", "Name"}) end
  local steam = propText(ps, {"SteamId", "SteamID", "UniqueId", "UniqueNetId", "PlayerId", "OwnerSteamId"})
  if steam == "" then steam = propText(pc, {"SteamId", "SteamID", "UniqueId", "UniqueNetId", "PlayerId"}) end
  if steam ~= "" and not looksLikeSteamId(steam) then steam = "" end
  local userProfileId = objectDbId(pc, {"GetUserProfileId"}, {"UserProfileId", "ProfileId", "_userProfileId"})
  if userProfileId == "" then userProfileId = objectDbId(ps, {}, {"UserProfileId", "ProfileId", "_userProfileId", "ServerUserProfileId", "_serverUserProfileId"}) end
  if userProfileId == "" then userProfileId = objectDbId(pawn, {}, {"_userId", "UserId", "UserProfileId", "OwnerUserProfileId"}) end
  local serverUserProfileId = objectDbId(pc, {"GetServerUserProfileId"}, {"ServerUserProfileId", "_serverUserProfileId"})
  local ping = propNumber(ps, {"Ping"})
  local score = propNumber(ps, {"Score"})
  local x, y, z = vectorOf(pawn)
  local pcKey = objectKey(pc)
  local psKey = objectKey(ps)
  local pawnKey = objectKey(pawn)
  local rpcKey = objectKey(rpc)
  return {
    name = name ~= "" and name or "Unknown",
    steam = steam,
    x = x,
    y = y,
    z = z,
    ping = ping,
    score = score,
    userProfileId = userProfileId,
    serverUserProfileId = serverUserProfileId,
    pc = pc,
    ps = ps,
    pawn = pawn,
    rpc = rpc,
    pcKey = pcKey,
    psKey = psKey,
    pawnKey = pawnKey,
    rpcKey = rpcKey,
    runtimeKey = psKey ~= "" and psKey or (pcKey ~= "" and pcKey or (pawnKey ~= "" and pawnKey or rpcKey)),
    source = source or "runtime"
  }
end

local function refreshRuntimePlayerInfo(info)
  if info == nil then return nil end
  local pc = info.pc
  local ps = info.ps
  if (pc == nil or not isValidObject(pc)) and ps ~= nil and isValidObject(ps) then
    pc = ownerController(ps)
  end
  if pc ~= nil and isValidObject(pc) then
    local refreshed = controllerInfo(pc, ps, info.source or "runtime-refresh")
    if tostring(refreshed.steam or "") == "" then refreshed.steam = tostring(info.steam or "") end
    if tostring(refreshed.name or "") == "" or tostring(refreshed.name or "") == "Unknown" then refreshed.name = tostring(info.name or "") end
    if tostring(refreshed.userProfileId or "") == "" then refreshed.userProfileId = tostring(info.userProfileId or "") end
    if tostring(refreshed.serverUserProfileId or "") == "" then refreshed.serverUserProfileId = tostring(info.serverUserProfileId or "") end
    if (refreshed.rpc == nil or not isValidObject(refreshed.rpc)) and info.rpc ~= nil and isValidObject(info.rpc) then
      refreshed.rpc = info.rpc
      refreshed.rpcKey = objectKey(info.rpc)
    end
    if tostring(refreshed.runtimeKey or "") == "" and tostring(refreshed.rpcKey or "") ~= "" then refreshed.runtimeKey = refreshed.rpcKey end
    return refreshed
  end
  if serverLogIndicatesOffline ~= nil and serverLogIndicatesOffline(info) then return nil end
  return nil
end

local function addPlayerInfo(infos, seen, info)
  if info == nil then return end
  local hasIdentity = tostring(info.steam or "") ~= "" or
    (tostring(info.name or "") ~= "" and tostring(info.name or "") ~= "Unknown") or
    tostring(info.userProfileId or "") ~= "" or
    tostring(info.serverUserProfileId or "") ~= ""
  local hasLivePawn = tostring(info.pawnKey or "") ~= "" and info.pawn ~= nil and isValidObject(info.pawn)
  local hasLiveLocation = math.abs(tonumber(info.x) or 0) + math.abs(tonumber(info.y) or 0) + math.abs(tonumber(info.z) or 0) > 1
  if not hasIdentity and not (hasLivePawn and hasLiveLocation) then return end

  local key = info.psKey
  if key == "" then key = info.pcKey end
  if key == "" then key = info.pawnKey end
  if key == "" then key = string.lower((info.steam or "") .. "|" .. (info.name or "") .. "|" .. tostring(info.x) .. "|" .. tostring(info.y) .. "|" .. tostring(info.z)) end
  if key == "" or key == "||0|0|0" then return end
  if seen[key] then return end
  seen[key] = true
  table.insert(infos, info)
end

local filterPlayerInfosByPresence

local function listPlayerInfosUnchecked(reason)
  local infos = {}
  local seen = {}

  local controllers = findAll({"BP_ConZPlayerController_C", "ConZPlayerController_C", "ConZPlayerController", "PlayerController", "SCUMPlayerController_C", "SCUMPlayerController"})
  for _, pc in ipairs(controllers) do
    if pc ~= nil and isValidObject(pc) then
      addPlayerInfo(infos, seen, controllerInfo(pc, nil, reason or "controller-scan-unchecked"))
    end
  end

  if #infos > 0 then return filterPlayerInfosByPresence(infos) end

  local gs = gameStateRoot()
  local playerArray = firstProp(gs, {"PlayerArray"})
  if playerArray ~= nil then
    local ok, num = pcall(function() return playerArray:GetArrayNum() end)
    if ok and tonumber(num) ~= nil then
      for i = 1, tonumber(num) do
        local ps = nil
        pcall(function() ps = playerArray[i] end)
        if ps ~= nil and isValidObject(ps) then
          addPlayerInfo(infos, seen, controllerInfo(ownerController(ps), ps, reason or "game-state-unchecked"))
        end
      end
    end
  end

  return filterPlayerInfosByPresence(infos)
end

local function listPlayerInfos()
  return listPlayerInfosUnchecked("runtime-scan")
end

local function cachedPlayerInfos(maxAgeSeconds)
  local infos = PLAYER_INFO_CACHE
  if infos == nil or #(infos or {}) == 0 then return nil end
  local maxAge = math.max(0.25, tonumber(maxAgeSeconds) or 3)
  local age = os.clock() - (tonumber(PLAYER_INFO_CACHE_AT) or 0)
  if age >= 0 and age <= maxAge then return filterPlayerInfosByPresence(infos) end
  return nil
end

local function playerInventoryComponent(info)
  if info == nil or info.pawn == nil or not isValidObject(info.pawn) then return nil end
  local inv = firstProp(info.pawn, {
    "PrisonerInventoryComponent",
    "InventoryComponent",
    "Inventory",
    "CharacterInventoryComponent",
    "InventoryUserComponent"
  })
  if inv ~= nil and isValidObject(inv) then return inv end
  return nil
end

local function playerHasUsableLocation(info)
  if info == nil then return false end
  local x = tonumber(info.x)
  local y = tonumber(info.y)
  local z = tonumber(info.z)
  if x == nil or y == nil or z == nil then return false end
  if x ~= x or y ~= y or z ~= z then return false end
  return math.abs(x) + math.abs(y) + math.abs(z) > 1
end

local function playerInfoHasLiveRuntime(info)
  return info ~= nil and (
    (info.pc ~= nil and isValidObject(info.pc)) or
    (info.rpc ~= nil and isValidObject(info.rpc)) or
    (info.pawn ~= nil and isValidObject(info.pawn))
  )
end

local function deliveryReadyInfo(info, options)
  options = options or {}
  local live = refreshRuntimePlayerInfo(info)
  if live == nil then
    return nil, false, "player is offline or not bound to runtime", "offline"
  end
  if tostring(live.steam or "") == "" and tostring(live.name or "") == "" then
    return live, false, "player identity is not ready", "identity"
  end
  if live.pc == nil or not isValidObject(live.pc) then
    return live, false, "player controller is not ready", "controller"
  end
  if live.pawn == nil or not isValidObject(live.pawn) then
    return live, false, "player pawn is not ready", "pawn"
  end
  if not playerHasUsableLocation(live) then
    local x, y, z = vectorOf(live.pawn)
    live.x, live.y, live.z = x, y, z
    if not playerHasUsableLocation(live) then
      return live, false, "player location is not ready", "location"
    end
  end
  if options.requireInventory ~= false and playerInventoryComponent(live) == nil then
    return live, false, "player inventory is not ready", "inventory"
  end
  return live, true, "ready", "ready"
end

local function deliveryReadyMessage(reason)
  if reason == "offline" then return "Игрок оффлайн или ещё не привязан к live runtime." end
  if reason == "identity" then return "Игрок найден, но SteamID/имя ещё не готовы." end
  if reason == "controller" then return "Игрок найден, но controller ещё не готов." end
  if reason == "pawn" then return "Игрок найден, но персонаж ещё не прогрузился." end
  if reason == "location" then return "Игрок найден, но координаты ещё не готовы." end
  if reason == "inventory" then return "Игрок найден, но инвентарь ещё не готов." end
  return "Игрок ещё не готов к безопасной выдаче."
end

local enrichPlayerInfoFromServerLog

local function runtimeKeyMatches(info, runtimeKey)
  local wanted = tostring(runtimeKey or "")
  if wanted == "" or info == nil then return false end
  return wanted == tostring(info.runtimeKey or "") or
    wanted == tostring(info.psKey or "") or
    wanted == tostring(info.pcKey or "") or
    wanted == tostring(info.pawnKey or "") or
    wanted == tostring(info.rpcKey or "")
end

local function findPlayer(steamId, name, runtimeKey)
  local targetSteam = tostring(steamId or ""):lower()
  local targetName = tostring(name or ""):lower()
  local targetRuntime = tostring(runtimeKey or "")
  local cacheTtl = math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))
  local infos = cachedPlayerInfos(cacheTtl) or {}
  if #infos == 0 and configBool("bridge-safety", { "AllowFindPlayerRuntimeScan", "allowFindPlayerRuntimeScan" }, false) then
    infos = listPlayerInfos()
  end
  if targetRuntime ~= "" then
    for _, info in ipairs(infos) do
      if runtimeKeyMatches(info, targetRuntime) then return info end
    end
  end
  for _, info in ipairs(infos) do
    if targetSteam ~= "" and tostring(info.steam):lower():find(targetSteam, 1, true) then return info end
    if targetName ~= "" and tostring(info.name):lower():find(targetName, 1, true) then return info end
  end
  if targetSteam ~= "" or targetName ~= "" then
    for _, info in ipairs(infos) do
      local enriched = enrichPlayerInfoFromServerLog(info) or info
      if targetSteam ~= "" and tostring(enriched.steam or ""):lower():find(targetSteam, 1, true) then return enriched end
      if targetName ~= "" and tostring(enriched.name or ""):lower():find(targetName, 1, true) then return enriched end
    end
  end
  if (targetRuntime ~= "" or targetSteam ~= "" or targetName ~= "") and configBool("bridge-safety", { "AllowFindPlayerUncheckedScan", "allowFindPlayerUncheckedScan" }, false) then
    local unchecked = listPlayerInfosUnchecked("target-command-scan")
    if unchecked ~= infos then
      if targetRuntime ~= "" then
        for _, info in ipairs(unchecked) do
          if runtimeKeyMatches(info, targetRuntime) then return info end
        end
      end
      for _, info in ipairs(unchecked) do
        if targetSteam ~= "" and tostring(info.steam):lower():find(targetSteam, 1, true) then return info end
        if targetName ~= "" and tostring(info.name):lower():find(targetName, 1, true) then return info end
      end
      for _, info in ipairs(unchecked) do
        local enriched = enrichPlayerInfoFromServerLog(info) or info
        if targetSteam ~= "" and tostring(enriched.steam or ""):lower():find(targetSteam, 1, true) then return enriched end
        if targetName ~= "" and tostring(enriched.name or ""):lower():find(targetName, 1, true) then return enriched end
      end
    end
  end
  if targetRuntime == "" and #infos == 1 then
    local only = enrichPlayerInfoFromServerLog(infos[1]) or infos[1]
    if targetSteam == "" and targetName == "" then return only end
    if targetSteam ~= "" and tostring(only.steam or ""):lower():find(targetSteam, 1, true) then return only end
    if targetName ~= "" and tostring(only.name or ""):lower():find(targetName, 1, true) then return only end
  end
  if targetRuntime == "" and targetSteam == "" and targetName == "" and #infos == 1 then return infos[1] end
  return nil
end

local function findPlayerByDbId(dbId)
  local wanted = tostring(dbId or "")
  if wanted == "" or wanted == "0" then return nil end
  local cacheTtl = math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))
  for _, info in ipairs(cachedPlayerInfos(cacheTtl) or {}) do
    if tostring(info.userProfileId or "") == wanted or tostring(info.serverUserProfileId or "") == wanted then return info end
  end
  return nil
end

local function splitLines(text)
  local lines = {}
  for line in tostring(text or ""):gmatch("[^\r\n]+") do
    table.insert(lines, line)
  end
  return lines
end

SERVER_STATS_STALE_SECONDS = 45

local function localUtcOffsetSeconds()
  local now = os.time()
  local utc = os.date("!*t", now)
  if utc == nil then return 0 end
  utc.isdst = false
  local ok, utcAsLocal = pcall(function() return os.time(utc) end)
  if ok and utcAsLocal ~= nil then return os.difftime(now, utcAsLocal) end
  return 0
end

local function serverLogTimestamp(line)
  local year, month, day, hour, minute, second = tostring(line or ""):match("^%[(%d%d%d%d)%.(%d%d)%.(%d%d)%-(%d%d)%.(%d%d)%.(%d%d)")
  if year == nil then return nil end
  local ok, value = pcall(function()
    return os.time({
      year = tonumber(year),
      month = tonumber(month),
      day = tonumber(day),
      hour = tonumber(hour),
      min = tonumber(minute),
      sec = tonumber(second)
    })
  end)
  if ok and value ~= nil then
    local utcValue = value + localUtcOffsetSeconds()
    local now = os.time()
    if math.abs(now - utcValue) < math.abs(now - value) then return utcValue end
    return value
  end
  return nil
end

serverLogIdentityCacheAt = 0
serverLogIdentityCache = nil

local function rememberServerLogIdentity(cache, steam, profileId, name)
  steam = cleanText(steam)
  name = cleanText(name)
  profileId = cleanText(profileId)
  if not looksLikeSteamId(steam) or name == "" then return end
  local identity = { steam = steam, name = name, profileId = profileId }
  if cache.latest == nil then cache.latest = identity end
  if profileId ~= "" and cache.byProfile[profileId] == nil then cache.byProfile[profileId] = identity end
  if cache.bySteam[steam] == nil then cache.bySteam[steam] = identity end
  local lowerName = name:lower()
  if lowerName ~= "" and cache.byName[lowerName] == nil then cache.byName[lowerName] = identity end
  cache.count = cache.count + 1
end

local function serverLogIdentities()
  local now = os.clock()
  if serverLogIdentityCache ~= nil and (now - serverLogIdentityCacheAt) < 5 then return serverLogIdentityCache end
  serverLogIdentityCacheAt = now
  serverLogIdentityCache = { latest = nil, byProfile = {}, bySteam = {}, byName = {}, count = 0 }
  local text = readTail(SERVER_LOG_FILE, 768 * 1024)
  if text == nil then return serverLogIdentityCache end
  local lines = splitLines(text)
  for i = #lines, math.max(1, #lines - 2500), -1 do
    local line = lines[i]
    local steam, profileId, name = line:match("APrisoner::HandlePossessedBy:%s*(%d+),%s*(%d+),%s*([^%s]+)")
    if steam == nil then
      steam, name, profileId = line:match("LogSCUM:%s*'[^']*%s+(%d+):([^%(]+)%((%d+)%)'%s+logged in")
    end
    if steam == nil then
      steam, name = line:match("Login request:.*%?user=(%d+).*%?Name=([^%?%s]+)")
    end
    if steam == nil then
      steam, name = line:match("Join request:.*%?user=(%d+).*%?Name=([^%?%s]+)")
    end
    rememberServerLogIdentity(serverLogIdentityCache, steam, profileId, name)
  end
  return serverLogIdentityCache
end

local serverLogPresenceCacheAt = 0
local serverLogPresenceCache = nil

local function rememberServerLogPresence(cache, online, steam, profileId, name)
  steam = cleanText(steam)
  profileId = cleanText(profileId)
  name = cleanText(name)
  local lowerName = name:lower()
  local identities = serverLogIdentities()
  local identity = nil
  if profileId ~= "" then identity = cache.knownByProfile[profileId] or identities.byProfile[profileId] end
  if identity == nil and looksLikeSteamId(steam) then identity = cache.knownBySteam[steam] or identities.bySteam[steam] end
  if identity == nil and lowerName ~= "" then identity = cache.knownByName[lowerName] or identities.byName[lowerName] end
  if not looksLikeSteamId(steam) and identity ~= nil and looksLikeSteamId(identity.steam) then steam = cleanText(identity.steam) end
  if profileId == "" and identity ~= nil then profileId = cleanText(identity.profileId) end
  if name == "" and identity ~= nil then
    name = cleanText(identity.name)
    lowerName = name:lower()
  end
  if not looksLikeSteamId(steam) and profileId == "" and lowerName == "" then return end
  local merged = {
    steam = looksLikeSteamId(steam) and steam or "",
    profileId = profileId,
    name = name
  }
  if merged.profileId ~= "" then cache.knownByProfile[merged.profileId] = merged end
  if merged.steam ~= "" then cache.knownBySteam[merged.steam] = merged end
  if lowerName ~= "" then cache.knownByName[lowerName] = merged end
  local active = online == true
  local canonical = merged.steam ~= "" and ("steam:" .. merged.steam) or
    (merged.profileId ~= "" and ("profile:" .. merged.profileId) or ("name:" .. lowerName))
  cache.active[canonical] = active and true or nil
  if merged.steam ~= "" then cache.statusBySteam[merged.steam] = active end
  if merged.profileId ~= "" then cache.statusByProfile[merged.profileId] = active end
  if lowerName ~= "" then cache.statusByName[lowerName] = active end
  if active then
    cache.onlineEvents = cache.onlineEvents + 1
  else
    cache.offlineEvents = cache.offlineEvents + 1
  end
end

local function serverLogPresenceSnapshot()
  local now = os.clock()
  if serverLogPresenceCache ~= nil and (now - serverLogPresenceCacheAt) < 3 then return serverLogPresenceCache end
  serverLogPresenceCacheAt = now
  serverLogPresenceCache = {
    knownByProfile = {},
    knownBySteam = {},
    knownByName = {},
    statusByProfile = {},
    statusBySteam = {},
    statusByName = {},
    active = {},
    activeCount = 0,
    onlineEvents = 0,
    offlineEvents = 0
  }
  local text = readTail(SERVER_LOG_FILE, 1024 * 1024)
  if text == nil then return serverLogPresenceCache end
  local lines = splitLines(text)
  for i = math.max(1, #lines - 3000), #lines do
    local line = tostring(lines[i] or "")
    local steam, profileId, name = line:match("APrisoner::HandlePossessedBy:%s*(%d+),%s*(%d+),%s*([^%s]+)")
    if steam ~= nil then
      rememberServerLogPresence(serverLogPresenceCache, true, steam, profileId, name)
    else
      steam, name, profileId = line:match("LogSCUM:%s*'[^']*%s+(%d+):([^%(]+)%((%d+)%)'%s+logged in")
      if steam ~= nil then
        rememberServerLogPresence(serverLogPresenceCache, true, steam, profileId, name)
      else
        steam, name = line:match("Join succeeded:.*%?user=(%d+).*%?Name=([^%?%s]+)")
        if steam ~= nil then
          rememberServerLogPresence(serverLogPresenceCache, true, steam, "", name)
        else
          steam, name, profileId = line:match("LogSCUM:%s*'[^']*%s+(%d+):([^%(]+)%((%d+)%)'%s+logged out")
          if steam ~= nil then
            rememberServerLogPresence(serverLogPresenceCache, false, steam, profileId, name)
          else
            name, profileId = line:match("Prisoner logging out:%s*([^%(]+)%s*%((%d+)%)")
            if name ~= nil then
              rememberServerLogPresence(serverLogPresenceCache, false, "", profileId, name)
            else
              name = line:match("LogBattlEye:%s*Display:%s*Player%s*#%d+%s+(.+)%s+disconnected")
              if name ~= nil then rememberServerLogPresence(serverLogPresenceCache, false, "", "", name) end
            end
          end
        end
      end
    end
  end
  for _ in pairs(serverLogPresenceCache.active) do
    serverLogPresenceCache.activeCount = serverLogPresenceCache.activeCount + 1
  end
  return serverLogPresenceCache
end

local function serverLogIndicatesOffline(info, presence)
  if info == nil then return false end
  presence = presence or serverLogPresenceSnapshot()
  if presence == nil then return false end
  local steam = cleanText(info.steam)
  if looksLikeSteamId(steam) then
    local status = presence.statusBySteam[steam]
    if status ~= nil then return status == false end
  end
  local profileId = cleanText(info.userProfileId or info.serverUserProfileId or "")
  if profileId ~= "" then
    local status = presence.statusByProfile[profileId]
    if status ~= nil then return status == false end
  end
  local lowerName = cleanText(info.name):lower()
  if lowerName ~= "" and lowerName ~= "unknown" then
    local status = presence.statusByName[lowerName]
    if status ~= nil then return status == false end
  end
  return false
end

filterPlayerInfosByPresence = function(infos)
  if infos == nil or #infos == 0 then return infos or {} end
  local presence = serverLogPresenceSnapshot()
  if presence == nil then return infos end
  local filtered = {}
  for _, info in ipairs(infos) do
    if not serverLogIndicatesOffline(info, presence) then table.insert(filtered, info) end
  end
  return filtered
end

serverLogOnlineCacheAt = 0
serverLogOnlineCache = nil

function serverLogOnlineSnapshot()
  local now = os.clock()
  if serverLogOnlineCache ~= nil and (now - serverLogOnlineCacheAt) < 3 then return serverLogOnlineCache end
  serverLogOnlineCacheAt = now
  serverLogOnlineCache = {
    playerCount = -1,
    lastLine = "",
    statsIndex = 0,
    statsEpoch = 0,
    statsAgeSeconds = -1,
    statsFresh = false,
    laterJoin = false,
    activePresenceCount = 0,
    offlinePresenceCount = 0
  }
  local text = readTail(SERVER_LOG_FILE, 512 * 1024)
  if text == nil then return serverLogOnlineCache end
  local lines = splitLines(text)
  for i = #lines, math.max(1, #lines - 1200), -1 do
    local line = lines[i]
    local count = line:match("Global Stats:.-|%s*C:%s*%d+%s*%([^%)]*%),%s*P:%s*(%d+)")
    if count ~= nil then
      serverLogOnlineCache.playerCount = tonumber(count) or -1
      serverLogOnlineCache.lastLine = line
      serverLogOnlineCache.statsIndex = i
      serverLogOnlineCache.statsEpoch = serverLogTimestamp(line) or 0
      break
    end
  end
  if tonumber(serverLogOnlineCache.statsEpoch or 0) > 0 then
    local age = os.time() - tonumber(serverLogOnlineCache.statsEpoch or 0)
    serverLogOnlineCache.statsAgeSeconds = age
    serverLogOnlineCache.statsFresh = age >= -300 and age <= SERVER_STATS_STALE_SECONDS
  end
  if tonumber(serverLogOnlineCache.playerCount or -1) == 0 and serverLogOnlineCache.statsIndex > 0 then
    for i = serverLogOnlineCache.statsIndex + 1, #lines do
      local line = tostring(lines[i] or "")
      local lower = line:lower()
      if lower:find("login request:", 1, true) ~= nil or
        lower:find("join request:", 1, true) ~= nil or
        lower:find("join succeeded:", 1, true) ~= nil or
        lower:find("logged in", 1, true) ~= nil or
        lower:find("aprisoner::handlepossessedby", 1, true) ~= nil then
        serverLogOnlineCache.laterJoin = true
        break
      end
    end
  end
  local presence = serverLogPresenceSnapshot()
  serverLogOnlineCache.activePresenceCount = tonumber(presence and presence.activeCount or 0) or 0
  serverLogOnlineCache.offlinePresenceCount = tonumber(presence and presence.offlineEvents or 0) or 0
  if tonumber(serverLogOnlineCache.playerCount or -1) == 0 then
    if serverLogOnlineCache.statsFresh == true then
      -- Fresh Global Stats P:0 is authoritative; stale login lines from earlier
      -- sessions must not keep a ghost player in the web panel.
      serverLogOnlineCache.laterJoin = serverLogOnlineCache.laterJoin == true
    elseif serverLogOnlineCache.activePresenceCount > 0 then
      serverLogOnlineCache.laterJoin = true
    elseif serverLogOnlineCache.offlinePresenceCount > 0 then
      serverLogOnlineCache.laterJoin = false
    end
  end
  return serverLogOnlineCache
end

function serverLogReportsNoPlayers()
  local snapshot = serverLogOnlineSnapshot()
  if snapshot == nil then return false end
  return snapshot.statsFresh == true and tonumber(snapshot.playerCount or -1) == 0 and snapshot.laterJoin ~= true
end

RUNTIME_SCAN_JOIN_SETTLE_SECONDS = 18

function latestServerLogJoinEpoch()
  local text = readTail(SERVER_LOG_FILE, 512 * 1024)
  if text == nil then return 0 end
  local lines = splitLines(text)
  for i = #lines, math.max(1, #lines - 1200), -1 do
    local line = tostring(lines[i] or "")
    local lower = line:lower()
    if lower:find("aprisoner::handlepossessedby", 1, true) ~= nil or
      lower:find("logged in at:", 1, true) ~= nil or
      lower:find("join succeeded:", 1, true) ~= nil then
      return serverLogTimestamp(line) or 0
    end
  end
  return 0
end

runtimeScanAllowed = function()
  local snapshot = serverLogOnlineSnapshot()
  if snapshot ~= nil and tonumber(snapshot.playerCount or -1) == 0 and snapshot.laterJoin ~= true then
    if not configBool("bridge-safety", { "IgnoreServerLogNoPlayersForRuntimeScan", "ignoreServerLogNoPlayersForRuntimeScan" }, false) then
      return false, "server-log reports zero players", -1
    end
  end
  local joinEpoch = latestServerLogJoinEpoch()
  if joinEpoch > 0 then
    local age = os.time() - joinEpoch
    if age >= 0 and age < RUNTIME_SCAN_JOIN_SETTLE_SECONDS then
      return false, "recent player join; waiting for UE objects to settle", age
    end
  end
  return true, "runtime scan allowed", -1
end

function logPlayerKey(steam, profileId, name)
  steam = cleanText(steam)
  profileId = cleanText(profileId)
  name = cleanText(name)
  if looksLikeSteamId(steam) then return "steam:" .. steam end
  if profileId ~= "" then return "profile:" .. profileId end
  if name ~= "" then return "name:" .. name:lower() end
  return ""
end

function rememberLogPlayer(cache, online, steam, profileId, name, x, y, z)
  steam = cleanText(steam)
  profileId = cleanText(profileId)
  name = cleanText(name)
  local key = logPlayerKey(steam, profileId, name)
  if key == "" and name ~= "" then key = cache.byName[name:lower()] or "" end
  if key == "" and profileId ~= "" then key = cache.byProfile[profileId] or "" end
  if key == "" and looksLikeSteamId(steam) then key = cache.bySteam[steam] or "" end
  if key == "" then return end

  local row = cache.rows[key] or {
    steam = "",
    profileId = "",
    name = "",
    x = 0,
    y = 0,
    z = 0,
    online = false
  }
  if looksLikeSteamId(steam) then row.steam = steam end
  if profileId ~= "" then row.profileId = profileId end
  if name ~= "" then row.name = name end
  if tonumber(x) ~= nil then row.x = tonumber(x) end
  if tonumber(y) ~= nil then row.y = tonumber(y) end
  if tonumber(z) ~= nil then row.z = tonumber(z) end
  row.online = online == true
  cache.rows[key] = row
  if row.steam ~= "" then cache.bySteam[row.steam] = key end
  if row.profileId ~= "" then cache.byProfile[row.profileId] = key end
  if row.name ~= "" then cache.byName[row.name:lower()] = key end
end

function serverLogPlayersJson()
  local snapshot = serverLogOnlineSnapshot()
  if snapshot ~= nil and snapshot.statsFresh == true and tonumber(snapshot.playerCount or -1) == 0 and snapshot.laterJoin ~= true then
    return '{"players":[],"count":0,"source":"server-log","runtimeReady":false,"serverStats":{"playerCount":0,"fresh":true,"ageSeconds":' ..
      tostring(tonumber(snapshot.statsAgeSeconds or 0) or 0) .. ',"lastLine":' .. js(snapshot.lastLine or "") .. '}}'
  end

  local cache = { rows = {}, bySteam = {}, byProfile = {}, byName = {} }
  local text = readTail(SERVER_LOG_FILE, 1024 * 1024)
  if text ~= nil then
    local lines = splitLines(text)
    for i = math.max(1, #lines - 3000), #lines do
      local line = tostring(lines[i] or "")
      local steam, profileId, name = line:match("APrisoner::HandlePossessedBy:%s*(%d+),%s*(%d+),%s*([^%s]+)")
      if steam ~= nil then
        rememberLogPlayer(cache, true, steam, profileId, name)
      else
        local x, y, z
        steam, name, profileId, x, y, z = line:match("LogSCUM:%s*'[^']*%s+(%d+):([^%(]+)%((%d+)%)'%s+logged in at:%s*X=([%-%.%d]+)%s+Y=([%-%.%d]+)%s+Z=([%-%.%d]+)")
        if steam ~= nil then
          rememberLogPlayer(cache, true, steam, profileId, name, x, y, z)
        else
          steam, name, profileId = line:match("LogSCUM:%s*'[^']*%s+(%d+):([^%(]+)%((%d+)%)'%s+logged out")
          if steam ~= nil then
            rememberLogPlayer(cache, false, steam, profileId, name)
          else
            name, profileId = line:match("Prisoner logging out:%s*([^%(]+)%s*%((%d+)%)")
            if name ~= nil then
              rememberLogPlayer(cache, false, "", profileId, name)
            else
              name = line:match("LogBattlEye:%s*Display:%s*Player%s*#%d+%s+(.+)%s+disconnected")
              if name ~= nil then rememberLogPlayer(cache, false, "", "", name) end
            end
          end
        end
      end
    end
  end

  local runtimeReady, runtimeReason, runtimeAge = runtimeScanAllowed()
  local parts = {}
  for _, row in pairs(cache.rows) do
    if row.online == true then
      table.insert(parts, '{"name":' .. js(row.name ~= "" and row.name or "Unknown") ..
        ',"steamId":' .. js(row.steam) ..
        ',"online":true' ..
        ',"status":"online"' ..
        ',"source":"server-log"' ..
        ',"x":' .. tostring(tonumber(row.x) or 0) ..
        ',"y":' .. tostring(tonumber(row.y) or 0) ..
        ',"z":' .. tostring(tonumber(row.z) or 0) ..
        ',"userProfileId":' .. js(row.profileId) ..
        ',"serverUserProfileId":' .. js(row.profileId) ..
        ',"runtimeKey":""' ..
        ',"runtimeReady":' .. (runtimeReady and "true" or "false") ..
        '}')
    end
  end
  return '{"players":[' .. table.concat(parts, ",") .. '],"count":' .. tostring(#parts) ..
    ',"source":"server-log","runtimeReady":' .. (runtimeReady and "true" or "false") ..
    ',"runtimeReason":' .. js(runtimeReason or "") ..
    ',"runtimeAgeSeconds":' .. tostring(tonumber(runtimeAge or -1) or -1) ..
    ',"serverStats":{"playerCount":' .. tostring(tonumber(snapshot and snapshot.playerCount or -1) or -1) ..
    ',"fresh":' .. ((snapshot and snapshot.statsFresh) and "true" or "false") ..
    ',"ageSeconds":' .. tostring(tonumber(snapshot and snapshot.statsAgeSeconds or -1) or -1) ..
    ',"lastLine":' .. js((snapshot and snapshot.lastLine) or "") ..
    '}}'
end

local function latestServerLogIdentity()
  local cache = serverLogIdentities()
  return cache and cache.latest or nil
end

enrichPlayerInfoFromServerLog = function(info)
  if info == nil then return nil end
  local hasSteam = looksLikeSteamId(info.steam)
  local hasName = not invalidRuntimeText(info.name)
  if hasSteam and hasName then return info end
  local cache = serverLogIdentities()
  if cache == nil then return info end
  local infoProfile = tostring(info.userProfileId or info.serverUserProfileId or "")
  local identity = nil
  if infoProfile ~= "" then identity = cache.byProfile[infoProfile] end
  if identity == nil and hasSteam then identity = cache.bySteam[tostring(info.steam or "")] end
  if identity == nil and hasName then identity = cache.byName[tostring(info.name or ""):lower()] end
  if identity == nil and infoProfile == "" and tonumber(cache.count or 0) == 1 then identity = cache.latest end
  if identity ~= nil then
    if not hasSteam then info.steam = identity.steam end
    if not hasName then info.name = identity.name end
  end
  return info
end

local function serverLogIdentityActive(identity, presence)
  if identity == nil then return false end
  presence = presence or serverLogPresenceSnapshot()
  if presence == nil then return false end
  local steam = cleanText(identity.steam)
  if looksLikeSteamId(steam) and presence.statusBySteam[steam] == true then return true end
  local profileId = cleanText(identity.profileId)
  if profileId ~= "" and presence.statusByProfile[profileId] == true then return true end
  local lowerName = cleanText(identity.name):lower()
  if lowerName ~= "" and presence.statusByName[lowerName] == true then return true end
  return false
end

local function serverLogIdentityForTarget(steamId, name)
  local cache = serverLogIdentities()
  if cache == nil then return nil end
  local targetSteam = cleanText(steamId)
  local targetName = cleanText(name):lower()
  local identity = nil
  if looksLikeSteamId(targetSteam) then identity = cache.bySteam[targetSteam] end
  if identity == nil and targetName ~= "" then identity = cache.byName[targetName] end
  if identity == nil then return nil end
  if not serverLogIdentityActive(identity) then return nil end
  return identity
end

local function applyServerLogIdentity(info, identity)
  if info == nil or identity == nil then return info end
  local steam = cleanText(identity.steam)
  local name = cleanText(identity.name)
  local profileId = cleanText(identity.profileId)
  if looksLikeSteamId(steam) then info.steam = steam end
  if name ~= "" then info.name = name end
  if profileId ~= "" then
    info.userProfileId = profileId
    info.serverUserProfileId = profileId
  end
  return info
end

local function resolvePlayerInfoFromServerLogTarget(steamId, name)
  local identity = serverLogIdentityForTarget(steamId, name)
  if identity == nil then return nil end
  local infos = cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 300))) or {}
  if infos == nil or #infos == 0 then return nil end

  local steam = cleanText(identity.steam)
  local profileId = cleanText(identity.profileId)
  local lowerName = cleanText(identity.name):lower()
  for _, info in ipairs(infos) do
    local enriched = enrichPlayerInfoFromServerLog(info) or info
    if (looksLikeSteamId(steam) and cleanText(enriched.steam) == steam) or
      (profileId ~= "" and (cleanText(enriched.userProfileId) == profileId or cleanText(enriched.serverUserProfileId) == profileId)) or
      (lowerName ~= "" and cleanText(enriched.name):lower() == lowerName) then
      return applyServerLogIdentity(enriched, identity)
    end
  end

  local presence = serverLogPresenceSnapshot()
  if #infos == 1 and presence ~= nil and tonumber(presence.activeCount or 0) == 1 then
    return applyServerLogIdentity(enrichPlayerInfoFromServerLog(infos[1]) or infos[1], identity)
  end

  appendLog("player resolve refused ambiguous server-log identity target=" ..
    tostring(steam ~= "" and steam or lowerName) .. " liveControllers=" .. tostring(#infos))
  return nil
end

local function resolvePlayerInfo(steamId, name, preferredInfo, runtimeKey)
  local targetSteam = tostring(steamId or ""):lower()
  local targetName = tostring(name or ""):lower()
  local targetRuntime = tostring(runtimeKey or "")
  if preferredInfo ~= nil then
    local priorPreferred = preferredInfo
    local refreshedPreferred = refreshRuntimePlayerInfo(preferredInfo)
    if refreshedPreferred ~= nil then
      refreshedPreferred = enrichPlayerInfoFromServerLog(refreshedPreferred)
      if targetRuntime ~= "" and runtimeKeyMatches(refreshedPreferred, targetRuntime) then return refreshedPreferred end
      if targetSteam == "" and targetName == "" and targetRuntime == "" then return refreshedPreferred end
      if targetSteam ~= "" and tostring(refreshedPreferred.steam or ""):lower():find(targetSteam, 1, true) then return refreshedPreferred end
      if targetName ~= "" and tostring(refreshedPreferred.name or ""):lower():find(targetName, 1, true) then return refreshedPreferred end
    end
    priorPreferred = enrichPlayerInfoFromServerLog(priorPreferred) or priorPreferred
    if not playerInfoHasLiveRuntime(priorPreferred) then
      local liveCandidate = findPlayer(steamId, name, runtimeKey)
      if liveCandidate ~= nil and playerInfoHasLiveRuntime(liveCandidate) then
        liveCandidate = enrichPlayerInfoFromServerLog(liveCandidate) or liveCandidate
        local matches = false
        if targetRuntime ~= "" and runtimeKeyMatches(liveCandidate, targetRuntime) then matches = true end
        if targetSteam ~= "" and tostring(liveCandidate.steam or ""):lower():find(targetSteam, 1, true) then matches = true end
        if targetName ~= "" and tostring(liveCandidate.name or ""):lower():find(targetName, 1, true) then matches = true end
        if targetSteam == "" and targetName == "" and targetRuntime == "" then matches = true end
        if matches then
          if type(mergeRuntimeIntoIdentity) == "function" then
            return mergeRuntimeIntoIdentity(priorPreferred, liveCandidate)
          end
          return liveCandidate
        end
      end
    end
    if priorPreferred ~= nil then
      if tostring(priorPreferred.steam or "") == "" then priorPreferred.steam = tostring(steamId or "") end
      if tostring(priorPreferred.name or "") == "" or tostring(priorPreferred.name or "") == "Unknown" then priorPreferred.name = tostring(name or "") end
      if targetRuntime ~= "" and runtimeKeyMatches(priorPreferred, targetRuntime) then return priorPreferred end
      if targetSteam == "" and targetName == "" and targetRuntime == "" then return priorPreferred end
      if targetSteam ~= "" and tostring(priorPreferred.steam or ""):lower():find(targetSteam, 1, true) then return priorPreferred end
      if targetName ~= "" and tostring(priorPreferred.name or ""):lower():find(targetName, 1, true) then return priorPreferred end
    end
  end
  local found = enrichPlayerInfoFromServerLog(findPlayer(steamId, name, runtimeKey))
  if found ~= nil then return found end

  if configBool("bridge-safety", { "AllowResolveSingletonRuntimeScan", "allowResolveSingletonRuntimeScan" }, false) then
    local fallbackInfos = listPlayerInfosUnchecked("resolve-singleton-fallback")
    if fallbackInfos ~= nil and #fallbackInfos == 1 and (targetSteam ~= "" or targetName ~= "" or targetRuntime ~= "") then
      local only = enrichPlayerInfoFromServerLog(fallbackInfos[1]) or fallbackInfos[1]
      local rawSteam = cleanText(steamId)
      local rawName = cleanText(name)
      if looksLikeSteamId(rawSteam) and cleanText(only.steam) == "" then only.steam = rawSteam end
      if rawName ~= "" and (cleanText(only.name) == "" or cleanText(only.name):lower() == "unknown") then only.name = rawName end
      return only
    end
  end

  return resolvePlayerInfoFromServerLogTarget(steamId, name)
end

local function livePlayerForTarget(steamId, name, runtimeKey, preferredInfo)
  local targetSteam = cleanText(steamId or (preferredInfo or {}).steam):lower()
  local targetName = cleanText(name or (preferredInfo or {}).name):lower()
  local targetRuntime = cleanText(runtimeKey or (preferredInfo or {}).runtimeKey)
  local function hasLiveChannel(candidate)
    return candidate ~= nil and (
      (candidate.pc ~= nil and isValidObject(candidate.pc)) or
      (candidate.rpc ~= nil and isValidObject(candidate.rpc))
    )
  end
  local function normalizeCandidate(candidate)
    if candidate == nil then return nil end
    local refreshed = refreshRuntimePlayerInfo(candidate) or candidate
    refreshed = enrichPlayerInfoFromServerLog(refreshed) or refreshed
    if not hasLiveChannel(refreshed) then return nil end
    if preferredInfo ~= nil and type(mergeRuntimeIntoIdentity) == "function" then
      return mergeRuntimeIntoIdentity(preferredInfo, refreshed)
    end
    return refreshed
  end
  local function targetMatches(candidate)
    if candidate == nil then return false end
    if targetRuntime ~= "" and runtimeKeyMatches(candidate, targetRuntime) then return true end
    local candidateSteam = cleanText(candidate.steam or candidate.steamId):lower()
    if targetSteam ~= "" and candidateSteam ~= "" and candidateSteam:find(targetSteam, 1, true) then return true end
    local candidateName = cleanText(candidate.name):lower()
    if targetName ~= "" and candidateName ~= "" and candidateName:find(targetName, 1, true) then return true end
    return targetSteam == "" and targetName == "" and targetRuntime == ""
  end

  local preferred = normalizeCandidate(preferredInfo)
  if preferred ~= nil and targetMatches(preferred) then return preferred end

  local freshInfos = listPlayerInfosUnchecked("live-target-command") or {}
  for _, candidate in ipairs(freshInfos) do
    local live = normalizeCandidate(candidate)
    if live ~= nil and targetRuntime ~= "" and runtimeKeyMatches(live, targetRuntime) then return live end
  end
  for _, candidate in ipairs(freshInfos) do
    local live = normalizeCandidate(candidate)
    if live ~= nil and targetMatches(live) then return live end
  end
  if targetSteam == "" and targetName == "" and targetRuntime == "" and #freshInfos == 1 then
    return normalizeCandidate(freshInfos[1])
  end
  return nil
end

local function findPlayerByContext(context)
  local cached = cachedPlayerByObject(context)
  if cached ~= nil then return enrichPlayerInfoFromServerLog(cached) or cached end
  local key = objectKey(context)
  local infos = cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 300))) or {}
  if key ~= "" then
    for _, info in ipairs(infos) do
      if info.pcKey == key or info.psKey == key or info.pawnKey == key then return enrichPlayerInfoFromServerLog(info) end
      local rpc = playerRpcChannel(info.pc)
      if objectKey(rpc) == key then return enrichPlayerInfoFromServerLog(info) end
    end
  end
  if #infos == 1 then return enrichPlayerInfoFromServerLog(infos[1]) end
  return nil
end

local function deferGame(delayMs, fn)
  if ExecuteInGameThreadWithDelay ~= nil then
    local okDelay, err = pcall(function()
      ExecuteInGameThreadWithDelay(delayMs or 50, function()
        local okRun, runErr = pcall(fn)
        if not okRun then appendLog("deferred game-thread task failed: " .. tostring(runErr)) end
      end)
    end)
    if okDelay then return true end
    appendLog("ExecuteInGameThreadWithDelay failed: " .. tostring(err))
  end
  if ExecuteWithDelay ~= nil then
    local okDelay, err = pcall(function()
      ExecuteWithDelay(delayMs or 50, function()
        if ExecuteInGameThread ~= nil then
          local okThread, threadErr = pcall(function() ExecuteInGameThread(fn) end)
          if okThread then return end
          appendLog("ExecuteInGameThread delayed task failed: " .. tostring(threadErr))
        end
        local okRun, runErr = pcall(fn)
        if not okRun then appendLog("deferred delayed task failed inline: " .. tostring(runErr)) end
      end)
    end)
    if okDelay then return true end
    appendLog("ExecuteWithDelay failed: " .. tostring(err))
  end
  if ExecuteInGameThread ~= nil then
    local okThread, err = pcall(function() ExecuteInGameThread(fn) end)
    if okThread then return true end
    appendLog("ExecuteInGameThread defer failed: " .. tostring(err))
  end
  local okNow, err = pcall(fn)
  if not okNow then appendLog("deferred task failed inline: " .. tostring(err)) end
  return okNow
end

PLAYERS_JSON_CACHE = PLAYERS_JSON_CACHE or nil
PLAYERS_JSON_CACHE_AT = PLAYERS_JSON_CACHE_AT or 0

local function liveRuntimePlayersJson()
  local runtimeReady, runtimeReason, runtimeAge = runtimeScanAllowed()
  if not runtimeReady then return nil, runtimeReason, runtimeAge end

  local cacheTtl = math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 300))
  local infos = cachedPlayerInfos(cacheTtl)
  if (infos == nil or #infos == 0) and configBool("bridge-safety", { "AllowPlayersJsonRuntimeScan", "allowPlayersJsonRuntimeScan" }, false) then
    infos = listPlayerInfos()
  end
  if infos == nil or #infos == 0 then return nil, "runtime returned no live players", runtimeAge end

  local snapshot = serverLogOnlineSnapshot()
  local parts = {}
  for _, info in ipairs(infos) do
    local p = enrichPlayerInfoFromServerLog(info) or info
    local x = tonumber(p.x)
    local y = tonumber(p.y)
    local z = tonumber(p.z)
    local hasLiveLocation = x ~= nil and y ~= nil and z ~= nil and (math.abs(x) + math.abs(y) + math.abs(z)) > 1
    table.insert(parts, '{"name":' .. js(p.name ~= "" and p.name or "Unknown") ..
      ',"steamId":' .. js(p.steam or "") ..
      ',"online":true' ..
      ',"status":"online"' ..
      ',"source":"ue4ss-live"' ..
      ',"positionSource":' .. js(hasLiveLocation and "ue4ss-live" or "runtime-no-location") ..
      ',"x":' .. tostring(x or 0) ..
      ',"y":' .. tostring(y or 0) ..
      ',"z":' .. tostring(z or 0) ..
      ',"userProfileId":' .. js(p.userProfileId or "") ..
      ',"serverUserProfileId":' .. js(p.serverUserProfileId or p.userProfileId or "") ..
      ',"runtimeKey":' .. js(p.runtimeKey or "") ..
      ',"runtimeReady":true' ..
      '}')
  end

  return '{"players":[' .. table.concat(parts, ",") .. '],"count":' .. tostring(#parts) ..
    ',"source":"ue4ss-live","runtimeReady":true' ..
    ',"runtimeReason":' .. js(runtimeReason or "") ..
    ',"runtimeAgeSeconds":' .. tostring(tonumber(runtimeAge or -1) or -1) ..
    ',"serverStats":{"playerCount":' .. tostring(tonumber(snapshot and snapshot.playerCount or -1) or -1) ..
    ',"fresh":' .. ((snapshot and snapshot.statsFresh) and "true" or "false") ..
    ',"ageSeconds":' .. tostring(tonumber(snapshot and snapshot.statsAgeSeconds or -1) or -1) ..
    ',"lastLine":' .. js((snapshot and snapshot.lastLine) or "") ..
    '}}'
end

local function playersJson()
  local now = os.clock()
  local cacheSeconds = math.max(3, configNumber("bridge-safety", { "PlayersJsonCacheSeconds", "playersJsonCacheSeconds" }, 15))
  if PLAYERS_JSON_CACHE ~= nil and (now - (tonumber(PLAYERS_JSON_CACHE_AT) or 0)) < cacheSeconds then
    return PLAYERS_JSON_CACHE
  end

  local liveJson, liveReason = liveRuntimePlayersJson()
  if liveJson ~= nil then
    PLAYERS_JSON_CACHE = liveJson
    PLAYERS_JSON_CACHE_AT = now
    return liveJson
  end

  local logJson = serverLogPlayersJson()
  if liveReason ~= nil and (PLAYERS_JSON_FALLBACK_LOG_AT == nil or (now - PLAYERS_JSON_FALLBACK_LOG_AT) > 30) then
    PLAYERS_JSON_FALLBACK_LOG_AT = now
    appendLog("playersJson fallback to server-log: " .. tostring(liveReason))
  end
  PLAYERS_JSON_CACHE = logJson
  PLAYERS_JSON_CACHE_AT = now
  return logJson
end

CURRENT_BRIDGE_RESULT_ID = ""

function resultIdJson(requestId)
  local id = tostring(requestId or CURRENT_BRIDGE_RESULT_ID or "")
  if id == "" then return "" end
  return ',"id":' .. js(id)
end

local function ok(command, message, dataJson, requestId)
  return '{"ok":true' .. resultIdJson(requestId) .. ',"source":"ue4ss","command":' .. js(command) .. ',"message":' .. js(message or "ok") .. ',"data":' .. (dataJson or "{}") .. '}'
end

local function fail(command, message, requestId)
  return '{"ok":false' .. resultIdJson(requestId) .. ',"source":"ue4ss","command":' .. js(command) .. ',"message":' .. js(message or "failed") .. '}'
end

adminBypassUntil = 0
adminBypassHooksInstalled = false

local function adminBypassActive()
  if adminBypassUntil <= 0 then return false end
  if os.clock() <= adminBypassUntil then return true end
  adminBypassUntil = 0
  return false
end

local function enableScopedAdminBypass(ms)
  local seconds = math.max(0.2, math.min((tonumber(ms) or 900) / 1000, 8.5))
  local untilTime = os.clock() + seconds
  if untilTime > adminBypassUntil then adminBypassUntil = untilTime end
end

local function disableScopedAdminBypass()
  adminBypassUntil = 0
end

local function disableScopedAdminBypassIfExpired(expectedUntil)
  local expected = tonumber(expectedUntil) or 0
  if expected <= 0 then return end
  if adminBypassUntil <= expected + 0.01 and os.clock() >= expected then
    adminBypassUntil = 0
  end
end

local function ensureAdminBypassHooks()
  if adminBypassHooksInstalled then return end
  adminBypassHooksInstalled = true
  local function hookBoolReturn(path, label)
    local function callback()
      if adminBypassActive() then return true end
      return nil
    end
    local okHook, preId, postId = pcall(function()
      return RegisterHook(path, callback, callback)
    end)
    if okHook then
      appendLog("admin bypass hook " .. tostring(label) .. ": ok pre=" .. tostring(preId) .. " post=" .. tostring(postId))
    else
      local errText = tostring(preId or "")
      local reason = "failed " .. (errText:match("([^\r\n]+)") or errText)
      if invalidRuntimeText(preId) or errText:find("no UFunction", 1, true) ~= nil or errText:find("specified name was found", 1, true) ~= nil then
        reason = "skipped missing runtime alias"
      end
      appendLog("admin bypass hook " .. tostring(label) .. ": " .. reason)
    end
  end
  hookBoolReturn("/Script/SCUM.ConZPlayerController:IsUserAdmin", "ConZPlayerController.IsUserAdmin")
  hookBoolReturn("/Script/SCUM.MiscStatics:IsUserDeveloper", "MiscStatics.IsUserDeveloper")
end

adminOutputHooksInstalled = false
adminCaptureActive = false
adminCaptureBuffer = {}
commandVerb = nil

local function ensureAdminOutputHooks()
  if adminOutputHooksInstalled then return end
  adminOutputHooksInstalled = true
  local paths = {
    "/Script/SCUM.ConZPlayerController:ClientShowAdminCommandResult",
    "/Script/ConZ.ConZPlayerController:ClientShowAdminCommandResult",
    "/Script/SCUM.ConZPlayerController:ClientShowCommandResult",
    "/Script/ConZ.ConZPlayerController:ClientShowCommandResult"
  }
  for _, path in ipairs(paths) do
    local okHook, err = pcall(function()
      RegisterHook(path, function(context, ...)
        if not adminCaptureActive then return end
        local args = {...}
        for _, arg in ipairs(args) do
          local text = paramText(arg)
          if text ~= "" then
            table.insert(adminCaptureBuffer, text)
            if type(rememberSpawnedVehicleAdminOutput) == "function" then rememberSpawnedVehicleAdminOutput(text) end
            appendLog("admin capture " .. tostring(path) .. ": " .. text:sub(1, 180))
          end
        end
      end)
    end)
    appendLog("admin output hook " .. tostring(path) .. "=" .. (okHook and "ok" or ("failed " .. tostring(err))))
  end
end

local function startAdminCapture()
  ensureAdminOutputHooks()
  adminCaptureBuffer = {}
  adminCaptureActive = true
end

local function stopAdminCapture()
  adminCaptureActive = false
  local messages = adminCaptureBuffer
  adminCaptureBuffer = {}
  return messages
end

local function waitForAdminCapture(ms)
  return
end

local function numberList(text)
  local out = {}
  for raw in tostring(text or ""):gmatch("[%-]?%d+%.?%d*") do
    local n = tonumber(raw)
    if n ~= nil then table.insert(out, n) end
  end
  return out
end

local function adminMessageIsFailure(message)
  local lower = tostring(message or ""):lower()
  return lower:find("not recognized", 1, true) ~= nil or
    lower:find("unrecognized", 1, true) ~= nil or
    lower:find("not authorized", 1, true) ~= nil or
    lower:find("not authorised", 1, true) ~= nil or
    lower:find("unknown command", 1, true) ~= nil or
    lower:find("command failed", 1, true) ~= nil
end

local function verifyAdminCommandMessages(commandText, messages)
  local verb = commandVerb(commandText):lower()
  for _, message in ipairs(messages or {}) do
    if adminMessageIsFailure(message) then return false, tostring(message) end
  end

  if verb == "setattributes" or verb == "setprisonerattributes" then
    local requested = numberList(commandText)
    if #requested < 4 then return false, "SetAttributes request has fewer than four values" end
    local sawAttributes = false
    for _, message in ipairs(messages or {}) do
      local lower = tostring(message or ""):lower()
      if lower:find("prisoner attributes are", 1, true) ~= nil or lower:find("attributes are", 1, true) ~= nil then
        local applied = numberList(message)
        if #applied >= 4 then
          sawAttributes = true
          local matched = true
          for i = 1, 4 do
            if math.abs(applied[i] - requested[i]) > 0.05 then matched = false end
          end
          if matched then
            return true, "SCUM confirmed attributes " .. tostring(applied[1]) .. " " .. tostring(applied[2]) .. " " .. tostring(applied[3]) .. " " .. tostring(applied[4])
          end
          return false, "SCUM applied different attributes: " .. tostring(message)
        end
      end
    end
    if sawAttributes then return false, "SCUM attribute response was unreadable" end
    return nil, "no SCUM attribute confirmation captured"
  end

  if messages ~= nil and #messages > 0 then return true, "SCUM returned command output" end
  return nil, "no SCUM command output captured"
end

local function objectFullName(obj)
  if obj == nil then return "" end
  local ok, name = pcall(function() return obj:GetFullName() end)
  if ok and name ~= nil then return tostring(name) end
  return tostring(obj)
end

local function firstValidAdminCommandObject(verb)
  local known = {
    SpawnItem = { "/Game/ConZ_Files/AdminCommands/SpawnItem.Default__SpawnItem_C" },
    SpawnVehicle = { "/Game/ConZ_Files/AdminCommands/SpawnVehicle.Default__SpawnVehicle_C" },
    DestroyVehicle = { "/Game/ConZ_Files/AdminCommands/DestroyVehicle.Default__DestroyVehicle_C" },
    ChangeCurrencyBalance = { "/Game/ConZ_Files/AdminCommands/ChangeCurrencyBalance.Default__ChangeCurrencyBalance_C" },
    SetCurrencyBalance = { "/Game/ConZ_Files/AdminCommands/SetCurrencyBalance.Default__SetCurrencyBalance_C" },
    ChangeFamePoints = { "/Game/ConZ_Files/AdminCommands/ChangeFamePoints.Default__ChangeFamePoints_C" },
    SetFamePoints = { "/Game/ConZ_Files/AdminCommands/SetFamePoints.Default__SetFamePoints_C" },
    SetAttributes = { "/Game/ConZ_Files/AdminCommands/Developer/Prisoner/SetAttributes.Default__SetAttributes_C" },
    SetPrisonerAttributes = {
      "/Game/ConZ_Files/AdminCommands/Developer/Prisoner/SetPrisonerAttributes.Default__SetPrisonerAttributes_C",
      "/Game/ConZ_Files/AdminCommands/Developer/Prisoner/SetAttributes.Default__SetAttributes_C"
    },
    SetSkillLevel = { "/Game/ConZ_Files/AdminCommands/Developer/SetSkillLevel.Default__SetSkillLevel_C" },
    DestroyEntity = {
      "/Game/ConZ_Files/AdminCommands/DestroyEntity.Default__DestroyEntity_C",
      "/Game/ConZ_Files/AdminCommands/Developer/DestroyEntity.Default__DestroyEntity_C",
      "/Game/ConZ_Files/AdminCommands/Entity/DestroyEntity.Default__DestroyEntity_C"
    },
    Teleport = {
      "/Game/ConZ_Files/AdminCommands/Teleport.Default__Teleport_C",
      "/Game/ConZ_Files/AdminCommands/Developer/Teleport.Default__Teleport_C",
      "/Game/ConZ_Files/AdminCommands/Entity/Teleport.Default__Teleport_C"
    },
    TeleportTo = {
      "/Game/ConZ_Files/AdminCommands/TeleportTo.Default__TeleportTo_C",
      "/Game/ConZ_Files/AdminCommands/Developer/TeleportTo.Default__TeleportTo_C"
    },
    GrantElevatedStatus = { "/Game/ConZ_Files/AdminCommands/GrantElevatedStatus.Default__GrantElevatedStatus_C" },
    RevokeElevatedStatus = { "/Game/ConZ_Files/AdminCommands/RevokeElevatedStatus.Default__RevokeElevatedStatus_C" }
  }
  local candidates = known[verb] or {
    "/Game/ConZ_Files/AdminCommands/" .. verb .. ".Default__" .. verb .. "_C",
    "/Game/ConZ_Files/AdminCommands/Developer/" .. verb .. ".Default__" .. verb .. "_C",
    "/Game/ConZ_Files/AdminCommands/Developer/Prisoner/" .. verb .. ".Default__" .. verb .. "_C"
  }
  for _, path in ipairs(candidates) do
    local obj = nil
    pcall(function() obj = StaticFindObject(path) end)
    if obj ~= nil and isValidObject(obj) then return obj end
  end
  for _, className in ipairs({ verb .. "_C", "UAdminCommand_" .. verb, "AdminCommand_" .. verb, verb }) do
    local obj = nil
    pcall(function() obj = FindFirstOf(className) end)
    if obj ~= nil and isValidObject(obj) then
      appendAdminVerboseLog("admin command object found through runtime class " .. tostring(className) .. " for " .. tostring(verb))
      return obj
    end
  end
  appendLog("admin command object not found through safe static paths for " .. tostring(verb))
  return nil
end

function commandVerb(commandText)
  local text = tostring(commandText or ""):gsub("^%s*#", ""):gsub("^%s+", "")
  return text:match("^([%w_]+)") or ""
end

local function patchAdminCommandFor(commandText)
  local verb = commandVerb(commandText)
  local patchable = {
    SpawnVehicle = true,
    DestroyVehicle = true,
    ChangeCurrencyBalance = true,
    SetCurrencyBalance = true,
    ChangeFamePoints = true,
    SetFamePoints = true,
    SetAttributes = true,
    SetPrisonerAttributes = true,
    SetSkillLevel = true,
    SpawnItem = true,
    DestroyEntity = true,
    Teleport = true,
    TeleportTo = true,
    TeleportToPlayer = true,
    TeleportToMe = true,
    GrantElevatedStatus = true,
    RevokeElevatedStatus = true
  }
  if not patchable[verb] then return nil end
  local obj = firstValidAdminCommandObject(verb)
  if obj == nil then
    appendLog("admin command patch skipped, object not found for " .. tostring(verb))
    return nil
  end

  local restore = {}
  local function setProp(prop, value)
    local okRead, old = pcall(function() return obj[prop] end)
    local okWrite, err = pcall(function() obj[prop] = value end)
    if okWrite then
      appendAdminVerboseLog("admin command patch " .. tostring(verb) .. "." .. tostring(prop) .. "=" .. tostring(value) .. " write=true")
    else
      appendLog("admin command patch " .. tostring(verb) .. "." .. tostring(prop) .. "=" .. tostring(value) .. " write=false err=" .. tostring(err))
    end
    if okRead and okWrite then table.insert(restore, { prop = prop, value = old }) end
  end

  setProp("_requiredExecutorLevel", 0)
  setProp("_isEnabled", true)
  setProp("_isEnabledInShippingBuild", true)
  appendAdminVerboseLog("admin command patch active for " .. tostring(verb) .. " object=" .. objectFullName(obj))

  appendAdminVerboseLog("admin command patch kept active for " .. tostring(verb) .. " to avoid unsafe delayed restore")
  return nil
end

local function adminExec(commandText, preferredInfo)
  commandText = tostring(commandText or "")
  local normalizedCommandText = commandText:gsub("^%s*#", "")
  local hashedCommandText = "#" .. normalizedCommandText
  local verb = commandVerb(normalizedCommandText)
  local serverScopedAdminVerbs = {
    Announce = true,
    Broadcast = true,
    SpawnItem = true,
    SpawnVehicle = true,
    DestroyVehicle = true,
    ChangeCurrencyBalance = true,
    SetCurrencyBalance = true,
    ChangeFamePoints = true,
    SetFamePoints = true,
    SetAttributes = true,
    SetPrisonerAttributes = true,
    SetSkillLevel = true,
    DestroyEntity = true
  }
  local playerBoundAdminVerbs = {
    SpawnItem = true,
    SpawnVehicle = true,
    DestroyVehicle = true,
    ChangeCurrencyBalance = true,
    SetCurrencyBalance = true,
    ChangeFamePoints = true,
    SetFamePoints = true,
    SetAttributes = true,
    SetPrisonerAttributes = true,
    SetSkillLevel = true,
    GrantElevatedStatus = true,
    RevokeElevatedStatus = true,
    DestroyEntity = true,
    Teleport = true,
    TeleportTo = true,
    TeleportToPlayer = true,
    TeleportToMe = true
  }
  -- Current hosted SCUM build does not echo attribute confirmations through the
  -- client-result hooks we can reliably capture. Treat admin mutations as a
  -- single live dispatch; verification belongs to a separate readback route.
  local requireProof = false
  local info = preferredInfo
  local needsLivePlayer = playerBoundAdminVerbs[verb] == true or not serverScopedAdminVerbs[verb]
  local function hasLiveAdminChannel(candidate)
    return candidate ~= nil and (
      (candidate.pc ~= nil and isValidObject(candidate.pc)) or
      (candidate.rpc ~= nil and isValidObject(candidate.rpc))
    )
  end
  if needsLivePlayer and not hasLiveAdminChannel(info) then
    local liveInfo = nil
    if info ~= nil then
      liveInfo = livePlayerForTarget(info.steam, info.name, info.runtimeKey, info)
    end
    if hasLiveAdminChannel(liveInfo) then
      if type(mergeRuntimeIntoIdentity) == "function" and info ~= nil then
        info = mergeRuntimeIntoIdentity(info, liveInfo)
      else
        info = liveInfo
      end
    elseif configBool("bridge-safety", { "AllowAdminExecRuntimeScan", "allowAdminExecRuntimeScan" }, false) then
      local runtimeInfos = listPlayerInfos()
      if runtimeInfos ~= nil and #runtimeInfos == 1 and hasLiveAdminChannel(runtimeInfos[1]) then
        if type(mergeRuntimeIntoIdentity) == "function" and info ~= nil then
          info = mergeRuntimeIntoIdentity(info, runtimeInfos[1])
        else
          info = runtimeInfos[1]
        end
      end
    end
  end
  if needsLivePlayer and not hasLiveAdminChannel(info) and configBool("bridge-safety", { "AllowAdminExecAnonymousRuntimeScan", "allowAdminExecAnonymousRuntimeScan" }, false) then info = findPlayer(nil, nil) end
  if needsLivePlayer and not hasLiveAdminChannel(info) and configBool("bridge-safety", { "AllowAdminExecRuntimeScan", "allowAdminExecRuntimeScan" }, false) then
    local controllers = listPlayerInfos()
    for _, candidate in ipairs(controllers) do
      if hasLiveAdminChannel(candidate) then
        info = candidate
        break
      end
    end
  end
  if info == nil then info = preferredInfo or {} end
  if needsLivePlayer and not hasLiveAdminChannel(info) then return false, "no live player rpc/controller" end
  ensureAdminBypassHooks()
  local bypassWindowMs = 6500
  enableScopedAdminBypass(bypassWindowMs)
  local bypassUntilForThisCommand = adminBypassUntil
  local restoreAdminCommand = patchAdminCommandFor(normalizedCommandText)
  local restoredAdminCommand = false
  local function restoreAdminCommandNow()
    if restoreAdminCommand == nil or restoredAdminCommand then return end
    restoredAdminCommand = true
    pcall(restoreAdminCommand)
  end
  if restoreAdminCommand ~= nil then
    deferGame(bypassWindowMs + 1500, restoreAdminCommandNow)
  end
  local methods = {}
  local function tryMethod(label, fn)
    local captureOutput = verb == "SpawnVehicle" or verb == "DestroyEntity"
    if requireProof or captureOutput then startAdminCapture() end
    local startedAtMs = math.floor(os.clock() * 1000)
    local okCall, result = pcall(fn)
    local durationMs = math.max(0, math.floor(os.clock() * 1000) - startedAtMs)
    local messages = {}
    if requireProof or captureOutput then
      waitForAdminCapture(verb == "DestroyEntity" and 300 or 150)
      messages = stopAdminCapture()
    end
    if requireProof then
      local verified, detail = verifyAdminCommandMessages(normalizedCommandText, messages)
      table.insert(methods, label .. "=" .. (okCall and "ok" or tostring(result)) .. ";durationMs=" .. tostring(durationMs) .. ";captured=" .. tostring(#messages) .. ";verified=" .. tostring(verified) .. ";detail=" .. tostring(detail))
      appendAdminVerboseLog("admin route " .. tostring(label) .. " ok=" .. tostring(okCall) .. " durationMs=" .. tostring(durationMs) .. " verified=" .. tostring(verified))
      if okCall and verified == true then return true, detail end
      return false, detail or result
    end
    table.insert(methods, label .. "=" .. (okCall and "ok" or tostring(result)) .. ";durationMs=" .. tostring(durationMs))
    appendAdminVerboseLog("admin route " .. tostring(label) .. " ok=" .. tostring(okCall) .. " durationMs=" .. tostring(durationMs))
    if okCall then
      if captureOutput and messages ~= nil then
        for _, capturedMessage in ipairs(messages) do
          if adminMessageIsFailure(capturedMessage) then
            table.insert(methods, label .. "=captured-failure:" .. tostring(capturedMessage))
            appendAdminVerboseLog("admin route " .. tostring(label) .. " captured failure: " .. tostring(capturedMessage))
            return false, tostring(capturedMessage)
          end
        end
      end
      local miscIsLastResort = label:find("misc.Test_ProcessAdminCommand", 1, true) ~= nil
      local needsRealPlayerRoute = verb == "SpawnItem" or verb == "SpawnVehicle" or
        verb == "ChangeCurrencyBalance" or verb == "SetCurrencyBalance" or
        verb == "ChangeFamePoints" or verb == "SetFamePoints" or
        verb == "SetAttributes" or verb == "SetPrisonerAttributes" or
        verb == "SetSkillLevel" or verb == "DestroyEntity" or
        verb == "Teleport" or verb == "TeleportTo" or verb == "TeleportToPlayer" or verb == "TeleportToMe"
      if miscIsLastResort and needsRealPlayerRoute then
        appendLog("admin route " .. tostring(label) .. " accepted but not trusted for " .. tostring(verb) .. "; continuing")
        return false, label .. " accepted but not trusted for " .. tostring(verb)
      end
      if captureOutput and messages ~= nil and #messages > 0 then
        return true, label .. " | " .. table.concat(messages, " | ")
      end
      return true, label
    end
    return false, result
  end

  local function runRoutes(routes)
    local last = nil
    for _, route in ipairs(routes) do
      local okCall, message = tryMethod(route.label, route.fn)
      last = message
      if okCall then return true, message end
    end
    return false, last
  end

  local rpc = nil
  if info ~= nil and info.rpc ~= nil and isValidObject(info.rpc) then rpc = info.rpc end
  if rpc == nil then rpc = playerRpcChannel(info.pc) end
  local hasPlayerController = info ~= nil and info.pc ~= nil and isValidObject(info.pc)
  local misc = nil
  pcall(function() misc = StaticFindObject("/Script/SCUM.Default__MiscStatics") end)

  local routes = {}
  local function addRoute(label, fn)
    table.insert(routes, { label = label, fn = fn })
  end

  if requireProof then
    if rpc ~= nil then addRoute("rpc.Chat_Server_ProcessAdminCommand#bare-fstring", function() rpc:Chat_Server_ProcessAdminCommand(ueString(normalizedCommandText)) end) end
    if rpc ~= nil then addRoute("rpc.Chat_Server_ProcessAdminCommand#bare", function() rpc:Chat_Server_ProcessAdminCommand(normalizedCommandText) end) end
    if misc ~= nil then
      local root = worldRoot() or info.pc
      addRoute("misc.Test_ProcessAdminCommand#hash-fstring", function() misc:Test_ProcessAdminCommand(root, ueString(hashedCommandText)) end)
    end
  else
    local kismet = kismetSystemLibrary()
    local rootForMisc = worldRoot() or gameModeRoot() or info.pc
    local rootForKismet = gameModeRoot() or worldRoot() or info.pc
    local gameModeForConsole = gameModeRoot() or rootForKismet
    local function callRpcAdminBare()
      if rpc == nil then error("rpc channel missing") end
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() rpc:Chat_Server_ProcessAdminCommand(ueString(normalizedCommandText)) end)
      if okHash then return true end
      appendLog("rpc admin bare fstring failed: " .. tostring(errHash))
      rpc:Chat_Server_ProcessAdminCommand(normalizedCommandText)
      return true
    end

    local function callRpcAdminHash()
      if rpc == nil then error("rpc channel missing") end
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() rpc:Chat_Server_ProcessAdminCommand(ueString(hashedCommandText)) end)
      if okHash then return true end
      appendLog("rpc admin hash fstring failed: " .. tostring(errHash))
      rpc:Chat_Server_ProcessAdminCommand(hashedCommandText)
      return true
    end

    local function callPcServerSayHash()
      if not hasPlayerController then error("player controller missing") end
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() info.pc:ServerSay(ueString(hashedCommandText)) end)
      if okHash then return true end
      appendLog("pc ServerSay hash fstring failed: " .. tostring(errHash))
      info.pc:ServerSay(hashedCommandText)
      return true
    end

    local function callKismetConsoleHash()
      if kismet == nil then error("KismetSystemLibrary missing") end
      if rootForKismet == nil then error("Kismet world context missing") end
      local pcArg = hasPlayerController and info.pc or nil
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() kismet:ExecuteConsoleCommand(rootForKismet, ueString(hashedCommandText), pcArg) end)
      if okHash then return true end
      appendLog("Kismet ExecuteConsoleCommand hash fstring failed: " .. tostring(errHash))
      kismet:ExecuteConsoleCommand(rootForKismet, hashedCommandText, pcArg)
      return true
    end

    local function callKismetConsoleNoHash()
      if kismet == nil then error("KismetSystemLibrary missing") end
      if rootForKismet == nil then error("Kismet world context missing") end
      local pcArg = hasPlayerController and info.pc or nil
      local okNoHash = false
      local errNoHash = nil
      okNoHash, errNoHash = pcall(function() kismet:ExecuteConsoleCommand(rootForKismet, ueString(normalizedCommandText), pcArg) end)
      if okNoHash then return true end
      appendLog("Kismet ExecuteConsoleCommand nohash fstring failed: " .. tostring(errNoHash))
      kismet:ExecuteConsoleCommand(rootForKismet, normalizedCommandText, pcArg)
      return true
    end

    local function callProcessConsoleExecHash()
      if gameModeForConsole == nil then error("game mode missing") end
      local pcArg = hasPlayerController and info.pc or nil
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() gameModeForConsole:ProcessConsoleExec(ueString(hashedCommandText), nil, pcArg) end)
      if okHash then return true end
      appendLog("ProcessConsoleExec hash fstring failed: " .. tostring(errHash))
      gameModeForConsole:ProcessConsoleExec(hashedCommandText, nil, pcArg)
      return true
    end

    local function callPcConsoleCommandHash()
      if not hasPlayerController then error("player controller missing") end
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() info.pc:ConsoleCommand(ueString(hashedCommandText), true) end)
      if okHash then return true end
      appendLog("PC ConsoleCommand hash fstring failed: " .. tostring(errHash))
      info.pc:ConsoleCommand(hashedCommandText, true)
      return true
    end

    local function callMiscAdminHash()
      if misc == nil then error("MiscStatics missing") end
      if rootForMisc == nil then error("MiscStatics world context missing") end
      local okHash = false
      local errHash = nil
      okHash, errHash = pcall(function() misc:Test_ProcessAdminCommand(rootForMisc, ueString(hashedCommandText)) end)
      if okHash then return true end
      appendLog("misc admin hash fstring failed: " .. tostring(errHash))
      misc:Test_ProcessAdminCommand(rootForMisc, hashedCommandText)
      return true
    end

    if playerBoundAdminVerbs[verb] then
      if rpc ~= nil then addRoute("rpc.Chat_Server_ProcessAdminCommand#bare", callRpcAdminBare) end
      if rpc ~= nil then addRoute("rpc.Chat_Server_ProcessAdminCommand#hash", callRpcAdminHash) end
      if hasPlayerController then addRoute("pc.ServerSay#hash", callPcServerSayHash) end
      if kismet ~= nil then addRoute("kismet.ExecuteConsoleCommand#hash", callKismetConsoleHash) end
      if kismet ~= nil then addRoute("kismet.ExecuteConsoleCommand#nohash", callKismetConsoleNoHash) end
      if gameModeForConsole ~= nil then addRoute("gameMode.ProcessConsoleExec#hash", callProcessConsoleExecHash) end
      if hasPlayerController then addRoute("pc.ConsoleCommand#hash", callPcConsoleCommandHash) end
      if misc ~= nil then addRoute("misc.Test_ProcessAdminCommand#hash", callMiscAdminHash) end
    else
      if rpc ~= nil then addRoute("rpc.Chat_Server_ProcessAdminCommand#hash", callRpcAdminHash) end
      if misc ~= nil then addRoute("misc.Test_ProcessAdminCommand#hash", callMiscAdminHash) end
      if kismet ~= nil then addRoute("kismet.ExecuteConsoleCommand#hash", callKismetConsoleHash) end
    end
  end

  local okRoute, routeMessage = runRoutes(routes)
  if okRoute then
    deferGame(bypassWindowMs + 250, function()
      disableScopedAdminBypassIfExpired(bypassUntilForThisCommand)
    end)
    appendAdminVerboseLog("admin exec dispatched for " .. tostring(normalizedCommandText) .. "; scoped admin bypass remains active for async command window")
    return true, routeMessage
  end
  restoreAdminCommandNow()
  disableScopedAdminBypass()
  appendLog("admin exec failed for " .. tostring(commandText) .. " methods: " .. table.concat(methods, " | "))
  return false, routeMessage or "no admin execution route succeeded"
end

vehicleRuntimeKeySet = nil
nearestNewVehicleRef = nil
findVehicleByRuntimeRef = nil

local function extractVehicleEntityIdFromText(text)
  local value = tostring(text or "")
  local id = value:match("[Ii][Dd]%s+(%d+)")
  if id == nil then id = value:match("[Vv]ehicle[Ii]d[%s:=]+(%d+)") end
  if id == nil then id = value:match("[Ee]ntity[Ii]d[%s:=]+(%d+)") end
  if id ~= nil and tostring(id) ~= "" and tostring(id) ~= "0" then return tostring(id) end
  return ""
end

RECENT_SPAWNED_VEHICLE_IDS = RECENT_SPAWNED_VEHICLE_IDS or {}

local function normalizeVehicleAssetName(value)
  local text = tostring(value or "")
  text = text:gsub("^%s+", ""):gsub("%s+$", "")
  text = text:gsub("^#", ""):gsub("^Vehicle:", ""):gsub("_C$", "")
  return text
end

function rememberSpawnedVehicleAdminOutput(text)
  local raw = tostring(text or "")
  local entityId = extractVehicleEntityIdFromText(raw)
  if entityId == "" then return end
  local vehicle = raw:match("[Ss]pawned%s+([^%s]+)%s+with%s+[Ii][Dd]") or raw:match("[Ss]pawned%s+([^%s]+)")
  vehicle = normalizeVehicleAssetName(vehicle)
  if vehicle == "" then vehicle = "*" end
  local now = os.time()
  table.insert(RECENT_SPAWNED_VEHICLE_IDS, { at = now, vehicle = vehicle, id = entityId, text = raw })
  while #RECENT_SPAWNED_VEHICLE_IDS > 30 do table.remove(RECENT_SPAWNED_VEHICLE_IDS, 1) end
  appendLog("spawned vehicle id captured vehicle=" .. tostring(vehicle) .. " id=" .. tostring(entityId))
end

local function recentSpawnedVehicleEntityId(vehicleId, afterEpoch)
  local wanted = normalizeVehicleAssetName(vehicleId):lower()
  local after = tonumber(afterEpoch or 0) or 0
  local now = os.time()
  for i = #RECENT_SPAWNED_VEHICLE_IDS, 1, -1 do
    local entry = RECENT_SPAWNED_VEHICLE_IDS[i]
    local at = tonumber(entry and entry.at or 0) or 0
    if at > 0 and now - at > 120 then
      table.remove(RECENT_SPAWNED_VEHICLE_IDS, i)
    elseif at >= math.max(0, after - 2) then
      local entryVehicle = normalizeVehicleAssetName(entry and entry.vehicle or ""):lower()
      local id = tostring(entry and entry.id or "")
      if id ~= "" and id ~= "0" and (entryVehicle == "*" or wanted == "" or entryVehicle == wanted) then
        return id
      end
    end
  end
  return ""
end

local function spawnVehicleForInfo(vehicle, info)
  local cleanVehicle = tostring(vehicle or ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub("^Vehicle:", "")
  if cleanVehicle == "" then
    appendActionEvent("spawn_vehicle", false, info, "vehicle is missing", '{"vehicleId":""}')
    return false, "vehicle is missing"
  end
  info = info or {}
  local resolvedVehicleInfo = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
  if configBool("vehicle-rental", { "RefreshPlayerBeforeVehicleSpawn", "refreshPlayerBeforeVehicleSpawn" }, false) then
    local refreshedVehicleInfo = refreshRuntimePlayerInfo(resolvedVehicleInfo)
    if refreshedVehicleInfo ~= nil then resolvedVehicleInfo = refreshedVehicleInfo end
  end
  local vehicleSelector = tostring(resolvedVehicleInfo.steam or "")
  if looksLikeSteamId(vehicleSelector) then
    local beforeVehicles = {}
    if configBool("vehicle-rental", { "CaptureVehiclesBeforeSpawn", "captureVehiclesBeforeSpawn", "EnableRuntimeVehicleTrackAfterSpawn", "enableRuntimeVehicleTrackAfterSpawn" }, true) then
      beforeVehicles = vehicleRuntimeKeySet(cleanVehicle)
    end
    local commandText = "SpawnVehicle " .. cleanVehicle .. " 1 Location " .. vehicleSelector
    local commandStartedAt = os.time()
    local sent, message = adminExec(commandText, resolvedVehicleInfo)
    local last = tostring(message or "")
    if sent then
      local entityId = extractVehicleEntityIdFromText(last)
      if entityId == "" then entityId = recentSpawnedVehicleEntityId(cleanVehicle, commandStartedAt) end
      local runtimeRef = entityId ~= "" and entityId or ""
      appendActionEvent("spawn_vehicle", true, resolvedVehicleInfo, last .. " command=" .. commandText,
        '{"vehicleId":' .. js(cleanVehicle) .. ',"command":' .. js(commandText) .. ',"runtimeRef":' .. js(runtimeRef) .. ',"adminTarget":true}')
      return true, last .. " command=" .. commandText, runtimeRef, beforeVehicles
    end
    appendActionEvent("spawn_vehicle", false, resolvedVehicleInfo, last ~= "" and last or "vehicle admin route failed",
      '{"vehicleId":' .. js(cleanVehicle) .. ',"command":' .. js(commandText) .. ',"adminTarget":true}')
    return false, last ~= "" and last or "vehicle admin route failed"
  end
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = false })
  if not ready then
    appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
      '{"reason":' .. js(readyReason or "") .. ',"vehicleId":' .. js(cleanVehicle) .. '}')
    return false, deliveryReadyMessage(readyReason)
  end
  info = liveInfo
  if info == nil or info.pc == nil or not isValidObject(info.pc) then
    appendActionEvent("spawn_vehicle", false, info, "Игрок не найден среди реально подключённых.",
      '{"vehicleId":' .. js(cleanVehicle) .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  local selector = ""
  if info ~= nil then selector = (info.steam ~= "" and info.steam) or info.name or "" end
  local beforeVehicles = {}
  if configBool("vehicle-rental", { "CaptureVehiclesBeforeSpawn", "captureVehiclesBeforeSpawn", "EnableRuntimeVehicleTrackAfterSpawn", "enableRuntimeVehicleTrackAfterSpawn" }, true) then
    beforeVehicles = vehicleRuntimeKeySet(cleanVehicle)
  end
  local commandText = "SpawnVehicle " .. cleanVehicle
  if looksLikeSteamId(selector) then commandText = commandText .. " 1 Location " .. selector end
  local commandStartedAt = os.time()
  local sent, message = adminExec(commandText, info)
  local last = tostring(message or "")
  if sent then
    local entityId = extractVehicleEntityIdFromText(last)
    if entityId == "" then entityId = recentSpawnedVehicleEntityId(cleanVehicle, commandStartedAt) end
    local runtimeRef = entityId ~= "" and entityId or ""
    appendActionEvent("spawn_vehicle", true, info, last .. " command=" .. commandText,
      '{"vehicleId":' .. js(cleanVehicle) .. ',"command":' .. js(commandText) .. ',"runtimeRef":' .. js(runtimeRef) .. '}')
    return true, last .. " command=" .. commandText, runtimeRef, beforeVehicles
  end
  appendActionEvent("spawn_vehicle", false, info, last ~= "" and last or "Маршрут выдачи транспорта не сработал.",
    '{"vehicleId":' .. js(cleanVehicle) .. '}')
  return false, last ~= "" and last or "Маршрут выдачи транспорта не сработал."
end

local function destroyVehicleRef(vehicleRef, info, reason)
  local ref = tostring(vehicleRef or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local targetInfo = info or {}
  if targetInfo ~= nil and (targetInfo.pc == nil or not isValidObject(targetInfo.pc)) then
    targetInfo = resolvePlayerInfo(targetInfo.steam, targetInfo.name, targetInfo, targetInfo.runtimeKey) or targetInfo
  end
  if targetInfo == nil or targetInfo.pc == nil or not isValidObject(targetInfo.pc) then
    targetInfo = findPlayer(nil, nil) or targetInfo or {}
  end
  local cleanReason = tostring(reason or "")
  if ref == "" or ref == "0" then
    appendActionEvent("vehicle_destroy", false, targetInfo, "vehicle destroy skipped: missing entity id",
      '{"vehicleRef":"","reason":' .. js(cleanReason) .. '}')
    return false, "missing vehicle entity id"
  end
  if ref:sub(1, 8) == "runtime:" then
    local vehicle = findVehicleByRuntimeRef(ref)
    if vehicle ~= nil then
      local okCall, err = safeCall(vehicle, "K2_DestroyActor")
      if not okCall then okCall, err = safeCall(vehicle, "Destroy") end
      appendActionEvent("vehicle_destroy", okCall, targetInfo, okCall and "vehicle destroyed through runtime object" or tostring(err),
        '{"vehicleRef":' .. js(ref) .. ',"reason":' .. js(cleanReason) .. ',"route":"runtime"}')
      return okCall, okCall and "vehicle destroyed through runtime object" or tostring(err)
    end
    appendActionEvent("vehicle_destroy", false, targetInfo, "runtime vehicle object not found",
      '{"vehicleRef":' .. js(ref) .. ',"reason":' .. js(cleanReason) .. ',"route":"runtime"}')
    return false, "runtime vehicle object not found"
  end
  local commandText = "DestroyVehicle " .. ref
  local sent, message = adminExec(commandText, targetInfo)
  appendActionEvent("vehicle_destroy", sent, targetInfo, tostring(message or ""),
    '{"vehicleRef":' .. js(ref) .. ',"reason":' .. js(cleanReason) .. ',"command":' .. js(commandText) .. '}')
  return sent, message
end

CHAT_ASCII_MAP = {
  ["А"] = "A", ["Б"] = "B", ["В"] = "V", ["Г"] = "G", ["Д"] = "D", ["Е"] = "E", ["Ё"] = "Yo", ["Ж"] = "Zh",
  ["З"] = "Z", ["И"] = "I", ["Й"] = "Y", ["К"] = "K", ["Л"] = "L", ["М"] = "M", ["Н"] = "N", ["О"] = "O",
  ["П"] = "P", ["Р"] = "R", ["С"] = "S", ["Т"] = "T", ["У"] = "U", ["Ф"] = "F", ["Х"] = "H", ["Ц"] = "Ts",
  ["Ч"] = "Ch", ["Ш"] = "Sh", ["Щ"] = "Sch", ["Ъ"] = "", ["Ы"] = "Y", ["Ь"] = "", ["Э"] = "E", ["Ю"] = "Yu",
  ["Я"] = "Ya", ["а"] = "a", ["б"] = "b", ["в"] = "v", ["г"] = "g", ["д"] = "d", ["е"] = "e", ["ё"] = "yo",
  ["ж"] = "zh", ["з"] = "z", ["и"] = "i", ["й"] = "y", ["к"] = "k", ["л"] = "l", ["м"] = "m", ["н"] = "n",
  ["о"] = "o", ["п"] = "p", ["р"] = "r", ["с"] = "s", ["т"] = "t", ["у"] = "u", ["ф"] = "f", ["х"] = "h",
  ["ц"] = "ts", ["ч"] = "ch", ["ш"] = "sh", ["щ"] = "sch", ["ъ"] = "", ["ы"] = "y", ["ь"] = "", ["э"] = "e",
  ["ю"] = "yu", ["я"] = "ya"
}

function chatSafeText(message)
  local text = tostring(message or "")
  text = text:gsub("[\r\n]+", " ")
  text = text:gsub("[%z\001-\031\127]", "")
  text = text:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  return text
end

local function broadcast(message)
  message = chatSafeText(message)
  local root = worldRoot()
  local misc = nil
  pcall(function() misc = StaticFindObject("/Script/SCUM.Default__MiscStatics") end)
  if misc ~= nil and root ~= nil then
    local okCall, err = safeCall(misc, "BroadcastChatLine", root, message, 6)
    if okCall then return true, "broadcast through MiscStatics" end
    appendLog("broadcast failed: " .. tostring(err))
  end
  local gm = gameModeRoot()
  if gm ~= nil then
    local okCall, err = safeCall(gm, "SendChatMessageToAll", message)
    if okCall then return true, "broadcast through GameMode SendChatMessageToAll" end
    appendLog("SendChatMessageToAll failed: " .. tostring(err))
    okCall, err = safeCall(gm, "BroadcastChatMessage", message)
    if okCall then return true, "broadcast through GameMode BroadcastChatMessage" end
    appendLog("BroadcastChatMessage failed: " .. tostring(err))
    okCall, err = safeCall(gm, "SendAdminMessage", message)
    if okCall then return true, "broadcast through GameMode SendAdminMessage" end
    appendLog("SendAdminMessage failed: " .. tostring(err))
  end
  return adminExec("#Announce " .. tostring(message or ""))
end

local function broadcastGlobalChatOnly(message)
  message = chatSafeText(message)
  local root = worldRoot()
  local misc = nil
  pcall(function() misc = StaticFindObject("/Script/SCUM.Default__MiscStatics") end)
  if misc ~= nil and root ~= nil then
    local okCall, err = safeCall(misc, "BroadcastChatLine", root, ueString(message), 2)
    if okCall then return true, "broadcast through MiscStatics global chat" end
    appendLog("global chat broadcast fstring failed: " .. tostring(err))
    okCall, err = safeCall(misc, "BroadcastChatLine", root, message, 2)
    if okCall then return true, "broadcast through MiscStatics global chat raw" end
    appendLog("global chat broadcast raw failed: " .. tostring(err))
  end
  for _, info in ipairs(cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 300))) or {}) do
    local rpc = playerRpcChannel(info.pc)
    if rpc ~= nil then
      local okCall, err = safeCall(rpc, "Chat_Server_BroadcastChatMessage", ueString(message), 2)
      if okCall then return true, "broadcast through PlayerRpcChannel global chat" end
      appendLog("global chat PlayerRpcChannel fstring failed: " .. tostring(err))
      okCall, err = safeCall(rpc, "Chat_Server_BroadcastChatMessage", message, 2)
      if okCall then return true, "broadcast through PlayerRpcChannel global chat raw" end
      appendLog("global chat PlayerRpcChannel raw failed: " .. tostring(err))
      break
    end
  end
  local gm = gameModeRoot()
  if gm ~= nil then
    local okCall, err = safeCall(gm, "SendChatMessageToAll", message)
    if okCall then return true, "broadcast through GameMode global chat" end
    appendLog("global chat SendChatMessageToAll failed: " .. tostring(err))
    okCall, err = safeCall(gm, "BroadcastChatMessage", message)
    if okCall then return true, "broadcast through GameMode BroadcastChatMessage" end
    appendLog("global chat BroadcastChatMessage failed: " .. tostring(err))
  end
  return false, "Маршрут синего глобального чата не найден; #Announce для kill feed отключён."
end

local function recordTargetMessage(info, message, source)
  if source == nil or source == false then return end
  local targetName = info and info.name or ""
  local targetSteam = info and info.steam or ""
  local label = "ScumNeDjin"
  if targetName ~= "" then
    label = label .. " -> " .. targetName
  elseif targetSteam ~= "" then
    label = label .. " -> " .. targetSteam
  end
  enqueueChatEventWrite(message, label, targetSteam, "server", tostring(source))
end

local function playerReplyTargetKey(info)
  if info == nil then return "" end
  local steam = cleanText(info.steam or info.steamId or "")
  if looksLikeSteamId(steam) then return "steam:" .. steam end
  if info.pc ~= nil and isValidObject(info.pc) then
    local pcKey = objectKey(info.pc)
    if pcKey ~= "" then return "pc:" .. pcKey end
  end
  local profile = cleanText(info.userProfileId or info.serverUserProfileId or info.profileId or "")
  if profile ~= "" and profile ~= "0" and info.pc ~= nil and isValidObject(info.pc) then return "profile:" .. profile end
  local name = cleanText(info.name or "")
  if name ~= "" and name:lower() ~= "unknown" and info.pc ~= nil and isValidObject(info.pc) then return "name:" .. name:lower() end
  return ""
end

local function playerReplyTargetReliable(info)
  return playerReplyTargetKey(info) ~= ""
end

local function targetMessageSent(info, message, source, route)
  recordTargetMessage(info, message, source)
  appendLog("target message sent target=" .. tostring((info and (info.steam or info.name)) or "") .. " route=" .. tostring(route))
  return true, route
end

local function sendTargetMessageToInfo(info, message, historySource)
  message = chatSafeText(message)
  if not playerReplyTargetReliable(info) then
    appendLog("target message skipped unresolved target source=" .. tostring(historySource or "command-reply"))
    return false, "target player unresolved"
  end
  local priorInfo = info
  local refreshed = nil
  if configBool("bridge-safety", { "RefreshPlayerBeforeMessage", "refreshPlayerBeforeMessage" }, false) then
    refreshed = refreshRuntimePlayerInfo(info)
  end
  if refreshed ~= nil then
    info = refreshed
    if (info.rpc == nil or not isValidObject(info.rpc)) and priorInfo ~= nil and priorInfo.rpc ~= nil and isValidObject(priorInfo.rpc) then
      info.rpc = priorInfo.rpc
      info.rpcKey = objectKey(priorInfo.rpc)
    end
  else
    info = priorInfo
  end
  if info ~= nil then
    local rpc = nil
    if info.rpc ~= nil and isValidObject(info.rpc) then rpc = info.rpc end
    if rpc == nil and info.pc ~= nil and isValidObject(info.pc) then rpc = playerRpcChannel(info.pc) end
    if rpc ~= nil then
      local okCall, err = safeCall(rpc, "Chat_Client_SendMessageToChat", message, info.ps, 4, false)
      if okCall then return targetMessageSent(info, message, historySource, "sent through PlayerRpcChannel chat client") end
      appendLog("RpcChannel target chat failed: " .. tostring(err))
      okCall, err = safeCall(rpc, "Chat_Client_SendMessageToChat", message, 4, false)
      if okCall then return targetMessageSent(info, message, historySource, "sent through PlayerRpcChannel compact chat client") end
      appendLog("RpcChannel compact target chat failed: " .. tostring(err))
    end
  end
  if info == nil or info.pc == nil or not isValidObject(info.pc) then
    appendLog("target message skipped without live PlayerController target=" .. tostring(playerReplyTargetKey(info)))
    return false, "target chat route unavailable"
  end
  if configBool("bridge-safety", { "RefreshPlayerBeforeMessageFallback", "refreshPlayerBeforeMessageFallback" }, false) then
    info = refreshRuntimePlayerInfo(info)
  end
  if info == nil then return false, "Игрок не найден среди реально подключённых." end
  if info.pc == nil or not isValidObject(info.pc) then return false, "Игрок не найден среди реально подключённых." end
  if info.pc ~= nil then
    local rpc = playerRpcChannel(info.pc)
    if rpc ~= nil then
      local okCall, err = safeCall(rpc, "Chat_Client_SendMessageToChat", message, info.ps, 4, false)
      if okCall then return targetMessageSent(info, message, historySource, "sent through PlayerRpcChannel chat client") end
      appendLog("RpcChannel target chat failed: " .. tostring(err))
    end
    local okCall, err = safeCall(info.pc, "ClientMessage", message)
    if okCall then return targetMessageSent(info, message, historySource, "sent through PlayerController ClientMessage") end
    appendLog("ClientMessage target chat failed: " .. tostring(err))
    okCall, err = safeCall(info.pc, "ClientReceiveChatMessage", message, "Server", 4)
    if okCall then return targetMessageSent(info, message, historySource, "sent through ClientReceiveChatMessage") end
    appendLog("ClientReceiveChatMessage target chat failed: " .. tostring(err))
  end
  local misc = nil
  pcall(function() misc = StaticFindObject("/Script/SCUM.Default__MiscStatics") end)
  if misc ~= nil and info.pc ~= nil then
    local okCall, err = safeCall(misc, "SendChatLineToPlayer", info.pc, message, 6, false)
    if okCall then return targetMessageSent(info, message, historySource, "sent through SendChatLineToPlayer") end
    appendLog("target chat failed: " .. tostring(err))
  end
  local gm = gameModeRoot()
  if gm ~= nil and info.pc ~= nil then
    local okCall, err = safeCall(gm, "SendChatMessage", message, info.pc)
    if okCall then return targetMessageSent(info, message, historySource, "sent through GameMode SendChatMessage") end
    appendLog("GameMode target chat failed: " .. tostring(err))
  end
  return false, "Сообщение игроку не удалось отправить через доступные маршруты."
end

local function targetMessage(steamId, name, message, historySource, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil and not configBool("bridge-safety", { "AllowTargetMessageRuntimeResolve", "allowTargetMessageRuntimeResolve" }, false) then
    info = resolvePlayerInfoFromServerLogTarget(steamId, name)
  elseif info == nil then
    info = resolvePlayerInfo(steamId, name, nil, runtimeKey)
  end
  return sendTargetMessageToInfo(info, message, historySource)
end

local function targetMessageResolved(info, message, historySource)
  return sendTargetMessageToInfo(info, message, historySource or "command-reply")
end

local function teleportResolved(info, x, y, z)
  info = enrichPlayerInfoFromServerLog(info) or info
  if info == nil then
    appendActionEvent("teleport", false, {}, "Игрок не найден среди реально подключённых.",
      '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  if info.pawn == nil or not isValidObject(info.pawn) then
    appendActionEvent("teleport", false, info, "target pawn missing",
      '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) .. '}')
    return false, "target pawn missing"
  end
  if configBool("bridge-safety", { "EnableDirectTeleport", "enableDirectTeleport", "AllowDirectPawnTeleport", "allowDirectPawnTeleport" }, false) then
    local location = { X = x, Y = y, Z = z }
    local okCall, err = safeCall(info.pawn, "K2_SetActorLocation", location, false, {}, true)
    if okCall then
      appendActionEvent("teleport", true, info, "teleported through pawn actor location",
        '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) .. ',"route":"pawn"}')
      return true, "teleported through pawn actor location"
    end
    appendLog("direct teleport failed: " .. tostring(err))
  else
    appendLog("direct pawn teleport skipped by bridge-safety")
  end
  local target = tostring(info.steam or "") ~= "" and info.steam or info.name
  local sent, message = adminExec("#Teleport " .. tostring(x) .. " " .. tostring(y) .. " " .. tostring(z) .. " " .. tostring(target), info)
  appendActionEvent("teleport", sent, info, tostring(message or ""),
    '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) .. ',"route":"admin"}')
  return sent, message
end

local function teleport(steamId, name, x, y, z, runtimeKey)
  local info = enrichPlayerInfoFromServerLog(findPlayer(steamId, name, runtimeKey))
  if info == nil then
    appendActionEvent("teleport", false, { steam = steamId, name = name }, "Игрок не найден среди реально подключённых.",
      '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  return teleportResolved(info, x, y, z)
end

local function changeMoney(steamId, name, amount, currency, runtimeKey)
  amount = tonumber(amount) or 0
  if amount == 0 then
    appendActionEvent("change_money", true, { steam = steamId, name = name, runtimeKey = runtimeKey }, "Баланс не изменён: сумма 0.", '{"amount":0,"currency":' .. js(currency or "Normal") .. ',"queued":false}')
    return true, "Баланс не изменён: сумма 0."
  end
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then info = resolvePlayerInfo(steamId, name, nil, runtimeKey) or { steam = tostring(steamId or ""), name = tostring(name or ""), runtimeKey = tostring(runtimeKey or ""), source = "money-identity" } end
  if tostring(info.steam or "") == "" then info.steam = tostring(steamId or "") end
  if tostring(info.name or "") == "" or tostring(info.name or "") == "Unknown" then info.name = tostring(name or "") end
  if info == nil then
    appendActionEvent("change_money", false, { steam = steamId, name = name }, "Игрок не найден среди реально подключённых.",
      '{"amount":' .. tostring(tonumber(amount) or 0) .. ',"currency":' .. js(currency or "Normal") .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  currency = valueText(currency)
  if currency == "" then currency = "Normal" end
  if currency:lower() == "gold" then currency = "Gold" else currency = "Normal" end
  local resolvedInfo = enrichPlayerInfoFromServerLog(info) or info
  local requestedName = valueText(name)
  local selector = valueText(resolvedInfo.steam)
  if selector == "" then selector = valueText(info.steam) end
  if selector == "" or selector == "Unknown" then selector = requestedName end
  if selector == "" or selector == "Unknown" then selector = resolvedInfo.name or "" end
  if selector == "" or selector == "Unknown" then selector = info.name or "" end
  local commandText = "ChangeCurrencyBalance " .. tostring(currency) .. " " .. tostring(amount) .. " " .. tostring(selector)
  local queued, queueIdOrMessage, depth = enqueueMutation("change-money", resolvedInfo, function()
    local liveInfo = resolvePlayerInfo(resolvedInfo.steam, resolvedInfo.name, resolvedInfo, resolvedInfo.runtimeKey) or resolvedInfo
    do
    if configBool("bridge-safety", { "RefreshPlayerBeforeMoneyChange", "refreshPlayerBeforeMoneyChange" }, false) then
      local refreshedMoneyInfo = refreshRuntimePlayerInfo(liveInfo)
      if refreshedMoneyInfo ~= nil then liveInfo = refreshedMoneyInfo end
    end
    local directSelector = valueText(liveInfo.steam)
    if directSelector == "" or directSelector == "Unknown" then directSelector = valueText(liveInfo.name) end
    if directSelector == "" or directSelector == "Unknown" then directSelector = selector end
    if directSelector == "" or directSelector == "Unknown" then
      appendActionEvent("change_money_execute", false, liveInfo, "missing target selector",
        '{"amount":' .. tostring(tonumber(amount) or 0) ..
        ',"currency":' .. js(currency) ..
        ',"selector":""}')
      return
    end
    local directCommand = "ChangeCurrencyBalance " .. tostring(currency) .. " " .. tostring(amount) .. " " .. tostring(directSelector)
    local directSent, directMessage = adminExec(directCommand, liveInfo)
    appendActionEvent("change_money_execute", directSent, liveInfo, tostring(directMessage or ""),
      '{"amount":' .. tostring(tonumber(amount) or 0) ..
      ',"currency":' .. js(currency) ..
      ',"selector":' .. js(directSelector) ..
      ',"command":' .. js(directCommand) .. '}')
    appendLog("queued money command target=" .. tostring(directSelector) ..
      " amount=" .. tostring(amount) ..
      " currency=" .. tostring(currency) ..
      " sent=" .. tostring(directSent) ..
      " route=" .. tostring(directMessage or ""))
    return
    end
    local readyInfo, ready, readyDetail, readyReason = deliveryReadyInfo(liveInfo, { requireInventory = false })
    if not ready then
      appendActionEvent("delivery_readiness", false, liveInfo, tostring(readyDetail or ""),
        '{"reason":' .. js(readyReason or "") ..
        ',"action":"change_money","amount":' .. tostring(tonumber(amount) or 0) ..
        ',"currency":' .. js(currency) .. '}')
      appendLog("queued money command skipped readiness target=" .. tostring(selector) .. " reason=" .. tostring(readyReason or ""))
      return
    end
    liveInfo = readyInfo or liveInfo
    local liveSelector = valueText(liveInfo.steam)
    if liveSelector == "" or liveSelector == "Unknown" then liveSelector = valueText(liveInfo.name) end
    if liveSelector == "" or liveSelector == "Unknown" then liveSelector = selector end
    local liveCommand = "ChangeCurrencyBalance " .. tostring(currency) .. " " .. tostring(amount) .. " " .. tostring(liveSelector)
    local sent, message = adminExec(liveCommand, liveInfo)
    appendActionEvent("change_money_execute", sent, liveInfo, tostring(message or ""),
      '{"amount":' .. tostring(tonumber(amount) or 0) ..
      ',"currency":' .. js(currency) ..
      ',"selector":' .. js(liveSelector) ..
      ',"command":' .. js(liveCommand) .. '}')
    appendLog("queued money command target=" .. tostring(liveSelector) ..
      " amount=" .. tostring(amount) ..
      " currency=" .. tostring(currency) ..
      " sent=" .. tostring(sent) ..
      " route=" .. tostring(message or ""))
  end)
  appendEconomyEvent("balance change requested", resolvedInfo.name, resolvedInfo.steam, amount, currency, queued)
  appendActionEvent("change_money", queued, resolvedInfo, queued and "Изменение баланса поставлено в live-очередь." or tostring(queueIdOrMessage or "Не удалось поставить изменение баланса в live-очередь."),
    '{"amount":' .. tostring(tonumber(amount) or 0) ..
    ',"currency":' .. js(currency) ..
    ',"selector":' .. js(selector) ..
    ',"queueId":' .. (queued and tostring(queueIdOrMessage) or "null") ..
    ',"depth":' .. tostring(depth or 0) ..
    ',"queued":' .. (queued and "true" or "false") .. '}')
  return queued, queued and "Изменение баланса поставлено в live-очередь." or tostring(queueIdOrMessage or "Не удалось поставить изменение баланса в live-очередь.")
end

local function setFame(steamId, name, amount, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then info = resolvePlayerInfo(steamId, name, nil, runtimeKey) or { steam = tostring(steamId or ""), name = tostring(name or ""), runtimeKey = tostring(runtimeKey or ""), source = "fame-identity" } end
  if tostring(info.steam or "") == "" then info.steam = tostring(steamId or "") end
  if tostring(info.name or "") == "" or tostring(info.name or "") == "Unknown" then info.name = tostring(name or "") end
  if info == nil then
    appendActionEvent("set_fame", false, { steam = steamId, name = name }, "Игрок не найден среди реально подключённых.",
      '{"amount":' .. tostring(tonumber(amount) or 0) .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  local resolvedInfo = enrichPlayerInfoFromServerLog(info) or info
  local target = resolvedInfo.steam ~= "" and resolvedInfo.steam or resolvedInfo.name
  local commandText = "#SetFamePoints " .. tostring(amount) .. " " .. tostring(target)
  local queued, queueIdOrMessage, depth = enqueueMutation("set-fame", resolvedInfo, function()
    local liveInfo = resolvePlayerInfo(resolvedInfo.steam, resolvedInfo.name, resolvedInfo, resolvedInfo.runtimeKey) or resolvedInfo
    local liveTarget = liveInfo.steam ~= "" and liveInfo.steam or liveInfo.name
    if liveInfo.pc ~= nil and isValidObject(liveInfo.pc) then
      local directOk, directErr = safeCall(liveInfo.pc, "SetFamePoints", tonumber(amount) or 0)
      if directOk then
        appendActionEvent("set_fame_execute", true, liveInfo, "direct ConZPlayerController.SetFamePoints",
          '{"amount":' .. tostring(tonumber(amount) or 0) .. ',"route":"direct-pc"}')
        appendLog("queued fame command target=" .. tostring(liveTarget) ..
          " amount=" .. tostring(amount) ..
          " sent=true route=direct-pc")
        return
      end
      appendLog("direct SetFamePoints failed: " .. tostring(directErr))
    end
    local liveCommand = "#SetFamePoints " .. tostring(amount) .. " " .. tostring(liveTarget)
    local sent, message = adminExec(liveCommand, liveInfo)
    appendActionEvent("set_fame_execute", sent, liveInfo, tostring(message or ""),
      '{"amount":' .. tostring(tonumber(amount) or 0) .. ',"command":' .. js(liveCommand) .. '}')
    appendLog("queued fame command target=" .. tostring(liveTarget) ..
      " amount=" .. tostring(amount) ..
      " sent=" .. tostring(sent) ..
      " route=" .. tostring(message or ""))
  end)
  appendActionEvent("set_fame", queued, resolvedInfo, queued and "Изменение славы поставлено в live-очередь." or tostring(queueIdOrMessage or "Не удалось поставить изменение славы в live-очередь."),
    '{"amount":' .. tostring(tonumber(amount) or 0) ..
    ',"command":' .. js(commandText) ..
    ',"queueId":' .. (queued and tostring(queueIdOrMessage) or "null") ..
    ',"depth":' .. tostring(depth or 0) ..
    ',"queued":' .. (queued and "true" or "false") .. '}')
  return queued, queued and "Изменение славы поставлено в live-очередь." or tostring(queueIdOrMessage or "Не удалось поставить изменение славы в live-очередь.")
end

local function changeFamePoints(steamId, name, amount, runtimeKey)
  amount = tonumber(amount) or 0
  if amount == 0 then
    appendActionEvent("change_fame", true, { steam = steamId, name = name, runtimeKey = runtimeKey }, "Слава не изменена: сумма 0.", '{"amount":0,"queued":false}')
    return true, "Слава не изменена: сумма 0."
  end
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then info = resolvePlayerInfo(steamId, name, nil, runtimeKey) or { steam = tostring(steamId or ""), name = tostring(name or ""), runtimeKey = tostring(runtimeKey or ""), source = "fame-identity" } end
  if tostring(info.steam or "") == "" then info.steam = tostring(steamId or "") end
  if tostring(info.name or "") == "" or tostring(info.name or "") == "Unknown" then info.name = tostring(name or "") end
  if info == nil then
    appendActionEvent("change_fame", false, { steam = steamId, name = name }, "Игрок не найден среди реально подключённых.",
      '{"amount":' .. tostring(tonumber(amount) or 0) .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  local resolvedInfo = enrichPlayerInfoFromServerLog(info) or info
  local selector = valueText(resolvedInfo.steam)
  if selector == "" or selector == "Unknown" then selector = valueText(info.steam) end
  if selector == "" or selector == "Unknown" then selector = valueText(resolvedInfo.name) end
  if selector == "" or selector == "Unknown" then selector = valueText(info.name) end
  local commandText = "ChangeFamePoints " .. tostring(amount) .. " " .. tostring(selector)
  local queued, queueIdOrMessage, depth = enqueueMutation("change-fame", resolvedInfo, function()
    local liveInfo = resolvePlayerInfo(resolvedInfo.steam, resolvedInfo.name, resolvedInfo, resolvedInfo.runtimeKey) or resolvedInfo
    local liveSelector = valueText(liveInfo.steam)
    if liveSelector == "" or liveSelector == "Unknown" then liveSelector = valueText(liveInfo.name) end
    if liveSelector == "" or liveSelector == "Unknown" then liveSelector = selector end
    if liveSelector == "" or liveSelector == "Unknown" then
      appendActionEvent("change_fame_execute", false, liveInfo, "missing target selector",
        '{"amount":' .. tostring(tonumber(amount) or 0) .. ',"selector":""}')
      return
    end
    local liveCommand = "ChangeFamePoints " .. tostring(amount) .. " " .. tostring(liveSelector)
    local sent, message = adminExec(liveCommand, liveInfo)
    appendActionEvent("change_fame_execute", sent, liveInfo, tostring(message or ""),
      '{"amount":' .. tostring(tonumber(amount) or 0) ..
      ',"selector":' .. js(liveSelector) ..
      ',"command":' .. js(liveCommand) .. '}')
    appendLog("queued fame change command target=" .. tostring(liveSelector) ..
      " amount=" .. tostring(amount) ..
      " sent=" .. tostring(sent) ..
      " route=" .. tostring(message or ""))
  end)
  appendActionEvent("change_fame", queued, resolvedInfo, queued and "Начисление очков славы поставлено в live-очередь." or tostring(queueIdOrMessage or "Не удалось поставить начисление очков славы в live-очередь."),
    '{"amount":' .. tostring(tonumber(amount) or 0) ..
    ',"command":' .. js(commandText) ..
    ',"queueId":' .. (queued and tostring(queueIdOrMessage) or "null") ..
    ',"depth":' .. tostring(depth or 0) ..
    ',"queued":' .. (queued and "true" or "false") .. '}')
  return queued, queued and "Начисление очков славы поставлено в live-очередь." or tostring(queueIdOrMessage or "Не удалось поставить начисление очков славы в live-очередь.")
end

local itemClassPaths = {
  apple_2 = "/Game/ConZ_Files/Items/Food/Fruit/Apple_2.Apple_2_C",
  emergency_bandage_big = "/Game/ConZ_Files/Items/Equipment/Active_Items/Emergency_bandage_Big.Emergency_bandage_Big_C",
  emergency_bandage = "/Game/ConZ_Files/Items/Equipment/Active_Items/Emergency_bandage.Emergency_bandage_C",
  cannedgoulash = "/Game/ConZ_Files/Items/Food/Canned_Food/CannedGoulash.CannedGoulash_C",
  beefravioli = "/Game/ConZ_Files/Items/Food/Canned_Food/BeefRavioli.BeefRavioli_C",
  bamboo_hat_02 = "/Game/ConZ_Files/Items/Clothes/Headgear/Bamboo_Hat_02.Bamboo_Hat_02_C",
  beijing_shoes_04 = "/Game/ConZ_Files/Items/Clothes/Footwear/Beijing_Shoes_04.Beijing_Shoes_04_C",
  tang_pants_04 = "/Game/ConZ_Files/Items/Clothes/Underwear_Pants/Tang_pants_04.Tang_pants_04_C",
  tang_shirt_04 = "/Game/ConZ_Files/Items/Clothes/Tops_And_TShirts/Tang_shirt_04.Tang_shirt_04_C",
  water_05l = "/Game/ConZ_Files/Items/Drink/Water_05l.Water_05l_C",
  mre_cheeseburger = "/Game/ConZ_Files/Items/Food/Canned_Food/MRE_Cheeseburger.MRE_Cheeseburger_C",
  weapon_ak47 = "/Game/ConZ_Files/Items/Weapons/Ranged_Weapons/Weapon_AK47.Weapon_AK47_C",
  magazine_ak47 = "/Game/ConZ_Files/Items/Weapons/Weapon_Clips/Magazine_AK47.Magazine_AK47_C",
  cal_7_62x39mm = "/Game/ConZ_Files/Items/Ammunition/Cal_7_62x39mm.Cal_7_62x39mm_C",
  cal_7_62x39mm_ammobox = "/Game/ConZ_Files/Items/Ammunition/Ammoboxes/Cal_7_62x39mm_Ammobox.Cal_7_62x39mm_Ammobox_C"
}
itemClassPaths.tang_shirt_04 = "/Game/ConZ_Files/Items/Clothes/Tops_And_T_Shirts/Tang_shirt_04.Tang_shirt_04_C"

local function vehicleClassHints(vehicleId)
  local raw = tostring(vehicleId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  raw = raw:gsub("^Vehicle:", "")
  local token = raw:gsub("^BPC_", ""):gsub("_C$", "")
  local genericHints = {
    "VehicleBase",
    "ConZVehicle",
    "ConZVehicleBase",
    "DcxVehicle",
    "DcxWheeledVehicle",
    "DcxWheeledVehicle4W",
    "DcxWheeledVehicleNW",
    "BP_VehicleBase_C",
    "BP_Vehicle_C"
  }
  local hints = {}
  if raw ~= "" then
    table.insert(hints, raw)
    table.insert(hints, raw .. "_C")
  end
  if token ~= "" then
    table.insert(hints, "BPC_" .. token)
    table.insert(hints, "BPC_" .. token .. "_C")
    table.insert(hints, "BP_" .. token)
    table.insert(hints, "BP_" .. token .. "_C")
  end
  if #hints == 0 then hints = genericHints end
  return hints
end

vehicleRuntimeKeySet = function(vehicleId)
  local seen = {}
  for _, vehicle in ipairs(findAll(vehicleClassHints(vehicleId))) do
    local key = objectKey(vehicle)
    if key ~= "" then seen[key] = true end
  end
  return seen
end

local function vehicleLooksLike(vehicle, vehicleId)
  local raw = tostring(vehicleId or ""):lower():gsub("^vehicle:", ""):gsub("_c$", "")
  local token = raw:gsub("^bpc_", ""):gsub("^bp_", "")
  if token == "" then return true end
  local full = objectFullName(vehicle):lower()
  return full:find(token, 1, true) ~= nil
end

function nearestNewVehicleRefAt(px, py, pz, vehicleId, beforeKeys, allowGenericFallback)
  px = tonumber(px) or 0
  py = tonumber(py) or 0
  pz = tonumber(pz) or 0
  local vehicles = findAll(vehicleClassHints(vehicleId))
  local function pick(requireLooksLike)
    local best = nil
    local bestDistance = nil
    for _, vehicle in ipairs(vehicles) do
      local key = objectKey(vehicle)
      if key ~= "" and (beforeKeys == nil or not beforeKeys[key]) and (not requireLooksLike or vehicleLooksLike(vehicle, vehicleId)) then
        local vx, vy, vz = vectorOf(vehicle)
        local dx, dy, dz = vx - px, vy - py, vz - pz
        local distance = math.sqrt(dx * dx + dy * dy + dz * dz)
        if distance <= 50000 and (bestDistance == nil or distance < bestDistance) then
          best = key
          bestDistance = distance
        end
      end
    end
    return best, bestDistance
  end
  local best, bestDistance = pick(true)
  if best == nil and allowGenericFallback == true and beforeKeys ~= nil then
    best, bestDistance = pick(false)
  end
  if best == nil then
    appendLog("vehicle runtime tracking miss vehicle=" .. tostring(vehicleId) .. " candidates=" .. tostring(#vehicles) .. " before=" .. (beforeKeys ~= nil and "yes" or "no"))
    return ""
  end
  appendLog("vehicle runtime tracked ref=runtime:" .. tostring(best) .. " distance=" .. tostring(math.floor((bestDistance or 0) + 0.5)))
  return "runtime:" .. tostring(best)
end

nearestNewVehicleRef = function(info, vehicleId, beforeKeys, allowGenericFallback)
  if info == nil or info.pawn == nil then return "" end
  local px, py, pz = vectorOf(info.pawn)
  return nearestNewVehicleRefAt(px, py, pz, vehicleId, beforeKeys, allowGenericFallback)
end

local function resolveRentalDestroyRef(active, info)
  if active == nil then return "" end
  local vehicleId = extractString(active, "vehicleId") or ""
  if vehicleId == "" then return "" end
  if info ~= nil and info.pawn ~= nil then
    local liveRef = nearestNewVehicleRef(info, vehicleId, nil, true)
    if liveRef ~= "" then return liveRef end
  end
  local recordedX = extractNumber(active, "x")
  local recordedY = extractNumber(active, "y")
  local recordedZ = extractNumber(active, "z") or 0
  if recordedX ~= nil and recordedY ~= nil then
    local recordedRef = nearestNewVehicleRefAt(recordedX, recordedY, recordedZ, vehicleId, nil, true)
    if recordedRef ~= "" then return recordedRef end
  end
  return ""
end

findVehicleByRuntimeRef = function(ref)
  local key = tostring(ref or ""):gsub("^runtime:", "")
  if key == "" then return nil end
  for _, vehicle in ipairs(findAll(vehicleClassHints(""))) do
    if objectKey(vehicle) == key then return vehicle end
  end
  return nil
end

catalogItemClassPaths = nil

local function normalizeItemKey(value)
  local text = tostring(value or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  text = text:gsub("^.*/", ""):gsub("^.*\\", ""):gsub("^.*%.", ""):gsub("_c$", "")
  return text
end

local function ensureCatalogItemClassPaths()
  if catalogItemClassPaths ~= nil then return catalogItemClassPaths end
  catalogItemClassPaths = {}
  local function addCatalogPath(itemId, runtimeId)
    itemId = tostring(itemId or "")
    runtimeId = tostring(runtimeId or "")
    if itemId ~= "" and runtimeId ~= "" and runtimeId:sub(1, 6) == "/Game/" then
      catalogItemClassPaths[itemId:lower()] = runtimeId
      catalogItemClassPaths[normalizeItemKey(itemId)] = runtimeId
      catalogItemClassPaths[normalizeItemKey(runtimeId)] = runtimeId
      return true
    end
    return false
  end
  local text = readAll(ITEM_CATALOG_FILE) or ""
  local loaded = 0
  for object in text:gmatch('%b{}') do
    local itemId = extractString(object, "itemId") or extractString(object, "id") or ""
    local runtimeId = extractString(object, "runtimeId") or extractString(object, "classPath") or extractString(object, "assetPath") or ""
    if addCatalogPath(itemId, runtimeId) then loaded = loaded + 1 end
  end
  if loaded < 10 then
    loaded = 0
    catalogItemClassPaths = {}
    for itemId, runtimeId in text:gmatch('"itemId"%s*:%s*"([^"]+)".-"runtimeId"%s*:%s*"([^"]+)"') do
      if addCatalogPath(itemId, runtimeId) then loaded = loaded + 1 end
    end
  end
  local actorMapLoaded = 0
  local actorText = readAll(ITEM_ACTOR_MAP_FILE) or ""
  for itemId, runtimeId in actorText:gmatch('"([^"]+)"%s*:%s*"(/Game/[^"]+)"') do
    if addCatalogPath(itemId, runtimeId) then actorMapLoaded = actorMapLoaded + 1 end
  end
  if actorMapLoaded > 0 then
    loaded = loaded + actorMapLoaded
    appendLog("actor map paths loaded=" .. tostring(actorMapLoaded))
  end
  appendLog("item catalog class paths loaded=" .. tostring(loaded))
  return catalogItemClassPaths
end

local function resolveItemPath(itemId)
  local raw = tostring(itemId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if raw == "" then return "" end
  if raw:sub(1, 6) == "/Game/" or raw:sub(1, 8) == "/Script/" then return raw end
  local catalog = ensureCatalogItemClassPaths()
  return itemClassPaths[raw:lower()] or catalog[raw:lower()] or catalog[normalizeItemKey(raw)] or raw
end

directItemAllowList = {
  aloe_vera = true,
  activatedcharcoal_01 = true,
  air_pump = true,
  armband_01 = true,
  ["1h_crowbar"] = true,
  ["12_gauge_birdshot"] = true,
  bicycle_wheel_54_622_item = true,
  grasshopper = true,
  diallock_item = true,
  bamboo_hat_02 = true,
  beijing_shoes_04 = true,
  tang_pants_04 = true,
  tang_shirt_04 = true,
  apple_2 = true,
  beefravioli = true,
  cannedgoulash = true,
  emergency_bandage_big = true
}

function itemLooksLikeWeapon(itemId)
  local raw = tostring(itemId or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local key = normalizeItemKey(raw)
  if key:find("^weapon_") ~= nil then return true end
  if raw:find("/ranged_weapons/", 1, true) ~= nil then return true end
  if raw:find("/items/weapons/ranged_weapons/", 1, true) ~= nil then return true end
  return false
end

local function shouldUseDirectItemRoute(itemId)
  local raw = tostring(itemId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local key = normalizeItemKey(raw)
  if itemLooksLikeWeapon(raw) then return false end
  if directItemAllowList[key] == true then return true end
  if raw:sub(1, 6) == "/Game/" and raw:find("/Items/", 1, true) ~= nil and not itemLooksLikeWeapon(raw) then return true end
  local catalog = ensureCatalogItemClassPaths()
  local path = catalog[raw:lower()] or catalog[key]
  return type(path) == "string" and path:sub(1, 6) == "/Game/" and path:find("/Items/", 1, true) ~= nil and not itemLooksLikeWeapon(path)
end

local function worldFor(info)
  local okCall, world = safeCall(info.pawn, "GetWorld")
  if okCall and world ~= nil and isValidObject(world) then return world end
  okCall, world = safeCall(info.pc, "GetWorld")
  if okCall and world ~= nil and isValidObject(world) then return world end
  local root = worldRoot()
  okCall, world = safeCall(root, "GetWorld")
  if okCall and world ~= nil and isValidObject(world) then return world end
  return findFirst({"World"})
end

local function pushUnique(list, seen, value)
  value = tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if value == "" or seen[value] then return end
  seen[value] = true
  table.insert(list, value)
end

local function itemClassLoadCandidates(path)
  local raw = tostring(path or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local classPaths = {}
  local assetPaths = {}
  local seenClass = {}
  local seenAsset = {}
  pushUnique(classPaths, seenClass, raw)

  if raw:sub(1, 6) == "/Game/" then
    local packagePath, objectName = raw:match("^(.-)%.([^%.\\/]+)$")
    if packagePath ~= nil and objectName ~= nil then
      local assetName = objectName:gsub("_C$", "")
      pushUnique(assetPaths, seenAsset, packagePath)
      pushUnique(classPaths, seenClass, packagePath .. "." .. assetName .. "_C")
      pushUnique(classPaths, seenClass, packagePath .. "." .. assetName)
    else
      local leaf = raw:match("([^/\\]+)$") or raw
      local assetName = leaf:gsub("_C$", "")
      pushUnique(assetPaths, seenAsset, raw)
      pushUnique(classPaths, seenClass, raw .. "." .. assetName .. "_C")
      pushUnique(classPaths, seenClass, raw .. "." .. assetName)
    end
  end

  return classPaths, assetPaths
end

loadedItemClassCache = {}

local function loadItemClass(path)
  local cacheKey = tostring(path or ""):lower()
  local cached = loadedItemClassCache[cacheKey]
  if cached ~= nil and isValidObject(cached) then return cached, "cached item class" end

  local classPaths, assetPaths = itemClassLoadCandidates(path)
  local attempts = {}
  local found = nil

  local function remember(result, route)
    if result ~= nil and isValidObject(result) and cacheKey ~= "" then
      loadedItemClassCache[cacheKey] = result
    end
    return result, route
  end

  for _, classPath in ipairs(classPaths) do
    local okFind, result = pcall(function() return StaticFindObject(classPath) end)
    table.insert(attempts, "StaticFindObject(" .. tostring(classPath) .. ")=" .. (okFind and (isValidObject(result) and "ok" or "nil") or tostring(result)))
    if okFind and result ~= nil and isValidObject(result) then return remember(result, "StaticFindObject:" .. tostring(classPath)) end
  end

  for _, assetPath in ipairs(assetPaths) do
    local okLoad, result = pcall(function() return LoadAsset(assetPath) end)
    table.insert(attempts, "LoadAsset(" .. tostring(assetPath) .. ")=" .. (okLoad and (isValidObject(result) and "ok" or "nil") or tostring(result)))
    if okLoad and result ~= nil and isValidObject(result) then found = result end
  end

  for _, classPath in ipairs(classPaths) do
    local okFind, result = pcall(function() return StaticFindObject(classPath) end)
    table.insert(attempts, "post StaticFindObject(" .. tostring(classPath) .. ")=" .. (okFind and (isValidObject(result) and "ok" or "nil") or tostring(result)))
    if okFind and result ~= nil and isValidObject(result) then return remember(result, "LoadAsset+StaticFindObject:" .. tostring(classPath)) end
  end

  if found ~= nil and isValidObject(found) then return remember(found, "LoadAsset object fallback") end
  return nil, "класс предмета не загрузился: " .. table.concat(attempts, " | ")
end

local function spawnItemActor(info, itemClass)
  local world = worldFor(info)
  if world == nil or not isValidObject(world) then return nil, "world unresolved" end
  local x, y, z = vectorOf(info.pawn)
  local loc = { X = x + 90, Y = y, Z = z + 80 }
  local rot = { Pitch = 0, Yaw = 0, Roll = 0 }
  local attempts = {}
  local okCall, actor = safeCall(world, "SpawnActor", itemClass, loc, rot)
  table.insert(attempts, "world.SpawnActor(3)=" .. (okCall and "ok" or tostring(actor)))
  if okCall and actor ~= nil and isValidObject(actor) then return actor, "world.SpawnActor" end
  okCall, actor = safeCall(world, "SpawnActor", itemClass, loc)
  table.insert(attempts, "world.SpawnActor(2)=" .. (okCall and "ok" or tostring(actor)))
  if okCall and actor ~= nil and isValidObject(actor) then return actor, "world.SpawnActor" end
  return nil, table.concat(attempts, " | ")
end

local function placeItemForPlayer(info, item)
  local attempts = {}
  local okCall, result = safeCall(info.pawn, "PlaceItemInInventoryOrHolster", item, true)
  table.insert(attempts, "pawn.PlaceItemInInventoryOrHolster=" .. (okCall and "ok" or tostring(result)))
  if okCall and result ~= false then return true, "placed through prisoner inventory" end

  local inv = firstProp(info.pawn, {"PrisonerInventoryComponent", "InventoryComponent", "Inventory", "CharacterInventoryComponent", "InventoryUserComponent"})
  if inv ~= nil and isValidObject(inv) then
    okCall, result = safeCall(inv, "AutoAddItemOnServer", item, true)
    table.insert(attempts, "inventory.AutoAddItemOnServer=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then return true, "placed through inventory AutoAddItemOnServer" end
    okCall, result = safeCall(inv, "EquipClothesItemOnServer", item)
    table.insert(attempts, "inventory.EquipClothesItemOnServer=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then return true, "equipped as clothes through inventory" end
    okCall, result = safeCall(inv, "EquipItemInHandsOnServer", item)
    table.insert(attempts, "inventory.EquipItemInHandsOnServer=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then return true, "equipped in hands through inventory" end
  end

  okCall, result = safeCall(info.pawn, "TakeItemInHands", item)
  table.insert(attempts, "pawn.TakeItemInHands=" .. (okCall and "ok" or tostring(result)))
  if okCall and result ~= false then return true, "taken in hands through prisoner" end
  return false, table.concat(attempts, " | ")
end

local function equipItemForPlayer(info, item)
  local attempts = {}
  local okCall, result = safeCall(info.pawn, "CanTakeItemInHands", item)
  table.insert(attempts, "pawn.CanTakeItemInHands=" .. (okCall and tostring(result) or tostring(result)))

  local inv = firstProp(info.pawn, {"PrisonerInventoryComponent", "InventoryComponent", "Inventory", "CharacterInventoryComponent", "InventoryUserComponent"})
  if inv ~= nil and isValidObject(inv) then
    okCall, result = safeCall(inv, "EquipItemInHandsOnServer", item)
    table.insert(attempts, "inventory.EquipItemInHandsOnServer=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then return true, "equipped in hands through inventory" end
    okCall, result = safeCall(inv, "Server_CharacterInventoryComponent_SetItemInHands", inv, item)
    table.insert(attempts, "inventory.Server_CharacterInventoryComponent_SetItemInHands=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then return true, "equipped in hands through server inventory RPC" end
  end

  okCall, result = safeCall(info.pawn, "TakeItemInHands", item)
  table.insert(attempts, "pawn.TakeItemInHands=" .. (okCall and "ok" or tostring(result)))
  if okCall and result ~= false then return true, "taken in hands through prisoner" end

  okCall, result = safeCall(info.pawn, "PlaceItemInInventoryOrHolster", item, true)
  table.insert(attempts, "pawn.PlaceItemInInventoryOrHolster=" .. (okCall and "ok" or tostring(result)))
  if okCall and result ~= false then return false, "hands route failed; item was placed in inventory. " .. table.concat(attempts, " | ") end

  return false, table.concat(attempts, " | ")
end

local function destroySpawnedItem(item)
  if item == nil or not isValidObject(item) then return end
  local okCall = false
  okCall = safeCall(item, "K2_DestroyActor")
  if okCall then return end
  safeCall(item, "Destroy")
end

local function itemAdminCommandId(itemId)
  local raw = tostring(itemId or ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub("^Item:", "")
  if raw:sub(1, 6) == "/Game/" then
    local objectName = raw:match("%.([^%.\\/]+)$") or raw:match("([^/\\]+)$") or raw
    raw = objectName:gsub("_C$", "")
  end
  return raw:gsub("[^%w_:/%.%-]", "")
end

local function itemRuntimeClassHints(itemId, classPath, assetPath)
  local hints = {}
  local seen = {}
  local function add(value)
    value = tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if value == "" then return end
    if value:sub(1, 6) == "/Game/" then
      local objectName = value:match("%.([^%.\\/]+)$") or value:match("([^/\\]+)$") or value
      local assetName = objectName:gsub("_C$", "")
      pushUnique(hints, seen, objectName)
      pushUnique(hints, seen, assetName)
      pushUnique(hints, seen, assetName .. "_C")
      return
    end
    value = value:gsub("^Item:", "")
    pushUnique(hints, seen, value)
    pushUnique(hints, seen, value:gsub("_C$", "") .. "_C")
    pushUnique(hints, seen, "BP_" .. value:gsub("_C$", ""))
    pushUnique(hints, seen, "BP_" .. value:gsub("_C$", "") .. "_C")
  end
  add(itemId)
  add(resolveItemPath(itemId))
  add(classPath)
  add(assetPath)
  pushUnique(hints, seen, "Item")
  pushUnique(hints, seen, "ItemBase")
  pushUnique(hints, seen, "InventoryItem")
  pushUnique(hints, seen, "ConZItem")
  pushUnique(hints, seen, "BP_ItemBase_C")
  return hints
end

local function objectEntityIdText(obj)
  local id = objectDbId(obj,
    {"GetEntityId", "GetEntityID", "GetDatabaseId", "GetDatabaseID", "GetDBId", "GetItemEntityId", "GetItemEntityID"},
    {"EntityId", "EntityID", "entityId", "_entityId", "DatabaseId", "DatabaseID", "DBId", "_databaseId", "ItemEntityId", "ItemEntityID"})
  if id ~= "" then return id end
  local printed = ""
  pcall(function() printed = tostring(obj) end)
  id = printed:match("EntityId%s*=%s*(%d+)") or printed:match("EntityID%s*=%s*(%d+)") or printed:match("DatabaseId%s*=%s*(%d+)")
  return tostring(id or "")
end

local function findInventoryItemObject(entityId, itemId, classPath, assetPath)
  local wanted = tostring(entityId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if wanted == "" then return nil, "entity id is missing" end
  local runtimeKey = wanted:gsub("^runtime:", "")
  local hints = itemRuntimeClassHints(itemId, classPath, assetPath)
  local scanned = 0
  for _, item in ipairs(findAll(hints)) do
    scanned = scanned + 1
    if objectKey(item) == runtimeKey then
      return item, "runtime key match"
    end
    local objectId = objectEntityIdText(item)
    if objectId ~= "" and objectId == wanted then
      return item, "entity id match"
    end
  end
  return nil, "item runtime object not found; scanned " .. tostring(scanned)
end

local function itemObjectNameText(obj)
  if obj == nil then return "" end
  local parts = {}
  local okName, name = pcall(function() return obj:GetName() end)
  if okName and name ~= nil then table.insert(parts, tostring(name)) end
  local okFull, full = pcall(function() return obj:GetFullName() end)
  if okFull and full ~= nil then table.insert(parts, tostring(full)) end
  local okClass, cls = pcall(function() return obj:GetClass() end)
  if okClass and cls ~= nil then table.insert(parts, objectFullName(cls)) end
  table.insert(parts, tostring(obj))
  return table.concat(parts, " ")
end

local function itemObjectMatchesHints(obj, itemId, classPath, assetPath)
  local hints = itemRuntimeClassHints(itemId, classPath, assetPath)
  local text = itemObjectNameText(obj):lower()
  if text == "" then return false end
  for _, hint in ipairs(hints) do
    local key = normalizeItemKey(hint)
    if key ~= "" and text:find(key, 1, true) ~= nil then return true end
    local lower = tostring(hint or ""):lower()
    if lower ~= "" and text:find(lower, 1, true) ~= nil then return true end
  end
  return false
end

local function itemInHandsObject(info, itemId, classPath, assetPath)
  if info == nil or info.pawn == nil or not isValidObject(info.pawn) then return nil, "pawn missing" end
  local candidates = {}
  for _, method in ipairs({ "GetItemInHands", "GetItemInHandsOnServer", "GetHeldItem", "GetCurrentItemInHands" }) do
    local okCall, value = safeCall(info.pawn, method)
    if okCall and value ~= nil and isValidObject(value) then table.insert(candidates, { value = value, route = "pawn." .. method }) end
  end
  for _, prop in ipairs({ "ItemInHands", "_itemInHands", "CurrentItemInHands", "HeldItem", "EquippedItem" }) do
    local value = firstProp(info.pawn, { prop })
    if value ~= nil and isValidObject(value) then table.insert(candidates, { value = value, route = "pawn." .. prop }) end
  end
  local inv = playerInventoryComponent(info)
  if inv ~= nil and isValidObject(inv) then
    for _, method in ipairs({ "GetItemInHands", "GetItemInHandsOnServer", "GetHeldItem", "GetCurrentItemInHands" }) do
      local okCall, value = safeCall(inv, method)
      if okCall and value ~= nil and isValidObject(value) then table.insert(candidates, { value = value, route = "inventory." .. method }) end
    end
    for _, prop in ipairs({ "ItemInHands", "_itemInHands", "CurrentItemInHands", "HeldItem", "EquippedItem" }) do
      local value = firstProp(inv, { prop })
      if value ~= nil and isValidObject(value) then table.insert(candidates, { value = value, route = "inventory." .. prop }) end
    end
  end
  for _, candidate in ipairs(candidates) do
    if itemObjectMatchesHints(candidate.value, itemId, classPath, assetPath) then
      return candidate.value, candidate.route
    end
  end
  if #candidates == 1 and tostring(itemId or "") == "" and tostring(classPath or "") == "" and tostring(assetPath or "") == "" then
    return candidates[1].value, candidates[1].route .. " single"
  end
  return nil, "item in hands did not match hints; candidates=" .. tostring(#candidates)
end

local function cleanEntityIdText(value)
  local text = tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local id = text:match("^(%d+)$") or text:match("entity[:=](%d+)") or text:match("(%d+)")
  return tostring(id or "")
end

local function destroyInventoryEntityByAdmin(entityId, info)
  local id = cleanEntityIdText(entityId)
  if id == "" or id == "0" then return false, "EntityID предмета невалидный." end
  local commandObject = firstValidAdminCommandObject("DestroyEntity")
  local sent, message = adminExec("DestroyEntity " .. id, info)
  if sent then return true, "DestroyEntity " .. id .. " отправлен через " .. tostring(message or "admin route") end
  if commandObject == nil then
    return false, "DestroyEntity не отправлен: объект admin-команды не найден, admin route ответил: " .. tostring(message or "")
  end
  return false, tostring(message or "DestroyEntity не отправлен")
end

local function destroyInventoryItemObject(item, info)
  if item == nil or not isValidObject(item) then return false, "item object is not valid" end
  local attempts = {}
  local inv = playerInventoryComponent(info)
  if inv ~= nil and isValidObject(inv) then
    for _, method in ipairs({"Server_DestroyItem", "DestroyItem", "Server_RemoveItem", "RemoveItem", "RemoveItemFromInventory", "Server_DropItem", "DropItem"}) do
      local okCall, result = safeCall(inv, method, item)
      table.insert(attempts, "inventory." .. method .. "=" .. (okCall and "ok" or tostring(result)))
      if okCall and result ~= false then return true, "removed through inventory " .. method end
    end
  end
  for _, method in ipairs({"Server_DestroyItem", "DestroyItem", "Server_DropItem", "DropItem", "K2_DestroyActor", "Destroy"}) do
    local okCall, result = safeCall(item, method)
    table.insert(attempts, "item." .. method .. "=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then return true, "removed through item " .. method end
  end
  return false, table.concat(attempts, " | ")
end

local function destroyInventoryEntitySmart(entityId, live, itemId, classPath, assetPath)
  local cleanEntityId = cleanEntityIdText(entityId)
  if cleanEntityId == "" then return false, "EntityID предмета не указан.", "none" end
  local preferLive = configBool("bridge-safety", { "PreferLiveInventoryDelete", "preferLiveInventoryDelete" }, false)
  if not preferLive then
    local adminRemoved, adminMessage = destroyInventoryEntityByAdmin(cleanEntityId, live)
    if adminRemoved then
      return true, tostring(adminMessage), "DestroyEntity"
    end
  end
  local item, findRoute = findInventoryItemObject(cleanEntityId, itemId, classPath, assetPath)
  if item == nil then
    item, findRoute = itemInHandsObject(live, itemId, classPath, assetPath)
  end
  if item ~= nil then
    local removed, message = destroyInventoryItemObject(item, live)
    if removed then
      return true, tostring(message), "live:" .. tostring(findRoute or "")
    end
    local adminRemoved, adminMessage = destroyInventoryEntityByAdmin(cleanEntityId, live)
    if adminRemoved then
      return true, tostring(adminMessage), "DestroyEntity-after-live"
    end
    return false, tostring(message) .. " | " .. tostring(adminMessage), "live-failed:" .. tostring(findRoute or "")
  end
  if preferLive then
    local adminRemoved, adminMessage = destroyInventoryEntityByAdmin(cleanEntityId, live)
    if adminRemoved then
      return true, tostring(adminMessage), "DestroyEntity"
    end
    return false, tostring(adminMessage or "") .. " | " .. tostring(findRoute or ""), "not-found"
  end
  return false, "DestroyEntity не сработал, live fallback тоже не нашёл предмет. " .. tostring(findRoute or ""), "not-found"
end

local function deleteInventoryItem(steamId, name, runtimeKey, entityId, itemId, classPath, assetPath)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then return false, "Игрок не найден среди реально подключённых." end
  local cleanEntityId = cleanEntityIdText(entityId)
  if cleanEntityId == "" then return false, "EntityID предмета не указан." end
  local live = livePlayerForTarget(info.steam, info.name, info.runtimeKey, info)
  if live == nil then return false, "Игрок есть в панели, но live-controller сейчас не найден. Подожди несколько секунд после входа игрока и обнови список игроков." end
  local removed, message, route = destroyInventoryEntitySmart(cleanEntityId, live, itemId, classPath, assetPath)
  appendActionEvent("delete_inventory_item", removed, live, tostring(message),
    '{"entityId":' .. js(cleanEntityId) .. ',"itemId":' .. js(itemId or "") .. ',"route":' .. js(route or "") .. ',"queued":false}')
  if tostring(live.steam or live.name or "") ~= "" then
    targetMessage(live.steam, live.name, removed and "Предмет удалён администратором." or ("Предмет не удалён: " .. tostring(message)), "inventory", live.runtimeKey)
  end
  return removed, tostring(message or (removed and "Предмет удалён." or "Предмет не удалён."))
end

local function parseEntityIdsText(value)
  local ids = {}
  local seen = {}
  local text = tostring(value or "")
  for id in text:gmatch("%d+") do
    id = tostring(id or "")
    if id ~= "" and id ~= "0" and seen[id] == nil then
      seen[id] = true
      table.insert(ids, id)
      if #ids >= 80 then break end
    end
  end
  return ids
end

local function destroyInventoryEntitiesBatch(steamId, name, runtimeKey, entitiesText)
  local ids = parseEntityIdsText(entitiesText)
  if #ids == 0 then return false, "EntityID list is empty." end
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then return false, "Игрок не найден среди реально подключённых." end
  info = enrichPlayerInfoFromServerLog(info) or info
  local maxPerBatch = math.max(1, math.min(tonumber(configNumber("bridge-safety", { "InventoryDeleteBatchSize", "inventoryDeleteBatchSize" }, 24)) or 24, 40))
  local requestedCount = #ids
  if #ids > maxPerBatch then
    local trimmed = {}
    for i = 1, maxPerBatch do trimmed[i] = ids[i] end
    ids = trimmed
  end
  local live = livePlayerForTarget(info.steam, info.name, info.runtimeKey, info)
  if live == nil then
    appendActionEvent("delete_inventory_batch", false, info, "Fast cleanup skipped: live player controller was not found.",
      '{"requested":' .. tostring(requestedCount) .. ',"sent":0,"queued":false}')
    return false, "Игрок есть в панели, но live-controller сейчас не найден. Подожди несколько секунд после входа игрока и обнови список игроков.", '{"requested":' .. tostring(requestedCount) .. ',"sent":0,"queued":false}'
  end
  local sentCount = 0
  local failed = {}
  local routes = {}
  for _, id in ipairs(ids) do
    local sent, message, route = destroyInventoryEntitySmart(id, live, "", "", "")
    if sent then
      sentCount = sentCount + 1
      table.insert(routes, tostring(id) .. ":" .. tostring(route or ""))
    else
      table.insert(failed, tostring(id) .. ":" .. tostring(message or "failed"))
    end
  end
  appendActionEvent("delete_inventory_batch", sentCount == #ids, live,
    "Inventory batch removed " .. tostring(sentCount) .. "/" .. tostring(#ids),
    '{"requested":' .. tostring(requestedCount) .. ',"batchSize":' .. tostring(#ids) .. ',"sent":' .. tostring(sentCount) .. ',"failed":' .. js(table.concat(failed, " | ")) .. ',"routes":' .. js(table.concat(routes, " | ")) .. ',"queued":false}')
  if live ~= nil and tostring(live.steam or live.name or "") ~= "" then
    targetMessage(live.steam, live.name, "Администратор удаляет предметы: отправлено " .. tostring(sentCount) .. "/" .. tostring(#ids) .. ".", "inventory", live.runtimeKey)
  end
  return sentCount == #ids, "Inventory batch removed " .. tostring(sentCount) .. "/" .. tostring(#ids),
    '{"requested":' .. tostring(requestedCount) .. ',"batchSize":' .. tostring(#ids) .. ',"sent":' .. tostring(sentCount) .. ',"failed":' .. js(table.concat(failed, " | ")) .. ',"routes":' .. js(table.concat(routes, " | ")) .. ',"queued":false}'
end

local function deliverItemThroughAdminSpawn(info, itemId, quantity)
  itemId = tostring(itemId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  quantity = math.max(1, math.min(tonumber(quantity) or 1, 100))
  local safeItem = itemAdminCommandId(itemId)
  if safeItem == "" then return 0, quantity, itemId, {"admin SpawnItem skipped: unsafe item id"} end
  local commandText = "SpawnItem " .. safeItem .. " " .. tostring(quantity)
  local targetSteam = tostring((info or {}).steam or "")
  if looksLikeSteamId(targetSteam) then commandText = commandText .. " Location " .. targetSteam end
  local sent, message = adminExec(commandText, info)
  if sent then
    return quantity, quantity, safeItem, {"admin SpawnItem dispatched: " .. tostring(message or "") .. " command=#" .. commandText}
  end
  return 0, quantity, safeItem, {"admin SpawnItem failed: " .. tostring(message or "") .. " command=#" .. commandText}
end

local function deliverItemTypeForInfo(info, itemId, quantity)
  itemId = tostring(itemId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  quantity = math.max(1, math.min(tonumber(quantity) or 1, 100))
  if itemId == "" then return 0, quantity, "", {"ID предмета не указан"} end
  if itemLooksLikeWeapon(itemId) then
    return deliverItemThroughAdminSpawn(info, itemId, quantity)
  end
  if itemId:sub(1, 6) ~= "/Game/" and itemId:sub(1, 8) ~= "/Script/" then
    local adminCount, adminRequested, adminPath, adminDetails = deliverItemThroughAdminSpawn(info, itemId, quantity)
    if adminCount == adminRequested then return adminCount, adminRequested, adminPath, adminDetails end
    local directAllowed = shouldUseDirectItemRoute(itemId)
    if not directAllowed then return adminCount, adminRequested, adminPath, adminDetails end
  end
  if not shouldUseDirectItemRoute(itemId) then
    return 0, quantity, itemId, {"безопасная direct-выдача для этого предмета ещё не подтверждена; SpawnItem fallback отключён"}
  end
  local path = resolveItemPath(itemId)
  local okCount = 0
  local details = {}
  local itemClass, loadRoute = loadItemClass(path)
  if itemClass == nil then
    table.insert(details, "загрузка не удалась: " .. tostring(loadRoute))
    return okCount, quantity, path, details
  end
  for i = 1, quantity do
    local delivered = false
    local attemptDetails = {}
    for attempt = 1, 3 do
      local liveInfo = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
      local actor, spawnRoute = spawnItemActor(liveInfo, itemClass)
      if actor == nil then
        table.insert(attemptDetails, "attempt " .. tostring(attempt) .. " spawn failed: " .. tostring(spawnRoute))
        break
      end
      local placed, placeRoute = placeItemForPlayer(liveInfo, actor)
      if placed then
        okCount = okCount + 1
        table.insert(details, loadRoute .. " -> " .. spawnRoute .. " -> " .. placeRoute .. (attempt > 1 and (" after retry " .. tostring(attempt)) or ""))
        delivered = true
        break
      end
      okCount = okCount + 1
      table.insert(details, loadRoute .. " -> " .. spawnRoute .. " -> создан рядом с игроком; инвентарь не принял предмет: " .. tostring(placeRoute))
      delivered = true
      break
    end
    if not delivered then
      table.insert(details, table.concat(attemptDetails, " || "))
    end
  end
  return okCount, quantity, path, details
end

local function deliverItemsForInfo(preferredInfo, steamId, name, itemId, quantity, runtimeKey)
  local info = resolvePlayerInfo(steamId, name, preferredInfo, runtimeKey)
  if info == nil then info = { steam = tostring(steamId or ""), name = tostring(name or ""), source = "delivery-identity" } end
  if tostring(info.steam or "") == "" then info.steam = tostring(steamId or "") end
  if tostring(info.name or "") == "" or tostring(info.name or "") == "Unknown" then info.name = tostring(name or "") end
  local refreshedInfo = refreshRuntimePlayerInfo(info)
  if refreshedInfo ~= nil then info = refreshedInfo end
  local hasAdminTarget = looksLikeSteamId(tostring(info.steam or ""))
  local hasDirectTarget = info.pawn ~= nil and isValidObject(info.pawn)
  if hasAdminTarget or hasDirectTarget then
    local okCount, requested, path, details = deliverItemTypeForInfo(info, itemId, quantity)
    details = details or {}
    appendLog("deliver_items routed item=" .. tostring(itemId) .. " path=" .. tostring(path) .. " qty=" .. tostring(requested) .. " ok=" .. tostring(okCount) .. " adminTarget=" .. tostring(hasAdminTarget) .. " directTarget=" .. tostring(hasDirectTarget) .. " details=" .. table.concat(details, " || "))
    appendActionEvent("deliver_item", okCount == requested, info, table.concat(details, " || "),
      '{"itemId":' .. js(itemId) .. ',"quantity":' .. tostring(requested) .. ',"delivered":' .. tostring(okCount) .. ',"path":' .. js(path) .. ',"adminTarget":' .. (hasAdminTarget and "true" or "false") .. '}')
    if okCount == requested then return true, "item delivery dispatched through safe admin route" end
    return false, "item delivery incomplete: " .. tostring(okCount) .. "/" .. tostring(requested) .. ". " .. table.concat(details, " || ")
  end
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = false })
  if info ~= nil and not ready then
    appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
      '{"reason":' .. js(readyReason or "") .. ',"itemId":' .. js(itemId or "") .. '}')
    return false, deliveryReadyMessage(readyReason), '{"ready":false,"reason":' .. js(readyReason or "") .. '}'
  end
  if liveInfo ~= nil then info = liveInfo end
  if info == nil then return false, "Игрок не найден среди реально подключённых." end
  local okCount, requested, path, details = deliverItemTypeForInfo(info, itemId, quantity)
  details = details or {}
  appendLog("deliver_items direct item=" .. tostring(itemId) .. " path=" .. tostring(path) .. " qty=" .. tostring(requested) .. " ok=" .. tostring(okCount) .. " details=" .. table.concat(details, " || "))
  appendActionEvent("deliver_item", okCount == requested, info, table.concat(details, " || "),
    '{"itemId":' .. js(itemId) .. ',"quantity":' .. tostring(requested) .. ',"delivered":' .. tostring(okCount) .. ',"path":' .. js(path) .. '}')
  if okCount == requested then return true, "Предмет выдан через безопасный маршрут." end
  return false, "Предмет выдан не полностью: " .. tostring(okCount) .. "/" .. tostring(requested) .. ". " .. table.concat(details, " || ")
end

local function deliverItems(steamId, name, itemId, quantity, runtimeKey)
  return deliverItemsForInfo(nil, steamId, name, itemId, quantity, runtimeKey)
end

local function equipItemForInfo(preferredInfo, steamId, name, itemId, quantity, runtimeKey)
  local info = resolvePlayerInfo(steamId, name, preferredInfo, runtimeKey)
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = false })
  if info ~= nil and not ready then
    appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
      '{"reason":' .. js(readyReason or "") .. ',"itemId":' .. js(itemId or "") .. ',"equip":true}')
    return false, deliveryReadyMessage(readyReason), '{"ready":false,"reason":' .. js(readyReason or "") .. '}'
  end
  if liveInfo ~= nil then info = liveInfo end
  if info == nil then return false, "Игрок не найден среди реально подключённых.", "{}" end
  if (info.pawn == nil or not isValidObject(info.pawn)) and not looksLikeSteamId(tostring(info.steam or "")) then
    return false, "Игрок подключён, но персонаж ещё не готов.", "{}"
  end
  itemId = tostring(itemId or ""):gsub("^%s+", ""):gsub("%s+$", "")
  quantity = math.max(1, math.min(tonumber(quantity) or 1, 10))
  if itemId == "" then return false, "ID предмета не указан.", "{}" end
  local adminCount, adminRequested, adminPath, adminDetails = deliverItemThroughAdminSpawn(info, itemId, quantity)
  adminDetails = adminDetails or {}
  local adminData = '{"itemId":' .. js(itemId) ..
    ',"quantity":' .. tostring(adminRequested) ..
    ',"delivered":' .. tostring(adminCount) ..
    ',"path":' .. js(adminPath or itemId) ..
    ',"route":"admin-spawn-safe","handsRequested":true}'
  appendLog("equip_item safe-admin item=" .. tostring(itemId) ..
    " qty=" .. tostring(adminRequested) ..
    " ok=" .. tostring(adminCount) ..
    " details=" .. table.concat(adminDetails, " || "))
  appendActionEvent("equip_item", adminCount == adminRequested, info, table.concat(adminDetails, " || "), adminData)
  if adminCount == adminRequested then
    return true, "Предмет отправлен безопасной командой SpawnItem к игроку. Если SCUM не взял его в руки автоматически, подними предмет рядом с собой.", adminData
  end

  if info.pawn == nil or not isValidObject(info.pawn) then
    return false, "Игрок найден, но персонаж ещё не готов. SpawnItem fallback тоже не прошёл: " .. table.concat(adminDetails, " || "), adminData
  end
  if not shouldUseDirectItemRoute(itemId) then
    return false, "Экипировка этого предмета direct-маршрутом ещё не подтверждена; unsafe SpawnItem fallback отключён.", "{}"
  end

  local path = resolveItemPath(itemId)
  local itemClass, loadRoute = loadItemClass(path)
  if itemClass == nil then
    return false, "Класс предмета не загрузился: " .. tostring(loadRoute), '{"itemId":' .. js(itemId) .. ',"path":' .. js(path) .. '}'
  end

  local equipped = 0
  local placed = 0
  local details = {}
  for i = 1, quantity do
    local liveInfo = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
    local actor, spawnRoute = spawnItemActor(liveInfo, itemClass)
    if actor == nil then
      table.insert(details, "spawn failed: " .. tostring(spawnRoute))
      break
    end

    local okEquip, equipRoute = equipItemForPlayer(liveInfo, actor)
    if okEquip then
      equipped = equipped + 1
      table.insert(details, loadRoute .. " -> " .. spawnRoute .. " -> " .. equipRoute)
    else
      if tostring(equipRoute or ""):find("item was placed in inventory", 1, true) ~= nil then
        placed = placed + 1
        table.insert(details, loadRoute .. " -> " .. spawnRoute .. " -> " .. tostring(equipRoute))
      else
        destroySpawnedItem(actor)
        table.insert(details, loadRoute .. " -> " .. spawnRoute .. " -> equip failed: " .. tostring(equipRoute))
      end
    end
  end

  local data = '{"itemId":' .. js(itemId) .. ',"quantity":' .. tostring(quantity) ..
    ',"equipped":' .. tostring(equipped) .. ',"placed":' .. tostring(placed) ..
    ',"path":' .. js(path) .. '}'
  appendLog("equip_item item=" .. tostring(itemId) .. " path=" .. tostring(path) ..
    " qty=" .. tostring(quantity) .. " equipped=" .. tostring(equipped) ..
    " placed=" .. tostring(placed) .. " details=" .. table.concat(details, " || "))
  appendActionEvent("equip_item", equipped == quantity, info, table.concat(details, " || "), data)
  if equipped == quantity then return true, "Предмет экипирован в руки.", data end
  if placed > 0 then return false, "Предмет не удалось взять в руки, но часть попала в инвентарь: " .. tostring(placed) .. "/" .. tostring(quantity) .. ". " .. table.concat(details, " || "), data end
  return false, "Предмет не экипирован: " .. table.concat(details, " || "), data
end

local function parseItemsSpec(spec)
  local items = {}
  for token in tostring(spec or ""):gmatch("[^;]+") do
    local sep = token:find("|", 1, true)
    if sep ~= nil then
      local itemId = token:sub(1, sep - 1):gsub("^%s+", ""):gsub("%s+$", "")
      local quantity = tonumber(token:sub(sep + 1)) or 1
      if itemId ~= "" then table.insert(items, { itemId = itemId, quantity = math.max(1, math.min(quantity, 100)) }) end
    end
  end
  return items
end

local function prewarmItems(itemsSpec)
  local items = parseItemsSpec(itemsSpec)
  if #items == 0 then return false, "Предметы для проверки не указаны.", '{"items":[],"count":0}' end
  local rows = {}
  local loaded = 0
  local failed = 0
  local maxItems = math.min(#items, 100)
  for i = 1, maxItems do
    local item = items[i]
    local itemId = item.itemId or ""
    local path = resolveItemPath(itemId)
    local itemClass, route = loadItemClass(path)
    local okLoad = itemClass ~= nil
    if okLoad then loaded = loaded + 1 else failed = failed + 1 end
    table.insert(rows, '{"itemId":' .. js(itemId) ..
      ',"path":' .. js(path) ..
      ',"ok":' .. (okLoad and "true" or "false") ..
      ',"route":' .. js(route or "") .. '}')
  end
  local data = '{"count":' .. tostring(maxItems) ..
    ',"loaded":' .. tostring(loaded) ..
    ',"failed":' .. tostring(failed) ..
    ',"truncated":' .. ((#items > maxItems) and "true" or "false") ..
    ',"items":[' .. table.concat(rows, ",") .. ']}'
  appendLog("prewarm_items loaded=" .. tostring(loaded) .. " failed=" .. tostring(failed) .. " count=" .. tostring(maxItems))
  appendActionEvent("items_prewarm", failed == 0, nil, "loaded=" .. tostring(loaded) .. " failed=" .. tostring(failed), data)
  if failed == 0 then return true, "Классы предметов проверены и предзагружены.", data end
  return false, "Часть предметов не загрузилась: " .. tostring(failed) .. "/" .. tostring(maxItems), data
end

local function numberField(text, key, fallback)
  local value = tostring(text or ""):match('"' .. key .. '"%s*:%s*(-?%d+%.?%d*)')
  return tonumber(value) or fallback
end

local function itemsSpecFromConfig(configText)
  local text = tostring(configText or "")
  local raw = text:match('"Items"%s*:%s*(%b[])') or text:match('"items"%s*:%s*(%b[])')
  if raw == nil then return "" end
  local parts = {}
  for object in raw:gmatch("%b{}") do
    local itemId = extractString(object, "ItemId") or extractString(object, "itemId") or ""
    local quantity = numberField(object, "Quantity", numberField(object, "quantity", 1))
    quantity = math.max(1, math.min(tonumber(quantity) or 1, 100))
    if itemId ~= "" then table.insert(parts, itemId .. "|" .. tostring(quantity)) end
  end
  return table.concat(parts, ";")
end

local function welcomeItemsSpec()
  local configured = itemsSpecFromConfig(configText("welcome-pack"))
  if configured ~= "" then return configured end
  return DEFAULT_WELCOME_ITEMS_SPEC
end

local function dailyPackItemsSpec()
  local configured = itemsSpecFromConfig(configText("daily-pack"))
  if configured ~= "" then return configured end
  return "Apple_2|2;CannedGoulash|1;Emergency_bandage_Big|1"
end

local function deliverItemsBatch(steamId, name, itemsSpec, preferredInfo, runtimeKey)
  local info = resolvePlayerInfo(steamId, name, preferredInfo, runtimeKey)
  if info == nil then info = { steam = tostring(steamId or ""), name = tostring(name or ""), source = "delivery-identity" } end
  if tostring(info.steam or "") == "" then info.steam = tostring(steamId or "") end
  if tostring(info.name or "") == "" or tostring(info.name or "") == "Unknown" then info.name = tostring(name or "") end
  local items = parseItemsSpec(itemsSpec)
  if #items == 0 then return false, "items for delivery are not configured", "{}" end
  local refreshedInfo = refreshRuntimePlayerInfo(info)
  if refreshedInfo ~= nil then info = refreshedInfo end
  local hasAdminTarget = looksLikeSteamId(tostring(info.steam or ""))
  local hasDirectTarget = info.pawn ~= nil and isValidObject(info.pawn)
  if hasAdminTarget or hasDirectTarget then
    local results = {}
    local failures = {}
    local okItems = 0
    local deliveredQuantity = 0
    for _, item in ipairs(items) do
      local okCount, requested, path, details = deliverItemTypeForInfo(info, item.itemId, item.quantity)
      details = details or {}
      local itemOk = okCount == requested
      if itemOk then okItems = okItems + 1 end
      if not itemOk then table.insert(failures, tostring(item.itemId) .. ": " .. table.concat(details, " || ")) end
      deliveredQuantity = deliveredQuantity + okCount
      table.insert(results, '{"itemId":' .. js(item.itemId) ..
        ',"quantity":' .. tostring(requested) ..
        ',"delivered":' .. tostring(okCount) ..
        ',"ok":' .. (itemOk and "true" or "false") ..
        ',"path":' .. js(path) ..
        ',"message":' .. js(table.concat(details, " || ")) .. '}')
    end
    local allOk = okItems == #items
    local data = '{"requested":' .. tostring(#items) ..
      ',"delivered":' .. tostring(okItems) ..
      ',"deliveredQuantity":' .. tostring(deliveredQuantity) ..
      ',"allOk":' .. (allOk and "true" or "false") ..
      ',"adminTarget":' .. (hasAdminTarget and "true" or "false") ..
      ',"results":[' .. table.concat(results, ",") .. ']}'
    appendLog("deliver_items_batch routed target=" .. tostring(info.steam or info.name or "") .. " requested=" .. tostring(#items) .. " okItems=" .. tostring(okItems) .. " adminTarget=" .. tostring(hasAdminTarget))
    appendActionEvent("deliver_items_batch", allOk, info, allOk and "batch delivery dispatched through safe admin route" or table.concat(failures, " || "), data)
    return allOk, allOk and "batch delivery dispatched through safe admin route" or ("batch delivery incomplete: " .. table.concat(failures, " || ")), data
  end
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = true })
  if info ~= nil and not ready then
    appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
      '{"reason":' .. js(readyReason or "") .. ',"itemsSpec":' .. js(itemsSpec or "") .. '}')
    return false, deliveryReadyMessage(readyReason), '{"ready":false,"reason":' .. js(readyReason or "") .. '}'
  end
  if liveInfo ~= nil then info = liveInfo end
  if info == nil then return false, "Игрок не найден среди реально подключённых.", "{}" end
  if info.pawn == nil or not isValidObject(info.pawn) then
    return false, "Игрок подключён, но персонаж и инвентарь ещё не готовы.", "{}"
  end
  local items = parseItemsSpec(itemsSpec)
  if #items == 0 then return false, "Предметы для выдачи не настроены.", "{}" end
  local results = {}
  local failures = {}
  local okItems = 0
  local deliveredQuantity = 0
  for _, item in ipairs(items) do
    local okCount, requested, path, details = deliverItemTypeForInfo(info, item.itemId, item.quantity)
    details = details or {}
    local itemOk = okCount == requested
    if itemOk then okItems = okItems + 1 end
    if not itemOk then table.insert(failures, tostring(item.itemId) .. ": " .. table.concat(details, " || ")) end
    deliveredQuantity = deliveredQuantity + okCount
    table.insert(results, '{"itemId":' .. js(item.itemId) ..
      ',"quantity":' .. tostring(requested) ..
      ',"delivered":' .. tostring(okCount) ..
      ',"ok":' .. (itemOk and "true" or "false") ..
      ',"path":' .. js(path) ..
      ',"message":' .. js(table.concat(details, " || ")) .. '}')
  end
  local allOk = okItems == #items
  local data = '{"requested":' .. tostring(#items) ..
    ',"delivered":' .. tostring(okItems) ..
    ',"deliveredQuantity":' .. tostring(deliveredQuantity) ..
    ',"allOk":' .. (allOk and "true" or "false") ..
    ',"results":[' .. table.concat(results, ",") .. ']}'
  appendLog("deliver_items_batch target=" .. tostring(steamId or name or "") .. " requested=" .. tostring(#items) .. " okItems=" .. tostring(okItems))
  appendActionEvent("deliver_items_batch", allOk, info, allOk and "Пакет предметов выдан через безопасный маршрут." or table.concat(failures, " || "), data)
  return allOk, allOk and "Пакет предметов выдан через безопасный маршрут." or ("Пакет предметов выдан не полностью: " .. table.concat(failures, " || ")), data
end

local function clearInventoryNow(info)
  local attempts = {}
  local successes = {}
  table.insert(attempts, "admin.ClearInventory=disabled; SCUM build reports this command as Unrecognized")
  local inv = playerInventoryComponent(info)
  if inv ~= nil and isValidObject(inv) then
    for _, method in ipairs({"Server_ClearInventory", "ClearInventory", "Server_DropAllItems", "DropAllItems", "RemoveAllItems", "DestroyAllItems", "DeleteAllItems"}) do
      local okCall, result = safeCall(inv, method)
      table.insert(attempts, "inventory." .. method .. "=" .. (okCall and "ok" or tostring(result)))
      if okCall and result ~= false then table.insert(successes, "inventory " .. method) end
    end
  end
  if info ~= nil and info.pawn ~= nil and isValidObject(info.pawn) then
    for _, method in ipairs({"Server_ClearInventory", "ClearInventory", "Server_DropAllItems", "DropAllItems", "RemoveAllItems", "DestroyAllItems", "Server_DropItemFromHands", "DropItemFromHands"}) do
      local okCall, result = safeCall(info.pawn, method)
      table.insert(attempts, "pawn." .. method .. "=" .. (okCall and "ok" or tostring(result)))
      if okCall and result ~= false then table.insert(successes, "pawn " .. method) end
    end
    local okCall, result = safeCall(info.pawn, "RemoveItemFromHands", 0)
    table.insert(attempts, "pawn.RemoveItemFromHands=" .. (okCall and "ok" or tostring(result)))
    if okCall and result ~= false then table.insert(successes, "pawn RemoveItemFromHands") end
  end
  if #successes > 0 then
    return true, "Очистка инвентаря отправлена через live runtime: " .. table.concat(successes, ", ")
  end
  appendLog("clear inventory failed: " .. table.concat(attempts, " | "))
  return false, "Безопасный общий маршрут очистки не найден. Используй очистку через панель: она удаляет предметы по EntityID по одному. Детали: " .. table.concat(attempts, " | ")
end

local function clearInventory(steamId, name, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then return false, "Игрок не найден среди реально подключённых." end
  local live = livePlayerForTarget(info.steam, info.name, info.runtimeKey, info)
  if live == nil then return false, "Игрок есть в панели, но live-controller сейчас не найден. Подожди несколько секунд после входа игрока и обнови список игроков." end
  local okClear, message = clearInventoryNow(live)
  appendActionEvent("clear_inventory", okClear, live, tostring(message), '{"queued":false}')
  targetMessage(live.steam, live.name, okClear and "Команда очистки инвентаря отправлена. Обнови инвентарь для проверки." or ("Инвентарь не очищен: " .. tostring(message)), "inventory", live.runtimeKey)
  return okClear, tostring(message or "")
end

local function setAttributes(steamId, name, strength, constitution, dexterity, intelligence, suppressActionLog, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then
    if not suppressActionLog then
      appendActionEvent("set_attributes", false, { steam = steamId, name = name }, "Игрок не найден среди реально подключённых.", "{}")
    end
    return false, "Игрок не найден среди реально подключённых."
  end
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = false })
  if not ready then
    if not suppressActionLog then
      appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
        '{"reason":' .. js(readyReason or "") .. ',"action":"set_attributes"}')
    end
    return false, deliveryReadyMessage(readyReason)
  end
  info = liveInfo
  strength = tonumber(strength) or 0
  constitution = tonumber(constitution) or 0
  dexterity = tonumber(dexterity) or 0
  intelligence = tonumber(intelligence) or 0
  local commandText = "SetAttributes " .. strength .. " " .. constitution .. " " .. dexterity .. " " .. intelligence
  local sent, message = adminExec(commandText, info)
  local resultMessage = sent and ("Атрибуты отправлены через live-маршрут игрока: " .. tostring(message or "")) or tostring(message or "")
  if not suppressActionLog then
    appendActionEvent("set_attributes", sent, info, resultMessage,
      '{"strength":' .. tostring(strength) .. ',"constitution":' .. tostring(constitution) .. ',"dexterity":' .. tostring(dexterity) .. ',"intelligence":' .. tostring(intelligence) .. ',"accepted":' .. (sent and "true" or "false") .. ',"verified":false}')
  end
  if sent then return true, resultMessage end
  return false, resultMessage ~= "" and resultMessage or "Маршрут изменения атрибутов не сработал."
end

local function normalizeSkillCommandName(skill)
  local raw = valueText(skill):gsub("^%s+", ""):gsub("%s+$", "")
  if raw == "" then return "" end
  local compact = raw:lower():gsub("[\"']", ""):gsub("[%s_%-%./]+", "")
  local aliases = {
    brawling = "Brawling",
    boxing = "Brawling",
    melee = "\"Melee Weapons\"",
    meleeweapon = "\"Melee Weapons\"",
    meleeweapons = "\"Melee Weapons\"",
    resistance = "Resistance",
    cooking = "Cooking",
    tactics = "Tactics",
    aviation = "Aviation",
    farming = "Farming",
    motorcycling = "Motorcycling",
    motorcycle = "Motorcycling",
    motorcycles = "Motorcycling",
    awareness = "Awareness",
    perception = "Awareness",
    rifles = "Rifles",
    rifle = "Rifles",
    sniping = "Sniping",
    camouflage = "Camouflage",
    survival = "Survival",
    handgun = "Handgun",
    handguns = "Handgun",
    running = "Running",
    endurance = "Endurance",
    thievery = "Thievery",
    archery = "Archery",
    driving = "Driving",
    engineering = "Engineering",
    demolition = "Demolition",
    medical = "Medical",
    stealth = "Stealth",
    brawl = "Brawling",
    meleecombat = "\"Melee Weapons\"",
    pistol = "Handgun",
    pistols = "Handgun",
    handgunweapon = "Handgun",
    handgunweapons = "Handgun",
    throwing = "Throwing"
  }
  return aliases[compact] or ""
end

local function setSkill(steamId, name, skill, level, experience, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then
    appendActionEvent("set_skill", false, { steam = steamId, name = name }, "Игрок не найден среди реально подключённых.",
      '{"skill":' .. js(skill or "") .. ',"level":' .. tostring(tonumber(level) or 0) .. '}')
    return false, "Игрок не найден среди реально подключённых."
  end
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = false })
  if not ready then
    appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
      '{"reason":' .. js(readyReason or "") .. ',"action":"set_skill","skill":' .. js(skill or "") .. '}')
    return false, deliveryReadyMessage(readyReason)
  end
  info = liveInfo
  skill = normalizeSkillCommandName(skill)
  if skill == "" then
    appendActionEvent("set_skill", false, info, "Навык не поддерживается текущим списком SCUM.", '{"skill":' .. js(skill or "") .. ',"level":' .. tostring(tonumber(level) or 0) .. '}')
    return false, "Навык не поддерживается текущим списком SCUM."
  end
  level = tonumber(level) or 0
  experience = tonumber(experience) or 0
  local commandText = "SetSkillLevel " .. skill .. " " .. tostring(level)
  if experience > 0 then commandText = commandText .. " " .. tostring(experience) end
  local sent, message = adminExec(commandText, info)
  appendActionEvent("set_skill", sent, info, tostring(message or ""),
    '{"skill":' .. js(skill) .. ',"level":' .. tostring(level) .. ',"experience":' .. tostring(experience) .. '}')
  if sent then return true, message end
  local finalMessage = tostring(message or "")
  return false, finalMessage ~= "" and finalMessage or "Маршрут изменения навыка не сработал."
end

SCUM_ALL_SKILLS = SCUM_ALL_SKILLS or {
  "Resistance",
  "Brawling",
  "Awareness",
  "Rifles",
  "Sniping",
  "Camouflage",
  "Survival",
  "Melee Weapons",
  "Handgun",
  "Running",
  "Endurance",
  "Tactics",
  "Cooking",
  "Thievery",
  "Archery",
  "Driving",
  "Engineering",
  "Demolition",
  "Medical",
  "Motorcycling",
  "Stealth",
  "Aviation",
  "Farming"
}

SKILL_BATCH_QUEUE = SKILL_BATCH_QUEUE or {}
SKILL_BATCH_ACTIVE = SKILL_BATCH_ACTIVE or false
SKILL_BATCH_SEQ = SKILL_BATCH_SEQ or 0

function skillBatchDelayMs(index)
  local baseDelay = math.max(1000, configNumber("bridge-safety", { "SkillCommandDelayMs", "skillCommandDelayMs" }, 4000))
  local batchSize = math.max(1, configNumber("bridge-safety", { "SkillCommandBatchSize", "skillCommandBatchSize" }, 6))
  local batchPause = math.max(0, configNumber("bridge-safety", { "SkillCommandBatchPauseMs", "skillCommandBatchPauseMs" }, 10000))
  if index > 1 and ((index - 1) % batchSize) == 0 then return baseDelay + batchPause end
  return baseDelay
end

function skillBatchPlayerKey(info)
  if info == nil then return "" end
  return tostring(info.steam or info.steamId or info.name or "")
end

function skillBatchHasPlayer(info)
  local key = skillBatchPlayerKey(info)
  if key == "" then return false end
  if SKILL_BATCH_ACTIVE ~= nil and SKILL_BATCH_ACTIVE ~= false and skillBatchPlayerKey(SKILL_BATCH_ACTIVE.info) == key then return true end
  for _, item in ipairs(SKILL_BATCH_QUEUE or {}) do
    if skillBatchPlayerKey(item.info) == key then return true end
  end
  return false
end

function runSkillBatchNext(item)
  if item == nil then
    SKILL_BATCH_ACTIVE = false
    return
  end
  local skills = item.skills or {}
  item.index = tonumber(item.index or 0) or 0
  if item.index >= #skills then
    appendActionEvent("set_all_skills", true, item.info, "All skills batch completed.",
      '{"batchId":' .. tostring(item.id or 0) .. ',"level":' .. tostring(item.level or 0) ..
      ',"okActions":' .. tostring(item.okCount or 0) .. ',"failedActions":' .. tostring(item.failCount or 0) .. '}')
    targetMessage(item.info.steam, item.info.name, "Все навыки выданы. Уровень: " .. tostring(item.level or 0) .. ".", "skills", item.info.runtimeKey)
    SKILL_BATCH_ACTIVE = false
    drainSkillBatchQueue()
    return
  end

  local nextIndex = item.index + 1
  local delayMs = nextIndex == 1 and 0 or skillBatchDelayMs(nextIndex)
  deferGame(delayMs, function()
    local skill = skills[nextIndex]
    local sent, message = setSkill(item.info.steam, item.info.name, skill, item.level, item.experience, item.info.runtimeKey)
    if sent then item.okCount = (tonumber(item.okCount or 0) or 0) + 1 else item.failCount = (tonumber(item.failCount or 0) or 0) + 1 end
    appendLog("skill batch id=" .. tostring(item.id or 0) .. " step=" .. tostring(nextIndex) .. "/" .. tostring(#skills) .. " skill=" .. tostring(skill) .. " sent=" .. tostring(sent) .. " message=" .. tostring(message or ""))
    item.index = nextIndex
    runSkillBatchNext(item)
  end)
end

function drainSkillBatchQueue()
  if SKILL_BATCH_ACTIVE ~= nil and SKILL_BATCH_ACTIVE ~= false then return end
  local item = table.remove(SKILL_BATCH_QUEUE, 1)
  if item == nil then return end
  SKILL_BATCH_ACTIVE = item
  appendLog("skill batch start id=" .. tostring(item.id or 0) .. " count=" .. tostring(#(item.skills or {})) .. " player=" .. tostring(item.info and item.info.name or ""))
  runSkillBatchNext(item)
end

function enqueueSkillBatch(steamId, name, skills, level, experience, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then
    appendActionEvent("set_all_skills", false, { steam = steamId, name = name }, "Player is not online for skill batch.", "{}")
    return false, "Игрок не найден среди реально подключённых."
  end
  local liveInfo, ready, readyDetail, readyReason = deliveryReadyInfo(info, { requireInventory = false })
  if not ready then
    appendActionEvent("delivery_readiness", false, info, tostring(readyDetail or ""),
      '{"reason":' .. js(readyReason or "") .. ',"action":"set_all_skills"}')
    return false, deliveryReadyMessage(readyReason)
  end
  info = liveInfo
  if skillBatchHasPlayer(info) then
    return false, "Выдача навыков этому игроку уже идёт. Дождись окончания очереди."
  end
  local maxQueue = math.max(1, configNumber("bridge-safety", { "SkillBatchQueueMax", "skillBatchQueueMax" }, 8))
  if #(SKILL_BATCH_QUEUE or {}) >= maxQueue then
    return false, "Очередь выдачи навыков заполнена. Повтори позже."
  end
  local normalized = {}
  for _, skill in ipairs(skills or {}) do
    local clean = normalizeSkillCommandName(skill)
    if clean ~= "" then table.insert(normalized, clean) end
  end
  if #normalized <= 0 then return false, "Нет поддерживаемых навыков для выдачи." end
  level = tonumber(level) or 4
  if level < 0 then level = 0 end
  if level > 4 then level = 4 end
  experience = tonumber(experience) or 0
  SKILL_BATCH_SEQ = (tonumber(SKILL_BATCH_SEQ or 0) or 0) + 1
  local item = { id = SKILL_BATCH_SEQ, info = info, skills = normalized, level = level, experience = experience, index = 0, okCount = 0, failCount = 0 }
  table.insert(SKILL_BATCH_QUEUE, item)
  appendActionEvent("set_all_skills", true, info, "All skills batch queued.",
    '{"batchId":' .. tostring(item.id) .. ',"level":' .. tostring(level) .. ',"count":' .. tostring(#normalized) ..
    ',"delayMs":' .. tostring(skillBatchDelayMs(2)) .. ',"depth":' .. tostring(#SKILL_BATCH_QUEUE) .. '}')
  targetMessage(info.steam, info.name, "Выдача всех навыков поставлена в очередь: " .. tostring(#normalized) .. " шт. Сервер выдаст их по одному.", "skills", info.runtimeKey)
  drainSkillBatchQueue()
  return true, "Выдача всех навыков поставлена в безопасную очередь: " .. tostring(#normalized) .. " шт."
end

local function allSkillsKeyword(value)
  local text = tostring(value or ""):lower():gsub("[%s_%-%.\"]+", "")
  return text == "all" or text == "allskills" or text == "fullskills" or text == "skillsall" or
    text == "maxskills" or text == "skillall" or text == "всенавыки" or text == "все"
end

local function setAllSkills(steamId, name, level, experience, runtimeKey)
  level = tonumber(level) or 4
  if level < 0 then level = 0 end
  if level > 4 then level = 4 end
  experience = tonumber(experience) or 0

  local okCount = 0
  local failCount = 0
  local firstError = ""
  local resultRows = {}

  local queued, queueMessage = enqueueSkillBatch(steamId, name, SCUM_ALL_SKILLS, level, experience, runtimeKey)
  if queued then return true, queueMessage end
  failCount = #SCUM_ALL_SKILLS
  firstError = tostring(queueMessage or "")
  table.insert(resultRows, '{"skill":"all","ok":false,"message":' .. js(firstError) .. '}')

  appendJsonArray(STATE_DIR .. "\\character-packs.json",
    '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(steamId or "") .. ',"name":' .. js(name or "") ..
    ',"pack":"all-skills","level":' .. tostring(level) .. ',"okActions":' .. tostring(okCount) ..
    ',"failedActions":' .. tostring(failCount) .. ',"results":[' .. table.concat(resultRows, ",") .. ']}',
    1024 * 1024)

  if okCount > 0 and failCount == 0 then
    return true, "Все навыки выданы: уровень " .. tostring(level) .. "."
  end
  if okCount > 0 then
    return false, "Навыки выданы частично: " .. tostring(okCount) .. "/" .. tostring(#SCUM_ALL_SKILLS) .. ". " .. tostring(firstError)
  end
  return false, firstError ~= "" and firstError or "Не удалось выдать все навыки."
end

local function objectClassFullName(obj)
  if obj == nil then return "" end
  local ok, cls = pcall(function() return obj:GetClass() end)
  if ok and cls ~= nil then return objectFullName(cls) end
  return ""
end

function unwrapHookParam(param)
  if param == nil then return nil end
  local ok, value = pcall(function()
    if type(param) == "userdata" and param.get ~= nil then return param:get() end
    return param
  end)
  if ok then return value end
  return param
end

function chatObjectDbId(obj)
  return objectDbId(obj,
    {"GetUserProfileId", "GetServerUserProfileId", "GetOwnerUserProfileId", "GetPlayerId"},
    {"UserProfileId", "ProfileId", "ServerUserProfileId", "_serverUserProfileId", "_userProfileId", "_userId", "UserId", "OwnerUserProfileId"})
end

function directPlayerInfoFromObject(obj, source)
  if obj == nil or not isValidObject(obj) then return nil end
  local className = objectClassFullName(obj) .. " " .. objectFullName(obj)
  local pc = nil
  local ps = nil
  local rpc = nil

  if className:find("PlayerController", 1, true) ~= nil or className:find("ConZPlayerController", 1, true) ~= nil then
    pc = obj
  elseif className:find("PlayerState", 1, true) ~= nil then
    ps = obj
    pc = ownerController(ps)
  elseif className:find("PlayerRpcChannel", 1, true) ~= nil or className:find("RpcChannel", 1, true) ~= nil then
    rpc = obj
    pc = firstProp(obj, {"PlayerController", "Controller", "Owner", "OwningController", "InstigatorController", "_playerController", "ConZPlayerController"})
    ps = firstProp(obj, {"PlayerState", "PlayerStatePrivate", "OwningPlayerState", "SenderPlayerState"})
  end

  local methodNames = {"GetPlayerController", "GetController", "GetOwner", "GetOuter", "GetOwningPlayer", "GetPlayerState"}
  for _, methodName in ipairs(methodNames) do
    if (pc == nil or not isValidObject(pc)) or (ps == nil or not isValidObject(ps)) then
      local okCall, value = safeCall(obj, methodName)
      if okCall and value ~= nil and isValidObject(value) then
        local valueClass = objectClassFullName(value) .. " " .. objectFullName(value)
        if (pc == nil or not isValidObject(pc)) and (valueClass:find("PlayerController", 1, true) ~= nil or valueClass:find("ConZPlayerController", 1, true) ~= nil) then pc = value end
        if (ps == nil or not isValidObject(ps)) and valueClass:find("PlayerState", 1, true) ~= nil then ps = value end
      end
    end
  end

  if pc ~= nil and isValidObject(pc) then
    local info = controllerInfo(pc, ps, source or "direct-object")
    if rpc ~= nil and isValidObject(rpc) then
      info.rpc = rpc
      info.rpcKey = objectKey(rpc)
      if tostring(info.runtimeKey or "") == "" then info.runtimeKey = info.rpcKey end
    end
    return enrichPlayerInfoFromServerLog(info) or info
  end
  if ps ~= nil and isValidObject(ps) then
    local info = controllerInfo(ownerController(ps), ps, source or "direct-player-state")
    if tostring(info.psKey or "") ~= "" then return enrichPlayerInfoFromServerLog(info) or info end
  end
  return nil
end

function findPlayerByObjectKey(key, infos)
  key = tostring(key or "")
  if key == "" then return nil end
  infos = infos or cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))) or {}
  for _, info in ipairs(infos) do
    if tostring(info.pcKey or "") == key or tostring(info.psKey or "") == key or tostring(info.pawnKey or "") == key then
      return enrichPlayerInfoFromServerLog(info)
    end
    local rpc = playerRpcChannel(info.pc)
    if objectKey(rpc) == key then return enrichPlayerInfoFromServerLog(info) end
    local owner = ownerController(info.ps)
    if objectKey(owner) == key then return enrichPlayerInfoFromServerLog(info) end
  end
  return nil
end

function findPlayerByLinkedObject(obj, infos)
  if obj == nil then return nil end
  local directInfo = directPlayerInfoFromObject(obj, "chat-linked-object")
  if directInfo ~= nil then return directInfo end
  local info = findPlayerByObjectKey(objectKey(obj), infos)
  if info ~= nil then return info end

  local dbId = chatObjectDbId(obj)
  if dbId ~= "" and dbId ~= "0" then
    info = findPlayerByDbId(dbId)
    if info ~= nil then return enrichPlayerInfoFromServerLog(info) end
  end

  local linked = {
    firstProp(obj, {"PlayerController", "Controller", "Owner", "OwningController", "InstigatorController"}),
    firstProp(obj, {"PlayerState", "PlayerStatePrivate", "OwningPlayerState", "SenderPlayerState"}),
    firstProp(obj, {"Pawn", "PawnPrivate", "AcknowledgedPawn", "Character", "Prisoner", "Instigator"}),
    firstProp(obj, {"PlayerRpcChannel", "_playerRpcChannel", "RpcChannel", "ChatChannel"})
  }
  local okCall, linkedObj = safeCall(obj, "GetOwner")
  if okCall then table.insert(linked, linkedObj) end
  okCall, linkedObj = safeCall(obj, "GetController")
  if okCall then table.insert(linked, linkedObj) end
  okCall, linkedObj = safeCall(obj, "GetPawn")
  if okCall then table.insert(linked, linkedObj) end
  okCall, linkedObj = safeCall(obj, "GetPlayerState")
  if okCall then table.insert(linked, linkedObj) end

  for _, candidate in ipairs(linked) do
    if candidate ~= nil then
      directInfo = directPlayerInfoFromObject(candidate, "chat-linked-candidate")
      if directInfo ~= nil then return directInfo end
      info = findPlayerByObjectKey(objectKey(candidate), infos)
      if info ~= nil then return info end
      dbId = chatObjectDbId(candidate)
      if dbId ~= "" and dbId ~= "0" then
        info = findPlayerByDbId(dbId)
        if info ~= nil then return enrichPlayerInfoFromServerLog(info) end
      end
    end
  end
  return nil
end

function findPlayerByHookArg(arg, message, infos)
  local value = unwrapHookParam(arg)
  local info = findPlayerByLinkedObject(value, infos)
  if info ~= nil then return info end

  local text = cleanText(paramText(arg))
  local rawMessage = cleanText(message)
  if text ~= "" and text ~= rawMessage then
    for _, candidate in ipairs(infos or cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 300))) or {}) do
      local enriched = enrichPlayerInfoFromServerLog(candidate) or candidate
      if tostring(enriched.steam or "") ~= "" and text:find(tostring(enriched.steam), 1, true) then return enriched end
      local profile = tostring(enriched.userProfileId or enriched.serverUserProfileId or "")
      if profile ~= "" and text == profile then return enriched end
      local candidateName = tostring(enriched.name or "")
      if candidateName ~= "" and candidateName ~= "Unknown" and text:lower():find(candidateName:lower(), 1, true) then return enriched end
    end
  end
  return nil
end

function findPlayerByChatContext(context, args, message)
  local info = findPlayerByContext(context)
  if info ~= nil then return info end
  local infos = cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))) or {}
  info = findPlayerByHookArg(context, message, infos)
  if info ~= nil then return info end
  for _, arg in ipairs(args or {}) do
    info = findPlayerByHookArg(arg, message, infos)
    if info ~= nil then return info end
  end
  return nil
end

function chatCommandText(text)
  local value = cleanText(text)
  if value == "" then return "" end
  local first = value:sub(1, 1)
  if first == "/" or first == "!" then return value end
  local embedded = value:match("^[^:]{1,96}:%s*([/!][%S].*)$")
  if embedded ~= nil then return cleanText(embedded) end
  return ""
end

chatUnresolvedCommandLogCount = chatUnresolvedCommandLogCount or 0

function chatArgSummary(args, maxCount)
  local parts = {}
  local limit = tonumber(maxCount) or 8
  for i, arg in ipairs(args or {}) do
    if i > limit then break end
    local value = unwrapHookParam(arg)
    local text = cleanText(paramText(arg))
    if #text > 160 then text = text:sub(1, 160) .. "..." end
    local fullName = objectFullName(value)
    if #fullName > 180 then fullName = fullName:sub(1, 180) .. "..." end
    table.insert(parts, '{"i":' .. tostring(i) ..
      ',"type":' .. js(type(value)) ..
      ',"text":' .. js(text) ..
      ',"dbId":' .. js(chatObjectDbId(value)) ..
      ',"key":' .. js(objectKey(value)) ..
      ',"class":' .. js(objectClassFullName(value)) ..
      ',"fullName":' .. js(fullName) .. '}')
  end
  return "[" .. table.concat(parts, ",") .. "]"
end

function chatPlayersSummaryJson()
  local parts = {}
  local infos = PLAYER_INFO_CACHE
  if infos == nil then infos = {} end
  for _, info in ipairs(infos or {}) do
    local p = enrichPlayerInfoFromServerLog(info) or info
    table.insert(parts, '{"name":' .. js(p.name or "") ..
      ',"steamId":' .. js(p.steam or "") ..
      ',"runtimeKey":' .. js(p.runtimeKey or "") ..
      ',"userProfileId":' .. js(p.userProfileId or "") ..
      ',"pcKey":' .. js(p.pcKey or "") ..
      ',"psKey":' .. js(p.psKey or "") ..
      ',"pawnKey":' .. js(p.pawnKey or "") .. '}')
  end
  return "[" .. table.concat(parts, ",") .. "]"
end

PLAYER_INFO_CACHE = PLAYER_INFO_CACHE or {}
PLAYER_INFO_CACHE_BY_KEY = PLAYER_INFO_CACHE_BY_KEY or {}
PLAYER_INFO_CACHE_BY_DB = PLAYER_INFO_CACHE_BY_DB or {}
PLAYER_INFO_CACHE_AT = PLAYER_INFO_CACHE_AT or 0

function replacePlayerInfoCache(sourceInfos)
  local infos = {}
  local byKey = {}
  local byDb = {}
  for _, info in ipairs(sourceInfos or {}) do
    local enriched = enrichPlayerInfoFromServerLog(info) or info
    table.insert(infos, enriched)
    local keys = {
      enriched.pcKey,
      enriched.psKey,
      enriched.pawnKey,
      enriched.runtimeKey
    }
    local rpc = playerRpcChannel(enriched.pc)
    local rpcKey = objectKey(rpc)
    if rpcKey ~= "" then table.insert(keys, rpcKey) end
    local owner = ownerController(enriched.ps)
    local ownerKey = objectKey(owner)
    if ownerKey ~= "" then table.insert(keys, ownerKey) end
    for _, key in ipairs(keys) do
      key = tostring(key or "")
      if key ~= "" then byKey[key] = enriched end
    end
    local dbIds = {
      enriched.userProfileId,
      enriched.serverUserProfileId
    }
    for _, dbId in ipairs(dbIds) do
      dbId = tostring(dbId or "")
      if dbId ~= "" and dbId ~= "0" then byDb[dbId] = enriched end
    end
  end
  PLAYER_INFO_CACHE = infos
  PLAYER_INFO_CACHE_BY_KEY = byKey
  PLAYER_INFO_CACHE_BY_DB = byDb
  PLAYER_INFO_CACHE_AT = os.clock()
  return #infos
end

function refreshPlayerInfoCache()
  local allowed, reason, age = runtimeScanAllowed()
  if not allowed then
    if serverLogReportsNoPlayers() then
      PLAYER_INFO_CACHE = {}
      PLAYER_INFO_CACHE_BY_KEY = {}
      PLAYER_INFO_CACHE_BY_DB = {}
      PLAYER_INFO_CACHE_AT = os.clock()
    end
    if (PLAYER_INFO_SCAN_GUARD_LOG_AT or 0) == 0 or (os.clock() - (PLAYER_INFO_SCAN_GUARD_LOG_AT or 0)) > 30 then
      PLAYER_INFO_SCAN_GUARD_LOG_AT = os.clock()
      appendLog("runtime player scan skipped: " .. tostring(reason or "") .. " age=" .. tostring(age or -1))
    end
    return
  end
  local freshInfos = listPlayerInfos()
  if (freshInfos == nil or #freshInfos == 0) and #(PLAYER_INFO_CACHE or {}) > 0 and
    not serverLogReportsNoPlayers() and
    configBool("bridge-safety", { "KeepPlayerCacheWhenRuntimeScanEmpty", "keepPlayerCacheWhenRuntimeScanEmpty" }, true) then
    PLAYER_INFO_CACHE_AT = os.clock()
    if (PLAYER_INFO_EMPTY_SCAN_KEEP_LOG_AT or 0) == 0 or (os.clock() - (PLAYER_INFO_EMPTY_SCAN_KEEP_LOG_AT or 0)) > 60 then
      PLAYER_INFO_EMPTY_SCAN_KEEP_LOG_AT = os.clock()
      appendLog("player-info-cache kept previous players after empty runtime scan")
    end
    return #(PLAYER_INFO_CACHE or {})
  end
  return replacePlayerInfoCache(freshInfos)
end

function cachedPlayerByObject(obj)
  if obj == nil then return nil end
  local key = objectKey(obj)
  if key ~= "" and PLAYER_INFO_CACHE_BY_KEY[key] ~= nil then return PLAYER_INFO_CACHE_BY_KEY[key] end
  local dbId = chatObjectDbId(obj)
  if dbId ~= "" and dbId ~= "0" and PLAYER_INFO_CACHE_BY_DB[dbId] ~= nil then return PLAYER_INFO_CACHE_BY_DB[dbId] end
  local linked = {
    firstProp(obj, {"PlayerController", "Controller", "Owner", "OwningController", "InstigatorController"}),
    firstProp(obj, {"PlayerState", "PlayerStatePrivate", "OwningPlayerState", "SenderPlayerState"}),
    firstProp(obj, {"Pawn", "PawnPrivate", "AcknowledgedPawn", "Character", "Prisoner", "Instigator"}),
    firstProp(obj, {"PlayerRpcChannel", "_playerRpcChannel", "RpcChannel", "ChatChannel"})
  }
  local okCall, linkedObj = safeCall(obj, "GetOwner")
  if okCall then table.insert(linked, linkedObj) end
  okCall, linkedObj = safeCall(obj, "GetController")
  if okCall then table.insert(linked, linkedObj) end
  okCall, linkedObj = safeCall(obj, "GetPawn")
  if okCall then table.insert(linked, linkedObj) end
  okCall, linkedObj = safeCall(obj, "GetPlayerState")
  if okCall then table.insert(linked, linkedObj) end
  for _, candidate in ipairs(linked) do
    if candidate ~= nil then
      key = objectKey(candidate)
      if key ~= "" and PLAYER_INFO_CACHE_BY_KEY[key] ~= nil then return PLAYER_INFO_CACHE_BY_KEY[key] end
      dbId = chatObjectDbId(candidate)
      if dbId ~= "" and dbId ~= "0" and PLAYER_INFO_CACHE_BY_DB[dbId] ~= nil then return PLAYER_INFO_CACHE_BY_DB[dbId] end
    end
  end
  return nil
end

function cachedPlayerByHookArg(arg, message)
  local value = unwrapHookParam(arg)
  local info = cachedPlayerByObject(value)
  if info ~= nil then return info end
  local text = cleanText(paramText(arg))
  local rawMessage = cleanText(message)
  if text ~= "" and text ~= rawMessage then
    for _, candidate in ipairs(PLAYER_INFO_CACHE or {}) do
      local steam = tostring(candidate.steam or "")
      if steam ~= "" and text:find(steam, 1, true) then return candidate end
      local profile = tostring(candidate.userProfileId or candidate.serverUserProfileId or "")
      if profile ~= "" and text == profile then return candidate end
      local candidateName = tostring(candidate.name or "")
      if candidateName ~= "" and candidateName ~= "Unknown" and text:lower():find(candidateName:lower(), 1, true) then return candidate end
    end
  end
  return nil
end

function findPlayerByChatContextCached(context, args, message)
  local cacheAge = os.clock() - (tonumber(PLAYER_INFO_CACHE_AT) or 0)
  local infos = PLAYER_INFO_CACHE or {}
  local cacheTtl = math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))
  if #infos == 0 or cacheAge > cacheTtl then return nil end
  local info = cachedPlayerByHookArg(context, message)
  if info ~= nil then return info end
  for _, arg in ipairs(args or {}) do
    info = cachedPlayerByHookArg(arg, message)
    if info ~= nil then return info end
  end
  if #infos == 1 then return infos[1] end
  return nil
end

local function stringArrayJson(items)
  local parts = {}
  for _, item in ipairs(items or {}) do
    table.insert(parts, js(item))
  end
  return "[" .. table.concat(parts, ",") .. "]"
end

local function itemName(item)
  if item == nil then return "" end
  local attempts = {
    function()
      local name = item:GetName()
      return name
    end,
    function()
      local fname = item:GetFName()
      if fname ~= nil and fname.ToString ~= nil then return fname:ToString() end
      return fname
    end,
    function()
      local full = item:GetFullName()
      return full
    end,
    function()
      return tostring(item)
    end
  }
  for _, fn in ipairs(attempts) do
    local okName, name = pcall(fn)
    if okName and name ~= nil then
      local text = tostring(name)
      if text ~= "" then return text end
    end
  end
  return ""
end

local function matchesAny(text, filters)
  local lower = tostring(text or ""):lower()
  for _, filter in ipairs(filters or {}) do
    if lower:find(tostring(filter):lower(), 1, true) ~= nil then return true end
  end
  return false
end

local function objectGetValue(obj, key)
  if obj == nil then return nil, "" end
  local ok, value = pcall(function() return obj[key] end)
  if ok and value ~= nil then return value, "index" end
  ok, value = pcall(function() return obj:GetPropertyValue(key) end)
  if ok and value ~= nil then return value, "GetPropertyValue" end
  return nil, ""
end

local function objectGetAny(obj, keys)
  for _, key in ipairs(keys or {}) do
    local value, route = objectGetValue(obj, key)
    if value ~= nil then return value, key, route end
  end
  return nil, "", ""
end

local function probeValueJson(value)
  local kind = type(value)
  if value == nil then return '{"kind":"nil"}' end
  if kind == "number" then return '{"kind":"number","value":' .. tostring(value) .. '}' end
  if kind == "boolean" then return '{"kind":"boolean","value":' .. (value and "true" or "false") .. '}' end
  if kind == "string" then return '{"kind":"string","value":' .. js(value) .. '}' end
  local fullName = objectFullName(value)
  local className = objectClassFullName(value)
  return '{"kind":' .. js(kind) ..
    ',"text":' .. js(valueText(value)) ..
    ',"fullName":' .. js(fullName) ..
    ',"class":' .. js(className) ..
    ',"key":' .. js(objectKey(value)) .. '}'
end

local function probeValuesJson(obj, keys)
  local parts = {}
  local seen = {}
  for _, key in ipairs(keys or {}) do
    if not seen[key] then
      seen[key] = true
      local value, route = objectGetValue(obj, key)
      if value ~= nil then
        table.insert(parts, '{"name":' .. js(key) .. ',"route":' .. js(route) .. ',"value":' .. probeValueJson(value) .. '}')
      end
    end
  end
  return "[" .. table.concat(parts, ",") .. "]"
end

local function reflectedNames(obj, method, filters, maxCount)
  return {}
end

local function probeObjectJson(label, obj, source, valueKeys, filters)
  if obj == nil or not isValidObject(obj) then
    return '{"label":' .. js(label) .. ',"present":false,"source":' .. js(source or "") .. '}'
  end
  return '{"label":' .. js(label) ..
    ',"present":true' ..
    ',"source":' .. js(source or "") ..
    ',"key":' .. js(objectKey(obj)) ..
    ',"fullName":' .. js(objectFullName(obj)) ..
    ',"class":' .. js(objectClassFullName(obj)) ..
    ',"values":' .. probeValuesJson(obj, valueKeys) ..
    ',"properties":' .. stringArrayJson(reflectedNames(obj, "ForEachProperty", filters, 100)) ..
    ',"functions":' .. stringArrayJson(reflectedNames(obj, "ForEachFunction", filters, 120)) ..
    '}'
end

local function firstLiveObject(classNames, ownerHint)
  local candidates = findAll(classNames or {})
  if #candidates == 0 then return nil, "" end
  local hint = tostring(ownerHint or "")
  if hint ~= "" then
    for _, candidate in ipairs(candidates) do
      local full = objectFullName(candidate)
      if full:find(hint, 1, true) ~= nil then return candidate, "class-scan-owner-hint" end
    end
  end
  if #candidates == 1 then return candidates[1], "class-scan-single" end
  return candidates[1], "class-scan-first-of-" .. tostring(#candidates)
end

local function playerProbe(steamId, name, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  if info == nil then return false, "Игрок не найден среди реально подключённых.", "{}" end
  local playerJson = '{"name":' .. js(info.name) ..
    ',"steamId":' .. js(info.steam) ..
    ',"runtimeKey":' .. js(info.runtimeKey or "") ..
    ',"x":' .. tostring(info.x or 0) ..
    ',"y":' .. tostring(info.y or 0) ..
    ',"z":' .. tostring(info.z or 0) .. '}'
  local data = '{"player":' .. playerJson .. ',"note":"safe probe only; deep reflection is disabled because it can stall UE4SS on hosted runtime"}'
  return true, "player probe captured", data
end

local function route(text)
  local id = extractString(text, "id") or ""
  CURRENT_BRIDGE_RESULT_ID = id
  local command = extractString(text, "command") or ""
  local runtimeKey = extractString(text, "runtimeKey") or ""
  appendLog("command " .. command .. " id=" .. id)

  if command == "list_players" then
    return ok(command, "players listed", playersJson())
  end

  if command == "reload_bridge" then
    appendActionEvent("bridge_reload", true, nil, "Безопасный reload: конфиги перечитываются при каждом действии; live-перезапуск Lua отключён, чтобы не закрывать SCUMServer.", '{"soft":true,"liveRestart":false}')
    return ok(command, "Безопасный reload выполнен. Конфиги перечитываются автоматически, сервер не перезапускался.", '{"queued":false,"soft":true,"liveRestart":false}')
  end

  if command == "queue_status" then
    local data = type(mutationQueueStatusJson) == "function" and mutationQueueStatusJson() or '{"available":false,"message":"Очередь ещё не инициализирована."}'
    return ok(command, "Очередь игровых действий прочитана.", data)
  end

  if command == "prewarm_items" or command == "prewarm_item_class" then
    local requestId = id
    local itemsSpec = extractString(text, "itemsSpec") or ""
    local queued, queueIdOrMessage, depth = enqueueMutation("prewarm-items", nil, function()
      local okRun, sent, message, data = pcall(function()
        return prewarmItems(itemsSpec)
      end)
      if okRun and sent then
        writeAll(RESULT_FILE, ok(command, message, data or "{}", requestId))
      elseif okRun then
        writeAll(RESULT_FILE, fail(command, message, requestId))
      else
        writeAll(RESULT_FILE, fail(command, tostring(sent), requestId))
      end
    end)
    if not queued then return fail(command, tostring(queueIdOrMessage or "Не удалось поставить проверку предметов в live-очередь."), requestId) end
    appendActionEvent("items_prewarm", true, nil, "Проверка предметов поставлена в live-очередь.",
      '{"itemsSpec":' .. js(itemsSpec) .. ',"queueId":' .. tostring(queueIdOrMessage or 0) .. ',"depth":' .. tostring(depth or 0) .. '}')
    return nil
  end

  if command == "player_details" then
    local info = resolvePlayerInfo(extractString(text, "steamId"), extractString(text, "name"), nil, runtimeKey)
    if info == nil then return fail(command, "Игрок не найден среди реально подключённых.") end
    return ok(command, "player resolved", '{"player":{"name":' .. js(info.name) .. ',"steamId":' .. js(info.steam) .. ',"runtimeKey":' .. js(info.runtimeKey or "") .. ',"userProfileId":' .. js(info.userProfileId or "") .. ',"serverUserProfileId":' .. js(info.serverUserProfileId or "") .. ',"x":' .. info.x .. ',"y":' .. info.y .. ',"z":' .. info.z .. '}}')
  end

  if command == "player_probe" or command == "debug_player_probe" then
    local sent, message, data = playerProbe(extractString(text, "steamId"), extractString(text, "name"), runtimeKey)
    if sent then return ok(command, message, data or "{}") end
    return fail(command, message)
  end

  if command == "player_plugin_command" then
    local info = findPlayer(extractString(text, "steamId"), extractString(text, "name"), runtimeKey)
    if info == nil then return fail(command, "Игрок не найден среди реально подключённых.") end
    local message = extractString(text, "message") or ""
    message = message:gsub("^%s+", ""):gsub("%s+$", "")
    if message == "" then return fail(command, "Команда плагина не задана.") end
    local commandName = (splitWords(message)[1] or ""):lower()
    local queued, queueIdOrMessage, depth = enqueuePlayerCommand(info, message, "panel", false)
    appendActionEvent("player_plugin_command", queued, info,
      queued and "Команда плагина поставлена в очередь." or tostring(queueIdOrMessage),
      '{"command":' .. js(commandName) .. ',"message":' .. js(message) .. ',"source":"panel","queued":' .. (queued and "true" or "false") .. ',"queueId":' .. (queued and tostring(queueIdOrMessage) or "null") .. ',"depth":' .. tostring(depth or 0) .. '}')
    if queued then
      return ok(command, "Команда плагина поставлена в очередь.", '{"queued":true,"queueId":' .. tostring(queueIdOrMessage) .. ',"depth":' .. tostring(depth or 0) .. ',"message":' .. js(message) .. '}')
    end
    return fail(command, tostring(queueIdOrMessage or "Команда не поставлена в очередь."))
  end

  if command == "cleanup_rentals" then
    if type(cleanupExpiredRentals) ~= "function" then return fail(command, "Очистка аренды ещё не инициализирована.") end
    local okRun, err = pcall(cleanupExpiredRentals)
    appendActionEvent("vehicle_rental_cleanup", okRun, nil, okRun and "Проверка истёкшей аренды выполнена." or tostring(err), "{}")
    if okRun then return ok(command, "Проверка истёкшей аренды выполнена.", '{"checked":true}') end
    return fail(command, tostring(err))
  end

  if command == "admin_exec" then
    local commandText = extractString(text, "commandText") or extractString(text, "command") or ""
    local info = findPlayer(extractString(text, "steamId"), extractString(text, "name"), runtimeKey)
    if info == nil then info = findPlayer(nil, nil) end
      local destroyEntitiesCommand = "ScumNeDjinDestroyEntities"
      local batchEntities = commandText:match("^%s*" .. destroyEntitiesCommand .. "%s+(.+)$")
    if batchEntities ~= nil then
      local sent, message, dataJson = destroyInventoryEntitiesBatch(extractString(text, "steamId"), extractString(text, "name"), runtimeKey, batchEntities)
      if sent then return ok(command, message, dataJson or "{}") end
      return fail(command, message)
    end
    local verb = commandVerb(commandText)
    local canRunWithoutLivePlayer = {
      SpawnItem = true,
      SpawnVehicle = true,
      DestroyVehicle = true,
      ChangeCurrencyBalance = true,
      SetCurrencyBalance = true,
      ChangeFamePoints = true,
      SetFamePoints = true,
      SetAttributes = true,
      SetPrisonerAttributes = true,
      SetSkillLevel = true,
      DestroyEntity = true
    }
    if info == nil then info = { steam = extractString(text, "steamId") or "", name = extractString(text, "name") or "", runtimeKey = runtimeKey or "" } end
    if (info.pc == nil or not isValidObject(info.pc)) and not canRunWithoutLivePlayer[verb] then
      return fail(command, "Нет живого PlayerController для выполнения admin-команды.")
    end
    info = enrichPlayerInfoFromServerLog(info) or info
    local queued, queueIdOrMessage, depth = enqueueMutation("admin-exec", info, function()
      local liveInfo = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
      local sent, message = adminExec(commandText, liveInfo)
      appendActionEvent("admin_exec_execute", sent, liveInfo, tostring(message or ""),
        '{"adminCommand":' .. js(commandText) .. '}')
    end)
    if queued then
      return ok(command, "Admin-команда поставлена в live-очередь.", '{"adminCommand":' .. js(commandText) .. ',"queued":true,"queueId":' .. tostring(queueIdOrMessage) .. ',"depth":' .. tostring(depth or 0) .. '}')
    end
    return fail(command, tostring(queueIdOrMessage or "Не удалось поставить admin-команду в live-очередь."))
  end

  if command == "chat_broadcast" then
    local sent, message = broadcast(extractString(text, "message") or "")
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "kill_feed_broadcast" then
    local rawMessage = extractString(text, "message") or ""
    local statsUpdated, statsReason = applyServerKillFeedStats(rawMessage)
    local sent, message = broadcastServerKillFeed(rawMessage)
    if sent then return ok(command, message, '{"statsUpdated":' .. tostring(statsUpdated == true) .. ',"statsReason":' .. js(statsReason or "") .. '}') end
    if tostring(message or ""):find("filtered:", 1, true) == 1 or tostring(message or "") == "duplicate" then
      return ok(command, "Killfeed event skipped: " .. tostring(message or ""), '{"filtered":true,"statsUpdated":' .. tostring(statsUpdated == true) .. ',"statsReason":' .. js(statsReason or "") .. '}')
    end
    return fail(command, message)
  end

  if command == "chat_target" then
    local sent, message = targetMessage(extractString(text, "targetSteamId"), extractString(text, "targetName"), extractString(text, "message") or "", nil, extractString(text, "targetRuntimeKey") or runtimeKey)
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "teleport_player" then
    local sent, message = teleport(extractString(text, "steamId"), extractString(text, "name"), extractNumber(text, "x") or 0, extractNumber(text, "y") or 0, extractNumber(text, "z") or 0, runtimeKey)
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "spawn_vehicle" then
    local requestId = id
    local vehicle = extractString(text, "vehicleId") or ""
    local minutes = math.max(0, math.floor(extractNumber(text, "minutes") or extractNumber(text, "rentalMinutes") or extractNumber(text, "lifetimeMinutes") or 0))
    local steamId = extractString(text, "steamId")
    local name = extractString(text, "name")
    local info = resolvePlayerInfo(steamId, name, nil, runtimeKey)
    if info == nil then return fail(command, "Игрок не найден среди реально подключённых.", requestId) end
    if type(vehicleRentalSpawnCooldownRemaining) == "function" then
      local waitSeconds = vehicleRentalSpawnCooldownRemaining(info)
      if waitSeconds > 0 then
        return fail(command, "Спавн транспорта сейчас в безопасной паузе. Подожди " .. tostring(waitSeconds) .. " сек.", requestId)
      end
    end
    local queued, queueIdOrMessage, depth = enqueueMutation("spawn-vehicle", info, function()
      local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
      if live == nil then
        writeAll(RESULT_FILE, fail(command, "Игрок не найден среди реально подключённых.", requestId))
        return
      end
      local spawnX, spawnY, spawnZ = vectorOf(live.pawn)
      local sent, message, runtimeRef, beforeVehicles = spawnVehicleForInfo(vehicle, live)
      if not sent then
        writeAll(RESULT_FILE, fail(command, message, requestId))
        return
      end
      local expiresAt = 0
      if minutes > 0 then
        local startedAt = os.time()
        expiresAt = startedAt + minutes * 60
        appendActiveRentalRecord(live, "panel", tostring(vehicle), tostring(vehicle), minutes, startedAt, expiresAt, 0, 0, 0, runtimeRef or "",
          ',"manualGrant":true,"source":"panel-spawn"')
        appendActionEvent("spawn_vehicle_timed", true, live, "Транспорт выдан с автоудалением по времени.",
          '{"vehicleId":' .. js(vehicle) .. ',"minutes":' .. tostring(minutes) .. ',"runtimeRef":' .. js(runtimeRef or "") .. '}')
      end
      if tostring(runtimeRef or "") ~= "" then
        writeAll(RESULT_FILE, ok(command, message, '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":' .. js(runtimeRef or "") .. ',"verified":true,"minutes":' .. tostring(minutes) .. ',"expiresAt":' .. tostring(expiresAt) .. '}', requestId))
        return
      end
      appendActionEvent("spawn_vehicle_pending_verify", true, live, "spawn command accepted; runtime vehicle scan skipped for stability",
        '{"vehicleId":' .. js(vehicle) .. '}')
      writeAll(RESULT_FILE, ok(command, message, '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":"","verified":false,"route":"admin-command","minutes":' .. tostring(minutes) .. ',"expiresAt":' .. tostring(expiresAt) .. '}', requestId))
      do return end
      local ref = nearestNewVehicleRefAt(spawnX, spawnY, spawnZ, vehicle, beforeVehicles, true)
      if ref ~= "" then
        appendActionEvent("spawn_vehicle_verified", true, live, "runtime vehicle found after command",
          '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":' .. js(ref) .. ',"stage":"immediate-scan"}')
        writeAll(RESULT_FILE, ok(command, message, '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":' .. js(ref) .. ',"verified":true}', requestId))
        return
      end
      appendActionEvent("spawn_vehicle_pending_verify", true, live, "spawn command accepted; runtime vehicle was not found immediately",
        '{"vehicleId":' .. js(vehicle) .. '}')
      writeAll(RESULT_FILE, ok(command, message, '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":"","verified":false,"route":"admin-command"}', requestId))
      do return end
      local liveSteam = tostring(live.steam or steamId or "")
      if liveSteam == "" then
        writeAll(RESULT_FILE, fail(command, "Команда спавна отправлена, но транспорт не подтверждён и SteamID для fallback не найден.", requestId))
        return
      end
      local fallbackBefore = vehicleRuntimeKeySet(vehicle)
      local fallbackCommand = "SpawnVehicle " .. tostring(vehicle) .. " 1 Location " .. liveSteam
      local sentFallback, fallbackMessage = adminExec(fallbackCommand, live)
      appendActionEvent("spawn_vehicle_location_fallback", sentFallback, live, tostring(fallbackMessage or ""),
        '{"vehicleId":' .. js(vehicle) .. ',"command":' .. js(fallbackCommand) .. '}')
      if not sentFallback then
        writeAll(RESULT_FILE, fail(command, "Первый спавн не подтверждён, fallback не сработал: " .. tostring(fallbackMessage), requestId))
        return
      end
      deferGame(2400, function()
        local liveAfter = resolvePlayerInfo(steamId, name, live, runtimeKey) or live
        local fallbackRef = nearestNewVehicleRefAt(spawnX, spawnY, spawnZ, vehicle, fallbackBefore, true)
        if fallbackRef ~= "" then
          appendActionEvent("spawn_vehicle_verified", true, liveAfter, "runtime vehicle found after location fallback",
            '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":' .. js(fallbackRef) .. ',"stage":"location-fallback"}')
          writeAll(RESULT_FILE, ok(command, tostring(fallbackMessage or message), '{"vehicleId":' .. js(vehicle) .. ',"runtimeRef":' .. js(fallbackRef) .. ',"verified":true,"fallback":true}', requestId))
        else
          appendActionEvent("spawn_vehicle_unverified", false, liveAfter, "spawn command accepted but runtime vehicle was not found",
            '{"vehicleId":' .. js(vehicle) .. ',"fallback":true}')
          writeAll(RESULT_FILE, fail(command, "Команда спавна отправлена, но транспорт не появился рядом с игроком.", requestId))
        end
      end)
    end)
    if queued and type(reserveVehicleRentalSpawnCooldown) == "function" then reserveVehicleRentalSpawnCooldown(info) end
    if not queued then return fail(command, tostring(queueIdOrMessage or "Не удалось поставить выдачу транспорта в live-очередь."), requestId) end
    appendActionEvent("spawn_vehicle", true, info, "Выдача транспорта поставлена в live-очередь.",
      '{"vehicleId":' .. js(vehicle) .. ',"queueId":' .. tostring(queueIdOrMessage or 0) .. ',"depth":' .. tostring(depth or 0) .. '}')
    return nil
  end

  if command == "destroy_vehicle_ref" then
    local ref = extractString(text, "vehicleRef") or extractString(text, "destroyRef") or ""
    local reason = extractString(text, "reason") or "bridge-request"
    local info = findPlayer(extractString(text, "steamId"), extractString(text, "name"), runtimeKey)
    local sent, message = destroyVehicleRef(ref, info, reason)
    if sent then return ok(command, message, '{"vehicleRef":' .. js(ref) .. '}') end
    return fail(command, message)
  end

  if command == "deliver_items" then
    local requestId = id
    local itemId = extractString(text, "itemId") or ""
    local quantity = extractNumber(text, "quantity") or 1
    local steamId = extractString(text, "steamId")
    local name = extractString(text, "name")
    local info = resolvePlayerInfo(steamId, name, nil, runtimeKey) or { steam = steamId or "", name = name or "", runtimeKey = runtimeKey or "" }
    local queued, queueIdOrMessage, depth = enqueueMutation("deliver-items", info, function()
      local okDeliver, sent, message = pcall(function()
        local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
        return deliverItemsForInfo(live, steamId, name, itemId, quantity, runtimeKey)
      end)
      if okDeliver and sent then
        writeAll(RESULT_FILE, ok(command, message, '{"itemId":' .. js(itemId) .. ',"quantity":' .. tostring(quantity) .. '}', requestId))
      elseif okDeliver then
        writeAll(RESULT_FILE, fail(command, message, requestId))
      else
        writeAll(RESULT_FILE, fail(command, tostring(sent), requestId))
      end
    end)
    if not queued then return fail(command, tostring(queueIdOrMessage or "Не удалось поставить выдачу предмета в live-очередь."), requestId) end
    appendActionEvent("deliver_item", true, info, "Выдача предмета поставлена в live-очередь.",
      '{"itemId":' .. js(itemId) .. ',"quantity":' .. tostring(quantity) .. ',"queueId":' .. tostring(queueIdOrMessage or 0) .. ',"depth":' .. tostring(depth or 0) .. '}')
    return nil
  end

  if command == "equip_item" then
    local requestId = id
    local itemId = extractString(text, "itemId") or ""
    local quantity = extractNumber(text, "quantity") or 1
    local steamId = extractString(text, "steamId")
    local name = extractString(text, "name")
    local info = resolvePlayerInfo(steamId, name, nil, runtimeKey) or { steam = steamId or "", name = name or "", runtimeKey = runtimeKey or "" }
    local queued, queueIdOrMessage, depth = enqueueMutation("equip-item", info, function()
      local okEquip, sent, message, data = pcall(function()
        local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
        return equipItemForInfo(live, steamId, name, itemId, quantity, runtimeKey)
      end)
      if okEquip and sent then
        writeAll(RESULT_FILE, ok(command, message, data or "{}", requestId))
      elseif okEquip then
        writeAll(RESULT_FILE, fail(command, message, requestId))
      else
        writeAll(RESULT_FILE, fail(command, tostring(sent), requestId))
      end
    end)
    if not queued then return fail(command, tostring(queueIdOrMessage or "Не удалось поставить экипировку предмета в live-очередь."), requestId) end
    appendActionEvent("equip_item", true, info, "Экипировка предмета поставлена в live-очередь.",
      '{"itemId":' .. js(itemId) .. ',"quantity":' .. tostring(quantity) .. ',"queueId":' .. tostring(queueIdOrMessage or 0) .. ',"depth":' .. tostring(depth or 0) .. '}')
    return nil
  end

  if command == "deliver_items_batch" then
    local requestId = id
    local itemsSpec = extractString(text, "itemsSpec") or ""
    local steamId = extractString(text, "steamId")
    local name = extractString(text, "name")
    local info = resolvePlayerInfo(steamId, name, nil, runtimeKey) or { steam = steamId or "", name = name or "", runtimeKey = runtimeKey or "" }
    local queued, queueIdOrMessage, depth = enqueueMutation("deliver-items-batch", info, function()
      local okDeliver, allOk, message, data = pcall(function()
        local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
        return deliverItemsBatch(steamId, name, itemsSpec, live, runtimeKey)
      end)
      if okDeliver and allOk then
        writeAll(RESULT_FILE, ok(command, message, data, requestId))
      elseif okDeliver then
        writeAll(RESULT_FILE, fail(command, message, requestId))
      else
        writeAll(RESULT_FILE, fail(command, tostring(allOk), requestId))
      end
    end)
    if not queued then return fail(command, tostring(queueIdOrMessage or "Не удалось поставить пакет предметов в live-очередь."), requestId) end
    appendActionEvent("deliver_items_batch", true, info, "Пакет предметов поставлен в live-очередь.",
      '{"queueId":' .. tostring(queueIdOrMessage or 0) .. ',"depth":' .. tostring(depth or 0) .. '}')
    return nil
  end

  if command == "change_money" then
    local amount = extractNumber(text, "amount") or 0
    local sent, message = changeMoney(extractString(text, "steamId"), extractString(text, "name"), amount, extractString(text, "currency"), runtimeKey)
    if sent then return ok(command, message, '{"amount":' .. tostring(amount) .. '}') end
    return fail(command, message)
  end

  if command == "set_fame" then
    local amount = extractNumber(text, "amount") or 0
    local sent, message = setFame(extractString(text, "steamId"), extractString(text, "name"), amount, runtimeKey)
    if sent then return ok(command, message, '{"amount":' .. tostring(amount) .. '}') end
    return fail(command, message)
  end

  if command == "change_fame" then
    local amount = extractNumber(text, "amount") or 0
    local sent, message = changeFamePoints(extractString(text, "steamId"), extractString(text, "name"), amount, runtimeKey)
    if sent then return ok(command, message, '{"amount":' .. tostring(amount) .. '}') end
    return fail(command, message)
  end

  if command == "clear_inventory" then
    local sent, message = clearInventory(extractString(text, "steamId"), extractString(text, "name"), runtimeKey)
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "delete_inventory_item" then
    local sent, message = deleteInventoryItem(
      extractString(text, "steamId"),
      extractString(text, "name"),
      runtimeKey,
      extractStringAny(text, { "entityId", "itemEntityId", "runtimeId" }) or "",
      extractStringAny(text, { "itemId", "ItemId" }) or "",
      extractStringAny(text, { "itemClass", "classPath" }) or "",
      extractStringAny(text, { "itemEntitySetup", "assetPath" }) or "")
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "set_attributes" then
    local sent, message = setAttributes(
      extractString(text, "steamId"),
      extractString(text, "name"),
      extractNumber(text, "strength") or extractNumber(text, "Strength") or 0,
      extractNumber(text, "constitution") or extractNumber(text, "Constitution") or 0,
      extractNumber(text, "dexterity") or extractNumber(text, "Dexterity") or 0,
      extractNumber(text, "intelligence") or extractNumber(text, "Intelligence") or 0,
      extractBool(text, "suppressActionLog", false),
      runtimeKey)
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "set_skill" then
    local requestedSkill = extractString(text, "skill") or extractString(text, "skillName") or ""
    local level = extractNumber(text, "level") or extractNumber(text, "skillLevel") or 0
    local experience = extractNumber(text, "experience") or extractNumber(text, "skillExperience") or 0
    if allSkillsKeyword(requestedSkill) or extractBoolAny(text, { "allSkills", "AllSkills", "giveAllSkills", "GiveAllSkills" }, false) == true then
      if level <= 0 then level = 4 end
      local sent, message = setAllSkills(extractString(text, "steamId"), extractString(text, "name"), level, experience, runtimeKey)
      if sent then return ok(command, message, "{}") end
      return fail(command, message)
    end
    local sent, message = setSkill(extractString(text, "steamId"), extractString(text, "name"), requestedSkill, level, experience, runtimeKey)
    if sent then return ok(command, message, "{}") end
    return fail(command, message)
  end

  if command == "apply_character_pack" then
    local sent, message, data = applyCharacterPack(extractString(text, "steamId"), extractString(text, "name"), extractString(text, "pack") or extractString(text, "packName") or "fullstats", runtimeKey)
    if sent then return ok(command, message, data or "{}") end
    return fail(command, message)
  end

  return fail(command, "Неизвестная команда bridge.")
end

fastTravelRoutes = {
  a0 = { name = "A0 Trader", x = -621973.438, y = -557260.438, z = 50 },
  b4 = { name = "B4 Trader", x = 571278.25, y = -224427.219, z = 50 },
  c2 = { name = "C2 Trader", x = -153247.156, y = 289822.219, z = 50 },
  z3 = { name = "Z3 Trader", x = 24006.01, y = -676488.25, z = 50 }
}

function configText(key)
  return readAll(CONFIG_LIVE_DIR .. "\\" .. key .. ".json") or readAll(CONFIG_DIR .. "\\" .. key .. ".json") or ""
end

function configNumber(key, names, fallback)
  local text = configText(key)
  for _, name in ipairs(names) do
    local value = numberField(text, name, nil)
    if value ~= nil then return value end
  end
  return fallback
end

function configBool(key, names, fallback)
  local text = configText(key)
  for _, name in ipairs(names) do
    local raw = text:match('"' .. name .. '"%s*:%s*(true)') or text:match('"' .. name .. '"%s*:%s*(false)')
    if raw == "true" then return true end
    if raw == "false" then return false end
  end
  return fallback
end

function configString(key, names, fallback)
  local text = configText(key)
  local value = extractStringAny(text, names)
  if value ~= nil then return value end
  return fallback or ""
end

DEFAULT_PERMISSION_STATE = [[{
  "Groups": {
    "default": { "Title": "Игрок", "Rank": 0, "ParentGroup": "", "Permissions": [] },
    "vip": { "Title": "VIP", "Rank": 10, "ParentGroup": "default", "Permissions": [ "sethome.vip" ] },
    "admin": { "Title": "Админ", "Rank": 100, "ParentGroup": "vip", "Permissions": [ "*" ] }
  },
  "Users": {}
}]]

function ensurePermissionDefaults()
  if readAll(PERMISSION_STATE_FILE) == nil then writeAll(PERMISSION_STATE_FILE, DEFAULT_PERMISSION_STATE) end
end

function jsonObjectForKey(text, key)
  text = tostring(text or "")
  local needle = '"' .. tostring(key or "") .. '"'
  local pos = text:find(needle, 1, true)
  if pos == nil then return nil end
  local colon = text:find(":", pos + #needle, true)
  if colon == nil then return nil end
  local start = text:find("{", colon + 1, true)
  if start == nil then return nil end
  local depth, inString, escaped = 0, false, false
  for i = start, #text do
    local ch = text:sub(i, i)
    if inString then
      if escaped then
        escaped = false
      elseif ch == "\\" then
        escaped = true
      elseif ch == '"' then
        inString = false
      end
    else
      if ch == '"' then
        inString = true
      elseif ch == "{" then
        depth = depth + 1
      elseif ch == "}" then
        depth = depth - 1
        if depth == 0 then return text:sub(start, i) end
      end
    end
  end
  return nil
end

function jsonArrayForKey(text, key)
  text = tostring(text or "")
  local needle = '"' .. tostring(key or "") .. '"'
  local pos = text:find(needle, 1, true)
  if pos == nil then return nil end
  local colon = text:find(":", pos + #needle, true)
  if colon == nil then return nil end
  local start = text:find("[", colon + 1, true)
  if start == nil then return nil end
  local depth, inString, escaped = 0, false, false
  for i = start, #text do
    local ch = text:sub(i, i)
    if inString then
      if escaped then
        escaped = false
      elseif ch == "\\" then
        escaped = true
      elseif ch == '"' then
        inString = false
      end
    else
      if ch == '"' then
        inString = true
      elseif ch == "[" then
        depth = depth + 1
      elseif ch == "]" then
        depth = depth - 1
        if depth == 0 then return text:sub(start, i) end
      end
    end
  end
  return nil
end

function jsonStringArrayForKey(text, key)
  local arrayText = jsonArrayForKey(text, key) or "[]"
  local out = {}
  for value in arrayText:gmatch('"(.-)"') do
    value = value:gsub('\\"', '"'):gsub("\\\\", "\\"):gsub("\\n", "\n"):gsub("\\r", "\r"):gsub("\\t", "\t")
    table.insert(out, value)
  end
  return out
end

function permissionMatches(granted, required)
  granted = tostring(granted or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  required = tostring(required or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if required == "" then return true end
  if granted == "*" or granted == required then return true end
  if granted:sub(-2) == ".*" then
    local prefix = granted:sub(1, -3)
    return required == prefix or required:sub(1, #prefix + 1) == prefix .. "."
  end
  return false
end

function permissionListHas(list, required)
  for _, granted in ipairs(list or {}) do
    if permissionMatches(granted, required) then return true end
  end
  return false
end

function groupHasPermission(text, groupName, required, visited)
  local group = tostring(groupName or "")
  if group == "" then return false end
  visited = visited or {}
  if visited[group] then return false end
  visited[group] = true
  local groups = jsonObjectForKey(text, "Groups") or ""
  local object = jsonObjectForKey(groups, group)
  if object == nil then return false end
  if permissionListHas(jsonStringArrayForKey(object, "Permissions"), required) then return true end
  local parent = extractStringAny(object, { "ParentGroup", "parentGroup", "parent" }) or ""
  return groupHasPermission(text, parent, required, visited)
end

function userPermissionObject(text, info)
  local users = jsonObjectForKey(text, "Users") or ""
  local steam = tostring((info or {}).steam or (info or {}).steamId or "")
  local profile = tostring((info or {}).userProfileId or (info or {}).serverUserProfileId or "")
  local name = tostring((info or {}).name or "")
  if steam ~= "" then
    local object = jsonObjectForKey(users, steam)
    if object ~= nil then return object end
  end
  if profile ~= "" then
    local object = jsonObjectForKey(users, profile)
    if object ~= nil then return object end
  end
  if name ~= "" then
    local object = jsonObjectForKey(users, name)
    if object ~= nil then return object end
  end
  return nil
end

function hasPermission(info, required)
  local permission = tostring(required or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if permission == "" then return true end
  local text = readAll(PERMISSION_STATE_FILE) or DEFAULT_PERMISSION_STATE
  local userObject = userPermissionObject(text, info)
  if userObject ~= nil and permissionListHas(jsonStringArrayForKey(userObject, "Permissions"), permission) then return true end
  local group = userObject ~= nil and (extractStringAny(userObject, { "Group", "group" }) or "default") or "default"
  return groupHasPermission(text, group, permission, {})
end

function permissionDeniedText(permission)
  return "Нет права для этой команды: " .. tostring(permission or "")
end

function samePlayerRecord(info, object)
  local steam = extractString(object, "steamId") or ""
  local name = extractString(object, "name") or ""
  local profileId = extractString(object, "userProfileId") or extractString(object, "profileId") or ""
  local infoProfileId = tostring(info.userProfileId or info.serverUserProfileId or "")
  return (infoProfileId ~= "" and profileId ~= "" and profileId == infoProfileId) or
    (info.steam ~= "" and steam == info.steam) or
    (info.name ~= "" and name == info.name)
end

function stateObjects(fileName)
  local cache = loadStateArrayCache(STATE_DIR .. "\\" .. tostring(fileName or ""), 4 * 1024 * 1024, false)
  local rows = {}
  for index, object in ipairs(cache.rows or {}) do rows[index] = object end
  return rows
end

function latestStateNumber(fileName, info, field)
  local value = nil
  for _, object in ipairs(stateObjects(fileName)) do
    if samePlayerRecord(info, object) then value = extractNumber(object, field) end
  end
  return value
end

function rememberCooldown(fileName, info, seconds)
  local now = os.time()
  local cooldownSeconds = math.max(0, tonumber(seconds or 0) or 0)
  local extra = ""
  if cooldownSeconds > 0 then
    extra = ',"cooldownHours":' .. tostring(math.floor(cooldownSeconds / 3600)) ..
      ',"expiresAtUtc":' .. js(os.date("!%Y-%m-%dT%H:%M:%SZ", now + cooldownSeconds))
  end
  appendJsonArray(STATE_DIR .. "\\" .. fileName, '{"utc":' .. js(nowUtc()) .. ',"at":' .. tostring(now) .. ',"steamId":' .. js(info.steam or "") .. ',"name":' .. js(info.name or "") .. ',"userProfileId":' .. js(info.userProfileId or info.serverUserProfileId or "") .. extra .. '}', 1024 * 1024)
end

function cooldownRemaining(fileName, info, seconds)
  if tonumber(seconds or 0) <= 0 then return 0 end
  local last = latestStateNumber(fileName, info, "at")
  if last == nil then return 0 end
  local left = math.ceil((tonumber(last) + tonumber(seconds)) - os.time())
  return left > 0 and left or 0
end

function characterConfig()
  local text = configText("character-packs")
  if text == nil or text:gsub("%s+", "") == "" then
    return '{"Enabled":true,"DefaultAttributes":{"Strength":8,"Constitution":8,"Dexterity":8,"Intelligence":8},"SkillPresets":[{"Name":"rifles-core","Skill":"rifles","Level":3},{"Name":"medical-core","Skill":"medical","Level":3},{"Name":"driving-core","Skill":"driving","Level":3}],"Packs":[{"Name":"fullstats","Aliases":["full"],"Enabled":true,"CooldownHours":0,"SuccessMessage":"Атрибуты персонажа обновлены.","Actions":[{"Type":"PlayerCommand","Value":"SetAttributes 8 8 8 8","StopOnFailure":true}]}]}'
  end
  return text
end

function characterModuleEnabled()
  return extractBoolAny(characterConfig(), { "Enabled", "enabled" }, true) ~= false
end

function characterPackObjects()
  local raw = characterConfig():match('"Packs"%s*:%s*(%b[])') or characterConfig():match('"packs"%s*:%s*(%b[])') or ""
  local rows = {}
  for object in raw:gmatch("%b{}") do table.insert(rows, object) end
  if #rows == 0 then
    table.insert(rows, '{"Name":"fullstats","Aliases":["full"],"Enabled":true,"CooldownHours":0,"SuccessMessage":"Атрибуты персонажа обновлены.","Actions":[{"Type":"PlayerCommand","Value":"SetAttributes 8 8 8 8","StopOnFailure":true}]}')
  end
  return rows
end

function characterSkillPresetObjects()
  local raw = characterConfig():match('"SkillPresets"%s*:%s*(%b[])') or characterConfig():match('"skillPresets"%s*:%s*(%b[])') or ""
  local rows = {}
  for object in raw:gmatch("%b{}") do table.insert(rows, object) end
  return rows
end

function characterNameMatches(object, wanted)
  wanted = tostring(wanted or ""):lower()
  if wanted == "" then return false end
  local name = (extractStringAny(object, { "Name", "name" }) or ""):lower()
  if name == wanted then return true end
  local aliases = object:match('"Aliases"%s*:%s*(%b[])') or object:match('"aliases"%s*:%s*(%b[])') or ""
  for alias in aliases:gmatch('"(.-)"') do
    if tostring(alias or ""):lower() == wanted then return true end
  end
  return false
end

function findCharacterPack(name)
  local wanted = tostring(name or "fullstats")
  if wanted == "" then wanted = "fullstats" end
  for _, object in ipairs(characterPackObjects()) do
    if characterNameMatches(object, wanted) then return object end
  end
  return nil
end

function findCharacterSkillPreset(name)
  local wanted = tostring(name or ""):lower()
  if wanted == "" then return nil end
  for _, object in ipairs(characterSkillPresetObjects()) do
    local presetName = (extractStringAny(object, { "Name", "name", "Skill", "skill" }) or ""):lower()
    if presetName == wanted then return object end
  end
  return nil
end

characterPackListText = function()
  if not characterModuleEnabled() then return "Пакеты персонажа сейчас отключены." end
  local packs = {}
  for _, object in ipairs(characterPackObjects()) do
    local name = extractStringAny(object, { "Name", "name" }) or ""
    if name ~= "" and extractBoolAny(object, { "Enabled", "enabled" }, true) ~= false then table.insert(packs, name) end
  end
  table.sort(packs)
  local presets = {}
  for _, object in ipairs(characterSkillPresetObjects()) do
    local name = extractStringAny(object, { "Name", "name" }) or ""
    if name ~= "" then table.insert(presets, name) end
  end
  table.sort(presets)
  local text = #packs > 0 and ("Пакеты персонажа: " .. table.concat(packs, ", ")) or "Пакетов персонажа нет."
  if #presets > 0 then text = text .. " Пресеты навыков: " .. table.concat(presets, ", ") end
  return text .. " Наборы персонажа применяются администратором через веб-панель."
end

function characterPackCooldownRemaining(info, packName, cooldownHours)
  local seconds = math.max(0, tonumber(cooldownHours or 0) or 0) * 3600
  if seconds <= 0 then return 0 end
  local wanted = tostring(packName or ""):lower()
  local latest = 0
  for _, object in ipairs(stateObjects("character-pack-timers.json")) do
    local samePack = (extractString(object, "pack") or ""):lower() == wanted
    local samePlayer = false
    local steam = extractString(object, "steamId") or ""
    local name = extractString(object, "name") or ""
    if info.steam ~= "" and steam ~= "" and steam == info.steam then samePlayer = true end
    if not samePlayer and info.name ~= "" and name ~= "" and name:lower() == info.name:lower() then samePlayer = true end
    if samePack and samePlayer then latest = math.max(latest, extractNumber(object, "at") or 0) end
  end
  if latest <= 0 then return 0 end
  return math.max(0, math.ceil((latest + seconds) - os.time()))
end

function rememberCharacterPack(info, packName, cooldownHours)
  local seconds = math.max(0, tonumber(cooldownHours or 0) or 0) * 3600
  local extra = ""
  if seconds > 0 then extra = ',"expiresAt":' .. tostring(os.time() + seconds) end
  appendJsonArray(STATE_DIR .. "\\character-pack-timers.json", '{"utc":' .. js(nowUtc()) .. ',"at":' .. tostring(os.time()) .. ',"steamId":' .. js(info.steam) .. ',"name":' .. js(info.name) .. ',"pack":' .. js(packName) .. ',"cooldownHours":' .. tostring(tonumber(cooldownHours or 0) or 0) .. extra .. '}', 512 * 1024)
end

function expandCharacterActionValue(value, info)
  local target = info.steam ~= "" and info.steam or info.name
  local expanded = tostring(value or "")
  expanded = expanded:gsub("{steamId}", info.steam or "")
  expanded = expanded:gsub("{SteamId}", info.steam or "")
  expanded = expanded:gsub("{steamID}", info.steam or "")
  expanded = expanded:gsub("{name}", info.name or "")
  expanded = expanded:gsub("{Name}", info.name or "")
  expanded = expanded:gsub("{player}", target or "")
  expanded = expanded:gsub("{Player}", target or "")
  expanded = expanded:gsub("{target}", target or "")
  expanded = expanded:gsub("{Target}", target or "")
  return expanded
end

function executeCharacterAction(info, actionType, actionValue)
  local expanded = expandCharacterActionValue(actionValue, info)
  local parts = splitWords(expanded:gsub("^%s*#", ""))
  local verb = (parts[1] or ""):lower()
  if verb == "setattributes" or verb == "setprisonerattributes" then
    local nums = {}
    for i = 2, #parts do
      local n = tonumber(parts[i])
      if n ~= nil then table.insert(nums, n) end
    end
    if #nums >= 4 then return setAttributes(info.steam, info.name, nums[1], nums[2], nums[3], nums[4], false, info.runtimeKey) end
  end
  if verb == "setskilllevel" then
    local skill = ""
    local level = nil
    local experience = 0
    for i = 2, #parts do
      local n = tonumber(parts[i])
      if n ~= nil and i > 2 then
        level = n
        skill = parts[i - 1] or ""
        experience = tonumber(parts[i + 1]) or 0
        break
      end
    end
    if skill ~= "" and level ~= nil then return setSkill(info.steam, info.name, skill, level, experience, info.runtimeKey) end
  end
  local sent, message = adminExec(expanded, info)
  return sent, message
end

function applyCharacterSkillPreset(info, object)
  local name = extractStringAny(object, { "Name", "name", "Skill", "skill" }) or "skill"
  local skill = extractStringAny(object, { "Skill", "skill", "Name", "name" }) or ""
  local level = extractNumberAny(object, { "Level", "level" }, 1)
  local experience = extractNumberAny(object, { "Experience", "experience" }, 0)
  if skill == "" then return false, "skill preset has no skill", "{}" end
  local sent, message = setSkill(info.steam, info.name, skill, level, experience, info.runtimeKey)
  appendJsonArray(STATE_DIR .. "\\character-packs.json", '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(info.steam) .. ',"name":' .. js(info.name) .. ',"pack":' .. js(name) .. ',"type":"skill-preset","skill":' .. js(skill) .. ',"level":' .. tostring(level) .. ',"ok":' .. (sent and "true" or "false") .. ',"message":' .. js(message) .. '}', 1024 * 1024)
  if sent then return true, "Пресет навыка применён: " .. name, '{"pack":' .. js(name) .. ',"type":"skill-preset","skill":' .. js(skill) .. ',"level":' .. tostring(level) .. '}' end
  return false, message, "{}"
end

applyCharacterPackForInfo = function(info, packName)
  if info == nil then return false, "Игрок не найден среди реально подключённых.", "{}" end
  if not characterModuleEnabled() then return false, "Пресеты персонажа отключены.", "{}" end
  packName = tostring(packName or "fullstats")
  if packName == "" then packName = "fullstats" end
  local object = findCharacterPack(packName)
  if object == nil then
    local preset = findCharacterSkillPreset(packName)
    if preset ~= nil then return applyCharacterSkillPreset(info, preset) end
    return false, "Пресет персонажа не найден: " .. packName, "{}"
  end
  if extractBoolAny(object, { "Enabled", "enabled" }, true) == false then return false, "Пресет персонажа отключён: " .. packName, "{}" end

  local name = extractStringAny(object, { "Name", "name" }) or packName
  local cooldownHours = extractNumberAny(object, { "CooldownHours", "cooldownHours" }, 0)
  local remaining = characterPackCooldownRemaining(info, name, cooldownHours)
  if remaining > 0 then return false, "Кулдаун пресета персонажа активен. Осталось секунд: " .. tostring(remaining), "{}" end

  local results = {}
  local okCount = 0
  local failCount = 0
  local actionsRaw = object:match('"Actions"%s*:%s*(%b[])') or object:match('"actions"%s*:%s*(%b[])') or ""
  for action in actionsRaw:gmatch("%b{}") do
    local actionType = extractStringAny(action, { "Type", "type" }) or "PlayerCommand"
    local actionValue = extractStringAny(action, { "Value", "value" }) or ""
    if actionValue ~= "" then
      local sent, message = executeCharacterAction(info, actionType, actionValue)
      table.insert(results, '{"ok":' .. (sent and "true" or "false") .. ',"type":' .. js(actionType) .. ',"value":' .. js(actionValue) .. ',"message":' .. js(message) .. '}')
      if sent then okCount = okCount + 1 else failCount = failCount + 1 end
      if not sent and extractBoolAny(action, { "StopOnFailure", "stopOnFailure" }, true) ~= false then break end
    end
  end

  if actionsRaw == "" and (object:find('"Strength"%s*:') or object:find('"strength"%s*:')) then
    local sent, message = setAttributes(info.steam, info.name,
      extractNumberAny(object, { "Strength", "strength" }, 8),
      extractNumberAny(object, { "Constitution", "constitution" }, 8),
      extractNumberAny(object, { "Dexterity", "dexterity" }, 8),
      extractNumberAny(object, { "Intelligence", "intelligence" }, 8),
      false,
      info.runtimeKey)
    table.insert(results, '{"ok":' .. (sent and "true" or "false") .. ',"type":"Attributes","message":' .. js(message) .. '}')
    if sent then okCount = okCount + 1 else failCount = failCount + 1 end
  end

  local skillsRaw = object:match('"Skills"%s*:%s*(%b[])') or object:match('"skills"%s*:%s*(%b[])') or ""
  for skillObject in skillsRaw:gmatch("%b{}") do
    local skill = extractStringAny(skillObject, { "Skill", "skill", "Name", "name" }) or ""
    local level = extractNumberAny(skillObject, { "Level", "level" }, 0)
    if skill ~= "" and level > 0 then
      local sent, message = setSkill(info.steam, info.name, skill, level, 0, info.runtimeKey)
      table.insert(results, '{"ok":' .. (sent and "true" or "false") .. ',"type":"Skill","skill":' .. js(skill) .. ',"level":' .. tostring(level) .. ',"message":' .. js(message) .. '}')
      if sent then okCount = okCount + 1 else failCount = failCount + 1 end
    end
  end

  if okCount > 0 and failCount == 0 then rememberCharacterPack(info, name, cooldownHours) end
  local data = '{"pack":' .. js(name) .. ',"okActions":' .. tostring(okCount) .. ',"failedActions":' .. tostring(failCount) .. ',"results":[' .. table.concat(results, ",") .. ']}'
  appendJsonArray(STATE_DIR .. "\\character-packs.json", '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(info.steam) .. ',"name":' .. js(info.name) .. ',"pack":' .. js(name) .. ',"okActions":' .. tostring(okCount) .. ',"failedActions":' .. tostring(failCount) .. ',"results":[' .. table.concat(results, ",") .. ']}', 1024 * 1024)
  if okCount > 0 and failCount == 0 then return true, extractStringAny(object, { "SuccessMessage", "successMessage" }) or ("Пакет персонажа применён: " .. name), data end
  if okCount > 0 then return false, "Пресет персонажа выполнен частично: " .. name, data end
  return false, "Пресет персонажа не выполнил ни одного действия: " .. name, data
end

applyCharacterPack = function(steamId, name, packName, runtimeKey)
  local info = findPlayer(steamId, name, runtimeKey)
  return applyCharacterPackForInfo(info, packName)
end

function distance2d(ax, ay, bx, by)
  local dx = (tonumber(ax) or 0) - (tonumber(bx) or 0)
  local dy = (tonumber(ay) or 0) - (tonumber(by) or 0)
  return math.sqrt(dx * dx + dy * dy)
end

function observePlayerArrival(action, info, x, y, z, timeoutSeconds, radius, onArrived, onFailed)
  local deadline = os.time() + math.max(1, tonumber(timeoutSeconds or 30) or 30)
  local maxDistance = math.max(100, tonumber(radius or 1500) or 1500)
  local function tick()
    local cached = findPlayer(info.steam, info.name, info.runtimeKey) or info
    local live = refreshRuntimePlayerInfo(cached) or enrichPlayerInfoFromServerLog(cached) or cached
    if live == nil then
      appendActionEvent(action .. "_arrival", false, info, "Игрок вышел до подтверждения прибытия.",
        '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) .. ',"radius":' .. tostring(maxDistance) .. '}')
      if onFailed ~= nil then onFailed("Игрок вышел до подтверждения прибытия.") end
      return
    end
    local distance = distance2d(live.x, live.y, x, y)
    if distance <= maxDistance then
      appendActionEvent(action .. "_arrival", true, live, "Прибытие подтверждено live-позицией.",
        '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) ..
        ',"distance":' .. tostring(math.floor(distance + 0.5)) ..
        ',"radius":' .. tostring(maxDistance) .. '}')
      if onArrived ~= nil then onArrived(live, distance) end
      return
    end
    if os.time() >= deadline then
      appendActionEvent(action .. "_arrival", false, live, "Прибытие не подтверждено live-позицией.",
        '{"x":' .. tostring(x or 0) .. ',"y":' .. tostring(y or 0) .. ',"z":' .. tostring(z or 0) ..
        ',"distance":' .. tostring(math.floor(distance + 0.5)) ..
        ',"radius":' .. tostring(maxDistance) .. '}')
      if onFailed ~= nil then onFailed("Прибытие не подтверждено: расстояние до точки " .. tostring(math.floor(distance + 0.5)) .. ".") end
      return
    end
    deferGame(1000, tick)
  end
  tick()
end

function configuredFastTravelRoutes()
  local text = configText("fast-travel")
  local raw = text:match('"Outposts"%s*:%s*(%b[])') or text:match('"outposts"%s*:%s*(%b[])')
  local routes = {}
  if raw ~= nil then
    for object in raw:gmatch("%b{}") do
      local alias = (extractString(object, "CommandAlias") or extractString(object, "commandAlias") or ""):lower()
      local display = extractString(object, "DisplayName") or extractString(object, "displayName") or alias
      local point = object:match('"ArrivalPoint"%s*:%s*%[(.-)%]') or object:match('"arrivalPoint"%s*:%s*%[(.-)%]')
      if alias ~= "" and point ~= nil then
        local values = {}
        for num in point:gmatch("-?%d+%.?%d*") do table.insert(values, tonumber(num)) end
        if #values >= 3 then
          routes[alias] = {
            name = display,
            x = values[1],
            y = values[2],
            z = values[3],
            price = numberField(object, "Price", numberField(object, "price", nil))
          }
        end
      end
    end
  end
  for alias, route in pairs(fastTravelRoutes) do
    if routes[alias] == nil then routes[alias] = route end
  end
  return routes
end

function configuredRentalVehicles()
  local text = configText("vehicle-rental")
  local defaultMinutes = math.max(1, configNumber("vehicle-rental", { "DefaultRentalMinutes", "defaultRentalMinutes", "DefaultMinutes", "defaultMinutes" }, 10))
  local minMinutes = math.max(1, configNumber("vehicle-rental", { "MinRentalMinutes", "minRentalMinutes", "MinMinutes", "minMinutes" }, 10))
  local maxMinutes = math.max(minMinutes, configNumber("vehicle-rental", { "MaxRentalMinutes", "maxRentalMinutes", "MaxMinutes", "maxMinutes" }, 60))
  local defaultPenalty = math.max(0, configNumber("vehicle-rental", { "DefaultMissingVehiclePenalty", "defaultMissingVehiclePenalty", "MissingVehiclePenalty", "missingVehiclePenalty", "SoldVehiclePenalty", "soldVehiclePenalty" }, 0))
  local raw = text:match('"Vehicles"%s*:%s*(%b[])') or text:match('"vehicles"%s*:%s*(%b[])')
  local vehicles = {}
  if raw == nil then
    vehicles = {
      rager = { display = "Rager", asset = "BPC_Rager", initial = 5000, price = 15000, defaultMinutes = defaultMinutes, minMinutes = minMinutes, maxMinutes = maxMinutes, penalty = defaultPenalty },
      wolfswaggen = { display = "WolfsWagen", asset = "BPC_WolfsWagen", initial = 4000, price = 12000, defaultMinutes = defaultMinutes, minMinutes = minMinutes, maxMinutes = maxMinutes, penalty = defaultPenalty },
      laika = { display = "Laika", asset = "BPC_Laika", initial = 4000, price = 8000, defaultMinutes = defaultMinutes, minMinutes = minMinutes, maxMinutes = maxMinutes, penalty = defaultPenalty }
    }
  end
  local function removeRentalVehicleDuplicates(alias, asset)
    local cleanAlias = tostring(alias or ""):lower()
    local cleanAsset = tostring(asset or ""):lower()
    if cleanAlias == "" or cleanAsset == "" then return end
    for existingAlias, vehicle in pairs(vehicles) do
      if tostring(existingAlias or "") ~= cleanAlias and tostring(vehicle and vehicle.asset or ""):lower() == cleanAsset then
        vehicles[existingAlias] = nil
      end
    end
  end
  if raw ~= nil then
    for object in raw:gmatch("%b{}") do
      local alias = (extractString(object, "Alias") or extractString(object, "alias") or ""):lower()
      local asset = extractString(object, "AssetName") or extractString(object, "assetName") or ""
      local enabled = object:match('"Enabled"%s*:%s*false') == nil and object:match('"enabled"%s*:%s*false') == nil
      if enabled and alias ~= "" and asset ~= "" then
        removeRentalVehicleDuplicates(alias, asset)
        vehicles[alias] = {
          display = extractString(object, "DisplayName") or extractString(object, "displayName") or alias,
          asset = asset,
          initial = numberField(object, "InitialCharge", numberField(object, "initialCharge", 0)),
          price = numberField(object, "PricePer10Minutes", numberField(object, "pricePer10Minutes", 0)),
          defaultMinutes = math.max(1, numberField(object, "DefaultMinutes", numberField(object, "defaultMinutes", defaultMinutes))),
          minMinutes = math.max(1, numberField(object, "MinMinutes", numberField(object, "minMinutes", minMinutes))),
          maxMinutes = math.max(1, numberField(object, "MaxMinutes", numberField(object, "maxMinutes", maxMinutes))),
          penalty = math.max(0, numberField(object, "MissingVehiclePenalty", numberField(object, "missingVehiclePenalty", numberField(object, "SoldVehiclePenalty", numberField(object, "soldVehiclePenalty", defaultPenalty)))))
        }
        if vehicles[alias].maxMinutes < vehicles[alias].minMinutes then vehicles[alias].maxMinutes = vehicles[alias].minMinutes end
      end
    end
  end
  return vehicles
end

local function moneyLabel(amount)
  local value = math.max(0, math.floor(tonumber(amount or 0) or 0))
  return "$" .. tostring(value)
end

local function rentPerMinute(vehicle)
  return math.max(0, math.floor(((vehicle and tonumber(vehicle.price or 0)) or 0) / 10))
end

VEHICLE_RENTAL_GLOBAL_NEXT_AT = VEHICLE_RENTAL_GLOBAL_NEXT_AT or 0
VEHICLE_RENTAL_PLAYER_NEXT_AT = VEHICLE_RENTAL_PLAYER_NEXT_AT or {}

function rentalCooldownKey(info)
  if info == nil then return "" end
  local steam = cleanText(info.steam or info.steamId or "")
  if steam ~= "" then return "steam:" .. steam end
  local profile = cleanText(info.userProfileId or info.serverUserProfileId or "")
  if profile ~= "" and profile ~= "0" then return "profile:" .. profile end
  local name = cleanText(info.name or ""):lower()
  if name ~= "" and name ~= "unknown" then return "name:" .. name end
  return ""
end

function vehicleRentalSpawnCooldownRemaining(info)
  local now = os.time()
  local waitGlobal = math.max(0, math.floor((tonumber(VEHICLE_RENTAL_GLOBAL_NEXT_AT or 0) or 0) - now))
  local key = rentalCooldownKey(info)
  local waitPlayer = 0
  if key ~= "" then waitPlayer = math.max(0, math.floor((tonumber(VEHICLE_RENTAL_PLAYER_NEXT_AT[key] or 0) or 0) - now)) end
  if waitPlayer >= waitGlobal and waitPlayer > 0 then return waitPlayer, "player" end
  if waitGlobal > 0 then return waitGlobal, "global" end
  return 0, ""
end

function reserveVehicleRentalSpawnCooldown(info)
  local now = os.time()
  local globalSeconds = math.max(0, configNumber("vehicle-rental", { "GlobalSpawnCooldownSeconds", "globalSpawnCooldownSeconds" }, 60))
  local playerSeconds = math.max(0, configNumber("vehicle-rental", { "PlayerSpawnCooldownSeconds", "playerSpawnCooldownSeconds" }, 180))
  VEHICLE_RENTAL_GLOBAL_NEXT_AT = math.max(tonumber(VEHICLE_RENTAL_GLOBAL_NEXT_AT or 0) or 0, now + globalSeconds)
  local key = rentalCooldownKey(info)
  if key ~= "" then
    VEHICLE_RENTAL_PLAYER_NEXT_AT[key] = math.max(tonumber(VEHICLE_RENTAL_PLAYER_NEXT_AT[key] or 0) or 0, now + playerSeconds)
  end
end

local function sendRentHelp(info, current)
  targetMessageResolved(info, "Аренда транспорта:")
  local labels = {}
  for alias, vehicle in pairs(configuredRentalVehicles()) do
    table.insert(labels, { alias = alias, vehicle = vehicle })
  end
  table.sort(labels, function(a, b)
    local ad = tostring((a.vehicle and a.vehicle.display) or a.alias or "")
    local bd = tostring((b.vehicle and b.vehicle.display) or b.alias or "")
    if ad == bd then return tostring(a.alias or "") < tostring(b.alias or "") end
    return ad < bd
  end)
  for _, row in ipairs(labels) do
    local vehicle = row.vehicle or {}
    local alias = tostring(row.alias or "")
    local display = tostring(vehicle.display or alias)
    local minMinutes = math.max(1, tonumber(vehicle.minMinutes or 10) or 10)
    local maxMinutes = math.max(minMinutes, tonumber(vehicle.maxMinutes or 60) or 60)
    local penalty = math.max(0, math.floor(tonumber(vehicle.penalty or 0) or 0))
    targetMessageResolved(info, "/rent " .. alias .. " [мин] - " .. display .. " | " .. moneyLabel(vehicle.initial) .. " сразу, " .. moneyLabel(rentPerMinute(vehicle)) .. "/мин после 10 | срок " .. tostring(minMinutes) .. "-" .. tostring(maxMinutes) .. " мин" .. (penalty > 0 and (" | штраф " .. moneyLabel(penalty)) or ""))
  end
  targetMessageResolved(info, "Команды: /rent time, /rent extend <мин>, /rent return.")
  if current ~= nil then
    local left = math.max(0, (extractNumber(current, "expiresAt") or 0) - os.time())
    targetMessageResolved(info, "Активно: " .. (extractString(current, "displayName") or extractString(current, "vehicleId") or "transport") .. ", осталось " .. tostring(math.ceil(left / 60)) .. " мин.")
  end
end

local function sendRentStatus(info, current)
  if current == nil then
    targetMessageResolved(info, "У тебя нет активной аренды.")
    return
  end
  local left = math.max(0, (extractNumber(current, "expiresAt") or 0) - os.time())
  local chargeableMinutes, totalCostSoFar, additionalCharge, outstanding, alreadyPaid = rentalTaxBreakdown(current, os.time())
  targetMessageResolved(info, "Аренда: " .. (extractString(current, "displayName") or extractString(current, "vehicleId") or "transport") .. " | осталось " .. tostring(math.ceil(left / 60)) .. " мин | использовано " .. tostring(chargeableMinutes) .. " мин.")
  targetMessageResolved(info, "Оплачено: " .. moneyLabel(alreadyPaid) .. " | стоимость сейчас: " .. moneyLabel(totalCostSoFar) .. " | доплата при возврате: " .. moneyLabel(outstanding) .. ". Команды: /rent extend <мин>, /rent return.")
end

function fastTravelFareForInfo(info, route)
  if route == nil then return 0 end
  local routeFare = tonumber(route.price)
  if routeFare ~= nil and routeFare > 0 then return math.max(0, math.floor(routeFare)) end
  local fixedFare = configNumber("fast-travel", { "FixedFare", "fixedFare", "TravelCost", "travelCost", "Amount", "amount" }, nil)
  if fixedFare ~= nil and tonumber(fixedFare) ~= nil and tonumber(fixedFare) > 0 then
    return math.max(0, math.floor(tonumber(fixedFare) or 0))
  end
  local rate = configNumber("fast-travel", { "RatePerMeter", "ratePerMeter" }, 0.5)
  local x = tonumber(info and info.x)
  local y = tonumber(info and info.y)
  if x == nil or y == nil then return 0 end
  return math.max(0, math.floor(distance2d(x, y, route.x, route.y) * rate + 0.5))
end

FAST_TRAVEL_PENDING = FAST_TRAVEL_PENDING or {}
FAST_TRAVEL_GLOBAL_PENDING = FAST_TRAVEL_GLOBAL_PENDING or false
HOME_TELEPORT_PENDING = HOME_TELEPORT_PENDING or {}

function transientPlayerKey(info)
  if info == nil then return "unknown" end
  local steam = tostring(info.steam or "")
  if steam ~= "" then return "steam:" .. steam end
  local runtimeKey = tostring(info.runtimeKey or "")
  if runtimeKey ~= "" then return "runtime:" .. runtimeKey end
  local name = tostring(info.name or "")
  if name ~= "" then return "name:" .. name:lower() end
  return "unknown"
end

function safeFastTravelZ(route)
  local z = tonumber(route and route.z) or 0
  if not configBool("bridge-safety", { "EnableDirectTeleport", "enableDirectTeleport", "AllowDirectPawnTeleport", "allowDirectPawnTeleport" }, false) then
    return z
  end
  local minZ = configNumber("fast-travel", { "MinArrivalZ", "minArrivalZ", "SafeArrivalZ", "safeArrivalZ" }, 12000)
  if z < minZ then return minZ end
  return z
end

function rentalRecordKeyFromObject(object)
  local steam = extractString(object, "steamId") or ""
  if steam ~= "" then return "steam:" .. steam end
  local name = extractString(object, "name") or ""
  if name ~= "" then return "name:" .. name:lower() end
  return ""
end

function rentalStatus(object)
  local status = (extractString(object, "status") or ""):lower()
  if status ~= "" then return status end
  if extractBool(object, "returned", false) then return "returned" end
  return "active"
end

function rentalClosed(object)
  local status = rentalStatus(object)
  return status == "returned" or status == "expired" or status == "expired_untracked" or status == "sold_or_missing" or status == "missing_vehicle" or status == "cancelled" or status == "failed"
end

function rentalPendingDestroy(object)
  local status = rentalStatus(object)
  return status == "expire_pending" or status == "expired_pending" or status == "pending_destroy"
end

function rentalWarningMinutes()
  local text = configText("vehicle-rental")
  local raw = text:match('"WarningMinutesBeforeExpiry"%s*:%s*(%b[])') or
    text:match('"warningMinutesBeforeExpiry"%s*:%s*(%b[])') or
    text:match('"WarningsBeforeExpiry"%s*:%s*(%b[])') or
    text:match('"warningsBeforeExpiry"%s*:%s*(%b[])') or ""
  local rows = {}
  local seen = {}
  for _, value in ipairs(numberList(raw)) do
    local minutes = math.floor(tonumber(value) or 0)
    if minutes > 0 and not seen[minutes] then
      seen[minutes] = true
      table.insert(rows, minutes)
    end
  end
  if #rows == 0 then rows = { 5, 1 } end
  table.sort(rows, function(a, b) return a < b end)
  return rows
end

function rentalWarningKey(object, minutes)
  return tostring(rentalRecordKeyFromObject(object)) ..
    "|alias:" .. tostring(extractString(object, "alias") or "") ..
    "|vehicle:" .. tostring(extractString(object, "vehicleId") or "") ..
    "|started:" .. tostring(extractNumber(object, "startedAt") or 0) ..
    "|expires:" .. tostring(extractNumber(object, "expiresAt") or 0) ..
    "|m:" .. tostring(minutes or 0)
end

function latestRentalWarningKeys()
  local sent = {}
  for _, object in ipairs(stateObjects("vehicle-rental-warnings.json")) do
    local key = extractString(object, "warningKey") or ""
    if key ~= "" and extractBool(object, "sent", false) then sent[key] = true end
  end
  return sent
end

function sendRentalExpiryWarningIfNeeded(object, sentKeys)
  if object == nil or rentalClosed(object) or rentalPendingDestroy(object) then return false end
  local expiresAt = extractNumber(object, "expiresAt") or 0
  local now = os.time()
  if expiresAt <= now then return false end
  local left = math.max(0, expiresAt - now)
  local dueMinutes = nil
  local dueKey = ""
  for _, minutes in ipairs(rentalWarningMinutes()) do
    local key = rentalWarningKey(object, minutes)
    if left <= minutes * 60 and not (sentKeys or {})[key] then
      dueMinutes = minutes
      dueKey = key
      break
    end
  end
  if dueMinutes == nil then return false end

  local steam = extractString(object, "steamId") or ""
  local name = extractString(object, "name") or ""
  local live = findPlayer(steam, name)
  if live == nil then return false end

  local displayName = extractString(object, "displayName") or extractString(object, "vehicleId") or "транспорта"
  local leftMinutes = math.max(1, math.ceil(left / 60))
  local sent, route = targetMessage(steam, name,
    "Внимание: до конца аренды " .. tostring(displayName) .. " осталось примерно " .. tostring(leftMinutes) ..
    " мин. Используй /rent extend <мин> или /rent return.",
    "vehicle-rental-warning", live.runtimeKey)

  appendActionEvent("vehicle_rental_warning", sent, live, tostring(route or ""),
    '{"warningKey":' .. js(dueKey) ..
    ',"warningMinutes":' .. tostring(dueMinutes) ..
    ',"leftSeconds":' .. tostring(left) ..
    ',"displayName":' .. js(displayName) .. '}')

  if sent then
    appendJsonArray(STATE_DIR .. "\\vehicle-rental-warnings.json",
      '{"utc":' .. js(nowUtc()) ..
      ',"warningKey":' .. js(dueKey) ..
      ',"sent":true' ..
      ',"steamId":' .. js(steam) ..
      ',"name":' .. js(name) ..
      ',"warningMinutes":' .. tostring(dueMinutes) ..
      ',"leftSeconds":' .. tostring(left) ..
      ',"displayName":' .. js(displayName) ..
      ',"expiresAt":' .. tostring(expiresAt) .. '}',
      512 * 1024)
    if sentKeys ~= nil then sentKeys[dueKey] = true end
  end
  return sent
end

function rentalDestroyRetryDelay(attempts)
  local n = math.max(1, tonumber(attempts) or 1)
  local delay = 60
  for _ = 2, math.min(n, 6) do delay = delay * 2 end
  if delay > 3600 then delay = 3600 end
  return delay
end

RENTAL_DESTROY_RESOLVE_NEXT_AT = RENTAL_DESTROY_RESOLVE_NEXT_AT or 0

local function rentalRuntimeDestroyResolveAllowed()
  if not configBool("vehicle-rental", { "EnableRuntimeVehicleExpireDestroy", "enableRuntimeVehicleExpireDestroy" }, true) then
    return false, "runtime vehicle lookup disabled"
  end
  local now = os.time()
  local nextAt = tonumber(RENTAL_DESTROY_RESOLVE_NEXT_AT or 0) or 0
  if nextAt > now then
    return false, "runtime vehicle lookup cooldown"
  end
  local cooldown = math.max(5, configNumber("vehicle-rental", { "RuntimeDestroyResolveCooldownSeconds", "runtimeDestroyResolveCooldownSeconds" }, 45))
  RENTAL_DESTROY_RESOLVE_NEXT_AT = now + cooldown
  return true, ""
end

local function rentalDestroyMaxAttempts()
  return math.max(1, math.floor(configNumber("vehicle-rental", { "ExpireDestroyMaxAttempts", "expireDestroyMaxAttempts", "DestroyMaxAttempts", "destroyMaxAttempts" }, 6)))
end

function vehicleDestroyRefFromRental(object)
  local numeric = extractNumber(object, "entityId") or extractNumber(object, "vehicleEntityId")
  if numeric ~= nil and numeric > 0 then return tostring(math.floor(numeric)) end
  local ref = extractString(object, "destroyRef") or ""
  if ref == "" then
    numeric = extractNumber(object, "destroyRef")
    if numeric ~= nil and numeric > 0 then ref = tostring(math.floor(numeric)) end
  end
  return tostring(ref or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

function rentalTaxRecordKey(object, reason)
  local steam = extractString(object, "steamId") or ""
  local alias = (extractString(object, "alias") or extractString(object, "vehicleId") or ""):lower()
  local startedAt = extractNumber(object, "startedAt") or 0
  local destroyRef = vehicleDestroyRefFromRental(object)
  return tostring(steam) .. "|" .. tostring(alias) .. "|" .. tostring(startedAt) .. "|" .. tostring(destroyRef) .. "|" .. tostring(reason or "usage")
end

function latestRentalPendingTaxesByKey()
  local latest = {}
  for _, object in ipairs(stateObjects("vehicle-rental-pending-taxes.json")) do
    local key = extractString(object, "taxKey") or ""
    if key ~= "" then latest[key] = object end
  end
  return latest
end

function rentalTaxBreakdown(object, endTime)
  local alias = (extractString(object, "alias") or ""):lower()
  local configured = configuredRentalVehicles()[alias]
  local startedAt = extractNumber(object, "startedAt") or os.time()
  local effectiveEnd = math.max(startedAt, tonumber(endTime) or os.time())
  local chargeableMinutes = math.max(0, math.ceil((effectiveEnd - startedAt) / 60))
  local initialCharge = extractNumber(object, "initialCharge") or (configured and configured.initial) or 0
  local pricePer10Minutes = extractNumber(object, "pricePer10Minutes") or (configured and configured.price) or 0
  local pricePerMinute = math.max(0, math.floor(pricePer10Minutes / 10))
  if chargeableMinutes <= 10 then
    return chargeableMinutes, initialCharge, 0, 0, math.max(0, initialCharge), 0, pricePerMinute
  end
  local minutesAfter10 = chargeableMinutes - 10
  local additionalCharge = math.max(0, minutesAfter10 * pricePerMinute)
  local totalCostSoFar = initialCharge + additionalCharge
  local alreadyPaid = math.max(0, extractNumber(object, "totalCharge") or initialCharge)
  local outstanding = math.max(0, totalCostSoFar - alreadyPaid)
  return chargeableMinutes, totalCostSoFar, additionalCharge, outstanding, alreadyPaid, minutesAfter10, pricePerMinute
end

function rentalMissingVehicleLikely(destroyAttempted, destroyOk, destroyMessage)
  if destroyOk then return false end
  if not destroyAttempted then return true end
  local lower = tostring(destroyMessage or ""):lower()
  return lower:find("not found", 1, true) ~= nil or
    lower:find("missing vehicle", 1, true) ~= nil or
    lower:find("missing entity", 1, true) ~= nil
end

function rentalMissingVehiclePenaltyAmount(object)
  local alias = (extractString(object, "alias") or ""):lower()
  local configured = configuredRentalVehicles()[alias]
  local amount = extractNumber(object, "missingVehiclePenalty") or extractNumber(object, "soldVehiclePenalty")
  if amount == nil and configured ~= nil then amount = tonumber(configured.penalty or 0) end
  if amount == nil then
    amount = configNumber("vehicle-rental", { "DefaultMissingVehiclePenalty", "defaultMissingVehiclePenalty", "MissingVehiclePenalty", "missingVehiclePenalty", "SoldVehiclePenalty", "soldVehiclePenalty" }, 0)
  end
  return math.max(0, tonumber(amount) or 0)
end

function chargeRentalMissingVehiclePenalty(info, object, reason)
  if not configBool("vehicle-rental", { "ChargePenaltyOnMissingVehicle", "chargePenaltyOnMissingVehicle" }, true) then
    return true, "Штраф за потерянный транспорт отключён.", 0, ""
  end
  local amount = rentalMissingVehiclePenaltyAmount(object)
  if amount <= 0 then return true, "", 0, "" end
  local live = info ~= nil and (resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info) or nil
  if live ~= nil and (live.steam or "") ~= "" then
    local charged, chargeMessage = changeMoney(live.steam, live.name, -amount, "Normal", live.runtimeKey)
    appendActionEvent("vehicle_rental_missing_penalty", charged, live,
      charged and "Штраф за потерянный/проданный транспорт поставлен в live-очередь." or tostring(chargeMessage),
      '{"reason":' .. js(reason or "missing-vehicle") .. ',"amount":' .. tostring(amount) .. '}')
    if charged then return true, chargeMessage, amount, "" end
  end
  local taxKey = appendRentalPendingTax(live or info, object, "missing-vehicle-penalty", amount, 0, 0, 0, 0, "Штраф за потерянный или проданный арендованный транспорт.")
  appendActionEvent("vehicle_rental_missing_penalty", false, live or info or {}, "Штраф за потерянный транспорт перенесён в ожидание.",
    '{"reason":' .. js(reason or "missing-vehicle") .. ',"amount":' .. tostring(amount) .. ',"taxKey":' .. js(taxKey or "") .. '}')
  return false, "Штраф перенесён в ожидание.", amount, taxKey
end

function appendRentalPendingTax(info, object, reason, amount, chargeableMinutes, minutesAfter10, totalCostSoFar, pricePerMinute, message)
  local taxKey = rentalTaxRecordKey(object, reason)
  local latest = latestRentalPendingTaxesByKey()[taxKey]
  if latest ~= nil then
    local latestStatus = (extractString(latest, "status") or ""):lower()
    if latestStatus == "pending" or latestStatus == "paid" then
      return taxKey, latestStatus
    end
  end
  local target = info or {}
  appendJsonArray(STATE_DIR .. "\\vehicle-rental-pending-taxes.json",
    '{"utc":' .. js(nowUtc()) ..
    ',"taxKey":' .. js(taxKey) ..
    ',"steamId":' .. js(extractString(object, "steamId") or target.steam or "") ..
    ',"name":' .. js(extractString(object, "name") or target.name or "") ..
    ',"alias":' .. js(extractString(object, "alias") or "") ..
    ',"displayName":' .. js(extractString(object, "displayName") or extractString(object, "vehicleId") or "vehicle") ..
    ',"vehicleId":' .. js(extractString(object, "vehicleId") or "") ..
    ',"startedAt":' .. tostring(extractNumber(object, "startedAt") or 0) ..
    ',"expiresAt":' .. tostring(extractNumber(object, "expiresAt") or 0) ..
    ',"destroyRef":' .. js(vehicleDestroyRefFromRental(object)) ..
    ',"status":"pending"' ..
    ',"reason":' .. js(reason or "usage") ..
    ',"amount":' .. tostring(math.max(0, tonumber(amount) or 0)) ..
    ',"chargeableMinutes":' .. tostring(chargeableMinutes or 0) ..
    ',"minutesAfter10":' .. tostring(minutesAfter10 or 0) ..
    ',"pricePerMinute":' .. tostring(pricePerMinute or 0) ..
    ',"totalCostSoFar":' .. tostring(totalCostSoFar or 0) ..
    ',"message":' .. js(message or "") .. '}',
    1024 * 1024)
  return taxKey, "pending"
end

function markRentalPendingTaxPaid(info, object, taxKey, amount, message)
  local target = info or {}
  appendJsonArray(STATE_DIR .. "\\vehicle-rental-pending-taxes.json",
    '{"utc":' .. js(nowUtc()) ..
    ',"taxKey":' .. js(taxKey or "") ..
    ',"steamId":' .. js(extractString(object, "steamId") or target.steam or "") ..
    ',"name":' .. js(extractString(object, "name") or target.name or "") ..
    ',"alias":' .. js(extractString(object, "alias") or "") ..
    ',"displayName":' .. js(extractString(object, "displayName") or extractString(object, "vehicleId") or "vehicle") ..
    ',"vehicleId":' .. js(extractString(object, "vehicleId") or "") ..
    ',"status":"paid"' ..
    ',"amount":' .. tostring(math.max(0, tonumber(amount) or 0)) ..
    ',"message":' .. js(message or "") .. '}',
    1024 * 1024)
end

function collectRentalPendingTaxes(info, notifyIfInsufficient)
  if info == nil then return 0, 0, true end
  local latest = latestRentalPendingTaxesByKey()
  local rows = {}
  for _, object in pairs(latest) do
    if samePlayerRecord(info, object) and (extractString(object, "status") or ""):lower() == "pending" then
      table.insert(rows, object)
    end
  end
  table.sort(rows, function(a, b)
    return tostring(extractString(a, "utc") or "") < tostring(extractString(b, "utc") or "")
  end)
  local chargedCount, chargedAmount = 0, 0
  for _, object in ipairs(rows) do
    local amount = math.max(0, extractNumber(object, "amount") or 0)
    if amount > 0 then
      local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
      local charged, chargeMessage = changeMoney(live.steam, live.name, -amount, "Normal", live.runtimeKey)
      if charged then
        markRentalPendingTaxPaid(live, object, extractString(object, "taxKey") or "", amount, chargeMessage)
        chargedCount = chargedCount + 1
        chargedAmount = chargedAmount + amount
        appendActionEvent("vehicle_rental_pending_tax", true, live, "Отложенная доплата поставлена в live-очередь.",
          '{"taxKey":' .. js(extractString(object, "taxKey") or "") .. ',"amount":' .. tostring(amount) .. '}')
      else
        appendActionEvent("vehicle_rental_pending_tax", false, live, tostring(chargeMessage),
          '{"taxKey":' .. js(extractString(object, "taxKey") or "") .. ',"amount":' .. tostring(amount) .. '}')
        if notifyIfInsufficient then
          targetMessage(live.steam, live.name,
            "У тебя есть долг по прошлой аренде: " .. tostring(amount) .. ". Сумма будет списана автоматически, когда игрок будет доступен для live-команды.",
            "vehicle-rental", live.runtimeKey)
        end
        return chargedCount, chargedAmount, false
      end
    end
  end
  return chargedCount, chargedAmount, true
end

function finalizeRentalUsageCharge(info, object, reason, endTime)
  local chargeableMinutes, totalCostSoFar, additionalCharge, outstanding, alreadyPaid, minutesAfter10, pricePerMinute = rentalTaxBreakdown(object, endTime)
  if outstanding <= 0 then
    return true, "", 0, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, ""
  end
  local live = info ~= nil and (resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info) or nil
  if live ~= nil and (live.steam or "") ~= "" then
    local charged, chargeMessage = changeMoney(live.steam, live.name, -outstanding, "Normal", live.runtimeKey)
    appendActionEvent("vehicle_rental_usage_charge", charged, live,
      charged and "Доплата аренды поставлена в live-очередь." or tostring(chargeMessage),
      '{"reason":' .. js(reason or "usage") ..
      ',"amount":' .. tostring(outstanding) ..
      ',"chargeableMinutes":' .. tostring(chargeableMinutes) ..
      ',"minutesAfter10":' .. tostring(minutesAfter10) ..
      ',"pricePerMinute":' .. tostring(pricePerMinute) ..
      ',"totalCostSoFar":' .. tostring(totalCostSoFar) ..
      ',"alreadyPaid":' .. tostring(alreadyPaid) .. '}')
    if charged then
      return true, chargeMessage, outstanding, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, ""
    end
  end
  local taxKey = ""
  taxKey = appendRentalPendingTax(live or info, object, reason, outstanding, chargeableMinutes, minutesAfter10, totalCostSoFar, pricePerMinute, "Доплата перенесена в ожидание.")
  appendActionEvent("vehicle_rental_usage_charge", false, live or info or {}, "Доплата аренды перенесена в ожидание.",
    '{"reason":' .. js(reason or "usage") ..
    ',"amount":' .. tostring(outstanding) ..
    ',"taxKey":' .. js(taxKey or "") ..
    ',"chargeableMinutes":' .. tostring(chargeableMinutes) ..
    ',"minutesAfter10":' .. tostring(minutesAfter10) ..
    ',"pricePerMinute":' .. tostring(pricePerMinute) ..
    ',"totalCostSoFar":' .. tostring(totalCostSoFar) ..
    ',"alreadyPaid":' .. tostring(alreadyPaid) .. '}')
  return false, "Доплата перенесена в ожидание.", outstanding, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, taxKey
end

function expireRentalObject(object, steam, name, info, source)
  steam = steam or extractString(object, "steamId") or ""
  name = name or extractString(object, "name") or ""
  local targetInfo = info or { steam = steam, name = name }
  local expiresAt = extractNumber(object, "expiresAt") or 0
  local displayName = extractString(object, "displayName") or extractString(object, "vehicleId") or "vehicle"
  local destroyRef = vehicleDestroyRefFromRental(object)
  local destroyResolveDeferred = false
  local destroyResolveAttempted = false
  local destroyResolveMessage = ""
  if destroyRef == "" then
    local canResolve, resolveReason = rentalRuntimeDestroyResolveAllowed()
    if canResolve then
      destroyResolveAttempted = true
      destroyRef = resolveRentalDestroyRef(object, targetInfo)
    else
      destroyResolveDeferred = true
      destroyResolveMessage = tostring(resolveReason or "runtime vehicle lookup deferred")
    end
  end
  local destroyAttempted = destroyRef ~= ""
  local destroyOk = false
  local destroyMessage = ""
  local destroyAttempts = math.max(0, extractNumber(object, "destroyAttempts") or 0)
  if destroyAttempted then
    destroyAttempts = destroyAttempts + 1
    destroyOk, destroyMessage = destroyVehicleRef(destroyRef, targetInfo, source or "expired")
  elseif destroyResolveAttempted then
    destroyAttempts = destroyAttempts + 1
    destroyMessage = "runtime vehicle lookup did not find entity"
  elseif destroyResolveDeferred then
    destroyMessage = destroyResolveMessage ~= "" and destroyResolveMessage or "runtime vehicle lookup deferred"
    appendActionEvent("vehicle_destroy", false, targetInfo, "vehicle destroy deferred: " .. destroyMessage,
      '{"reason":' .. js(source or "expired") .. ',"displayName":' .. js(displayName) .. '}')
  else
    destroyMessage = "missing vehicle entity id"
    appendActionEvent("vehicle_destroy", false, targetInfo, "vehicle destroy skipped: missing entity id",
      '{"reason":' .. js(source or "expired") .. ',"displayName":' .. js(displayName) .. '}')
  end
  local status = "expired"
  local nextRetryAt = 0
  local missingVehicle = rentalMissingVehicleLikely(destroyAttempted, destroyOk, destroyMessage)
  if destroyResolveDeferred then
    status = "expire_pending"
    nextRetryAt = os.time() + rentalDestroyRetryDelay(destroyAttempts + 1)
    missingVehicle = false
  elseif missingVehicle then
    if destroyAttempts < rentalDestroyMaxAttempts() and (extractString(object, "vehicleId") or "") ~= "" then
      status = "expire_pending"
      nextRetryAt = os.time() + rentalDestroyRetryDelay(destroyAttempts)
      missingVehicle = false
    else
      status = "expired_untracked"
    end
  elseif destroyAttempted and not destroyOk then
    status = "expire_pending"
    nextRetryAt = os.time() + rentalDestroyRetryDelay(destroyAttempts)
  end
  local usageChargeQueued = false
  local usageChargeMessage = ""
  local usageChargeAmount = 0
  local chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute = 0, 0, 0, 0, 0
  local usageTaxKey = ""
  local penaltyQueued = false
  local penaltyMessage = ""
  local penaltyAmount = 0
  local penaltyTaxKey = ""
  if status == "expired" or status == "expired_untracked" then
    usageChargeQueued, usageChargeMessage, usageChargeAmount, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, usageTaxKey =
      finalizeRentalUsageCharge(targetInfo, object, source or "expired", expiresAt > 0 and expiresAt or os.time())
    if missingVehicle then
      penaltyQueued, penaltyMessage, penaltyAmount, penaltyTaxKey =
        chargeRentalMissingVehiclePenalty(targetInfo, object, source or "expired-missing-vehicle")
    end
  end
  appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
    '{"utc":' .. js(nowUtc()) ..
    ',"steamId":' .. js(steam) ..
    ',"name":' .. js(name) ..
    ',"alias":' .. js(extractString(object, "alias") or "") ..
    ',"x":' .. tostring(extractNumber(object, "x") or tonumber(targetInfo.x) or 0) ..
    ',"y":' .. tostring(extractNumber(object, "y") or tonumber(targetInfo.y) or 0) ..
    ',"z":' .. tostring(extractNumber(object, "z") or tonumber(targetInfo.z) or 0) ..
    ',"status":' .. js(status) ..
    ',"expiresAt":' .. tostring(expiresAt) ..
    ',"displayName":' .. js(displayName) ..
    ',"vehicleId":' .. js(extractString(object, "vehicleId") or "") ..
    ',"minutes":' .. tostring(extractNumber(object, "minutes") or 0) ..
    ',"startedAt":' .. tostring(extractNumber(object, "startedAt") or 0) ..
    ',"initialCharge":' .. tostring(extractNumber(object, "initialCharge") or 0) ..
    ',"pricePer10Minutes":' .. tostring(extractNumber(object, "pricePer10Minutes") or 0) ..
    ',"totalCharge":' .. tostring(extractNumber(object, "totalCharge") or 0) ..
    ',"missingVehiclePenalty":' .. tostring(rentalMissingVehiclePenaltyAmount(object)) ..
    ',"destroyRef":' .. js(destroyRef) ..
    ',"destroyAttempted":' .. (destroyAttempted and "true" or "false") ..
    ',"destroyOk":' .. (destroyOk and "true" or "false") ..
    ',"destroyAttempts":' .. tostring(destroyAttempts) ..
    ',"nextRetryAt":' .. tostring(nextRetryAt) ..
    ',"destroyMessage":' .. js(destroyMessage) ..
    ',"usageChargeQueued":' .. (usageChargeQueued and "true" or "false") ..
    ',"usageChargeAmount":' .. tostring(usageChargeAmount) ..
    ',"chargeableMinutes":' .. tostring(chargeableMinutes) ..
    ',"minutesAfter10":' .. tostring(minutesAfter10) ..
    ',"pricePerMinute":' .. tostring(pricePerMinute) ..
    ',"usageTotalCost":' .. tostring(totalCostSoFar) ..
    ',"usageAlreadyPaid":' .. tostring(alreadyPaid) ..
    ',"usageTaxKey":' .. js(usageTaxKey or "") ..
    ',"usageChargeMessage":' .. js(usageChargeMessage) ..
    ',"missingVehicle":' .. (missingVehicle and "true" or "false") ..
    ',"missingVehiclePenaltyQueued":' .. (penaltyQueued and "true" or "false") ..
    ',"missingVehiclePenaltyAmount":' .. tostring(penaltyAmount) ..
    ',"missingVehiclePenaltyTaxKey":' .. js(penaltyTaxKey or "") ..
    ',"missingVehiclePenaltyMessage":' .. js(penaltyMessage or "") .. '}',
    1024 * 1024)
  return destroyAttempted, destroyOk, destroyMessage
end

function latestActiveRental(info)
  local latest = {}
  for _, object in ipairs(stateObjects("vehicle-rentals.json")) do
    local key = rentalRecordKeyFromObject(object)
    if key ~= "" then latest[key] = object end
  end

  local keys = {}
  if info.steam ~= "" then table.insert(keys, "steam:" .. info.steam) end
  if info.name ~= "" then table.insert(keys, "name:" .. tostring(info.name):lower()) end
  for _, key in ipairs(keys) do
    local object = latest[key]
    if object ~= nil and not rentalClosed(object) then
      if rentalPendingDestroy(object) then return object end
      local expiresAt = extractNumber(object, "expiresAt") or 0
      if expiresAt > 0 and expiresAt <= os.time() then
        expireRentalObject(object, info.steam, info.name, info, "latest-active-expired")
      else
        return object
      end
    end
  end
  return nil
end

function latestReturnableRental(info)
  if info == nil then return nil end
  local latest = {}
  local lastDetailed = {}
  for _, object in ipairs(stateObjects("vehicle-rentals.json")) do
    if samePlayerRecord(info, object) then
      local key = rentalRecordKeyFromObject(object)
      if key ~= "" then
        latest[key] = object
        if (extractString(object, "vehicleId") or "") ~= "" then
          lastDetailed[key] = object
        end
      end
    end
  end
  local keys = {}
  if info.steam ~= "" then table.insert(keys, "steam:" .. info.steam) end
  if info.name ~= "" then table.insert(keys, "name:" .. tostring(info.name):lower()) end
  for _, key in ipairs(keys) do
    local object = latest[key]
    if object ~= nil then
      if not rentalClosed(object) then return object, rentalStatus(object) end
      local status = rentalStatus(object)
      if status == "expired_untracked" or status == "missing_vehicle" or status == "sold_or_missing" then
        local detailed = lastDetailed[key]
        if detailed ~= nil then return detailed, status end
      end
    end
  end
  return nil
end

function appendActiveRentalRecord(info, alias, displayName, vehicleId, minutes, startedAt, expiresAt, initialCharge, pricePer10Minutes, totalCharge, destroyRef, extraFields)
  local tracked = tostring(destroyRef or "") ~= ""
  local entityId = 0
  local destroyText = tostring(destroyRef or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if destroyText:match("^%d+$") then entityId = tonumber(destroyText) or 0 end
  local configured = configuredRentalVehicles()[(tostring(alias or "")):lower()]
  local missingPenalty = configured ~= nil and tonumber(configured.penalty or 0) or configNumber("vehicle-rental", { "DefaultMissingVehiclePenalty", "defaultMissingVehiclePenalty", "MissingVehiclePenalty", "missingVehiclePenalty", "SoldVehiclePenalty", "soldVehiclePenalty" }, 0)
  appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
    '{"utc":' .. js(nowUtc()) ..
    ',"steamId":' .. js(info.steam or "") ..
    ',"name":' .. js(info.name or "") ..
    ',"x":' .. tostring(tonumber(info.x) or 0) ..
    ',"y":' .. tostring(tonumber(info.y) or 0) ..
    ',"z":' .. tostring(tonumber(info.z) or 0) ..
    ',"alias":' .. js(alias or "") ..
    ',"status":"active"' ..
    tostring(extraFields or "") ..
    ',"displayName":' .. js(displayName or vehicleId or "vehicle") ..
    ',"vehicleId":' .. js(vehicleId or "") ..
    ',"minutes":' .. tostring(minutes or 0) ..
    ',"startedAt":' .. tostring(startedAt or os.time()) ..
    ',"expiresAt":' .. tostring(expiresAt or 0) ..
    ',"initialCharge":' .. tostring(initialCharge or 0) ..
    ',"pricePer10Minutes":' .. tostring(pricePer10Minutes or 0) ..
    ',"totalCharge":' .. tostring(totalCharge or 0) ..
    ',"missingVehiclePenalty":' .. tostring(math.max(0, tonumber(missingPenalty) or 0)) ..
    ',"entityId":' .. tostring(math.floor(entityId)) ..
    ',"vehicleEntityId":' .. tostring(math.floor(entityId)) ..
    ',"destroyRef":' .. js(destroyRef or "") ..
    ',"destroyTracked":' .. (tracked and "true" or "false") .. '}',
    1024 * 1024)
end

RENTAL_TRACK_REFRESH_PENDING = RENTAL_TRACK_REFRESH_PENDING or {}

function completeRentalCreation(info, alias, displayName, vehicleId, minutes, initialCharge, pricePer10Minutes, totalCharge, destroyRef, startedAt, expiresAt, verifiedAfterDelay)
  local tracked = tostring(destroyRef or "") ~= ""
  appendActiveRentalRecord(info, alias, displayName, vehicleId, minutes, startedAt or os.time(), expiresAt or (os.time() + (tonumber(minutes) or 0) * 60), initialCharge, pricePer10Minutes, totalCharge, destroyRef, verifiedAfterDelay and ',"verifiedAfterDelay":true' or "")
  appendActionEvent("vehicle_rental_created", tracked, info, tracked and "rental created with runtime vehicle tracking" or "rental spawn accepted but vehicle tracking missing",
    '{"alias":' .. js(alias or "") ..
    ',"vehicleId":' .. js(vehicleId or "") ..
    ',"minutes":' .. tostring(minutes or 0) ..
    ',"charge":' .. tostring(totalCharge or 0) ..
    ',"destroyRef":' .. js(destroyRef or "") ..
    ',"destroyTracked":' .. (tracked and "true" or "false") ..
    ',"verifiedAfterDelay":' .. (verifiedAfterDelay and "true" or "false") .. '}')
  targetMessage(info.steam, info.name, "Ты арендовал " .. tostring(displayName or vehicleId or "vehicle") .. " на " .. tostring(minutes or 0) .. " мин. Списано: " .. tostring(totalCharge or 0) .. ".", "vehicle-rental", info.runtimeKey)
end

function scheduleRentalCreationVerification(info, alias, option, minutes, rentalCharge, beforeVehicles, spawnX, spawnY, spawnZ)
  if info == nil or option == nil then return end
  local steamId = tostring(info.steam or "")
  local name = tostring(info.name or "")
  local runtimeKey = tostring(info.runtimeKey or "")
  local vehicleId = tostring(option.asset or "")
  local displayName = tostring(option.display or vehicleId)
  local initialCharge = tonumber(option.initial or 0) or 0
  local pricePer10Minutes = tonumber(option.price or 0) or 0
  local startedAt = os.time()
  local expiresAt = startedAt + (tonumber(minutes or 0) or 0) * 60
  if not configBool("vehicle-rental", { "EnableRuntimeVehicleTrackAfterSpawn", "enableRuntimeVehicleTrackAfterSpawn" }, true) then
    deferGame(900, function()
      local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
      local charged = true
      local chargeMessage = ""
      if tonumber(rentalCharge or 0) > 0 then
        charged, chargeMessage = changeMoney(live.steam, live.name, -rentalCharge, "Normal", live.runtimeKey)
      end
      if not charged then
        appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
          '{"utc":' .. js(nowUtc()) ..
          ',"steamId":' .. js(live.steam or steamId) ..
          ',"name":' .. js(live.name or name) ..
          ',"alias":' .. js(alias or "") ..
          ',"status":"active","chargePending":true,"chargeQueued":false' ..
          ',"displayName":' .. js(displayName) ..
          ',"vehicleId":' .. js(vehicleId) ..
          ',"minutes":' .. tostring(minutes or 0) ..
          ',"startedAt":' .. tostring(startedAt) ..
          ',"expiresAt":' .. tostring(expiresAt) ..
          ',"initialCharge":' .. tostring(initialCharge) ..
          ',"pricePer10Minutes":' .. tostring(pricePer10Minutes) ..
          ',"totalCharge":0' ..
          ',"destroyRef":""' ..
          ',"destroyTracked":false' ..
          ',"reason":' .. js("spawn accepted; charge queue failed: " .. tostring(chargeMessage or "")) .. '}',
          1024 * 1024)
        appendActionEvent("vehicle_rental_charge_pending", false, live, tostring(chargeMessage or "charge queue failed"),
          '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"charge":' .. tostring(rentalCharge or 0) .. '}')
        return
      end
      completeRentalCreation(live, alias, displayName, vehicleId, minutes, initialCharge, pricePer10Minutes, rentalCharge, "", startedAt, expiresAt, true)
      appendActionEvent("vehicle_rental_tracking_safe_skip", true, live, "spawn accepted; runtime vehicle scan skipped for stability",
        '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"charge":' .. tostring(rentalCharge or 0) .. '}')
    end)
    return
  end
  local function completeWithRef(live, ref, verifiedAfterDelay)
    if ref ~= "" then
      local charged, chargeMessage = true, ""
      if tonumber(rentalCharge or 0) > 0 then
        charged, chargeMessage = changeMoney(live.steam, live.name, -rentalCharge, "Normal", live.runtimeKey)
      end
      if not charged then
        destroyVehicleRef(ref, live, "rental-charge-failed")
        appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
          '{"utc":' .. js(nowUtc()) ..
          ',"steamId":' .. js(live.steam or steamId) ..
          ',"name":' .. js(live.name or name) ..
          ',"alias":' .. js(alias or "") ..
          ',"status":"failed"' ..
          ',"displayName":' .. js(displayName) ..
          ',"vehicleId":' .. js(vehicleId) ..
          ',"minutes":' .. tostring(minutes or 0) ..
          ',"startedAt":' .. tostring(startedAt) ..
          ',"expiresAt":' .. tostring(expiresAt) ..
          ',"totalCharge":' .. tostring(rentalCharge or 0) ..
          ',"destroyRef":' .. js(ref) ..
          ',"reason":"charge not confirmed after verified spawn"}',
          1024 * 1024)
        appendActionEvent("vehicle_rental_charge_failed", false, live, tostring(chargeMessage),
          '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"charge":' .. tostring(rentalCharge or 0) .. ',"destroyRef":' .. js(ref) .. ',"stage":"after-spawn-verified"}')
        targetMessage(live.steam, live.name, "Транспорт появился, но оплату не удалось подтвердить. Аренда отменена, транспорт удалён.", "vehicle-rental", live.runtimeKey)
        return
      end
      completeRentalCreation(live, alias, displayName, vehicleId, minutes, initialCharge, pricePer10Minutes, rentalCharge, ref, startedAt, expiresAt, true)
      return
    end
    return false
  end
  local function failUnverified(live, reason)
    local charged, chargeMessage = true, ""
    if tonumber(rentalCharge or 0) > 0 then
      charged, chargeMessage = changeMoney(live.steam, live.name, -rentalCharge, "Normal", live.runtimeKey)
    end
    if not charged then
      appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
        '{"utc":' .. js(nowUtc()) ..
        ',"steamId":' .. js(live.steam or steamId) ..
        ',"name":' .. js(live.name or name) ..
        ',"alias":' .. js(alias or "") ..
        ',"status":"failed"' ..
        ',"displayName":' .. js(displayName) ..
        ',"vehicleId":' .. js(vehicleId) ..
        ',"minutes":' .. tostring(minutes or 0) ..
        ',"startedAt":' .. tostring(startedAt) ..
        ',"expiresAt":' .. tostring(expiresAt) ..
        ',"totalCharge":' .. tostring(rentalCharge or 0) ..
        ',"charged":false' ..
        ',"refundQueued":false' ..
        ',"reason":' .. js("charge not confirmed after accepted spawn: " .. tostring(reason or "")) .. '}',
        1024 * 1024)
      appendActionEvent("vehicle_rental_charge_failed", false, live, tostring(chargeMessage),
        '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"charge":' .. tostring(rentalCharge or 0) .. ',"stage":"accepted-spawn-untracked"}')
      targetMessage(live.steam, live.name, "Транспорт отправлен, но оплату не удалось подтвердить. Деньги не списывал.", "vehicle-rental", live.runtimeKey)
      do return end
    end
    completeRentalCreation(live, alias, displayName, vehicleId, minutes, initialCharge, pricePer10Minutes, rentalCharge, "", startedAt, expiresAt, true)
    appendActionEvent("vehicle_rental_tracking_pending", true, live, "spawn command accepted; rental active while runtime tracking is pending",
      '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"reason":' .. js(reason or "spawn not verified immediately") .. '}')
    if type(scheduleRentalTrackingRefresh) == "function" then
      scheduleRentalTrackingRefresh(live, alias, vehicleId, beforeVehicles, 1)
    end
    do return end
    appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
      '{"utc":' .. js(nowUtc()) ..
      ',"steamId":' .. js(live.steam or steamId) ..
      ',"name":' .. js(live.name or name) ..
      ',"alias":' .. js(alias or "") ..
      ',"status":"failed"' ..
      ',"displayName":' .. js(displayName) ..
      ',"vehicleId":' .. js(vehicleId) ..
      ',"minutes":' .. tostring(minutes or 0) ..
      ',"startedAt":' .. tostring(startedAt) ..
      ',"expiresAt":' .. tostring(expiresAt) ..
      ',"totalCharge":' .. tostring(rentalCharge or 0) ..
      ',"charged":false' ..
      ',"refundQueued":false' ..
      ',"reason":' .. js(reason or "spawn not verified") .. '}',
      1024 * 1024)
    appendActionEvent("vehicle_rental_spawn_unverified", false, live, "spawn command accepted but runtime vehicle was not found; no charge was made",
      '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"charged":false,"chargeRefunded":0,"reason":' .. js(reason or "spawn not verified") .. '}')
    targetMessage(live.steam, live.name, "Транспорт не подтверждён после выдачи. Деньги не списывал, попробуй ещё раз или выбери другой транспорт.", "vehicle-rental", live.runtimeKey)
  end
  deferGame(2200, function()
    local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
    local ref = recentSpawnedVehicleEntityId(vehicleId, startedAt)
    if ref == "" then ref = nearestNewVehicleRefAt(spawnX, spawnY, spawnZ, vehicleId, beforeVehicles, true) end
    if completeWithRef(live, ref, true) ~= false then return end
    failUnverified(live, "spawn accepted but runtime tracking delayed")
    do return end
    if steamId ~= "" then
      local fallbackBefore = vehicleRuntimeKeySet(vehicleId)
      local fallbackCommand = "SpawnVehicle " .. vehicleId .. " 1 Location " .. steamId
      local sentFallback, fallbackMessage = adminExec(fallbackCommand, live)
      appendActionEvent("vehicle_rental_spawn_location_fallback", sentFallback, live, tostring(fallbackMessage or ""),
        '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId) .. ',"command":' .. js(fallbackCommand) .. '}')
      if sentFallback then
        deferGame(2400, function()
          local liveAfter = resolvePlayerInfo(steamId, name, live, runtimeKey) or live
          local fallbackRef = nearestNewVehicleRefAt(spawnX, spawnY, spawnZ, vehicleId, fallbackBefore, true)
          if completeWithRef(liveAfter, fallbackRef, true) ~= false then return end
          failUnverified(liveAfter, "spawn location fallback not verified")
        end)
        return
      end
    end
    failUnverified(live, "spawn not verified")
  end)
end

function scheduleRentalTrackingRefresh(info, alias, vehicleId, beforeVehicles, attempt)
  if info == nil or tostring(vehicleId or "") == "" then return end
  local steamId = tostring(info.steam or "")
  local name = tostring(info.name or "")
  local runtimeKey = tostring(info.runtimeKey or "")
  local refreshKey = tostring(steamId) .. "|" .. tostring(alias or "") .. "|" .. tostring(vehicleId or "")
  if RENTAL_TRACK_REFRESH_PENDING[refreshKey] then return end
  RENTAL_TRACK_REFRESH_PENDING[refreshKey] = true
  local tries = math.max(1, tonumber(attempt) or 1)
  local delayMs = 900 + math.min(tries, 4) * 350
  deferGame(delayMs, function()
    local live = resolvePlayerInfo(steamId, name, info, runtimeKey) or info
    local active = latestActiveRental(live)
    if active == nil then
      RENTAL_TRACK_REFRESH_PENDING[refreshKey] = nil
      return
    end
    local currentRef = vehicleDestroyRefFromRental(active)
    if currentRef ~= "" then
      RENTAL_TRACK_REFRESH_PENDING[refreshKey] = nil
      return
    end
    local ref = recentSpawnedVehicleEntityId(vehicleId, extractNumber(active, "startedAt") or 0)
    if ref == "" then ref = nearestNewVehicleRef(live, vehicleId, beforeVehicles, true) end
    if ref == "" then
      RENTAL_TRACK_REFRESH_PENDING[refreshKey] = nil
      if tries < 4 then
        scheduleRentalTrackingRefresh(live, alias, vehicleId, beforeVehicles, tries + 1)
        return
      end
      appendActionEvent("vehicle_rental_tracking", false, live, "runtime vehicle tracking still not found",
        '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId or "") .. ',"attempt":' .. tostring(tries) .. '}')
      return
    end
    appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
      '{"utc":' .. js(nowUtc()) ..
      ',"steamId":' .. js(extractString(active, "steamId") or steamId) ..
      ',"name":' .. js(extractString(active, "name") or name) ..
      ',"alias":' .. js(extractString(active, "alias") or alias or "") ..
      ',"status":"active","trackingRefreshedAt":' .. tostring(os.time()) ..
      ',"displayName":' .. js(extractString(active, "displayName") or extractString(active, "vehicleId") or vehicleId) ..
      ',"vehicleId":' .. js(extractString(active, "vehicleId") or vehicleId) ..
      ',"x":' .. tostring(tonumber(live.x) or 0) ..
      ',"y":' .. tostring(tonumber(live.y) or 0) ..
      ',"z":' .. tostring(tonumber(live.z) or 0) ..
      ',"minutes":' .. tostring(extractNumber(active, "minutes") or 0) ..
      ',"startedAt":' .. tostring(extractNumber(active, "startedAt") or os.time()) ..
      ',"expiresAt":' .. tostring(extractNumber(active, "expiresAt") or 0) ..
      ',"initialCharge":' .. tostring(extractNumber(active, "initialCharge") or 0) ..
      ',"pricePer10Minutes":' .. tostring(extractNumber(active, "pricePer10Minutes") or 0) ..
      ',"totalCharge":' .. tostring(extractNumber(active, "totalCharge") or extractNumber(active, "initialCharge") or 0) ..
      ',"trackingRefreshAttempt":' .. tostring(tries) ..
      ',"destroyRef":' .. js(ref) ..
      ',"destroyTracked":true}',
      1024 * 1024)
    appendActionEvent("vehicle_rental_tracking", true, live, "runtime vehicle tracking refreshed",
      '{"alias":' .. js(alias or "") .. ',"vehicleId":' .. js(vehicleId or "") .. ',"destroyRef":' .. js(ref) .. ',"attempt":' .. tostring(tries) .. '}')
    RENTAL_TRACK_REFRESH_PENDING[refreshKey] = nil
  end)
end

cleanupExpiredRentals = function()
  local latest = {}
  for _, object in ipairs(stateObjects("vehicle-rentals.json")) do
    local key = rentalRecordKeyFromObject(object)
      if key ~= "" then latest[key] = object end
  end
  local processed = 0
  local warningsSent = 0
  local maxWarningsPerRun = math.max(1, configNumber("vehicle-rental", { "WarningMaxPerRun", "warningMaxPerRun" }, 5))
  local warningKeys = latestRentalWarningKeys()
  for key, object in pairs(latest) do
    if not rentalClosed(object) then
      local expiresAt = extractNumber(object, "expiresAt") or 0
      local retryAt = extractNumber(object, "nextRetryAt") or 0
      local dueActive = expiresAt > 0 and expiresAt <= os.time() and not rentalPendingDestroy(object)
      local dueRetry = rentalPendingDestroy(object) and (retryAt <= 0 or retryAt <= os.time())
      if dueActive or dueRetry then
        processed = (processed or 0) + 1
        local steam = extractString(object, "steamId") or ""
        local name = extractString(object, "name") or ""
        local live = findPlayer(steam, name)
        local attempted, destroyed = expireRentalObject(object, steam, name, live or { steam = steam, name = name }, "cleanup-expired")
        local suffix = attempted and (destroyed and " Транспорт удалён." or " Удаление транспорта не подтверждено, будет повторная попытка.") or " Нет entityId для удаления, смотри журнал действий."
        if live ~= nil then
          targetMessage(steam, name, "Срок аренды транспорта истёк. Запись отмечена в панели." .. suffix, "vehicle-rental", live.runtimeKey)
        end
        local maxPerRun = math.max(1, configNumber("vehicle-rental", { "CleanupMaxPerRun", "cleanupMaxPerRun" }, 1))
        if processed >= maxPerRun then return end
      elseif warningsSent < maxWarningsPerRun and sendRentalExpiryWarningIfNeeded(object, warningKeys) then
        warningsSent = warningsSent + 1
      end
    end
  end
end

MUTATION_QUEUE = MUTATION_QUEUE or {}
MUTATION_QUEUE_BUSY = MUTATION_QUEUE_BUSY or false
MUTATION_QUEUE_CURRENT = MUTATION_QUEUE_CURRENT or nil
MUTATION_QUEUE_NEXT_AT = MUTATION_QUEUE_NEXT_AT or 0
MUTATION_QUEUE_SEQ = MUTATION_QUEUE_SEQ or 0
MUTATION_QUEUE_MAX = MUTATION_QUEUE_MAX or 120
MUTATION_QUEUE_SPACING_MS = MUTATION_QUEUE_SPACING_MS or 750
MUTATION_QUEUE_PLAYER_MAX = MUTATION_QUEUE_PLAYER_MAX or 2
MUTATION_QUEUE_REENTRANT_DEPTH = MUTATION_QUEUE_REENTRANT_DEPTH or 0

function mutationQueueDepth()
  local depth = #MUTATION_QUEUE
  if MUTATION_QUEUE_BUSY then depth = depth + 1 end
  return depth
end

local function mutationPlayerKey(info)
  if info == nil then return "" end
  if type(playerStateKey) == "function" then
    local key = playerStateKey(info)
    if tostring(key or "") ~= "" then return tostring(key) end
  end
  local steam = tostring(info.steam or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if steam ~= "" then return "steam:" .. steam end
  local name = tostring(info.name or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if name ~= "" and name ~= "Unknown" then return "name:" .. name:lower() end
  local runtimeKey = tostring(info.runtimeKey or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if runtimeKey ~= "" then return "runtime:" .. runtimeKey end
  return ""
end

local function mutationQueuePlayerDepth(info)
  local key = mutationPlayerKey(info)
  if key == "" then return 0 end
  local depth = 0
  if MUTATION_QUEUE_CURRENT ~= nil and mutationPlayerKey(MUTATION_QUEUE_CURRENT.info) == key then
    depth = depth + 1
  end
  for _, item in ipairs(MUTATION_QUEUE or {}) do
    if mutationPlayerKey(item.info) == key then depth = depth + 1 end
  end
  return depth
end

function mutationQueueEntryJson(item)
  if item == nil then return "null" end
  return '{"id":' .. tostring(item.id or 0) ..
    ',"label":' .. js(item.label or "") ..
    ',"queuedAt":' .. tostring(item.queuedAt or 0) ..
    ',"target":' .. js((item.info and (item.info.name or item.info.steam)) or "") .. '}'
end

function mutationQueueStatusJson()
  local nowMs = math.floor(os.clock() * 1000)
  local nextDelay = math.max(0, (tonumber(MUTATION_QUEUE_NEXT_AT) or 0) - nowMs)
  local preview = {}
  local limit = math.min(#(MUTATION_QUEUE or {}), 20)
  for i = 1, limit do table.insert(preview, mutationQueueEntryJson(MUTATION_QUEUE[i])) end
  local playerCommands = ""
  if type(playerCommandQueueStatusJson) == "function" then
    playerCommands = ',"playerCommands":' .. playerCommandQueueStatusJson()
  end
  return '{"available":true' ..
    ',"depth":' .. tostring(mutationQueueDepth()) ..
    ',"pending":' .. tostring(#(MUTATION_QUEUE or {})) ..
    ',"busy":' .. ((MUTATION_QUEUE_BUSY and "true") or "false") ..
    ',"current":' .. mutationQueueEntryJson(MUTATION_QUEUE_CURRENT) ..
    ',"max":' .. tostring(MUTATION_QUEUE_MAX or 0) ..
    ',"perPlayerMax":' .. tostring(MUTATION_QUEUE_PLAYER_MAX or 0) ..
    ',"spacingMs":' .. tostring(MUTATION_QUEUE_SPACING_MS or 0) ..
    ',"nextDelayMs":' .. tostring(nextDelay) ..
    ',"sequence":' .. tostring(MUTATION_QUEUE_SEQ or 0) ..
    ',"lastAction":' .. tostring(LAST_ACTION_EVENT_JSON or "null") ..
    ',"lastDelivery":' .. tostring(LAST_DELIVERY_EVENT_JSON or "null") ..
    ',"pendingPreview":[' .. table.concat(preview, ",") .. ']' ..
    playerCommands ..
    '}'
end

function enqueueMutation(label, info, fn)
  if type(fn) ~= "function" then
    return false, "Внутренняя ошибка очереди: действие не задано.", #MUTATION_QUEUE
  end
  if (MUTATION_QUEUE_REENTRANT_DEPTH or 0) > 0 then
    appendActionEvent("mutation_queue", true, info, "Вложенное действие выполняется внутри текущей очереди", '{"label":' .. js(label or "") .. ',"inline":true}')
    local okRun, err = pcall(fn)
    if okRun then
      appendActionEvent("mutation_queue", true, info, "Вложенное действие выполнено", '{"label":' .. js(label or "") .. ',"inline":true}')
      appendLog("mutation inline done label=" .. tostring(label or "mutation"))
      return true, 0, mutationQueueDepth()
    end
    appendActionEvent("mutation_queue", false, info, "Ошибка вложенного действия: " .. tostring(err), '{"label":' .. js(label or "") .. ',"inline":true}')
    appendLog("mutation inline error label=" .. tostring(label or "mutation") .. " err=" .. tostring(err))
    return false, "Ошибка вложенного игрового действия: " .. tostring(err), mutationQueueDepth()
  end
  if #MUTATION_QUEUE >= MUTATION_QUEUE_MAX then
    appendActionEvent("mutation_queue", false, info, "Очередь игровых действий переполнена", '{"label":' .. js(label or "") .. ',"depth":' .. tostring(#MUTATION_QUEUE) .. '}')
    return false, "Очередь игровых действий переполнена. Повтори команду чуть позже.", #MUTATION_QUEUE
  end
  local playerDepth = mutationQueuePlayerDepth(info)
  if playerDepth >= MUTATION_QUEUE_PLAYER_MAX then
    appendActionEvent("mutation_queue", false, info, "У игрока уже есть активные действия в очереди", '{"label":' .. js(label or "") .. ',"playerDepth":' .. tostring(playerDepth) .. '}')
    return false, "Твои выдачи уже обрабатываются. Подожди очередь и повтори чуть позже.", mutationQueueDepth()
  end
  MUTATION_QUEUE_SEQ = MUTATION_QUEUE_SEQ + 1
  table.insert(MUTATION_QUEUE, { id = MUTATION_QUEUE_SEQ, label = tostring(label or "mutation"), info = info, fn = fn, queuedAt = os.time() })
  appendActionEvent("mutation_queue", true, info, "Действие поставлено в очередь", '{"label":' .. js(label or "") .. ',"id":' .. tostring(MUTATION_QUEUE_SEQ) .. ',"depth":' .. tostring(#MUTATION_QUEUE) .. '}')
  appendLog("mutation queued id=" .. tostring(MUTATION_QUEUE_SEQ) .. " label=" .. tostring(label or "mutation") .. " depth=" .. tostring(#MUTATION_QUEUE))
  return true, MUTATION_QUEUE_SEQ, #MUTATION_QUEUE
end

function drainMutationQueue()
  if MUTATION_QUEUE_BUSY then return end
  local nowMs = math.floor(os.clock() * 1000)
  if nowMs < (tonumber(MUTATION_QUEUE_NEXT_AT) or 0) then return end
  local item = table.remove(MUTATION_QUEUE, 1)
  if item == nil then return end
  MUTATION_QUEUE_BUSY = true
  MUTATION_QUEUE_CURRENT = item
  appendLog("mutation start id=" .. tostring(item.id) .. " label=" .. tostring(item.label) .. " depth=" .. tostring(#MUTATION_QUEUE))

  local function runItem()
    MUTATION_QUEUE_REENTRANT_DEPTH = (MUTATION_QUEUE_REENTRANT_DEPTH or 0) + 1
    local okRun, err = pcall(item.fn)
    MUTATION_QUEUE_REENTRANT_DEPTH = math.max(0, (MUTATION_QUEUE_REENTRANT_DEPTH or 1) - 1)
    MUTATION_QUEUE_BUSY = false
    MUTATION_QUEUE_CURRENT = nil
    MUTATION_QUEUE_NEXT_AT = math.floor(os.clock() * 1000) + MUTATION_QUEUE_SPACING_MS
    if okRun then
      appendActionEvent("mutation_queue", true, item.info, "Действие выполнено", '{"label":' .. js(item.label) .. ',"id":' .. tostring(item.id) .. ',"remaining":' .. tostring(#MUTATION_QUEUE) .. '}')
      appendLog("mutation done id=" .. tostring(item.id) .. " label=" .. tostring(item.label) .. " depth=" .. tostring(#MUTATION_QUEUE))
    else
      appendActionEvent("mutation_queue", false, item.info, "Ошибка действия: " .. tostring(err), '{"label":' .. js(item.label) .. ',"id":' .. tostring(item.id) .. ',"remaining":' .. tostring(#MUTATION_QUEUE) .. '}')
      appendLog("mutation error id=" .. tostring(item.id) .. " label=" .. tostring(item.label) .. " err=" .. tostring(err))
    end
  end

  if deferGame(0, runItem) then return end

  if ExecuteInGameThread ~= nil then
    local okThread, err = pcall(function() ExecuteInGameThread(runItem) end)
    if okThread then return end
    appendLog("mutation ExecuteInGameThread failed, running inline: " .. tostring(err))
  end

  runItem()
end

splitWords = function(text)
  local words = {}
  for word in tostring(text or ""):gmatch("%S+") do table.insert(words, word) end
  return words
end

function sectorFromCoordinates(x, y)
  local minX, maxX = -768000, 768000
  local minY, maxY = -768000, 768000
  local sectorRows = { "D", "C", "B", "A", "Z" }
  local sectorColumns = { "4", "3", "2", "1", "0" }
  local col = math.floor(((maxX - x) / (maxX - minX)) * 5)
  local row = math.floor(((maxY - y) / (maxY - minY)) * 5)
  if col < 0 then col = 0 elseif col > 4 then col = 4 end
  if row < 0 then row = 0 elseif row > 4 then row = 4 end
  return sectorRows[row + 1] .. sectorColumns[col + 1]
end

function normalizeSectorCode(value)
  local text = tostring(value or ""):upper():gsub("[^A-Z0-9]", "")
  if #text ~= 2 then return "" end
  local row = text:sub(1, 1)
  local col = text:sub(2, 2)
  if row ~= "D" and row ~= "C" and row ~= "B" and row ~= "A" and row ~= "Z" then return "" end
  if col ~= "4" and col ~= "3" and col ~= "2" and col ~= "1" and col ~= "0" then return "" end
  return row .. col
end

function sectorHelpText()
  return "Формат: /scan B2 или /scan C0. Доступные строки: D, C, B, A, Z; колонки: 4, 3, 2, 1, 0."
end

function sectorScanPlayerInfos(maxAgeSeconds, includeInfo)
  local maxAge = math.max(1, tonumber(maxAgeSeconds) or 8)
  local infos = cachedPlayerInfos(maxAge) or {}
  if #infos == 0 then
    local okRefresh, err = pcall(refreshPlayerInfoCache)
    if not okRefresh then appendLog("sector scan player refresh failed: " .. tostring(err)) end
    infos = cachedPlayerInfos(maxAge) or {}
  end

  local result = {}
  local seen = {}
  local function add(info)
    if info == nil then return end
    local live = refreshRuntimePlayerInfo(info)
    if live == nil then return end
    live = enrichPlayerInfoFromServerLog(live) or live
    local x = tonumber(live.x)
    local y = tonumber(live.y)
    if x == nil or y == nil or x ~= x or y ~= y or (math.abs(x) + math.abs(y)) <= 1 then return end
    local key = playerStateKey(live)
    if key == "" then key = tostring(live.runtimeKey or "") end
    if key == "" then key = tostring(live.name or "") .. "|" .. tostring(live.x or "") .. "|" .. tostring(live.y or "") end
    if key == "" or seen[key] then return end
    seen[key] = true
    table.insert(result, live)
  end

  for _, info in ipairs(infos or {}) do add(info) end
  add(includeInfo)
  return result
end

function appendHome(info, label)
  local nameLabel = tostring(label or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if nameLabel == "" then nameLabel = "home" end
  local record = '{"utc":' .. js(nowUtc()) ..
    ',"label":' .. js(nameLabel) ..
    ',"steamId":' .. js(info.steam or "") ..
    ',"name":' .. js(info.name or "") ..
    ',"userProfileId":' .. js(info.userProfileId or info.serverUserProfileId or "") ..
    ',"x":' .. tostring(info.x) ..
    ',"y":' .. tostring(info.y) ..
    ',"z":' .. tostring(info.z) .. '}'
  return appendJsonArray(STATE_DIR .. "\\homes.json", record, 1024 * 1024)
end

function homesForInfo(info)
  local homes = {}
  for _, object in ipairs(stateObjects("homes.json")) do
    if samePlayerRecord(info, object) then
      local label = extractString(object, "label") or "home"
      homes[label:lower()] = {
        label = label,
        x = extractNumber(object, "x") or 0,
        y = extractNumber(object, "y") or 0,
        z = extractNumber(object, "z") or 0
      }
    end
  end
  local rows = {}
  for _, home in pairs(homes) do table.insert(rows, home) end
  table.sort(rows, function(a, b) return tostring(a.label):lower() < tostring(b.label):lower() end)
  return rows
end

function homeByLabel(info, label)
  local wanted = tostring(label or ""):gsub("^%s+", ""):gsub("%s+$", ""):lower()
  local homes = homesForInfo(info)
  if wanted == "" then
    if #homes == 1 then return homes[1] end
    return nil
  end
  for _, home in ipairs(homes) do
    if tostring(home.label):lower() == wanted then return home end
  end
  return nil
end

function homeListText(info)
  local homes = homesForInfo(info)
  if #homes == 0 then return "У тебя ещё нет установленных домов." end
  local lines = {}
  for _, home in ipairs(homes) do table.insert(lines, "- " .. tostring(home.label)) end
  return "Дома: " .. table.concat(lines, ", ")
end

function deleteHomes(info, label)
  local path = STATE_DIR .. "\\homes.json"
  local text = readAll(path) or "[]"
  local kept = {}
  local removed = 0
  local wanted = tostring(label or ""):lower()
  for object in text:gmatch("%b{}") do
    local steam = extractString(object, "steamId") or ""
    local name = extractString(object, "name") or ""
    local homeLabel = extractString(object, "label") or "home"
    local samePlayer = (info.steam ~= "" and steam == info.steam) or (info.name ~= "" and name == info.name)
    local sameLabel = wanted == "" or tostring(homeLabel):lower() == wanted
    if samePlayer and sameLabel then
      removed = removed + 1
    else
      table.insert(kept, object)
    end
  end
  writeAll(path, "[" .. table.concat(kept, ",") .. "]")
  return removed
end

pmReplies = {}

function playerReplyKey(info)
  if info == nil then return "" end
  if tostring(info.steam or "") ~= "" then return tostring(info.steam) end
  return tostring(info.name or "")
end

function recordPmReply(left, right)
  local leftKey = playerReplyKey(left)
  local rightKey = playerReplyKey(right)
  if leftKey ~= "" and right ~= nil then pmReplies[leftKey] = { steam = right.steam or "", name = right.name or "" } end
  if rightKey ~= "" and left ~= nil then pmReplies[rightKey] = { steam = left.steam or "", name = left.name or "" } end
end

function privateMessageCooldownRemaining(info)
  if not configBool("private-messages", { "UseCooldown", "useCooldown" }, true) then return 0 end
  local seconds = configNumber("private-messages", { "CooldownTimeSeconds", "cooldownTimeSeconds" }, 3)
  return cooldownRemaining("private-message-cooldowns.json", info, seconds)
end

function rememberPrivateMessageCooldown(info)
  if configBool("private-messages", { "UseCooldown", "useCooldown" }, true) then
    rememberCooldown("private-message-cooldowns.json", info, configNumber("private-messages", { "CooldownTimeSeconds", "cooldownTimeSeconds" }, 3))
  end
end

function privateMessageHistory(info, maxCount)
  local text = readAll(STATE_DIR .. "\\private-messages.json") or "[]"
  local rows = {}
  local keyName = tostring(info.name or "")
  for object in text:gmatch("%b{}") do
    local fromName = extractString(object, "from") or ""
    local toName = extractString(object, "to") or ""
    if fromName == keyName or toName == keyName then
      table.insert(rows, (extractString(object, "utc") or "") .. " " .. fromName .. " -> " .. toName .. ": " .. (extractString(object, "message") or ""))
    end
  end
  local count = math.min(#rows, tonumber(maxCount) or 5)
  if count <= 0 then return "История личных сообщений пуста." end
  local start = #rows - count + 1
  local out = {}
  for i = start, #rows do table.insert(out, rows[i]) end
  return table.concat(out, " | ")
end

function identityKey(steamId, name, dbId)
  steamId = tostring(steamId or "")
  dbId = tostring(dbId or "")
  name = tostring(name or "")
  if steamId ~= "" then return "steam:" .. steamId end
  if dbId ~= "" and dbId ~= "0" then return "db:" .. dbId end
  if name ~= "" then return "name:" .. name:lower() end
  return ""
end

function identityFromDbId(fallbackDbId)
  local dbId = tostring(fallbackDbId or "")
  if dbId == "" or dbId == "0" then return nil end
  local cache = serverLogIdentities()
  local identity = cache and cache.byProfile and cache.byProfile[dbId] or nil
  if identity ~= nil then
    return { steam = tostring(identity.steam or ""), name = tostring(identity.name or ""), dbId = dbId }
  end
  return { steam = "", name = "user#" .. dbId, dbId = dbId }
end

function identityFromInfo(info, fallbackDbId)
  if info == nil then
    return identityFromDbId(fallbackDbId) or { steam = "", name = "Unknown", dbId = tostring(fallbackDbId or "") }
  end
  info = enrichPlayerInfoFromServerLog(info) or info
  local dbId = tostring(info.userProfileId or "")
  if dbId == "" then dbId = tostring(info.serverUserProfileId or "") end
  if dbId == "" then dbId = tostring(fallbackDbId or "") end
  local identity = identityFromDbId(dbId)
  local name = tostring(info.name or "")
  local steam = tostring(info.steam or "")
  if (name == "" or name == "Unknown") and identity ~= nil then name = tostring(identity.name or name) end
  if steam == "" and identity ~= nil then steam = tostring(identity.steam or "") end
  return {
    steam = steam,
    name = name,
    dbId = dbId
  }
end

function bountyStats()
  local stats = {}
  for _, object in ipairs(stateObjects("bounty-hunt.json")) do
    local kind = extractString(object, "kind") or "stat"
    if kind == "stat" then
      local steam = extractString(object, "steamId") or ""
      local name = extractString(object, "name") or ""
      local dbId = extractString(object, "userProfileId") or ""
      local key = identityKey(steam, name, dbId)
      if key ~= "" then
        stats[key] = {
          steam = steam,
          name = name ~= "" and name or "Unknown",
          dbId = dbId,
          current = math.max(0, extractNumber(object, "currentStreak") or 0),
          best = math.max(0, extractNumber(object, "bestStreak") or 0),
          kills = math.max(0, extractNumber(object, "kills") or 0),
          deaths = math.max(0, extractNumber(object, "deaths") or 0),
          updatedAt = extractString(object, "updatedAtUtc") or extractString(object, "utc") or ""
        }
      end
    end
  end
  return stats
end

function bountyEntry(stats, identity)
  local key = identityKey(identity.steam, identity.name, identity.dbId)
  if key == "" then return nil, "" end
  local entry = stats[key]
  if entry == nil then
    entry = { steam = identity.steam or "", name = identity.name ~= "" and identity.name or "Unknown", dbId = identity.dbId or "", current = 0, best = 0, kills = 0, deaths = 0, updatedAt = "" }
    stats[key] = entry
  end
  if identity.steam ~= "" then entry.steam = identity.steam end
  if identity.name ~= "" and identity.name ~= "Unknown" then entry.name = identity.name end
  if identity.dbId ~= "" then entry.dbId = identity.dbId end
  return entry, key
end

function appendBountySnapshot(entry)
  appendJsonArray(STATE_DIR .. "\\bounty-hunt.json", '{"kind":"stat","updatedAtUtc":' .. js(nowUtc()) ..
    ',"steamId":' .. js(entry.steam or "") ..
    ',"name":' .. js(entry.name or "") ..
    ',"userProfileId":' .. js(entry.dbId or "") ..
    ',"currentStreak":' .. tostring(entry.current or 0) ..
    ',"bestStreak":' .. tostring(entry.best or 0) ..
    ',"kills":' .. tostring(entry.kills or 0) ..
    ',"deaths":' .. tostring(entry.deaths or 0) .. '}', 2 * 1024 * 1024)
end

function killLocationJson(x, y, z)
  x = tonumber(x)
  y = tonumber(y)
  z = tonumber(z)
  if x == nil or y == nil or z == nil then return "null" end
  return '{"x":' .. tostring(x) .. ',"y":' .. tostring(y) .. ',"z":' .. tostring(z) .. '}'
end

function appendKillEvent(killer, victim, meta, victimPreviousStreak)
  meta = meta or {}
  local killerX = tonumber(meta.killerX or meta.killerLocationX or meta.killer_x)
  local killerY = tonumber(meta.killerY or meta.killerLocationY or meta.killer_y)
  local killerZ = tonumber(meta.killerZ or meta.killerLocationZ or meta.killer_z)
  local victimX = tonumber(meta.victimX or meta.victimLocationX or meta.victim_x)
  local victimY = tonumber(meta.victimY or meta.victimLocationY or meta.victim_y)
  local victimZ = tonumber(meta.victimZ or meta.victimLocationZ or meta.victim_z)
  local weapon = tostring(meta.weapon or "")
  local distance = tonumber(meta.distance or 0) or 0
  if distance <= 0 and killerX ~= nil and killerY ~= nil and killerZ ~= nil and victimX ~= nil and victimY ~= nil and victimZ ~= nil then
    local dx = killerX - victimX
    local dy = killerY - victimY
    local dz = killerZ - victimZ
    distance = math.sqrt(dx * dx + dy * dy + dz * dz) / 100
  end
  local message = tostring(killer.name or "Unknown") .. " убил " .. tostring(victim.name or "Unknown")
  if weapon ~= "" then message = message .. " (" .. weapon .. ")" end
  if distance > 0 then message = message .. " с " .. tostring(math.floor(distance + 0.5)) .. " м" end
  local record = '{"type":"kill","timestampUtc":' .. js(nowUtc()) ..
    ',"message":' .. js(message) ..
    ',"killerName":' .. js(killer.name or "") ..
    ',"killerSteamId":' .. js(killer.steam or "") ..
    ',"killerUserProfileId":' .. js(killer.dbId or "") ..
    ',"victimName":' .. js(victim.name or "") ..
    ',"victimSteamId":' .. js(victim.steam or "") ..
    ',"victimUserProfileId":' .. js(victim.dbId or "") ..
    ',"weapon":' .. js(weapon) ..
    ',"distance":' .. tostring(distance) ..
    ',"killerLocation":' .. killLocationJson(killerX, killerY, killerZ) ..
    ',"victimLocation":' .. killLocationJson(victimX, victimY, victimZ) ..
    ',"victimPreviousStreak":' .. tostring(victimPreviousStreak or 0) ..
    ',"source":' .. js(meta.source or "ue4ss-kill-registry") .. '}'
  appendJsonArray(STATE_DIR .. "\\kill-feed.json", record, 2 * 1024 * 1024)
  appendJsonArray(STATE_DIR .. "\\server-kill-feed.json", record, 2 * 1024 * 1024)
  return message
end

function serverKillFeedEnabled()
  return configBool("server-kill-feed", { "Enabled", "enabled" }, true) ~= false
end

function serverKillFeedPrefix()
  local prefix = extractStringAny(configText("server-kill-feed"), { "Prefix", "prefix" }) or "ScumNeDjin"
  prefix = tostring(prefix or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if prefix == "" then prefix = "ScumNeDjin" end
  if prefix:sub(1, 1) == "[" then return prefix end
  return "[" .. prefix .. "]"
end

function serverKillFeedShowWeapon()
  return configBool("server-kill-feed", { "IncludeWeapon", "includeWeapon", "ShowWeapon", "showWeapon" }, false) == true
end

function serverKillFeedShowDistance()
  return configBool("server-kill-feed", { "IncludeDistance", "includeDistance", "ShowDistance", "showDistance" }, false) == true
end

SERVER_KILL_FEED_BROADCAST_DEDUP = SERVER_KILL_FEED_BROADCAST_DEDUP or {}
SERVER_KILL_FEED_STATS_DEDUP = SERVER_KILL_FEED_STATS_DEDUP or {}

function stripKillFeedPrefix(message)
  return cleanText(message or ""):gsub("^%[[^%]]+%]%s*", "")
end

function killFeedMessageLooksTechnical(message)
  local text = tostring(message or "")
  if text == "" then return true, "empty" end
  if text:find("%c") ~= nil then return true, "control-char" end
  if text:find("\\u", 1, true) ~= nil or text:find("\\U", 1, true) ~= nil then return true, "unicode-escape" end
  if text:find("KillerLoc", 1, true) ~= nil or text:find("VictimLoc", 1, true) ~= nil then return true, "debug-location" end
  if text:find("Distance:", 1, true) ~= nil and text:find("[Projectile]", 1, true) ~= nil then return true, "debug-projectile" end
  if text:find(" убил ", 1, true) == nil and text:find(" погиб", 1, true) == nil then return true, "not-killfeed" end
  return false, ""
end

function normalizeServerKillFeedMessage(message)
  local body = stripKillFeedPrefix(message)
  local technical, reason = killFeedMessageLooksTechnical(body)
  if technical then return "", "filtered:" .. tostring(reason or "technical") end
  if not serverKillFeedShowWeapon() then
    body = body:gsub("%s*%([^%)]*%)", "")
  end
  if not serverKillFeedShowDistance() then
    body = body:gsub("%s+с%s+%d+%s+м%s*$", "")
  end
  body = cleanText(body)
  if body == "" then return "", "filtered:empty-after-clean" end
  return serverKillFeedPrefix() .. " " .. body, ""
end

function serverKillFeedDedupKey(message)
  local body = stripKillFeedPrefix(message):lower()
  body = body:gsub("%s*%([^%)]*%)", "")
  body = body:gsub("%s+с%s+%d+%s+м%s*$", "")
  body = body:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  return body
end

function shouldSkipServerKillFeedBroadcast(message)
  local key = serverKillFeedDedupKey(message)
  if key == "" then return false end
  local now = os.time()
  local duplicateWindow = math.max(1, configNumber("server-kill-feed", { "DuplicateWindowSeconds", "duplicateWindowSeconds" }, 8))
  for oldKey, seenAt in pairs(SERVER_KILL_FEED_BROADCAST_DEDUP) do
    if (now - seenAt) > (duplicateWindow * 4) then SERVER_KILL_FEED_BROADCAST_DEDUP[oldKey] = nil end
  end
  local last = SERVER_KILL_FEED_BROADCAST_DEDUP[key]
  if last ~= nil and (now - last) <= duplicateWindow then return true end
  SERVER_KILL_FEED_BROADCAST_DEDUP[key] = now
  return false
end

function shouldSkipServerKillFeedStats(message)
  local key = serverKillFeedDedupKey(message)
  if key == "" then return true end
  local now = os.time()
  local duplicateWindow = math.max(1, configNumber("server-kill-feed", { "DuplicateWindowSeconds", "duplicateWindowSeconds" }, 8))
  for oldKey, seenAt in pairs(SERVER_KILL_FEED_STATS_DEDUP) do
    if (now - seenAt) > (duplicateWindow * 4) then SERVER_KILL_FEED_STATS_DEDUP[oldKey] = nil end
  end
  local last = SERVER_KILL_FEED_STATS_DEDUP[key]
  if last ~= nil and (now - last) <= duplicateWindow then return true end
  SERVER_KILL_FEED_STATS_DEDUP[key] = now
  return false
end

function resolveKillFeedIdentityByName(name)
  name = cleanText(name)
  if name == "" then return nil end
  if findCachedPlayerByExactName ~= nil then
    local cached = findCachedPlayerByExactName(name)
    if cached ~= nil then return cached end
  end
  local resolved = resolvePlayerInfoFromServerLogTarget("", name)
  if resolved ~= nil then return resolved end
  local cache = serverLogIdentities()
  local identity = cache and cache.byName and cache.byName[name:lower()] or nil
  if identity ~= nil then
    local profileId = cleanText(identity.profileId)
    return {
      steam = cleanText(identity.steam),
      name = cleanText(identity.name) ~= "" and cleanText(identity.name) or name,
      userProfileId = profileId,
      serverUserProfileId = profileId
    }
  end
  return { steam = "", name = name, userProfileId = "", serverUserProfileId = "" }
end

function applyServerKillFeedStats(message)
  local normalized, reason = normalizeServerKillFeedMessage(message)
  if normalized == "" then return false, reason ~= "" and reason or "filtered" end
  local body = stripKillFeedPrefix(normalized)
  if body == "" then return false, "empty" end

  local killerName, victimName = body:match("^(.-)%s+убил%s+(.+)$")
  if killerName ~= nil and victimName ~= nil then
    killerName = cleanText(killerName)
    victimName = cleanText(victimName)
    if killerName == "" or victimName == "" then return false, "empty-kill-name" end
    if shouldSkipServerKillFeedStats(body) then return false, "duplicate" end
    local killerInfo = resolveKillFeedIdentityByName(killerName)
    local victimInfo = resolveKillFeedIdentityByName(victimName)
    if killerInfo == nil or victimInfo == nil then
      appendLog("server kill feed stats skipped identity killer=" .. tostring(killerName) .. " victim=" .. tostring(victimName))
      return false, "identity-not-found"
    end
    local updated = handleKillEvent(killerInfo, victimInfo, { source = "server-kill-feed", skipKillFeed = true })
    appendLog("server kill feed stats kill updated=" .. tostring(updated) ..
      " killer=" .. tostring(killerName) .. " victim=" .. tostring(victimName))
    return updated == true, updated and "updated" or "stats-failed"
  end

  local deadName = body:match("^(.-)%s+погиб$")
  if deadName ~= nil then
    deadName = cleanText(deadName)
    if deadName == "" then return false, "empty-death-name" end
    if shouldSkipServerKillFeedStats(body) then return false, "duplicate" end
    local victimInfo = resolveKillFeedIdentityByName(deadName)
    if victimInfo == nil then
      appendLog("server kill feed death stats skipped identity victim=" .. tostring(deadName))
      return false, "identity-not-found"
    end
    local updated = handleDeathEvent(victimInfo, { source = "server-kill-feed", skipKillFeed = true })
    appendLog("server kill feed stats death updated=" .. tostring(updated) ..
      " victim=" .. tostring(deadName))
    return updated == true, updated and "updated" or "stats-failed"
  end

  return false, "not-stat-event"
end

function killFeedRecordLooksTechnical(recordText)
  local text = tostring(recordText or "")
  if text:find('"source":"savefile-kill-log"', 1, true) ~= nil or
    text:find('"killerLocation"', 1, true) ~= nil or
    text:find('"victimLocation"', 1, true) ~= nil then
    return false
  end
  return text:find("KillerLoc", 1, true) ~= nil or
    text:find("VictimLoc", 1, true) ~= nil or
    text:find("\\u00", 1, true) ~= nil or
    text:find("\\u001", 1, true) ~= nil or
    text:find("\\u000", 1, true) ~= nil
end

function sanitizeKillFeedStateFile(path)
  local text = readAll(path)
  if text == nil or text == "" or not killFeedRecordLooksTechnical(text) then return end
  local kept = {}
  local removed = 0
  for objectText in tostring(text):gmatch("%b{}") do
    if killFeedRecordLooksTechnical(objectText) then
      removed = removed + 1
    else
      table.insert(kept, objectText)
    end
  end
  if removed > 0 then
    writeAll(path, "[" .. table.concat(kept, ",") .. "]")
    appendLog("server kill feed state sanitized path=" .. tostring(path or "") .. " removed=" .. tostring(removed))
  end
end

function sanitizeKillFeedStateFiles()
  sanitizeKillFeedStateFile(STATE_DIR .. "\\kill-feed.json")
  sanitizeKillFeedStateFile(STATE_DIR .. "\\server-kill-feed.json")
end

function broadcastServerKillFeed(message)
  local normalized, reason = normalizeServerKillFeedMessage(message)
  if normalized == "" then
    sanitizeKillFeedStateFiles()
    appendLog("server kill feed broadcast skipped reason=" .. tostring(reason or "filtered") ..
      " message=" .. tostring(message or ""))
    return false, reason ~= "" and reason or "filtered"
  end
  if shouldSkipServerKillFeedBroadcast(normalized) then
    appendLog("server kill feed broadcast skipped duplicate message=" .. tostring(normalized or ""))
    return false, "duplicate"
  end
  local sent, route = broadcastGlobalChatOnly(normalized)
  appendLog("server kill feed broadcast sent=" .. tostring(sent) ..
    " route=" .. tostring(route or "") ..
    " message=" .. tostring(normalized or ""))
  appendChatEvent(normalized, "Kill feed", "", "global", "server-kill-feed")
  appendActionEvent("server_kill_feed_broadcast", sent, nil, tostring(route or ""),
    '{"message":' .. js(normalized) .. ',"route":' .. js(route or "") .. ',"channel":"global"}')
  return sent, route
end

function appendDeathEvent(victim, meta)
  meta = meta or {}
  local victimX = tonumber(meta.victimX or meta.victimLocationX or meta.victim_x)
  local victimY = tonumber(meta.victimY or meta.victimLocationY or meta.victim_y)
  local victimZ = tonumber(meta.victimZ or meta.victimLocationZ or meta.victim_z)
  local message = tostring(victim.name or "Unknown") .. " погиб"
  local record = '{"type":"death","timestampUtc":' .. js(nowUtc()) ..
    ',"message":' .. js(message) ..
    ',"victimName":' .. js(victim.name or "") ..
    ',"victimSteamId":' .. js(victim.steam or "") ..
    ',"victimUserProfileId":' .. js(victim.dbId or "") ..
    ',"victimLocation":' .. killLocationJson(victimX, victimY, victimZ) ..
    ',"source":' .. js(meta.source or "ue4ss-death") .. '}'
  appendJsonArray(STATE_DIR .. "\\kill-feed.json", record, 2 * 1024 * 1024)
  appendJsonArray(STATE_DIR .. "\\server-kill-feed.json", record, 2 * 1024 * 1024)
  return message
end

function handleDeathEvent(victimInfo, meta)
  meta = meta or {}
  if victimInfo ~= nil then
    meta.victimX = meta.victimX or victimInfo.x
    meta.victimY = meta.victimY or victimInfo.y
    meta.victimZ = meta.victimZ or victimInfo.z
  end
  local victim = identityFromInfo(victimInfo, meta.victimDbId or "")
  local victimKey = identityKey(victim.steam, victim.name, victim.dbId)
  if victimKey == "" then return false end
  appendLog("death event victim=" .. tostring(victim.name or "") ..
    " steam=" .. tostring(victim.steam or "") ..
    " dbId=" .. tostring(victim.dbId or "") ..
    " source=" .. tostring(meta.source or ""))

  local stats = bountyStats()
  local victimEntry = bountyEntry(stats, victim)
  if victimEntry ~= nil then
    victimEntry.deaths = (victimEntry.deaths or 0) + 1
    victimEntry.current = 0
    appendBountySnapshot(victimEntry)
  end

  if not meta.skipKillFeed then
    local deathMessage = appendDeathEvent(victimEntry or victim, meta)
    if serverKillFeedEnabled() then
      broadcastServerKillFeed(serverKillFeedPrefix() .. " " .. deathMessage)
    end
  end
  return true
end

function handleKillEvent(killerInfo, victimInfo, meta)
  meta = meta or {}
  if killerInfo ~= nil then
    meta.killerX = meta.killerX or killerInfo.x
    meta.killerY = meta.killerY or killerInfo.y
    meta.killerZ = meta.killerZ or killerInfo.z
  end
  if victimInfo ~= nil then
    meta.victimX = meta.victimX or victimInfo.x
    meta.victimY = meta.victimY or victimInfo.y
    meta.victimZ = meta.victimZ or victimInfo.z
  end
  local killer = identityFromInfo(killerInfo, meta and meta.killerDbId or "")
  local victim = identityFromInfo(victimInfo, meta and meta.victimDbId or "")
  local killerKey = identityKey(killer.steam, killer.name, killer.dbId)
  local victimKey = identityKey(victim.steam, victim.name, victim.dbId)
  if victimKey ~= "" and (killerKey == "" or killerKey == victimKey) then return handleDeathEvent(victimInfo, meta) end
  if killerKey == "" or victimKey == "" then return false end
  appendLog("kill event killer=" .. tostring(killer.name or "") ..
    " victim=" .. tostring(victim.name or "") ..
    " killerDbId=" .. tostring(killer.dbId or "") ..
    " victimDbId=" .. tostring(victim.dbId or "") ..
    " source=" .. tostring(meta and meta.source or ""))

  local stats = bountyStats()
  local killerEntry = bountyEntry(stats, killer)
  local victimEntry = bountyEntry(stats, victim)
  if killerEntry == nil or victimEntry == nil then return false end

  local victimPreviousStreak = victimEntry.current or 0
  killerEntry.kills = (killerEntry.kills or 0) + 1
  killerEntry.current = (killerEntry.current or 0) + 1
  killerEntry.best = math.max(killerEntry.best or 0, killerEntry.current)
  victimEntry.deaths = (victimEntry.deaths or 0) + 1
  victimEntry.current = 0

  appendBountySnapshot(killerEntry)
  appendBountySnapshot(victimEntry)
  appendJsonArray(STATE_DIR .. "\\bounty-hunt-events.json", '{"utc":' .. js(nowUtc()) .. ',"killer":' .. js(killerEntry.name) .. ',"victim":' .. js(victimEntry.name) .. ',"killerSteamId":' .. js(killerEntry.steam) .. ',"victimSteamId":' .. js(victimEntry.steam) .. ',"victimPreviousStreak":' .. tostring(victimPreviousStreak) .. '}', 1024 * 1024)

  if not meta.skipKillFeed then
    local killMessage = appendKillEvent(killerEntry, victimEntry, meta, victimPreviousStreak)
    if serverKillFeedEnabled() then
      broadcastServerKillFeed(serverKillFeedPrefix() .. " " .. killMessage)
    end
  end

  local broadcastThreshold = configNumber("bounty-hunt", { "BroadcastThreshold", "broadcastThreshold" }, 3)
  local heroThreshold = configNumber("bounty-hunt", { "HeroThreshold", "heroThreshold" }, 5)
  if killerEntry.current >= broadcastThreshold then
    broadcast("[Bounty] " .. killerEntry.name .. " на серии " .. tostring(killerEntry.current) .. " убийств.")
  end
  if killerEntry.current == heroThreshold then
    broadcast("[Bounty] " .. killerEntry.name .. " стал целью сервера. Остановите его.")
  end
  if victimPreviousStreak >= broadcastThreshold then
    broadcast("[Bounty] " .. killerEntry.name .. " остановил серию " .. victimEntry.name .. " (" .. tostring(victimPreviousStreak) .. ").")
  end

  local rewardAmount = configNumber("bounty-hunt", { "LeaderKillRewardAmount", "leaderKillRewardAmount" }, 0)
  local rewardMode = extractStringAny(configText("bounty-hunt"), { "LeaderKillRewardMode", "leaderKillRewardMode" }) or "None"
  if victimPreviousStreak >= heroThreshold and rewardAmount > 0 and rewardMode:lower() ~= "none" and killerInfo ~= nil then
    local currency = rewardMode:lower() == "gold" and "Gold" or "Normal"
    local paid = changeMoney(killerEntry.steam, killerEntry.name, rewardAmount, currency)
    if paid then targetMessage(killerEntry.steam, killerEntry.name, "Награда за остановку bounty: " .. tostring(rewardAmount) .. " " .. currency .. ".", "bounty-hunt") end
  end
  return true
end

commandKey = nil

function formatBountyStats(info, command)
  return table.concat(bountyStatsLines(info, command), " | ")
end

function bountyStatsLines(info, command)
  local key = commandKey(command)
  local stats = bountyStats()
  local selfIdentity = identityFromInfo(info, "")
  local selfEntry = stats[identityKey(selfIdentity.steam, selfIdentity.name, selfIdentity.dbId)]

  if key == "streak" then
    if selfEntry == nil then
      return {
        "Твоя статистика:",
        "Текущая серия: 0",
        "Лучшая серия: 0",
        "Убийств: 0",
        "Смертей: 0"
      }
    end
    return {
      "Твоя статистика:",
      "Текущая серия: " .. tostring(selfEntry.current or 0),
      "Лучшая серия: " .. tostring(selfEntry.best or 0),
      "Убийств: " .. tostring(selfEntry.kills or 0),
      "Смертей: " .. tostring(selfEntry.deaths or 0)
    }
  end

  local rows = {}
  for _, entry in pairs(stats) do
    if key == "bounty" then
      if (entry.current or 0) >= configNumber("bounty-hunt", { "BroadcastThreshold", "broadcastThreshold" }, 3) then table.insert(rows, entry) end
    else
      if (entry.best or 0) > 0 or (entry.kills or 0) > 0 then table.insert(rows, entry) end
    end
  end
  table.sort(rows, function(a, b)
    if key == "bounty" then
      if (a.current or 0) ~= (b.current or 0) then return (a.current or 0) > (b.current or 0) end
    else
      if (a.best or 0) ~= (b.best or 0) then return (a.best or 0) > (b.best or 0) end
      if (a.kills or 0) ~= (b.kills or 0) then return (a.kills or 0) > (b.kills or 0) end
    end
    return tostring(a.name or "") < tostring(b.name or "")
  end)
  local maxRows = math.max(1, configNumber("bounty-hunt", { "MaxBoardEntries", "maxBoardEntries" }, 5))
  if #rows == 0 then
    return { key == "bounty" and "Сейчас нет активных целей с наградой." or "Топ охотников пока пуст." }
  end
  local out = { key == "bounty" and "Активные bounty:" or "Топ охотников:" }
  for i = 1, math.min(#rows, maxRows) do
    local entry = rows[i]
    if key == "bounty" then
      table.insert(out, tostring(i) .. ". " .. tostring(entry.name) .. " - серия: " .. tostring(entry.current or 0))
    else
      table.insert(out, tostring(i) .. ". " .. tostring(entry.name) ..
        " - лучшая: " .. tostring(entry.best or 0) ..
        ", убийств: " .. tostring(entry.kills or 0) ..
        ", смертей: " .. tostring(entry.deaths or 0))
    end
  end
  return out
end

function sendBountyStats(info, command)
  for _, line in ipairs(bountyStatsLines(info, command)) do
    targetMessageResolved(info, line)
  end
end

function wargmOperationIdValue(object)
  local keys = { "operationId", "OperationId", "id", "Id", "orderId", "OrderId", "purchaseId", "PurchaseId" }
  for _, key in ipairs(keys) do
    local value = extractString(object, key) or ""
    if value ~= "" then return value end
    local numberValue = extractNumber(object, key)
    if numberValue ~= nil then return tostring(math.floor(numberValue)) end
  end
  return ""
end

function wargmOperationKey(object, index)
  local operationId = wargmOperationIdValue(object)
  local steam = extractString(object, "steamId") or ""
  local mode = (extractString(object, "mode") or extractString(object, "DeliveryMode") or extractString(object, "deliveryMode") or "item"):lower():gsub("[%s_%-%.\"]+", "")
  local offerId = extractString(object, "offerId") or extractString(object, "OfferId") or extractString(object, "offer_id") or extractString(object, "offer") or ""
  local itemId = extractString(object, "itemId") or extractString(object, "ItemId") or extractString(object, "item") or extractString(object, "Item") or ""
  local vehicleId = extractString(object, "vehicleId") or extractString(object, "VehicleId") or ""
  local skill = extractString(object, "skill") or extractString(object, "skillName") or extractString(object, "SkillName") or ""
  local title = extractString(object, "title") or extractString(object, "Title") or extractString(object, "name") or extractString(object, "Name") or ""
  local amount = extractNumber(object, "amount") or extractNumber(object, "Amount") or extractNumber(object, "money") or extractNumber(object, "Money") or extractNumber(object, "gold") or extractNumber(object, "Gold") or extractNumber(object, "fame") or extractNumber(object, "Fame") or 0
  local quantity = extractNumber(object, "quantity") or extractNumber(object, "Quantity") or extractNumber(object, "buy_count") or extractNumber(object, "set_count") or 1
  local itemsSpec = extractString(object, "itemsSpec") or extractString(object, "ItemsSpec") or itemsSpecFromConfig(object)
  local base = operationId ~= "" and ("operation:" .. operationId) or ("pending:" .. tostring(index or 0))
  return base ..
    "|steam:" .. steam ..
    "|offer:" .. offerId ..
    "|mode:" .. mode ..
    "|item:" .. itemId ..
    "|vehicle:" .. vehicleId ..
    "|skill:" .. skill ..
    "|amount:" .. tostring(amount) ..
    "|qty:" .. tostring(quantity) ..
    "|title:" .. title ..
    "|items:" .. itemsSpec
end

function deliveredWargmKeys()
  local keys = {}
  local function addFromObject(object, index)
    local key = extractString(object, "key") or ""
    if key ~= "" then keys[key] = true end
    local fullKey = wargmOperationKey(object, index)
    if fullKey ~= "" then keys[fullKey] = true end
  end
  for index, object in ipairs(stateObjects("wargm-delivered.json")) do
    addFromObject(object, index)
  end
  for index, object in ipairs(stateObjects("wargm-confirmed.json")) do
    addFromObject(object, index)
  end
  return keys
end

function pruneWargmPending(deliveredKeys)
  deliveredKeys = deliveredKeys or deliveredWargmKeys()
  local kept = {}
  local removed = 0
  for index, object in ipairs(stateObjects("wargm-pending.json")) do
    local key = wargmOperationKey(object, index)
    local settled = deliveredKeys[key]
    if settled then
      removed = removed + 1
    else
      table.insert(kept, object)
    end
  end
  if removed > 0 then
    writeAll(STATE_DIR .. "\\wargm-pending.json", "[" .. table.concat(kept, ",") .. "]")
    appendJsonArray(STATE_DIR .. "\\wargm-shop.json", '{"utc":' .. js(nowUtc()) .. ',"status":"pending-pruned","removed":' .. tostring(removed) .. ',"remaining":' .. tostring(#kept) .. '}', 1024 * 1024)
  end
  return removed
end

function wargmRetrySecondsRemaining(opKey)
  local now = os.time()
  local remaining = 0
  for _, object in ipairs(stateObjects("wargm-attempts.json")) do
    if (extractString(object, "key") or "") == tostring(opKey or "") then
      local retryAfter = extractNumber(object, "retryAfter") or 0
      if retryAfter > now and (retryAfter - now) > remaining then remaining = retryAfter - now end
    end
  end
  return remaining
end

function requestWargmSync(info)
  info = info or {}
  local request = '{"utc":' .. js(nowUtc()) ..
    ',"steamId":' .. js(info.steam or info.steamId or "") ..
    ',"name":' .. js(info.name or "") ..
    ',"runtimeKey":' .. js(info.runtimeKey or "") ..
    ',"source":"player-command"}'
  local saved = writeAll(STATE_DIR .. "\\wargm-sync-request.json", request)
  appendJsonArray(STATE_DIR .. "\\wargm-shop.json", '{"utc":' .. js(nowUtc()) ..
    ',"status":"sync-requested","steamId":' .. js(info.steam or info.steamId or "") ..
    ',"name":' .. js(info.name or "") ..
    ',"saved":' .. (saved and "true" or "false") .. '}', 1024 * 1024)
  appendLog("wargm sync requested steam=" .. tostring(info.steam or info.steamId or "") .. " name=" .. tostring(info.name or "") .. " saved=" .. tostring(saved))
  return saved
end

function requestWargmConfirm(info, operationId)
  info = info or {}
  local request = '{"utc":' .. js(nowUtc()) ..
    ',"steamId":' .. js(info.steam or info.steamId or "") ..
    ',"name":' .. js(info.name or "") ..
    ',"operationId":' .. js(operationId or "") ..
    ',"source":"player-command"}'
  local saved = writeAll(STATE_DIR .. "\\wargm-confirm-request.json", request)
  appendLog("wargm confirm requested operationId=" .. tostring(operationId or "") .. " saved=" .. tostring(saved))
  return saved
end

welcomeClaimsInFlight = {}
dailyPackClaimsInFlight = {}

function playerStateKey(info)
  if info == nil then return "" end
  if tostring(info.steam or "") ~= "" then return "steam:" .. tostring(info.steam) end
  if tostring(info.userProfileId or info.serverUserProfileId or "") ~= "" then return "profile:" .. tostring(info.userProfileId or info.serverUserProfileId) end
  if tostring(info.name or "") ~= "" then return "name:" .. tostring(info.name):lower() end
  return ""
end

playerCommandAliases = {
  help = { "/help", "!help" },
  hello = { "/hello", "!hello" },
  sethome = { "/sethome", "!sethome" },
  home = { "/home", "!home" },
  homes = { "/homes", "!homes" },
  delhome = { "/delhome", "!delhome" },
  pm = { "/pm", "!pm" },
  reply = { "/reply", "!reply", "/r", "!r" },
  pmhistory = { "/pmhistory", "!pmhistory" },
  scan = { "/scan", "!scan" },
  travel = { "/travel", "!travel" },
  rent = { "/rent", "!rent" },
  invdel = { "/invdel", "!invdel", "/deleteitem", "!deleteitem" },
  welcomepack = { "/starter", "!starter", "/welcomepack", "!welcomepack" },
  dailypack = { "/daily", "!daily", "/dailypack", "!dailypack", "/daily-pack", "!daily-pack" },
  wargm = { "/wargm", "!wargm" },
  streak = { "/streak", "!streak" },
  bounty = { "/bounty", "!bounty" },
  huntertop = { "/huntertop", "!huntertop" }
}

function commandMatches(command, key)
  local aliases = playerCommandAliases[key] or {}
  for _, alias in ipairs(aliases) do
    if command == alias then return true end
  end
  return false
end

commandKey = function(command)
  for key, aliases in pairs(playerCommandAliases) do
    for _, alias in ipairs(aliases) do
      if command == alias then return key end
    end
  end
  return ""
end

function moduleEnabled(key, fallback)
  return configBool(key, { "Enabled", "enabled" }, fallback ~= false) ~= false
end

function playerHelpText(info)
  return table.concat(playerHelpLines(info), " | ")
end

function playerHelpLines(info)
  local lines = { "Помощь сервера:" }
  table.insert(lines, "Основные:")
  table.insert(lines, "/help - показать команды")
  table.insert(lines, "/hello - проверить связь с сервером")
  if moduleEnabled("home-system", true) then
    table.insert(lines, "Дом:")
    table.insert(lines, "/sethome <name> - сохранить точку дома")
    table.insert(lines, "/home <name> - перейти домой")
    table.insert(lines, "/homes - список домов")
    table.insert(lines, "/delhome <name> - удалить дом")
  end
  if moduleEnabled("private-messages", true) and
    (not configBool("private-messages", { "UsePermission", "usePermission" }, false) or hasPermission(info, configString("private-messages", { "AllowPermission", "allowPermission" }, "pm.use"))) then
    table.insert(lines, "Общение:")
    table.insert(lines, "/pm <nick> <text> - личное сообщение")
    table.insert(lines, "/reply <text> - ответить последнему")
  end
  local serviceHeaderAdded = false
  local function serviceHeader()
    if not serviceHeaderAdded then
      table.insert(lines, "Сервисы:")
      serviceHeaderAdded = true
    end
  end
  if moduleEnabled("sector-scan", true) and hasPermission(info, configString("sector-scan", { "RequiredPermission", "requiredPermission" }, "")) then
    local scanCost = configNumber("sector-scan", { "ScanCost", "scanCost", "price" }, 1000)
    serviceHeader()
    table.insert(lines, scanCost > 0 and ("/scan <B2> - скан выбранного сектора, цена $" .. tostring(scanCost)) or "/scan <B2> - скан выбранного сектора бесплатно")
    table.insert(lines, "Пример: /scan B2 или /scan C0")
  end
  if moduleEnabled("fast-travel", true) then
    serviceHeader()
    table.insert(lines, "/travel - список точек и цен")
    table.insert(lines, "/travel <code> - переместиться к точке")
  end
  if moduleEnabled("vehicle-rental", true) then
    serviceHeader()
    table.insert(lines, "/rent - список транспорта и условий")
    table.insert(lines, "/rent <type> <minutes> - арендовать транспорт")
    table.insert(lines, "/rent return - вернуть аренду")
  end
  if moduleEnabled("welcome-pack", true) and hasPermission(info, configString("welcome-pack", { "RequiredPermission", "requiredPermission" }, "")) then
    serviceHeader()
    table.insert(lines, "/starter - получить стартовый набор")
  end
  if moduleEnabled("daily-pack", true) and hasPermission(info, configString("daily-pack", { "RequiredPermission", "requiredPermission" }, "")) then
    serviceHeader()
    table.insert(lines, "/daily - получить ежедневный пак")
  end
  if moduleEnabled("bounty-hunt", true) then
    table.insert(lines, "Охота:")
    table.insert(lines, "/streak - твоя серия и смерти")
    table.insert(lines, "/bounty - активные цели")
    table.insert(lines, "/huntertop - топ охотников")
  end
  if moduleEnabled("wargm-shop", false) then
    table.insert(lines, "Магазин:")
    table.insert(lines, "/wargm - получить покупку Wargm")
  end
  return lines
end

function sendPlayerHelp(info)
  for _, line in ipairs(playerHelpLines(info)) do
    targetMessageResolved(info, line)
  end
end

handlePlayerCommand = function(info, message)
  info = enrichPlayerInfoFromServerLog(info) or info
  local words = splitWords(message)
  local command = (words[1] or ""):lower()
  if command == "" then return false end

  if commandMatches(command, "help") then
    sendPlayerHelp(info)
    return true
  end

  if commandMatches(command, "hello") then
    local name = tostring((info or {}).name or "")
    if name == "" then name = tr(info, "playerFallback", "игрок") end
    targetMessageResolved(info, tr(info, "hello", "Привет, {name}. Система сервера работает.", { name = name }))
    return true
  end

  if commandMatches(command, "sethome") then
    if not moduleEnabled("home-system", true) then
      targetMessageResolved(info, "Система домов сейчас отключена.")
      return true
    end
    local label = table.concat(words, " ", 2)
    if label == "" then
      targetMessageResolved(info, "Использование: /sethome <name>")
      return true
    end
    local homes = homesForInfo(info)
    local already = homeByLabel(info, label) ~= nil
    local limit = configNumber("home-system", { "DefaultMaxHomes", "defaultMaxHomes" }, 2)
    local vipPermission = configString("home-system", { "VipPermission", "vipPermission" }, "")
    if vipPermission ~= "" and hasPermission(info, vipPermission) then
      limit = configNumber("home-system", { "VipMaxHomes", "vipMaxHomes" }, limit)
    end
    if not already and #homes >= limit then
      targetMessageResolved(info, "Достигнут лимит. Тебе доступно только " .. tostring(limit) .. " домов.")
      return true
    end
    if appendHome(info, label) then
      targetMessageResolved(info, "Дом '" .. label .. "' успешно установлен.")
    else
      targetMessageResolved(info, "Не удалось сохранить дом.")
    end
    return true
  end

  if commandMatches(command, "home") then
    if not moduleEnabled("home-system", true) then
      targetMessageResolved(info, "Система домов сейчас отключена.")
      return true
    end
    local label = table.concat(words, " ", 2)
    local cooldown = cooldownRemaining("home-cooldowns.json", info, configNumber("home-system", { "TeleportCooldownMinutes", "teleportCooldownMinutes", "cooldownMinutes" }, 0) * 60)
    if cooldown > 0 then
      targetMessageResolved(info, "Кулдаун ещё активен. Повтори через " .. tostring(cooldown) .. " сек.")
      return true
    end
    local home = homeByLabel(info, label)
    if home == nil then
      targetMessageResolved(info, label == "" and ("Укажи дом: /home <name>. " .. homeListText(info)) or ("Дом '" .. label .. "' не найден."))
      return true
    end
    local pendingKey = transientPlayerKey(info)
    if HOME_TELEPORT_PENDING[pendingKey] then
      targetMessageResolved(info, "Телепорт уже готовится. Дождись завершения предыдущей заявки.")
      return true
    end
    HOME_TELEPORT_PENDING[pendingKey] = true
    local delayMs = math.max(0, configNumber("home-system", { "TeleportDelaySeconds", "teleportDelaySeconds" }, 0)) * 1000
    local startX, startY = info.x, info.y
    targetMessageResolved(info, delayMs > 0 and ("Телепорт к дому '" .. home.label .. "' через " .. tostring(delayMs / 1000) .. " сек. Не двигайся!") or ("Телепорт к дому '" .. home.label .. "'."))
    deferGame(delayMs, function()
      local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
      if live == nil then HOME_TELEPORT_PENDING[pendingKey] = nil; return end
      local cancelDistance = configNumber("home-system", { "CancelMoveDistance", "cancelMoveDistance" }, 150)
      if delayMs > 0 and distance2d(startX, startY, live.x, live.y) > cancelDistance then
        HOME_TELEPORT_PENDING[pendingKey] = nil
        targetMessageResolved(live, "Телепорт отменён: ты сдвинулся с места.")
        return
      end
      local sent, result = teleportResolved(live, home.x, home.y, home.z)
      if not sent then
        HOME_TELEPORT_PENDING[pendingKey] = nil
        targetMessageResolved(live, "Не удалось телепортировать: " .. tostring(result))
        return
      end
      local confirmSeconds = configNumber("home-system", { "TeleportConfirmationSeconds", "teleportConfirmationSeconds", "TravelConfirmationSeconds", "travelConfirmationSeconds" }, 30)
      local arrivalRadius = configNumber("home-system", { "SuccessArrivalDistance", "successArrivalDistance", "ArrivalRadius", "arrivalRadius" }, 1500)
      observePlayerArrival("home", live, home.x, home.y, home.z, confirmSeconds, arrivalRadius, function(arrivalInfo)
        HOME_TELEPORT_PENDING[pendingKey] = nil
        rememberCooldown("home-cooldowns.json", arrivalInfo or live)
        targetMessageResolved(arrivalInfo or live, "Ты прибыл домой: " .. home.label)
      end, function(reason)
        HOME_TELEPORT_PENDING[pendingKey] = nil
        targetMessageResolved(live, "Телепорт отправлен, но прибытие не подтверждено: " .. tostring(reason))
      end)
    end)
    return true
  end

  if commandMatches(command, "homes") then
    if not moduleEnabled("home-system", true) then
      targetMessageResolved(info, "Система домов сейчас отключена.")
      return true
    end
    targetMessageResolved(info, homeListText(info))
    return true
  end

  if commandMatches(command, "delhome") then
    if not moduleEnabled("home-system", true) then
      targetMessageResolved(info, "Система домов сейчас отключена.")
      return true
    end
    local label = table.concat(words, " ", 2)
    local removed = deleteHomes(info, label)
    targetMessageResolved(info, removed > 0 and ("Удалено точек дома: " .. tostring(removed)) or "Подходящих точек дома не найдено.")
    return true
  end

  if commandMatches(command, "pm") then
    if not moduleEnabled("private-messages", true) then
      targetMessageResolved(info, "Личные сообщения сейчас отключены.")
      return true
    end
    local pmPermission = configString("private-messages", { "AllowPermission", "allowPermission" }, "pm.use")
    if configBool("private-messages", { "UsePermission", "usePermission" }, false) and not hasPermission(info, pmPermission) then
      targetMessageResolved(info, permissionDeniedText(pmPermission))
      return true
    end
    local target = words[2] or ""
    local body = table.concat(words, " ", 3)
    if target == "" or body == "" then
      targetMessageResolved(info, "Формат: /pm name message")
      return true
    end
    local cooldown = privateMessageCooldownRemaining(info)
    if cooldown > 0 then
      targetMessageResolved(info, "Личные сообщения на кулдауне. Подожди " .. tostring(cooldown) .. " сек.")
      return true
    end
    local other = findPlayer(nil, target)
    if other == nil then
      targetMessageResolved(info, "Игрок для /pm не найден.")
      return true
    end
    targetMessageResolved(other, "[PM] " .. (info.name or "Игрок") .. ": " .. body)
    targetMessageResolved(info, "[PM -> " .. (other.name or target) .. "] " .. body)
    recordPmReply(info, other)
    rememberPrivateMessageCooldown(info)
    appendJsonArray(STATE_DIR .. "\\private-messages.json", '{"utc":' .. js(nowUtc()) .. ',"from":' .. js(info.name) .. ',"to":' .. js(other.name) .. ',"message":' .. js(body) .. '}', 1024 * 1024)
    return true
  end

  if commandMatches(command, "reply") then
    if not moduleEnabled("private-messages", true) then
      targetMessageResolved(info, "Личные сообщения сейчас отключены.")
      return true
    end
    local pmPermission = configString("private-messages", { "AllowPermission", "allowPermission" }, "pm.use")
    if configBool("private-messages", { "UsePermission", "usePermission" }, false) and not hasPermission(info, pmPermission) then
      targetMessageResolved(info, permissionDeniedText(pmPermission))
      return true
    end
    local body = table.concat(words, " ", 2)
    local reply = pmReplies[playerReplyKey(info)]
    if body == "" then
      targetMessageResolved(info, "Формат: /reply message")
      return true
    end
    if reply == nil then
      targetMessageResolved(info, "Некому ответить. Сначала используй /pm.")
      return true
    end
    local cooldown = privateMessageCooldownRemaining(info)
    if cooldown > 0 then
      targetMessageResolved(info, "Личные сообщения на кулдауне. Подожди " .. tostring(cooldown) .. " сек.")
      return true
    end
    local other = findPlayer(reply.steam, reply.name)
    if other == nil then
      targetMessageResolved(info, "Игрок для ответа не найден.")
      return true
    end
    targetMessageResolved(other, "[PM] " .. (info.name or "Игрок") .. ": " .. body)
    targetMessageResolved(info, "[PM -> " .. (other.name or reply.name or "") .. "] " .. body)
    recordPmReply(info, other)
    rememberPrivateMessageCooldown(info)
    appendJsonArray(STATE_DIR .. "\\private-messages.json", '{"utc":' .. js(nowUtc()) .. ',"from":' .. js(info.name) .. ',"to":' .. js(other.name) .. ',"message":' .. js(body) .. '}', 1024 * 1024)
    return true
  end

  if commandMatches(command, "pmhistory") then
    if not moduleEnabled("private-messages", true) then
      targetMessageResolved(info, "Личные сообщения сейчас отключены.")
      return true
    end
    local pmPermission = configString("private-messages", { "AllowPermission", "allowPermission" }, "pm.use")
    if configBool("private-messages", { "UsePermission", "usePermission" }, false) and not hasPermission(info, pmPermission) then
      targetMessageResolved(info, permissionDeniedText(pmPermission))
      return true
    end
    targetMessageResolved(info, privateMessageHistory(info, tonumber(words[2]) or 5))
    return true
  end

  if commandMatches(command, "scan") then
    if not moduleEnabled("sector-scan", true) then
      targetMessageResolved(info, "Сканирование квадрата сейчас отключено.")
      return true
    end
    local requiredPermission = configString("sector-scan", { "RequiredPermission", "requiredPermission" }, "")
    if not hasPermission(info, requiredPermission) then
      targetMessageResolved(info, permissionDeniedText(requiredPermission))
      return true
    end
    local cooldown = cooldownRemaining("sector-scan-cooldowns.json", info, configNumber("sector-scan", { "CooldownSeconds", "cooldownSeconds" }, 120))
    if cooldown > 0 then
      targetMessageResolved(info, "Сканирование ещё на кулдауне. Подожди " .. tostring(cooldown) .. " сек.")
      return true
    end
    local liveInfo = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
    local requested = normalizeSectorCode(words[2] or "")
    if tostring(words[2] or "") ~= "" and requested == "" then
      targetMessageResolved(info, sectorHelpText())
      return true
    end
    local wanted = requested
    if wanted == "" then
      local x = tonumber(liveInfo.x)
      local y = tonumber(liveInfo.y)
      if x == nil or y == nil then
        targetMessageResolved(info, "Скан не выполнен: не удалось определить твой текущий квадрат. Укажи сектор вручную, например /scan B2.")
        return true
      end
      wanted = sectorFromCoordinates(x, y):upper()
    end
    local maxPositionAge = configNumber("sector-scan", { "PositionMaxAgeSeconds", "positionMaxAgeSeconds", "FreshPositionSeconds", "freshPositionSeconds" }, 8)
    local scanInfos = sectorScanPlayerInfos(maxPositionAge, liveInfo)
    if #scanInfos == 0 then
      targetMessageResolved(info, "Скан не выполнен: нет свежих live-координат игроков. Повтори через несколько секунд.")
      return true
    end
    local cost = configNumber("sector-scan", { "ScanCost", "scanCost", "price" }, 1000)
    if cost > 0 then
      local charged, chargeMessage = changeMoney(liveInfo.steam, liveInfo.name, -cost, "Normal", liveInfo.runtimeKey)
      if not charged then
        targetMessageResolved(info, "Скан не выполнен: " .. tostring(chargeMessage))
        return true
      end
    end
    local count = 0
    local names = {}
    local includeNames = configBool("sector-scan", { "IncludePlayerNames", "includePlayerNames" }, true)
    local includeSelf = configBool("sector-scan", { "IncludeSelf", "includeSelf" }, false)
    local maxNames = configNumber("sector-scan", { "MaxListedNames", "maxListedNames" }, 5)
    for _, p in ipairs(scanInfos) do
      local px = tonumber(p.x)
      local py = tonumber(p.y)
      local same = (tostring(liveInfo.steam or "") ~= "" and tostring(p.steam or "") == tostring(liveInfo.steam or "")) or
        (tostring(liveInfo.runtimeKey or "") ~= "" and tostring(p.runtimeKey or "") == tostring(liveInfo.runtimeKey or "")) or
        (tostring(liveInfo.name or "") ~= "" and tostring(p.name or "") == tostring(liveInfo.name or ""))
      if px ~= nil and py ~= nil and sectorFromCoordinates(px, py):upper() == wanted and (includeSelf or not same) then
        count = count + 1
        if includeNames and #names < maxNames then
          local display = tostring(p.name or "")
          if display == "" then display = tostring(p.steam or "") end
          if display ~= "" then table.insert(names, display) end
        end
      end
    end
    rememberCooldown("sector-scan-cooldowns.json", liveInfo)
    local suffix = #names > 0 and (" " .. table.concat(names, ", ")) or ""
    local costText = cost > 0 and (" Стоимость: $" .. tostring(cost) .. ".") or " Стоимость: бесплатно."
    local sourceText = " Источник: live-координаты."
    appendActionEvent("sector_scan", true, liveInfo, "sector=" .. wanted .. " count=" .. tostring(count),
      '{"sector":' .. js(wanted) .. ',"count":' .. tostring(count) .. ',"names":' .. stringArrayJson(names) .. ',"playersChecked":' .. tostring(#scanInfos) .. ',"positionMaxAgeSeconds":' .. tostring(maxPositionAge) .. '}')
    targetMessageResolved(info, count > 0 and ("[Скан] Квадрат " .. wanted .. ": найдено " .. tostring(count) .. "." .. costText .. sourceText .. suffix) or ("[Скан] Квадрат " .. wanted .. " пуст." .. costText .. sourceText))
    return true
  end

  if commandMatches(command, "travel") then
    if not moduleEnabled("fast-travel", true) then
      targetMessageResolved(info, "Быстрое перемещение сейчас отключено.")
      return true
    end
    local alias = (words[2] or ""):lower()
    local routes = configuredFastTravelRoutes()
    if alias == "" then
      local labels = {}
      for key, route in pairs(routes) do
        local fare = fastTravelFareForInfo(info, route)
        table.insert(labels, { key = key, text = "/travel " .. key .. " - " .. tostring(route.name) .. " - цена: " .. tostring(fare) })
      end
      table.sort(labels, function(a, b) return tostring(a.key) < tostring(b.key) end)
      targetMessageResolved(info, "Маршруты быстрого перемещения:")
      for _, row in ipairs(labels) do targetMessageResolved(info, row.text) end
      targetMessageResolved(info, "Использование: /travel <код>. Цена считается до выбранной точки.")
      return true
    end
    local route = routes[alias]
    if route == nil then
      targetMessageResolved(info, "Маршрут не найден. Используй /travel чтобы увидеть список.")
      return true
    end
    local cooldown = cooldownRemaining("fast-travel-cooldowns.json", info, configNumber("fast-travel", { "TransferCooldownMinutes", "transferCooldownMinutes", "cooldownMinutes" }, 60) * 60)
    if cooldown > 0 then
      targetMessageResolved(info, "Кулдаун быстрого перемещения активен. Осталось " .. tostring(cooldown) .. " сек.")
      return true
    end
    local fare = fastTravelFareForInfo(info, route)
    local targetZ = safeFastTravelZ(route)
    local pendingKey = transientPlayerKey(info)
    if FAST_TRAVEL_GLOBAL_PENDING then
      targetMessageResolved(info, "Очередь перемещения занята. Повтори команду через несколько секунд.")
      return true
    end
    if FAST_TRAVEL_PENDING[pendingKey] then
      targetMessageResolved(info, "Перемещение уже готовится. Дождись завершения предыдущей заявки.")
      return true
    end
    FAST_TRAVEL_GLOBAL_PENDING = true
    FAST_TRAVEL_PENDING[pendingKey] = true
    local delayMs = math.max(0, configNumber("fast-travel", { "TeleportDelaySeconds", "teleportDelaySeconds", "delaySeconds" }, 5)) * 1000
    local startX, startY = info.x, info.y
    targetMessageResolved(info, "Подготовка перемещения в '" .. route.name .. "' за $" .. tostring(fare) .. " через " .. tostring(delayMs / 1000) .. " сек. Не двигайся.")
    deferGame(delayMs, function()
      local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
      if live == nil then FAST_TRAVEL_PENDING[pendingKey] = nil; FAST_TRAVEL_GLOBAL_PENDING = false; return end
      local cancelDistance = configNumber("fast-travel", { "CancelMoveDistance", "cancelMoveDistance" }, 150)
      if delayMs > 0 and distance2d(startX, startY, live.x, live.y) > cancelDistance then
        FAST_TRAVEL_PENDING[pendingKey] = nil
        FAST_TRAVEL_GLOBAL_PENDING = false
        targetMessageResolved(live, "Быстрое перемещение отменено: ты сдвинулся с места.")
        return
      end
      local sent, result = teleportResolved(live, route.x, route.y, targetZ)
      if not sent then
        FAST_TRAVEL_PENDING[pendingKey] = nil
        FAST_TRAVEL_GLOBAL_PENDING = false
        targetMessageResolved(live, "Не удалось выполнить быстрое перемещение: " .. tostring(result))
        return
      end
      local confirmSeconds = configNumber("fast-travel", { "TravelConfirmationSeconds", "travelConfirmationSeconds" }, 90)
      local arrivalRadius = configNumber("fast-travel", { "SuccessArrivalDistance", "successArrivalDistance", "ArrivalRadius", "arrivalRadius" }, 1500)
      observePlayerArrival("fast_travel", live, route.x, route.y, targetZ, confirmSeconds, arrivalRadius, function(arrivalInfo)
        FAST_TRAVEL_PENDING[pendingKey] = nil
        FAST_TRAVEL_GLOBAL_PENDING = false
        live = arrivalInfo or live
        local charged, chargeMessage = true, ""
        if fare > 0 then charged, chargeMessage = changeMoney(live.steam, live.name, -fare, "Normal", live.runtimeKey) end
        rememberCooldown("fast-travel-cooldowns.json", live)
        appendJsonArray(STATE_DIR .. "\\fast-travel-trips.json", '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(live.steam) .. ',"name":' .. js(live.name) .. ',"route":' .. js(route.name) .. ',"fare":' .. tostring(fare) .. ',"charged":' .. (charged and "true" or "false") .. '}', 1024 * 1024)
        if charged then
          targetMessageResolved(live, "Быстрое перемещение выполнено. Списано: $" .. tostring(fare) .. ".")
        else
          targetMessageResolved(live, "Ты прибыл, но списание не подтверждено: " .. tostring(chargeMessage))
        end
      end, function(reason)
        FAST_TRAVEL_PENDING[pendingKey] = nil
        FAST_TRAVEL_GLOBAL_PENDING = false
        targetMessageResolved(live, "Перемещение отправлено, но прибытие не подтверждено. Деньги не списаны: " .. tostring(reason))
      end)
    end)
    return true
  end

  if commandMatches(command, "rent") then
    if not moduleEnabled("vehicle-rental", true) then
      targetMessageResolved(info, "Аренда транспорта сейчас отключена.")
      return true
    end
    local sub = (words[2] or ""):lower()
    if sub == "" or sub == "list" then
      sendRentHelp(info, latestActiveRental(info))
      return true
    end
    info = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
    if not playerInfoHasLiveRuntime(info) then
      targetMessageResolved(info, "Аренда не запущена: сервер ещё не привязал твоего персонажа к live runtime. Подожди 10 секунд и повтори /rent.")
      return true
    end
    info = enrichPlayerInfoFromServerLog(info) or info
    if not looksLikeSteamId(cleanText(info.steam or "")) then
      targetMessageResolved(info, "Аренда не запущена: сервер пока не определил твой SteamID. Подожди 10 секунд и повтори /rent.")
      return true
    end
    collectRentalPendingTaxes(info, false)
    local current = latestActiveRental(info)
    if sub == "status" or sub == "time" then
      sendRentStatus(info, current)
      return true
    end
    if sub == "extend" then
      if current == nil then
        targetMessageResolved(info, "У тебя нет активной аренды.")
        return true
      end
      local minutes = math.floor(tonumber(words[3]) or 0)
      if minutes < 1 then
        targetMessageResolved(info, "Использование: /rent extend <минуты>. Продление считает только время, доплата спишется при возврате или по окончании.")
        return true
      end
      local queued, queueResult = enqueueMutation("vehicle-rental-extend", info, function()
        local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey)
        if live == nil then return end
        local active = latestActiveRental(live)
        if active == nil then
          targetMessage(info.steam, info.name, "Продление не выполнено: активная аренда не найдена.", "vehicle-rental", info.runtimeKey)
          return
        end
        local alias = (extractString(active, "alias") or ""):lower()
        local configured = configuredRentalVehicles()[alias]
        local price = extractNumber(active, "pricePer10Minutes") or (configured and configured.price) or 0
        local previousMinutes = extractNumber(active, "minutes") or 0
        local newMinutes = previousMinutes + minutes
        local maxTotalMinutes = (configured and configured.maxMinutes) or configNumber("vehicle-rental", { "MaxRentalMinutes", "maxRentalMinutes", "MaxMinutes", "maxMinutes" }, 120)
        if newMinutes > maxTotalMinutes then
          targetMessage(info.steam, info.name, "Нельзя продлить аренду: общий срок не может превышать " .. tostring(maxTotalMinutes) .. " минут.", "vehicle-rental", info.runtimeKey)
          return
        end
        local previousExpiresAt = extractNumber(active, "expiresAt") or os.time()
        local newExpiresAt = math.max(previousExpiresAt, os.time()) + minutes * 60
        local displayName = extractString(active, "displayName") or (configured and configured.display) or extractString(active, "vehicleId") or "vehicle"
        local totalCharge = extractNumber(active, "totalCharge") or extractNumber(active, "initialCharge") or 0
        local destroyRef = vehicleDestroyRefFromRental(active)
        appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json", '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(live.steam) .. ',"name":' .. js(live.name) .. ',"alias":' .. js(alias) .. ',"status":"active","displayName":' .. js(displayName) .. ',"vehicleId":' .. js(extractString(active, "vehicleId") or "") .. ',"minutes":' .. tostring(newMinutes) .. ',"startedAt":' .. tostring(extractNumber(active, "startedAt") or os.time()) .. ',"extendedAt":' .. tostring(os.time()) .. ',"extensionMinutes":' .. tostring(minutes) .. ',"expiresAt":' .. tostring(newExpiresAt) .. ',"initialCharge":' .. tostring(extractNumber(active, "initialCharge") or 0) .. ',"pricePer10Minutes":' .. tostring(price) .. ',"extensionCharge":0,"totalCharge":' .. tostring(totalCharge) .. ',"destroyRef":' .. js(destroyRef) .. ',"destroyTracked":' .. (destroyRef ~= "" and "true" or "false") .. '}', 1024 * 1024)
        targetMessage(info.steam, info.name, "Аренда " .. displayName .. " продлена на " .. tostring(minutes) .. " мин. Доплата будет рассчитана при возврате или по окончании.", "vehicle-rental", info.runtimeKey)
      end)
      targetMessageResolved(info, queued and "Продление аренды принято в очередь. Подожди, обновляю срок аренды." or tostring(queueResult))
      return true
    end
    if sub == "return" then
      if current == nil then
        current = latestReturnableRental(info)
      end
      if current == nil then
        targetMessageResolved(info, "У тебя нет активной аренды.")
      else
        local queued, queueResult = enqueueMutation("vehicle-rental-return", info, function()
          local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey)
          local active = latestActiveRental(live or info)
          if active == nil then active = latestReturnableRental(live or info) end
          if active == nil then
            targetMessage(info.steam, info.name, "Возврат не выполнен: активная аренда не найдена.", "vehicle-rental", info.runtimeKey)
            return
          end
          local allowRuntimeReturnDestroy = configBool("vehicle-rental", { "EnableRuntimeVehicleReturnDestroy", "enableRuntimeVehicleReturnDestroy", "AllowRuntimeVehicleReturnDestroy", "allowRuntimeVehicleReturnDestroy" }, true)
          local destroyRef = vehicleDestroyRefFromRental(active)
          if destroyRef == "" and allowRuntimeReturnDestroy then
            destroyRef = resolveRentalDestroyRef(active, live or info)
            if destroyRef ~= "" then
              appendActionEvent("vehicle_rental_return_resolved_ref", true, live or info, "runtime vehicle found near player for return",
                '{"destroyRef":' .. js(destroyRef) .. ',"vehicleId":' .. js(extractString(active, "vehicleId") or "") .. '}')
            end
          end
          local destroyAttempted = destroyRef ~= ""
          local destroyOk = false
          local destroyMessage = ""
          if destroyAttempted and allowRuntimeReturnDestroy then
            destroyOk, destroyMessage = destroyVehicleRef(destroyRef, live or info, "rent-return")
          else
            destroyAttempted = false
            destroyMessage = allowRuntimeReturnDestroy and "missing vehicle entity id" or "runtime vehicle destroy skipped for stability"
            appendActionEvent("vehicle_destroy", false, live or info, destroyMessage,
              '{"reason":"rent-return","displayName":' .. js(extractString(active, "displayName") or "") .. ',"runtimeDestroyEnabled":' .. (allowRuntimeReturnDestroy and "true" or "false") .. '}')
          end
          if not destroyOk then
            if not allowRuntimeReturnDestroy then
              local usageChargeQueued, usageChargeMessage, usageChargeAmount, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, usageTaxKey =
                finalizeRentalUsageCharge(live or info, active, "rent-return-untracked", os.time())
              appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
                '{"utc":' .. js(nowUtc()) ..
                ',"steamId":' .. js(info.steam) ..
                ',"name":' .. js(info.name) ..
                ',"status":"returned","returned":"true","returnedAt":' .. tostring(os.time()) ..
                ',"displayName":' .. js(extractString(active, "displayName") or "") ..
                ',"vehicleId":' .. js(extractString(active, "vehicleId") or "") ..
                ',"destroyRef":' .. js(destroyRef) ..
                ',"destroyAttempted":false' ..
                ',"destroyOk":false' ..
                ',"destroySkippedForStability":true' ..
                ',"destroyMessage":' .. js(destroyMessage) ..
                ',"usageChargeQueued":' .. (usageChargeQueued and "true" or "false") ..
                ',"usageChargeAmount":' .. tostring(usageChargeAmount) ..
                ',"chargeableMinutes":' .. tostring(chargeableMinutes) ..
                ',"minutesAfter10":' .. tostring(minutesAfter10) ..
                ',"pricePerMinute":' .. tostring(pricePerMinute) ..
                ',"usageTotalCost":' .. tostring(totalCostSoFar) ..
                ',"usageAlreadyPaid":' .. tostring(alreadyPaid) ..
                ',"usageTaxKey":' .. js(usageTaxKey or "") ..
                ',"usageChargeMessage":' .. js(usageChargeMessage) .. '}',
                1024 * 1024)
              if usageChargeAmount > 0 then
                targetMessage(info.steam, info.name, "Аренда возвращена. Запись закрыта безопасно, без тяжёлого поиска транспорта. Доплата: " .. tostring(usageChargeAmount) .. ".", "vehicle-rental", info.runtimeKey)
              else
                targetMessage(info.steam, info.name, "Аренда возвращена. Запись закрыта безопасно, без тяжёлого поиска транспорта.", "vehicle-rental", info.runtimeKey)
              end
              return
            end
            local missingVehicle = rentalMissingVehicleLikely(destroyAttempted, destroyOk, destroyMessage)
            if missingVehicle and rentalMissingVehiclePenaltyAmount(active) > 0 then
              local usageChargeQueued, usageChargeMessage, usageChargeAmount, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, usageTaxKey =
                finalizeRentalUsageCharge(live or info, active, "rent-return-missing-vehicle", os.time())
              local penaltyQueued, penaltyMessage, penaltyAmount, penaltyTaxKey =
                chargeRentalMissingVehiclePenalty(live or info, active, "rent-return-missing-vehicle")
              appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
                '{"utc":' .. js(nowUtc()) ..
                ',"steamId":' .. js(info.steam) ..
                ',"name":' .. js(info.name) ..
                ',"alias":' .. js(extractString(active, "alias") or "") ..
                ',"status":"sold_or_missing","returnAttemptedAt":' .. tostring(os.time()) ..
                ',"displayName":' .. js(extractString(active, "displayName") or "") ..
                ',"vehicleId":' .. js(extractString(active, "vehicleId") or "") ..
                ',"minutes":' .. tostring(extractNumber(active, "minutes") or 0) ..
                ',"startedAt":' .. tostring(extractNumber(active, "startedAt") or os.time()) ..
                ',"expiresAt":' .. tostring(extractNumber(active, "expiresAt") or 0) ..
                ',"initialCharge":' .. tostring(extractNumber(active, "initialCharge") or 0) ..
                ',"pricePer10Minutes":' .. tostring(extractNumber(active, "pricePer10Minutes") or 0) ..
                ',"totalCharge":' .. tostring(extractNumber(active, "totalCharge") or extractNumber(active, "initialCharge") or 0) ..
                ',"destroyRef":' .. js(destroyRef) ..
                ',"destroyAttempted":' .. (destroyAttempted and "true" or "false") ..
                ',"destroyOk":false' ..
                ',"destroyMessage":' .. js(destroyMessage) ..
                ',"missingVehicle":true' ..
                ',"usageChargeQueued":' .. (usageChargeQueued and "true" or "false") ..
                ',"usageChargeAmount":' .. tostring(usageChargeAmount) ..
                ',"chargeableMinutes":' .. tostring(chargeableMinutes) ..
                ',"minutesAfter10":' .. tostring(minutesAfter10) ..
                ',"pricePerMinute":' .. tostring(pricePerMinute) ..
                ',"usageTotalCost":' .. tostring(totalCostSoFar) ..
                ',"usageAlreadyPaid":' .. tostring(alreadyPaid) ..
                ',"usageTaxKey":' .. js(usageTaxKey or "") ..
                ',"usageChargeMessage":' .. js(usageChargeMessage) ..
                ',"missingVehiclePenaltyQueued":' .. (penaltyQueued and "true" or "false") ..
                ',"missingVehiclePenaltyAmount":' .. tostring(penaltyAmount) ..
                ',"missingVehiclePenaltyTaxKey":' .. js(penaltyTaxKey or "") ..
                ',"missingVehiclePenaltyMessage":' .. js(penaltyMessage or "") .. '}',
                1024 * 1024)
              targetMessage(info.steam, info.name, "Арендованный транспорт не найден. Если он продан или потерян, аренда закрыта, штраф: " .. tostring(penaltyAmount) .. ".", "vehicle-rental", info.runtimeKey)
            else
              appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
                '{"utc":' .. js(nowUtc()) ..
                ',"steamId":' .. js(info.steam) ..
                ',"name":' .. js(info.name) ..
                ',"alias":' .. js(extractString(active, "alias") or "") ..
                ',"status":"active","returnAttemptedAt":' .. tostring(os.time()) ..
                ',"displayName":' .. js(extractString(active, "displayName") or "") ..
                ',"vehicleId":' .. js(extractString(active, "vehicleId") or "") ..
                ',"minutes":' .. tostring(extractNumber(active, "minutes") or 0) ..
                ',"startedAt":' .. tostring(extractNumber(active, "startedAt") or os.time()) ..
                ',"expiresAt":' .. tostring(extractNumber(active, "expiresAt") or 0) ..
                ',"initialCharge":' .. tostring(extractNumber(active, "initialCharge") or 0) ..
                ',"pricePer10Minutes":' .. tostring(extractNumber(active, "pricePer10Minutes") or 0) ..
                ',"totalCharge":' .. tostring(extractNumber(active, "totalCharge") or extractNumber(active, "initialCharge") or 0) ..
                ',"destroyRef":' .. js(destroyRef) ..
                ',"destroyAttempted":' .. (destroyAttempted and "true" or "false") ..
                ',"destroyOk":false' ..
                ',"destroyMessage":' .. js(destroyMessage) .. '}',
                1024 * 1024)
              targetMessage(info.steam, info.name, "Возврат транспорта не подтверждён, аренда остаётся активной. Причина: " .. tostring(destroyMessage), "vehicle-rental", info.runtimeKey)
            end
            return
          end
          local usageChargeQueued, usageChargeMessage, usageChargeAmount, chargeableMinutes, minutesAfter10, totalCostSoFar, alreadyPaid, pricePerMinute, usageTaxKey =
            finalizeRentalUsageCharge(live or info, active, "rent-return", os.time())
          appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
            '{"utc":' .. js(nowUtc()) ..
            ',"steamId":' .. js(info.steam) ..
            ',"name":' .. js(info.name) ..
            ',"status":"returned","returned":"true","returnedAt":' .. tostring(os.time()) ..
            ',"displayName":' .. js(extractString(active, "displayName") or "") ..
            ',"vehicleId":' .. js(extractString(active, "vehicleId") or "") ..
            ',"destroyRef":' .. js(destroyRef) ..
            ',"destroyAttempted":true' ..
            ',"destroyOk":true' ..
            ',"destroyMessage":' .. js(destroyMessage) ..
            ',"usageChargeQueued":' .. (usageChargeQueued and "true" or "false") ..
            ',"usageChargeAmount":' .. tostring(usageChargeAmount) ..
            ',"chargeableMinutes":' .. tostring(chargeableMinutes) ..
            ',"minutesAfter10":' .. tostring(minutesAfter10) ..
            ',"pricePerMinute":' .. tostring(pricePerMinute) ..
            ',"usageTotalCost":' .. tostring(totalCostSoFar) ..
            ',"usageAlreadyPaid":' .. tostring(alreadyPaid) ..
            ',"usageTaxKey":' .. js(usageTaxKey or "") ..
            ',"usageChargeMessage":' .. js(usageChargeMessage) .. '}',
            1024 * 1024)
          if usageChargeAmount > 0 then
            if usageChargeQueued then
              targetMessage(info.steam, info.name,
                "Аренда возвращена. Транспорт удалён. Использовано " .. tostring(chargeableMinutes) .. " мин., доплата " .. tostring(usageChargeAmount) .. " поставлена в очередь.",
                "vehicle-rental", info.runtimeKey)
            else
              targetMessage(info.steam, info.name,
                "Аренда возвращена. Транспорт удалён. Использовано " .. tostring(chargeableMinutes) .. " мин., доплата " .. tostring(usageChargeAmount) .. " перенесена в ожидание.",
                "vehicle-rental", info.runtimeKey)
            end
          else
            targetMessage(info.steam, info.name, "Аренда возвращена. Транспорт удалён, запись сохранена в панели.", "vehicle-rental", info.runtimeKey)
          end
        end)
        targetMessageResolved(info, queued and "Возврат аренды принят в очередь. Подожди, удаляю транспорт и обновляю запись." or tostring(queueResult))
      end
      return true
    end
    if current ~= nil then
      targetMessageResolved(info, "У тебя уже есть активная аренда. Используй /rent time, /rent extend <minutes> или /rent return.")
      return true
    end
    local vehicles = configuredRentalVehicles()
    local option = vehicles[sub]
    if option == nil and sub == "wolfswaggen" then option = vehicles["wolfswagen"] end
    if option == nil and sub == "wolfswagen" then option = vehicles["wolfswaggen"] end
    if option == nil then
      targetMessageResolved(info, "Неизвестный тип транспорта. Используй /rent list.")
      return true
    end
    local minMinutes = math.max(1, tonumber(option.minMinutes or 10) or 10)
    local maxMinutes = math.max(minMinutes, tonumber(option.maxMinutes or 60) or 60)
    local defaultMinutes = math.max(minMinutes, tonumber(option.defaultMinutes or minMinutes) or minMinutes)
    if defaultMinutes > maxMinutes then defaultMinutes = maxMinutes end
    local minutes = math.floor(tonumber(words[3]) or defaultMinutes)
    if minutes < minMinutes then minutes = minMinutes end
    if minutes > maxMinutes then minutes = maxMinutes end
    local waitSeconds = vehicleRentalSpawnCooldownRemaining(info)
    if waitSeconds > 0 then
      targetMessageResolved(info, "Аренда транспорта сейчас в безопасной паузе. Подожди " .. tostring(waitSeconds) .. " сек., чтобы сервер не лагал.")
      return true
    end
    local rentalCharge = math.max(0, option.initial)
    local queued, queueResult = enqueueMutation("vehicle-rental-create", info, function()
      local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey)
      if live == nil or not playerInfoHasLiveRuntime(live) or not looksLikeSteamId(cleanText(live.steam or "")) then
        targetMessage(info.steam, info.name, "Аренда не выполнена: игрок ещё не готов в live runtime. Повтори команду через несколько секунд.", "vehicle-rental", info.runtimeKey)
        return
      end
      if latestActiveRental(live) ~= nil then
        targetMessage(info.steam, info.name, "Аренда не создана: у тебя уже есть активная аренда.", "vehicle-rental", info.runtimeKey)
        return
      end
      local spawnX, spawnY, spawnZ = vectorOf(live.pawn)
      local sent, result, destroyRef, beforeVehicles = spawnVehicleForInfo(option.asset, live)
      if sent then
        local startedAt = os.time()
        local expiresAt = startedAt + minutes * 60
        local tracked = tostring(destroyRef or "") ~= ""
        if tracked then
          local charged, chargeMessage = true, ""
          if rentalCharge > 0 then
            charged, chargeMessage = changeMoney(live.steam, live.name, -rentalCharge, "Normal", live.runtimeKey)
          end
          if not charged then
            destroyVehicleRef(destroyRef, live, "rental-charge-failed")
            appendActionEvent("vehicle_rental_charge_failed", false, live, tostring(chargeMessage),
              '{"alias":' .. js(sub) .. ',"vehicleId":' .. js(option.asset) .. ',"charge":' .. tostring(rentalCharge) .. ',"destroyRef":' .. js(destroyRef) .. ',"stage":"after-spawn-tracked"}')
            appendJsonArray(STATE_DIR .. "\\vehicle-rentals.json",
              '{"utc":' .. js(nowUtc()) ..
              ',"steamId":' .. js(live.steam or "") ..
              ',"name":' .. js(live.name or "") ..
              ',"alias":' .. js(sub) ..
              ',"status":"failed"' ..
              ',"displayName":' .. js(option.display) ..
              ',"vehicleId":' .. js(option.asset) ..
              ',"minutes":' .. tostring(minutes) ..
              ',"startedAt":' .. tostring(startedAt) ..
              ',"expiresAt":' .. tostring(expiresAt) ..
              ',"totalCharge":' .. tostring(rentalCharge) ..
              ',"destroyRef":' .. js(destroyRef) ..
              ',"reason":"charge not confirmed after tracked spawn"}',
              1024 * 1024)
            targetMessage(info.steam, info.name, "Транспорт появился, но оплату не удалось подтвердить. Аренда отменена, транспорт удалён.", "vehicle-rental", info.runtimeKey)
            return
          end
          completeRentalCreation(live, sub, option.display, option.asset, minutes, option.initial, option.price, rentalCharge, destroyRef, startedAt, expiresAt, false)
        else
          appendActiveRentalRecord(live, sub, option.display, option.asset, minutes, startedAt, expiresAt, option.initial, option.price, 0, "", ',"pendingVerify":true,"chargePending":true')
          appendActionEvent("vehicle_rental_spawn_pending_verify", true, live, "spawn command accepted; waiting for runtime vehicle confirmation",
            '{"alias":' .. js(sub) .. ',"vehicleId":' .. js(option.asset) .. ',"minutes":' .. tostring(minutes) .. ',"chargePending":' .. tostring(rentalCharge) .. '}')
          targetMessage(info.steam, info.name, "Команда аренды отправлена. Проверяю, что транспорт реально появился рядом с тобой.", "vehicle-rental", info.runtimeKey)
          scheduleRentalCreationVerification(live, sub, option, minutes, rentalCharge, beforeVehicles, spawnX, spawnY, spawnZ)
        end
      else
        appendActionEvent("vehicle_rental_spawn_failed", false, live, tostring(result),
          '{"alias":' .. js(sub) .. ',"vehicleId":' .. js(option.asset) .. ',"charged":false,"chargeRefunded":0}')
        targetMessage(info.steam, info.name, "Транспорт не выдан: " .. tostring(result) .. ". Деньги не списывал.", "vehicle-rental", info.runtimeKey)
      end
    end)
    if queued then reserveVehicleRentalSpawnCooldown(info) end
    targetMessageResolved(info, queued and "Заявка на аренду принята в очередь. Подожди, проверяю транспорт рядом с тобой." or tostring(queueResult))
    return true
  end

  if commandMatches(command, "invdel") then
    local entityId = words[2] or ""
    local itemId = words[3] or ""
    if entityId == "" then
      targetMessageResolved(info, "Использование: /invdel <EntityID>. Лучше удалять предмет кнопкой в панели.")
      return true
    end
    local queued, queueResult = deleteInventoryItem(info.steam, info.name, info.runtimeKey, entityId, itemId, "", "")
    targetMessageResolved(info, queued and "Удаление предмета принято в очередь." or tostring(queueResult))
    return true
  end

  if commandMatches(command, "welcomepack") then
    if not moduleEnabled("welcome-pack", true) then
      targetMessageResolved(info, "Стартовый набор сейчас отключён.")
      return true
    end
    local requiredPermission = configString("welcome-pack", { "RequiredPermission", "requiredPermission" }, "")
    if not hasPermission(info, requiredPermission) then
      targetMessageResolved(info, permissionDeniedText(requiredPermission))
      return true
    end
    local cooldownSeconds = math.max(0, configNumber("welcome-pack", { "CooldownHours", "cooldownHours" }, 30000)) * 3600
    local remaining = cooldownRemaining("welcome-pack-timers.json", info, cooldownSeconds)
    if remaining > 0 then
      targetMessageResolved(info, "Стартовый набор уже получен. Осталось " .. tostring(remaining) .. " сек.")
      return true
    end
    local claimKey = playerStateKey(info)
    if claimKey ~= "" and welcomeClaimsInFlight[claimKey] then
      targetMessageResolved(info, "Стартовый набор уже выдаётся. Дождись окончания текущей выдачи.")
      return true
    end
    if claimKey ~= "" then welcomeClaimsInFlight[claimKey] = true end
    targetMessageResolved(info, "Стартовый набор принят в очередь, выдаю предметы.")
    local steamId = info.steam
    local name = info.name
    local itemsSpec = welcomeItemsSpec()
    deferGame(100, function()
      local queued, queueResult = enqueueMutation("welcome-pack", info, function()
        local live = resolvePlayerInfo(steamId, name, info, info.runtimeKey) or info
        local okRun, allOk, message = pcall(function()
          return deliverItemsBatch(steamId, name, itemsSpec, live, live.runtimeKey or info.runtimeKey)
        end)
        if not okRun then
          local err = tostring(allOk)
          allOk = false
          message = err
        end
        if allOk then
          rememberCooldown("welcome-pack-timers.json", info, cooldownSeconds)
        end
        appendJsonArray(STATE_DIR .. "\\welcome-pack-claims.json", '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(steamId or "") .. ',"name":' .. js(name or "") .. ',"ok":' .. (allOk and "true" or "false") .. ',"message":' .. js(tostring(message or "")) .. '}', 1024 * 1024)
        local successMessage = extractStringAny(configText("welcome-pack"), { "SuccessMessage", "successMessage" }) or "Стартовый набор выдан."
        targetMessage(steamId, name, allOk and successMessage or ("Стартовый набор не выдан полностью: " .. tostring(message)), "command-reply", info.runtimeKey)
        if claimKey ~= "" then welcomeClaimsInFlight[claimKey] = nil end
      end)
      if not queued then
        if claimKey ~= "" then welcomeClaimsInFlight[claimKey] = nil end
        targetMessage(steamId, name, tostring(queueResult), "command-reply", info.runtimeKey)
      end
    end)
    return true
  end

  if commandMatches(command, "dailypack") then
    if not moduleEnabled("daily-pack", true) then
      targetMessageResolved(info, "Ежедневный пак сейчас отключён.")
      return true
    end
    local requiredPermission = configString("daily-pack", { "RequiredPermission", "requiredPermission" }, "")
    if not hasPermission(info, requiredPermission) then
      targetMessageResolved(info, permissionDeniedText(requiredPermission))
      return true
    end
    local cooldownSeconds = math.max(0, configNumber("daily-pack", { "CooldownHours", "cooldownHours" }, 24)) * 3600
    local remaining = cooldownRemaining("daily-pack-timers.json", info, cooldownSeconds)
    if remaining > 0 then
      targetMessageResolved(info, "Ежедневный пак уже получен. Осталось " .. tostring(remaining) .. " сек.")
      return true
    end
    local claimKey = playerStateKey(info)
    if claimKey ~= "" and dailyPackClaimsInFlight[claimKey] then
      targetMessageResolved(info, "Ежедневный пак уже выдаётся. Дождись окончания текущей выдачи.")
      return true
    end
    if claimKey ~= "" then dailyPackClaimsInFlight[claimKey] = true end
    targetMessageResolved(info, "Ежедневный пак принят в очередь, выдаю предметы.")
    local steamId = info.steam
    local name = info.name
    local itemsSpec = dailyPackItemsSpec()
    deferGame(100, function()
      local queued, queueResult = enqueueMutation("daily-pack", info, function()
        local live = resolvePlayerInfo(steamId, name, info, info.runtimeKey) or info
        local okRun, allOk, message = pcall(function()
          return deliverItemsBatch(steamId, name, itemsSpec, live, live.runtimeKey or info.runtimeKey)
        end)
        if not okRun then
          local err = tostring(allOk)
          allOk = false
          message = err
        end
        if allOk then
          rememberCooldown("daily-pack-timers.json", info, cooldownSeconds)
        end
        appendJsonArray(STATE_DIR .. "\\daily-pack-claims.json", '{"utc":' .. js(nowUtc()) .. ',"steamId":' .. js(steamId or "") .. ',"name":' .. js(name or "") .. ',"ok":' .. (allOk and "true" or "false") .. ',"message":' .. js(tostring(message or "")) .. '}', 1024 * 1024)
        local successMessage = extractStringAny(configText("daily-pack"), { "SuccessMessage", "successMessage" }) or "Ежедневный пак выдан."
        targetMessage(steamId, name, allOk and successMessage or ("Ежедневный пак не выдан полностью: " .. tostring(message)), "command-reply", info.runtimeKey)
        if claimKey ~= "" then dailyPackClaimsInFlight[claimKey] = nil end
      end)
      if not queued then
        if claimKey ~= "" then dailyPackClaimsInFlight[claimKey] = nil end
        targetMessage(steamId, name, tostring(queueResult), "command-reply", info.runtimeKey)
      end
    end)
    return true
  end

  if commandMatches(command, "discordtest") then
    if not moduleEnabled("discord-log", false) then
      targetMessageResolved(info, "Журнал Discord сейчас отключён.")
      return true
    end
    local route = (words[2] or "system"):lower()
    local note = table.concat(words, " ", 3)
    if note == "" then note = "Проверка Discord от " .. tostring(info.name ~= "" and info.name or info.steam) end
    appendJsonArray(STATE_DIR .. "\\discord-log.json", '{"utc":' .. js(nowUtc()) .. ',"route":' .. js(route) .. ',"message":' .. js(note) .. ',"player":' .. js(info.name) .. ',"steamId":' .. js(info.steam) .. ',"ok":true}', 1024 * 1024)
    targetMessageResolved(info, "Проверка Discord записана в очередь панели для канала '" .. route .. "'. Для реальной отправки настрой вебхук и нажми проверку в панели.")
    return true
  end

  if commandMatches(command, "wargm") then
    if not moduleEnabled("wargm-shop", false) then
      targetMessageResolved(info, "Магазин Wargm сейчас отключён.")
      return true
    end
    WARGM_COMMAND_NEXT_AT = WARGM_COMMAND_NEXT_AT or {}
    local wargmKey = playerStateKey(info)
    local now = os.time()
    local nextAt = tonumber(WARGM_COMMAND_NEXT_AT[wargmKey] or 0) or 0
    if wargmKey ~= "" and nextAt > now then
      targetMessageResolved(info, "Wargm: выдача уже в очереди. Повтори через " .. tostring(nextAt - now) .. " сек.")
      return true
    end
    if wargmKey ~= "" then WARGM_COMMAND_NEXT_AT[wargmKey] = now + 60 end
    local syncRequested = requestWargmSync(info)
    targetMessageResolved(info, syncRequested and "Wargm: проверяю покупки. Если покупка есть, выдача начнётся через несколько секунд." or "Wargm: не удалось поставить проверку Wargm API, пробую локальную очередь.")
    deferGame(3500, function()
    local queued, queueResult = enqueueMutation("wargm-claim", info, function()
      local live = resolvePlayerInfo(info.steam, info.name, info, info.runtimeKey) or info
      local pending = stateObjects("wargm-pending.json")
      local deliveredKeys = deliveredWargmKeys()
      local delivered = 0
      local skipped = 0
      for index, object in ipairs(pending) do
        local steam = extractString(object, "steamId") or ""
        local mode = (extractString(object, "mode") or "item"):lower():gsub("[%s_%-%.\"]+", "")
        local opKey = wargmOperationKey(object, index)
        local operationIdForState = wargmOperationIdValue(object)
        local alreadyDelivered = deliveredKeys[opKey]
        if steam ~= "" and steam == live.steam and not alreadyDelivered then
          local retryRemaining = wargmRetrySecondsRemaining(opKey)
          if retryRemaining > 0 then
            skipped = skipped + 1
            appendJsonArray(STATE_DIR .. "\\wargm-shop.json", '{"utc":' .. js(nowUtc()) .. ',"key":' .. js(opKey) .. ',"steamId":' .. js(live.steam or "") .. ',"name":' .. js(live.name or "") .. ',"status":"retry-wait","seconds":' .. tostring(retryRemaining) .. '}', 1024 * 1024)
          else
          local okDelivery = false
          local deliveryMessage = ""
          appendJsonArray(STATE_DIR .. "\\wargm-attempts.json", '{"utc":' .. js(nowUtc()) .. ',"key":' .. js(opKey) .. ',"steamId":' .. js(live.steam or "") .. ',"name":' .. js(live.name or "") .. ',"mode":' .. js(mode) .. ',"status":"delivering"}', 1024 * 1024)
          if mode == "money" or mode == "currency" or mode == "balance" or mode == "gold" then
            local amount = extractNumber(object, "amount") or extractNumber(object, "Amount") or extractNumber(object, "money") or extractNumber(object, "Money") or extractNumber(object, "gold") or extractNumber(object, "Gold") or 0
            if amount ~= 0 then
              local okMoney, moneyMessage = changeMoney(live.steam, live.name, amount, mode == "gold" and "Gold" or "Normal", live.runtimeKey)
              deliveryMessage = tostring(moneyMessage or "")
              if okMoney then okDelivery = true end
            end
          elseif mode == "fame" or mode == "famepoint" or mode == "famepoints" or mode == "changefame" or mode == "changefamepoints" then
            local amount = extractNumber(object, "amount") or extractNumber(object, "Amount") or extractNumber(object, "fame") or extractNumber(object, "Fame") or extractNumber(object, "famePoints") or extractNumber(object, "FamePoints") or 0
            if amount ~= 0 then
              local okFame, fameMessage = changeFamePoints(live.steam, live.name, amount, live.runtimeKey)
              deliveryMessage = tostring(fameMessage or "")
              if okFame then okDelivery = true end
            end
          elseif mode == "setfame" or mode == "setfamepoints" then
            local amount = extractNumber(object, "amount") or extractNumber(object, "Amount") or extractNumber(object, "fame") or extractNumber(object, "Fame") or extractNumber(object, "famePoints") or extractNumber(object, "FamePoints") or 0
            if amount ~= 0 then
              local okFame, fameMessage = setFame(live.steam, live.name, amount, live.runtimeKey)
              deliveryMessage = tostring(fameMessage or "")
              if okFame then okDelivery = true end
            end
          elseif mode == "vehicle" or mode == "spawnvehicle" then
            local vehicleId = extractString(object, "vehicleId") or ""
            if vehicleId ~= "" then
              local waitSeconds = vehicleRentalSpawnCooldownRemaining(live)
              if waitSeconds > 0 then
                deliveryMessage = "Спавн транспорта сейчас в безопасной паузе. Повтор будет через " .. tostring(waitSeconds) .. " сек."
              else
                local okVehicle, vehicleMessage = spawnVehicleForInfo(vehicleId, live)
                deliveryMessage = tostring(vehicleMessage or "")
                if okVehicle then
                  okDelivery = true
                  reserveVehicleRentalSpawnCooldown(live)
                end
              end
            end
          elseif mode == "allskills" or mode == "allskill" or mode == "skills" or mode == "skillpack" or mode == "skillspack" then
            local level = extractNumber(object, "level") or extractNumber(object, "skillLevel") or extractNumber(object, "SkillLevel") or 4
            local experience = extractNumber(object, "experience") or extractNumber(object, "skillExperience") or extractNumber(object, "SkillExperience") or 0
            local okSkills, skillsMessage = setAllSkills(live.steam, live.name, level, experience, live.runtimeKey)
            deliveryMessage = tostring(skillsMessage or "")
            if okSkills then okDelivery = true end
          elseif mode == "skill" or mode == "setskill" then
            local skill = extractString(object, "skill") or extractString(object, "skillName") or ""
            local level = extractNumber(object, "level") or extractNumber(object, "skillLevel") or 0
            local experience = extractNumber(object, "experience") or extractNumber(object, "skillExperience") or 0
            if extractBoolAny(object, { "allSkills", "AllSkills", "giveAllSkills", "GiveAllSkills" }, false) == true or allSkillsKeyword(skill) then
              if level <= 0 then level = 4 end
              local okSkill, skillMessage = setAllSkills(live.steam, live.name, level, experience, live.runtimeKey)
              deliveryMessage = tostring(skillMessage or "")
              if okSkill then okDelivery = true end
            elseif skill ~= "" then
              local okSkill, skillMessage = setSkill(live.steam, live.name, skill, level, experience, live.runtimeKey)
              deliveryMessage = tostring(skillMessage or "")
              if okSkill then okDelivery = true end
            end
          elseif mode == "attributes" or mode == "attribute" or mode == "stats" then
            local okAttributes, attributesMessage = setAttributes(live.steam, live.name,
              extractNumber(object, "strength") or extractNumber(object, "Strength") or 0,
              extractNumber(object, "constitution") or extractNumber(object, "Constitution") or 0,
              extractNumber(object, "dexterity") or extractNumber(object, "Dexterity") or 0,
              extractNumber(object, "intelligence") or extractNumber(object, "Intelligence") or 0,
              false,
              live.runtimeKey)
            deliveryMessage = tostring(attributesMessage or "")
            if okAttributes then okDelivery = true end
          elseif mode == "command" or mode == "admincommand" or mode == "playercommand" or mode == "servercommand" then
            local commandTemplate = extractString(object, "command") or extractString(object, "commandTemplate") or ""
            commandTemplate = commandTemplate:gsub("{steamId}", live.steam or ""):gsub("{name}", live.name or "")
            if commandTemplate ~= "" then
              local okCommand, commandMessage = adminExec(commandTemplate, live)
              deliveryMessage = tostring(commandMessage or "")
              if okCommand then okDelivery = true end
            end
          else
            local itemsSpec = extractString(object, "itemsSpec") or extractString(object, "ItemsSpec") or itemsSpecFromConfig(object)
            local itemId = extractString(object, "itemId") or extractString(object, "ItemId") or ""
            local qty = extractNumber(object, "quantity") or extractNumber(object, "Quantity") or 1
            if itemsSpec ~= "" or itemId ~= "" then
              local spec = itemsSpec ~= "" and itemsSpec or (itemId .. "|" .. tostring(qty))
              local okItems, itemsMessage = deliverItemsBatch(live.steam, live.name, spec, live, live.runtimeKey)
              deliveryMessage = tostring(itemsMessage or "")
              if okItems then okDelivery = true end
            end
          end
          if okDelivery then
            delivered = delivered + 1
            deliveredKeys[opKey] = true
            local operationId = operationIdForState
            local offerId = extractString(object, "offerId") or extractString(object, "OfferId") or ""
            local title = extractString(object, "title") or extractString(object, "Title") or ""
            local deliveryItemId = extractString(object, "itemId") or extractString(object, "ItemId") or extractString(object, "item") or ""
            local deliveryItemsSpec = extractString(object, "itemsSpec") or extractString(object, "ItemsSpec") or itemsSpecFromConfig(object)
            local deliveryQuantity = extractNumber(object, "quantity") or extractNumber(object, "Quantity") or 1
            appendJsonArray(STATE_DIR .. "\\wargm-delivered.json", '{"utc":' .. js(nowUtc()) .. ',"key":' .. js(opKey) .. ',"operationId":' .. js(operationId) .. ',"offerId":' .. js(offerId) .. ',"title":' .. js(title) .. ',"steamId":' .. js(live.steam) .. ',"name":' .. js(live.name) .. ',"mode":' .. js(mode) .. ',"itemId":' .. js(deliveryItemId) .. ',"itemsSpec":' .. js(deliveryItemsSpec) .. ',"quantity":' .. tostring(deliveryQuantity) .. ',"status":"delivered"}', 1024 * 1024)
            appendJsonArray(STATE_DIR .. "\\wargm-shop.json", '{"utc":' .. js(nowUtc()) .. ',"key":' .. js(opKey) .. ',"operationId":' .. js(operationId) .. ',"offerId":' .. js(offerId) .. ',"title":' .. js(title) .. ',"steamId":' .. js(live.steam) .. ',"name":' .. js(live.name) .. ',"mode":' .. js(mode) .. ',"itemId":' .. js(deliveryItemId) .. ',"itemsSpec":' .. js(deliveryItemsSpec) .. ',"quantity":' .. tostring(deliveryQuantity) .. ',"status":"delivered"}', 1024 * 1024)
            requestWargmConfirm(live, operationId)
          else
            appendJsonArray(STATE_DIR .. "\\wargm-attempts.json", '{"utc":' .. js(nowUtc()) .. ',"key":' .. js(opKey) .. ',"steamId":' .. js(live.steam or "") .. ',"name":' .. js(live.name or "") .. ',"mode":' .. js(mode) .. ',"status":"retry","retryAfter":' .. tostring(os.time() + 60) .. ',"message":' .. js(deliveryMessage or "delivery failed") .. '}', 1024 * 1024)
            appendJsonArray(STATE_DIR .. "\\wargm-shop.json", '{"utc":' .. js(nowUtc()) .. ',"key":' .. js(opKey) .. ',"steamId":' .. js(live.steam or "") .. ',"name":' .. js(live.name or "") .. ',"mode":' .. js(mode) .. ',"status":"retry","message":' .. js(deliveryMessage or "delivery failed") .. '}', 1024 * 1024)
          end
          end
        elseif steam ~= "" and steam == live.steam and alreadyDelivered then
          skipped = skipped + 1
        end
      end
      if delivered > 0 or skipped > 0 then pruneWargmPending(deliveredKeys) end
      local emptyMessage = skipped > 0 and ("Wargm: новых pending-покупок нет. Уже выданных пропущено: " .. tostring(skipped) .. ".") or "Wargm: новых pending-покупок для твоего SteamID нет. Ручная выдача доступна в панели."
      targetMessage(info.steam, info.name, delivered > 0 and ("Wargm: выдано операций: " .. tostring(delivered) .. ". Уже выданных пропущено: " .. tostring(skipped) .. ".") or emptyMessage, "wargm-shop", info.runtimeKey)
    end)
    if not queued then
      if wargmKey ~= "" then WARGM_COMMAND_NEXT_AT[wargmKey] = os.time() + 10 end
      targetMessageResolved(info, tostring(queueResult))
    end
    end)
    return true
  end

  if commandMatches(command, "streak") or commandMatches(command, "bounty") or commandMatches(command, "huntertop") then
    if not moduleEnabled("bounty-hunt", true) then
      targetMessageResolved(info, "Охота за наградой сейчас отключена.")
      return true
    end
    sendBountyStats(info, command)
    return true
  end

  return false
end

function playerCommandShouldRunImmediately(message)
  local command = (splitWords(message)[1] or ""):lower()
  local key = commandKey(command)
  return key == "help" or key == "hello" or key == "homes" or key == "delhome" or
    key == "sethome" or key == "pm" or key == "reply" or key == "pmhistory" or
    key == "streak" or key == "bounty" or key == "huntertop" or
    key == "welcomepack" or key == "dailypack" or key == "wargm"
end

function playerCommandRequiresLiveRefresh(commandName)
  local key = commandKey(tostring(commandName or ""):lower())
  return key == "home" or key == "sethome" or key == "scan" or key == "travel"
end

PLAYER_COMMAND_QUEUE = PLAYER_COMMAND_QUEUE or {}
PLAYER_COMMAND_QUEUE_BUSY = PLAYER_COMMAND_QUEUE_BUSY or false
PLAYER_COMMAND_QUEUE_CURRENT = PLAYER_COMMAND_QUEUE_CURRENT or nil
PLAYER_COMMAND_QUEUE_SEQ = PLAYER_COMMAND_QUEUE_SEQ or 0
PLAYER_COMMAND_QUEUE_MAX = PLAYER_COMMAND_QUEUE_MAX or 160
PLAYER_COMMAND_QUEUE_MAX_PER_PLAYER = PLAYER_COMMAND_QUEUE_MAX_PER_PLAYER or 8
PLAYER_COMMAND_QUEUE_TIMEOUT_SECONDS = PLAYER_COMMAND_QUEUE_TIMEOUT_SECONDS or 25

function playerCommandQueueKey(info)
  if info == nil then return "" end
  if tostring(info.steam or "") ~= "" then return "steam:" .. tostring(info.steam) end
  if tostring(info.userProfileId or info.serverUserProfileId or "") ~= "" then return "profile:" .. tostring(info.userProfileId or info.serverUserProfileId) end
  if tostring(info.runtimeKey or "") ~= "" then return "runtime:" .. tostring(info.runtimeKey) end
  local name = tostring(info.name or "")
  if name ~= "" and name:lower() ~= "unknown" then return "name:" .. name:lower() end
  return ""
end

function playerCommandRequiresResolvedSteam(commandName)
  local key = commandKey(tostring(commandName or ""):lower())
  return key == "rent" or key == "starter" or key == "welcomepack" or key == "dailypack" or key == "wargm" or
    key == "travel" or key == "home" or key == "sethome" or key == "delhome" or
    key == "scan" or key == "invdel"
end

CHAT_COMMAND_PLAYER_REFRESH_AT = CHAT_COMMAND_PLAYER_REFRESH_AT or 0

function enrichCommandPlayerIdentity(info)
  if info == nil then return nil end
  local steam = cleanText(info.steam or info.steamId or "")
  if looksLikeSteamId(steam) then
    info.steam = steam
    info.steamId = steam
    return info
  end

  local okLog, fromLog = pcall(function()
    if enrichPlayerInfoFromServerLog ~= nil then return enrichPlayerInfoFromServerLog(info) end
    return info
  end)
  if okLog and fromLog ~= nil then info = fromLog end
  steam = cleanText(info.steam or info.steamId or "")
  if looksLikeSteamId(steam) then
    info.steam = steam
    info.steamId = steam
    return info
  end

  local maxAge = math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))
  local infos = cachedPlayerInfos(maxAge)
  if infos == nil or #(infos or {}) == 0 then
    pcall(refreshPlayerInfoCache)
    infos = PLAYER_INFO_CACHE or {}
  end

  local profile = cleanText(info.userProfileId or info.serverUserProfileId or info.profileId or "")
  local runtimeKey = cleanText(info.runtimeKey or info.rpcKey or info.pcKey or info.psKey or info.pawnKey or "")
  local name = cleanText(info.name or "")
  local lowerName = name:lower()

  for _, candidate in ipairs(infos or {}) do
    local candidateProfile = cleanText(candidate.userProfileId or candidate.serverUserProfileId or candidate.profileId or "")
    local profileMatches = profile ~= "" and profile ~= "0" and candidateProfile ~= "" and candidateProfile ~= "0" and profile == candidateProfile
    local runtimeMatches = runtimeKey ~= "" and runtimeKeyMatches(candidate, runtimeKey)
    local candidateName = cleanText(candidate.name or "")
    local nameMatches = lowerName ~= "" and lowerName ~= "unknown" and candidateName ~= "" and candidateName:lower() == lowerName

    if profileMatches or runtimeMatches or nameMatches then
      local okCandidateLog, candidateFromLog = pcall(function()
        if enrichPlayerInfoFromServerLog ~= nil then return enrichPlayerInfoFromServerLog(candidate) end
        return candidate
      end)
      if okCandidateLog and candidateFromLog ~= nil then candidate = candidateFromLog end

      local candidateSteam = cleanText(candidate.steam or candidate.steamId or "")
      if looksLikeSteamId(candidateSteam) then
        info = mergeRuntimeIntoIdentity(info, candidate)
        info.steam = candidateSteam
        info.steamId = candidateSteam
        if cleanText(info.name or "") == "" or cleanText(info.name or ""):lower() == "unknown" then
          info.name = candidateName
        end
        if cleanText(info.userProfileId or "") == "" then info.userProfileId = candidateProfile end
        if cleanText(info.serverUserProfileId or "") == "" then info.serverUserProfileId = candidateProfile end
        local source = tostring(info.source or "")
        if source:find("command-live-cache", 1, true) == nil then
          info.source = (source ~= "" and (source .. "+") or "") .. "command-live-cache"
        end
        return info
      end
    end
  end

  return info
end

function playerCommandHasResolvedSteam(info)
  info = enrichCommandPlayerIdentity(info)
  return info ~= nil and looksLikeSteamId(cleanText(info.steam or info.steamId or ""))
end

function playerCommandIdentityReady(info, commandName)
  if info == nil then return false end
  if playerCommandRequiresResolvedSteam(commandName) then return playerCommandHasResolvedSteam(info) end
  return playerInfoHasIdentity(info)
end

function refreshPlayerInfoCacheForCommand(commandName)
  local cooldown = math.max(1, configNumber("bridge-safety", { "CommandResolveRefreshCooldownSeconds", "commandResolveRefreshCooldownSeconds" }, 3))
  local now = os.clock()
  if (now - (CHAT_COMMAND_PLAYER_REFRESH_AT or 0)) < cooldown then return false end
  CHAT_COMMAND_PLAYER_REFRESH_AT = now
  local okRefresh, refreshErr = pcall(refreshPlayerInfoCache)
  if not okRefresh then
    appendLog("command player cache refresh failed command=" .. tostring(commandName or "") .. " err=" .. tostring(refreshErr))
    return false
  end
  local count = #(PLAYER_INFO_CACHE or {})
  local bypassedJoinSettle = false
  if count == 0 and configBool("bridge-safety", { "AllowCommandRuntimeScanDuringJoinSettle", "allowCommandRuntimeScanDuringJoinSettle" }, true) then
    local okBypass, bypassErr = pcall(function()
      count = replacePlayerInfoCache(listPlayerInfosUnchecked("command-runtime-scan") or {})
    end)
    if okBypass then
      bypassedJoinSettle = true
    else
      appendLog("command player cache bypass refresh failed command=" .. tostring(commandName or "") .. " err=" .. tostring(bypassErr))
    end
  end
  appendLog("command player cache refreshed command=" .. tostring(commandName or "") .. " players=" .. tostring(count) .. " bypassJoinSettle=" .. tostring(bypassedJoinSettle))
  return true
end

function targetMessagePlayerCommandFailure(info, commandName, message)
  if playerCommandRequiresResolvedSteam(commandName) and not playerCommandHasResolvedSteam(info) then
    appendLog("player command reply skipped unresolved steam command=" .. tostring(commandName or "") .. " targetKey=" .. tostring(playerReplyTargetKey(info)))
    return false
  end
  if not playerReplyTargetReliable(info) then
    appendLog("player command reply skipped unresolved target command=" .. tostring(commandName or ""))
    return false
  end
  targetMessageResolved(info, tostring(message or "Команда не поставлена в очередь."))
  return true
end

function playerCommandPendingFor(key)
  local count = 0
  for _, item in ipairs(PLAYER_COMMAND_QUEUE or {}) do
    if tostring(item.key or "") == key then count = count + 1 end
  end
  if PLAYER_COMMAND_QUEUE_CURRENT ~= nil and tostring(PLAYER_COMMAND_QUEUE_CURRENT.key or "") == key then count = count + 1 end
  return count
end

function playerCommandPendingForCommand(key, commandName)
  local count = 0
  for _, item in ipairs(PLAYER_COMMAND_QUEUE or {}) do
    if tostring(item.key or "") == key and tostring(item.commandName or "") == tostring(commandName or "") then count = count + 1 end
  end
  if PLAYER_COMMAND_QUEUE_CURRENT ~= nil and tostring(PLAYER_COMMAND_QUEUE_CURRENT.key or "") == key and tostring(PLAYER_COMMAND_QUEUE_CURRENT.commandName or "") == tostring(commandName or "") then
    count = count + 1
  end
  return count
end

function playerCommandQueueStatusJson()
  local preview = {}
  local limit = math.min(#(PLAYER_COMMAND_QUEUE or {}), 20)
  for i = 1, limit do
    local item = PLAYER_COMMAND_QUEUE[i]
    table.insert(preview, '{"id":' .. tostring(item.id or 0) ..
      ',"command":' .. js(item.commandName or "") ..
      ',"target":' .. js((item.info and (item.info.name or item.info.steam)) or "") ..
      ',"queuedAt":' .. tostring(item.queuedAt or 0) .. '}')
  end
  local current = "null"
  if PLAYER_COMMAND_QUEUE_CURRENT ~= nil then
    local age = math.max(0, os.time() - (tonumber(PLAYER_COMMAND_QUEUE_CURRENT.startedAt or PLAYER_COMMAND_QUEUE_CURRENT.queuedAt) or os.time()))
    current = '{"id":' .. tostring(PLAYER_COMMAND_QUEUE_CURRENT.id or 0) ..
      ',"command":' .. js(PLAYER_COMMAND_QUEUE_CURRENT.commandName or "") ..
      ',"target":' .. js((PLAYER_COMMAND_QUEUE_CURRENT.info and (PLAYER_COMMAND_QUEUE_CURRENT.info.name or PLAYER_COMMAND_QUEUE_CURRENT.info.steam)) or "") ..
      ',"queuedAt":' .. tostring(PLAYER_COMMAND_QUEUE_CURRENT.queuedAt or 0) ..
      ',"startedAt":' .. tostring(PLAYER_COMMAND_QUEUE_CURRENT.startedAt or 0) ..
      ',"ageSeconds":' .. tostring(age) .. '}'
  end
  return '{"available":true' ..
    ',"depth":' .. tostring(#(PLAYER_COMMAND_QUEUE or {}) + (PLAYER_COMMAND_QUEUE_BUSY and 1 or 0)) ..
    ',"pending":' .. tostring(#(PLAYER_COMMAND_QUEUE or {})) ..
    ',"busy":' .. (PLAYER_COMMAND_QUEUE_BUSY and "true" or "false") ..
    ',"current":' .. current ..
    ',"max":' .. tostring(PLAYER_COMMAND_QUEUE_MAX or 0) ..
    ',"maxPerPlayer":' .. tostring(PLAYER_COMMAND_QUEUE_MAX_PER_PLAYER or 0) ..
    ',"timeoutSeconds":' .. tostring(PLAYER_COMMAND_QUEUE_TIMEOUT_SECONDS or 0) ..
    ',"sequence":' .. tostring(PLAYER_COMMAND_QUEUE_SEQ or 0) ..
    ',"pendingPreview":[' .. table.concat(preview, ",") .. ']}'
end

function enqueuePlayerCommand(info, message, sourcePath, quiet)
  info = enrichCommandPlayerIdentity(info)
  local key = playerCommandQueueKey(info)
  if key == "" then return false, "Не удалось определить игрока для команды.", 0 end
  if not playerReplyTargetReliable(info) then return false, "Не удалось определить игрока для команды.", 0 end
  local commandName = (splitWords(message)[1] or ""):lower()
  if playerCommandRequiresResolvedSteam(commandName) and not playerCommandHasResolvedSteam(info) then
    if not quiet then
      appendActionEvent("player_command_queue", false, info, "Команда не поставлена в очередь: SteamID игрока ещё не определён",
        '{"command":' .. js(commandName) .. ',"source":' .. js(sourcePath or "") .. '}')
    end
    return false, "Сервер ещё определяет твоего игрока. Подожди 10 секунд и повтори команду.", 0
  end
  if #PLAYER_COMMAND_QUEUE >= PLAYER_COMMAND_QUEUE_MAX then
    if not quiet then appendActionEvent("player_command_queue", false, info, "Очередь команд игроков переполнена", '{"depth":' .. tostring(#PLAYER_COMMAND_QUEUE) .. '}') end
    return false, "Очередь команд сервера переполнена. Повтори чуть позже.", #PLAYER_COMMAND_QUEUE
  end
  local perPlayer = playerCommandPendingFor(key)
  if perPlayer >= PLAYER_COMMAND_QUEUE_MAX_PER_PLAYER then
    if not quiet then appendActionEvent("player_command_queue", false, info, "Очередь команд игрока переполнена", '{"perPlayer":' .. tostring(perPlayer) .. '}') end
    return false, "У тебя уже много команд в обработке. Дождись ответа сервера.", perPlayer
  end
  if playerCommandPendingForCommand(key, commandName) > 0 then
    if not quiet then
      appendActionEvent("player_command_queue", false, info, "Такая команда игрока уже обрабатывается",
        '{"command":' .. js(commandName) .. ',"depth":' .. tostring(#PLAYER_COMMAND_QUEUE) .. '}')
    end
    return false, "Эта команда уже обрабатывается. Дождись ответа сервера.", #PLAYER_COMMAND_QUEUE
  end
  PLAYER_COMMAND_QUEUE_SEQ = PLAYER_COMMAND_QUEUE_SEQ + 1
  table.insert(PLAYER_COMMAND_QUEUE, {
    id = PLAYER_COMMAND_QUEUE_SEQ,
    key = key,
    info = info,
    message = message,
    commandName = commandName,
    sourcePath = sourcePath,
    queuedAt = os.time()
  })
  if not quiet then
    appendActionEvent("player_command_queue", true, info, "Команда игрока поставлена в очередь",
      '{"id":' .. tostring(PLAYER_COMMAND_QUEUE_SEQ) .. ',"command":' .. js(commandName) .. ',"depth":' .. tostring(#PLAYER_COMMAND_QUEUE) .. '}')
    appendLog("player command queued id=" .. tostring(PLAYER_COMMAND_QUEUE_SEQ) .. " command=" .. tostring(commandName) .. " player=" .. tostring(info.name or info.steam or "") .. " depth=" .. tostring(#PLAYER_COMMAND_QUEUE))
  end
  return true, PLAYER_COMMAND_QUEUE_SEQ, #PLAYER_COMMAND_QUEUE
end

function drainPlayerCommandQueue()
  if PLAYER_COMMAND_QUEUE_BUSY then
    local current = PLAYER_COMMAND_QUEUE_CURRENT
    local timeoutSeconds = math.max(10, tonumber(PLAYER_COMMAND_QUEUE_TIMEOUT_SECONDS) or 25)
    local age = current ~= nil and (os.time() - (tonumber(current.startedAt or current.queuedAt) or os.time())) or 0
    if current ~= nil and age >= timeoutSeconds then
      current.cancelled = true
      appendLog("queued player command timeout id=" .. tostring(current.id) ..
        " command=" .. tostring(current.commandName or "") ..
        " ageSeconds=" .. tostring(age) ..
        " player=" .. tostring((current.info and (current.info.name or current.info.steam)) or ""))
      appendActionEvent("player_command", false, current.info, "Команда снята с очереди по таймауту",
        '{"id":' .. tostring(current.id or 0) ..
        ',"command":' .. js(current.commandName or "") ..
        ',"ageSeconds":' .. tostring(age) ..
        ',"timeoutSeconds":' .. tostring(timeoutSeconds) ..
        ',"handled":false,"queued":true,"timeout":true}')
      local timeoutInfo = current.info
      deferGame(0, function()
        targetMessageResolved(timeoutInfo, "Команда слишком долго обрабатывалась и снята с очереди. Повтори позже или выбери другое действие.")
      end)
      PLAYER_COMMAND_QUEUE_BUSY = false
      PLAYER_COMMAND_QUEUE_CURRENT = nil
    else
      return
    end
  end
  local item = table.remove(PLAYER_COMMAND_QUEUE, 1)
  if item == nil then return end
  PLAYER_COMMAND_QUEUE_BUSY = true
  PLAYER_COMMAND_QUEUE_CURRENT = item
  item.startedAt = os.time()
  local started = os.clock()
  local function finish(okRun, handledOrErr)
    if item.cancelled then
      appendLog("queued player command late finish ignored id=" .. tostring(item.id) .. " command=" .. tostring(item.commandName or ""))
      return
    end
    if PLAYER_COMMAND_QUEUE_CURRENT ~= item then
      appendLog("queued player command stale finish ignored id=" .. tostring(item.id) .. " command=" .. tostring(item.commandName or ""))
      return
    end
    local durationMs = math.floor((os.clock() - started) * 1000)
    PLAYER_COMMAND_QUEUE_BUSY = false
    PLAYER_COMMAND_QUEUE_CURRENT = nil
    if not okRun then
      appendLog("queued player command failed id=" .. tostring(item.id) .. " err=" .. tostring(handledOrErr))
      appendActionEvent("player_command", false, item.info, tostring(handledOrErr),
        '{"id":' .. tostring(item.id) .. ',"command":' .. js(item.commandName or "") .. ',"durationMs":' .. tostring(durationMs) .. ',"handled":false,"queued":true}')
      targetMessageResolved(item.info, "Команда завершилась с ошибкой. Администратор увидит детали в журнале.")
      return
    end
    appendLog("queued player command id=" .. tostring(item.id) ..
      " command=" .. tostring(item.commandName or "") ..
      " handled=" .. tostring(handledOrErr) ..
      " durationMs=" .. tostring(durationMs) ..
      " player=" .. tostring((item.info and (item.info.name or item.info.steam)) or ""))
    appendActionEvent("player_command", handledOrErr == true, item.info, "handled=" .. tostring(handledOrErr),
      '{"id":' .. tostring(item.id) .. ',"command":' .. js(item.commandName or "") .. ',"durationMs":' .. tostring(durationMs) .. ',"handled":' .. (handledOrErr and "true" or "false") .. ',"queued":true}')
  end
  local function runItem()
    appendLog("queued player command start id=" .. tostring(item.id) ..
      " command=" .. tostring(item.commandName or "") ..
      " player=" .. tostring((item.info and (item.info.name or item.info.steam)) or ""))
    local queuedInfo = item.info
    local live = queuedInfo
    if queuedInfo ~= nil and playerCommandRequiresLiveRefresh(item.commandName) then
      live = resolvePlayerInfo(queuedInfo.steam, queuedInfo.name, queuedInfo, queuedInfo.runtimeKey) or queuedInfo
    end
    if live == nil or not playerReplyTargetReliable(live) then
      finish(false, "Игрок вышел до обработки команды.")
      return
    end
    item.info = live
    local okRun, handledOrErr = pcall(function() return handlePlayerCommand(live, item.message) end)
    finish(okRun, handledOrErr)
  end
  if deferGame(0, runItem) then return end

  if ExecuteInGameThread ~= nil then
    local okThread, err = pcall(function() ExecuteInGameThread(runItem) end)
    if okThread then return end
    appendLog("player command ExecuteInGameThread failed, running inline: " .. tostring(err))
  end
  runItem()
end

chatHookStatus = {}
chatHookFailures = {}
CHAT_EVENT_DEDUP = CHAT_EVENT_DEDUP or {}
CHAT_EVENT_WRITE_QUEUE = CHAT_EVENT_WRITE_QUEUE or {}
CHAT_EVENT_WRITE_QUEUE_MAX = CHAT_EVENT_WRITE_QUEUE_MAX or 2000

function enqueueStateWrite(path, recordJson, maxBytes)
  return appendJsonArray(path or "", recordJson or "{}", maxBytes)
end

function drainStateWriteQueue(limit)
  local max = math.max(1, tonumber(limit) or 20)
  local count = 0
  while count < max do
    local path = table.remove(STATE_WRITE_QUEUE, 1)
    if path == nil then return end
    STATE_WRITE_QUEUE_PENDING[path] = nil
    if not flushStateArrayCache(path) then queueStateFlushPath(path) end
    count = count + 1
  end
end

function normalizeChatChannelName(channel, message, path)
  local raw = cleanText(channel or ""):lower()
  local source = tostring(path or ""):lower()
  local text = cleanText(message or "")
  local first = text:sub(1, 1)
  if raw == "0" then return "local" end
  if raw == "1" then return "squad" end
  if raw == "2" then return "global" end
  if raw == "3" then return "admin" end
  if raw == "4" then return "command" end
  if raw:find("local", 1, true) or raw:find("proximity", 1, true) or raw:find("vicinity", 1, true) then return "local" end
  if raw:find("squad", 1, true) or raw:find("team", 1, true) or raw:find("clan", 1, true) or raw:find("party", 1, true) then return "squad" end
  if raw:find("admin", 1, true) or raw:find("moderator", 1, true) then return "admin" end
  if raw:find("command", 1, true) or source:find("processadmincommand", 1, true) or source:find("command-reply", 1, true) or first == "/" or first == "!" or first == "#" then return "command" end
  if raw:find("global", 1, true) or raw:find("world", 1, true) then return "global" end
  if raw == "" or raw == "chat" or raw == "server" then return "global" end
  return raw
end

function enqueueChatEventWriteAt(message, name, steam, channel, path, timestampUtc)
  if #(CHAT_EVENT_WRITE_QUEUE or {}) >= CHAT_EVENT_WRITE_QUEUE_MAX then
    table.remove(CHAT_EVENT_WRITE_QUEUE, 1)
  end
  table.insert(CHAT_EVENT_WRITE_QUEUE, {
    message = message,
    name = name,
    steam = steam,
    channel = normalizeChatChannelName(channel, message, path),
    path = path,
    timestampUtc = cleanText(timestampUtc or nowUtc())
  })
end

function enqueueChatEventWrite(message, name, steam, channel, path)
  enqueueChatEventWriteAt(message, name, steam, channel, path, nowUtc())
end

function drainChatEventWriteQueue(limit)
  local max = math.max(1, tonumber(limit) or 40)
  local count = 0
  while count < max do
    local item = table.remove(CHAT_EVENT_WRITE_QUEUE, 1)
    if item == nil then return end
    enqueueStateWrite(CHAT_STATE_FILE,
      '{"type":"chat","timestampUtc":' .. js(item.timestampUtc or nowUtc()) ..
      ',"message":' .. js(item.message or "") ..
      ',"name":' .. js(item.name or "") ..
      ',"steamId":' .. js(item.steam or "") ..
      ',"channel":' .. js(item.channel or "") ..
      ',"source":' .. js(item.path or "ue4ss") .. '}',
      2 * 1024 * 1024)
    count = count + 1
  end
end

SCUM_CHAT_LOG_SEEN = SCUM_CHAT_LOG_SEEN or {}
SCUM_CHAT_LOG_LAST_FILE = SCUM_CHAT_LOG_LAST_FILE or ""
SCUM_CHAT_LOG_IMPORT_LOGGED = SCUM_CHAT_LOG_IMPORT_LOGGED or false

function utf8FromCodepoint(cp)
  cp = tonumber(cp) or 0
  if cp <= 0 then return "" end
  if cp < 0x80 then return string.char(cp) end
  if cp < 0x800 then
    return string.char(0xC0 + math.floor(cp / 0x40), 0x80 + (cp % 0x40))
  end
  if cp < 0x10000 then
    return string.char(0xE0 + math.floor(cp / 0x1000), 0x80 + (math.floor(cp / 0x40) % 0x40), 0x80 + (cp % 0x40))
  end
  return string.char(0xF0 + math.floor(cp / 0x40000), 0x80 + (math.floor(cp / 0x1000) % 0x40), 0x80 + (math.floor(cp / 0x40) % 0x40), 0x80 + (cp % 0x40))
end

function decodeUtf16Le(text)
  local s = tostring(text or "")
  if s == "" then return "" end
  if not s:find("\0", 1, true) then return s end
  local out = {}
  local i = 1
  if s:byte(1) == 0xFF and s:byte(2) == 0xFE then i = 3 end
  while i < #s do
    local lo = s:byte(i) or 0
    local hi = s:byte(i + 1) or 0
    local cp = lo + hi * 256
    i = i + 2
    if cp >= 0xD800 and cp <= 0xDBFF and i < #s then
      local lo2 = s:byte(i) or 0
      local hi2 = s:byte(i + 1) or 0
      local cp2 = lo2 + hi2 * 256
      if cp2 >= 0xDC00 and cp2 <= 0xDFFF then
        cp = 0x10000 + ((cp - 0xD800) * 0x400) + (cp2 - 0xDC00)
        i = i + 2
      end
    end
    table.insert(out, utf8FromCodepoint(cp))
  end
  return table.concat(out)
end

function latestScumChatLogPath()
  local command = 'dir /b /o-d "' .. SCUM_SAVE_LOG_DIR .. '\\chat_*.log" 2>nul'
  local pipe = nil
  local okPipe = pcall(function() pipe = io.popen(command, "r") end)
  if not okPipe or pipe == nil then return SCUM_CHAT_LOG_LAST_FILE end
  local name = cleanText(pipe:read("*l") or "")
  pipe:close()
  if name == "" then return SCUM_CHAT_LOG_LAST_FILE end
  local path = SCUM_SAVE_LOG_DIR .. "\\" .. name
  SCUM_CHAT_LOG_LAST_FILE = path
  return path
end

function scumChatTimestampUtc(stamp)
  local y, mo, d, h, mi, se = tostring(stamp or ""):match("^(%d%d%d%d)%.(%d%d)%.(%d%d)%-(%d%d)%.(%d%d)%.(%d%d)$")
  if y == nil then return nowUtc() end
  return y .. "-" .. mo .. "-" .. d .. "T" .. h .. ":" .. mi .. ":" .. se .. "Z"
end

function parseScumChatLogLine(line)
  local value = cleanText(line)
  if value == "" or value:find("Game version", 1, true) ~= nil then return nil end
  local stamp, identity, body = value:match("^(%d%d%d%d%.%d%d%.%d%d%-%d%d%.%d%d%.%d%d):%s*'([^']+)'%s*'([^']*)'")
  if stamp == nil then return nil end
  local steam, name, profile = identity:match("^(%d+):(.-)%((%d+)%)$")
  if steam == nil then return nil end
  local channel, message = body:match("^([^:]+):%s*(.*)$")
  channel = cleanText(channel or "")
  message = cleanText(message or "")
  if message == "" then return nil end
  local first = message:sub(1, 1)
  if first == "/" or first == "!" or first == "#" then return nil end
  local lower = channel:lower()
  if lower == "local" or lower == "squad" or lower == "global" or lower == "admin" then
    return {
      timestampUtc = scumChatTimestampUtc(stamp),
      steam = steam,
      name = cleanText(name or ""),
      profile = cleanText(profile or ""),
      channel = lower,
      message = message
    }
  end
  return nil
end

function importScumChatLog()
  local path = latestScumChatLogPath()
  if path == nil or path == "" then return end
  local raw = readTail(path, 128 * 1024)
  if raw == nil or raw == "" then return end
  local text = decodeUtf16Le(raw)
  local imported = 0
  for line in tostring(text):gmatch("[^\r\n]+") do
    local event = parseScumChatLogLine(line)
    if event ~= nil then
      local key = event.timestampUtc .. "|" .. event.steam .. "|" .. event.channel .. "|" .. event.message
      if not SCUM_CHAT_LOG_SEEN[key] then
        SCUM_CHAT_LOG_SEEN[key] = os.clock()
        enqueueChatEventWriteAt(event.message, event.name, event.steam, event.channel, "scum-chat-log", event.timestampUtc)
        imported = imported + 1
      end
    end
  end
  local nowClock = os.clock()
  for key, seenAt in pairs(SCUM_CHAT_LOG_SEEN) do
    if (nowClock - (tonumber(seenAt) or 0)) > 900 then SCUM_CHAT_LOG_SEEN[key] = nil end
  end
  if imported > 0 and not SCUM_CHAT_LOG_IMPORT_LOGGED then
    SCUM_CHAT_LOG_IMPORT_LOGGED = true
    appendLog("scum chat log import active path=" .. tostring(path) .. " imported=" .. tostring(imported))
  end
end

SCUM_KILL_LOG_SEEN = SCUM_KILL_LOG_SEEN or {}
SCUM_KILL_LOG_LAST_FILE = SCUM_KILL_LOG_LAST_FILE or ""
SCUM_KILL_LOG_IMPORT_LOGGED = SCUM_KILL_LOG_IMPORT_LOGGED or false

function latestScumKillLogPath()
  local command = 'dir /b /o-d "' .. SCUM_SAVE_LOG_DIR .. '\\kill_*.log" 2>nul'
  local pipe = nil
  local okPipe = pcall(function() pipe = io.popen(command, "r") end)
  if not okPipe or pipe == nil then return SCUM_KILL_LOG_LAST_FILE end
  local name = cleanText(pipe:read("*l") or "")
  pipe:close()
  if name == "" then return SCUM_KILL_LOG_LAST_FILE end
  local path = SCUM_SAVE_LOG_DIR .. "\\" .. name
  SCUM_KILL_LOG_LAST_FILE = path
  return path
end

function killLogNumber(value)
  local text = tostring(value or ""):gsub(",", "."):gsub("[^%-%d%.]", "")
  return tonumber(text)
end

function cleanKillWeapon(rawWeapon)
  local weapon = cleanText(rawWeapon or "")
  weapon = weapon:gsub("%s*%[[^%]]+%]%s*$", "")
  weapon = weapon:gsub("_C$", "")
  return weapon
end

function killDeathTypeLabel(cause, killerId, killerName)
  local raw = cleanText(cause or "")
  local lower = raw:lower()
  if lower == "projectile" then return "пуля/снаряд" end
  if lower == "melee" then return "ближний бой" end
  if lower == "explosion" then return "взрыв" end
  if lower == "vehicle" then return "транспорт" end
  if lower == "fall" then return "падение" end
  if lower == "suicide" then return "самоубийство" end
  if tostring(killerId or "") == "NPC" then return "NPC" end
  if tostring(killerName or ""):find("BP_", 1, true) ~= nil then return "NPC" end
  return raw ~= "" and raw or "неизвестно"
end

function parseScumKillLogLine(line)
  local value = cleanText(line)
  if value == "" or value:find("Game version", 1, true) ~= nil then return nil end
  if value:find("Died:", 1, true) == nil or value:find("Killer:", 1, true) == nil then return nil end

  local stamp, victimName, victimId, killerName, killerId, weaponRaw, tail =
    value:match("^(%d%d%d%d%.%d%d%.%d%d%-%d%d%.%d%d%.%d%d):%s*Died:%s*(.-)%s*%(([^%)]+)%),%s*Killer:%s*(.-)%s*%(([^%)]+)%)%s*Weapon:%s*(.-)%s*S:%[(.+)%]$")
  if stamp == nil then return nil end

  local killerX, killerY, killerZ = tail:match("KillerLoc%s*:%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)")
  if killerX == nil then
    killerX, killerY, killerZ = tail:match("KillerLocation%s*:%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)")
  end
  local victimX, victimY, victimZ = tail:match("VictimLoc%s*:%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)")
  if victimX == nil then
    victimX, victimY, victimZ = tail:match("VictimLocation%s*:%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)%s*,%s*([%-%.%d]+)")
  end
  local distance = tail:match("Distance%s*:%s*([%-%.%d]+)")

  local cause = tostring(weaponRaw or ""):match("%[([^%]]+)%]") or ""
  local weapon = cleanKillWeapon(weaponRaw)
  victimName = cleanText(victimName)
  killerName = cleanText(killerName)
  victimId = cleanText(victimId)
  killerId = cleanText(killerId)

  if victimName == "" then return nil end
  local killerSteam = looksLikeSteamId(killerId) and killerId or ""
  local victimSteam = looksLikeSteamId(victimId) and victimId or ""
  local isSelf = victimSteam ~= "" and killerSteam ~= "" and victimSteam == killerSteam
  local isPve = killerSteam == "" or tostring(killerId or "") == "NPC"
  local message = ""
  if isSelf then
    message = victimName .. " погиб"
  elseif isPve then
    message = victimName .. " погиб от " .. (killerName ~= "" and killerName or "NPC")
  else
    message = (killerName ~= "" and killerName or "Unknown") .. " убил " .. victimName
  end
  if weapon ~= "" and serverKillFeedShowWeapon() then message = message .. " (" .. weapon .. ")" end
  local distanceNumber = killLogNumber(distance)
  if distanceNumber ~= nil and distanceNumber > 0 and serverKillFeedShowDistance() then
    message = message .. " с " .. tostring(math.floor(distanceNumber + 0.5)) .. " м"
  end

  return {
    timestampUtc = scumChatTimestampUtc(stamp),
    message = message,
    killerName = killerName,
    killerSteamId = killerSteam,
    killerUserId = killerId,
    victimName = victimName,
    victimSteamId = victimSteam,
    weapon = weapon,
    weaponRaw = cleanText(weaponRaw),
    cause = cleanText(cause),
    deathType = killDeathTypeLabel(cause, killerId, killerName),
    distance = distanceNumber,
    killerX = killLogNumber(killerX),
    killerY = killLogNumber(killerY),
    killerZ = killLogNumber(killerZ),
    victimX = killLogNumber(victimX),
    victimY = killLogNumber(victimY),
    victimZ = killLogNumber(victimZ),
    raw = value,
    isPve = isPve,
    isSelf = isSelf
  }
end

function appendSavefileKillEvent(event, path)
  if event == nil then return false end
  local distance = tonumber(event.distance or 0) or 0
  local broadcastMessage = serverKillFeedPrefix() .. " " .. tostring(event.message or "")
  local record = '{"type":"kill","timestampUtc":' .. js(event.timestampUtc or nowUtc()) ..
    ',"message":' .. js(event.message or "") ..
    ',"broadcastMessage":' .. js(broadcastMessage) ..
    ',"killerName":' .. js(event.killerName or "") ..
    ',"killerSteamId":' .. js(event.killerSteamId or "") ..
    ',"killerUserId":' .. js(event.killerUserId or "") ..
    ',"victimName":' .. js(event.victimName or "") ..
    ',"victimSteamId":' .. js(event.victimSteamId or "") ..
    ',"weapon":' .. js(event.weapon or "") ..
    ',"weaponRaw":' .. js(event.weaponRaw or "") ..
    ',"cause":' .. js(event.cause or "") ..
    ',"deathType":' .. js(event.deathType or "") ..
    ',"distance":' .. tostring(distance) ..
    ',"distanceMeters":' .. tostring(distance) ..
    ',"killerLocation":' .. killLocationJson(event.killerX, event.killerY, event.killerZ) ..
    ',"victimLocation":' .. killLocationJson(event.victimX, event.victimY, event.victimZ) ..
    ',"source":"savefile-kill-log"' ..
    ',"logFile":' .. js(tostring(path or ""):match("([^\\]+)$") or tostring(path or "")) ..
    ',"raw":' .. js(event.raw or "") .. '}'
  appendJsonArray(STATE_DIR .. "\\kill-feed.json", record, 2 * 1024 * 1024)
  appendJsonArray(STATE_DIR .. "\\server-kill-feed.json", record, 2 * 1024 * 1024)
  return true
end

function updateStatsFromSavefileKill(event)
  if event == nil then return false, "empty" end
  local statBody = ""
  if event.isSelf or event.isPve or tostring(event.killerSteamId or "") == "" then
    statBody = tostring(event.victimName or "") .. " погиб"
  else
    statBody = tostring(event.killerName or "") .. " убил " .. tostring(event.victimName or "")
  end
  if shouldSkipServerKillFeedStats(statBody) then return false, "duplicate" end

  local victimInfo = resolveKillFeedIdentityByName(event.victimName or "")
  if event.isSelf or event.isPve or tostring(event.killerSteamId or "") == "" then
    if victimInfo == nil then return false, "victim-not-found" end
    return handleDeathEvent(victimInfo, {
      source = "savefile-kill-log",
      skipKillFeed = true,
      victimX = event.victimX,
      victimY = event.victimY,
      victimZ = event.victimZ,
      weapon = event.weapon,
      cause = event.cause,
      distance = event.distance
    }), "death"
  end
  local killerInfo = resolveKillFeedIdentityByName(event.killerName or "")
  if killerInfo == nil or victimInfo == nil then return false, "identity-not-found" end
  return handleKillEvent(killerInfo, victimInfo, {
    source = "savefile-kill-log",
    skipKillFeed = true,
    killerX = event.killerX,
    killerY = event.killerY,
    killerZ = event.killerZ,
    victimX = event.victimX,
    victimY = event.victimY,
    victimZ = event.victimZ,
    weapon = event.weapon,
    cause = event.cause,
    distance = event.distance
  }), "kill"
end

function importScumKillLog()
  if configBool("server-kill-feed", { "ImportSaveFileKillLog", "importSaveFileKillLog" }, true) == false then return end
  local path = latestScumKillLogPath()
  if path == nil or path == "" then return end
  local raw = readTail(path, 256 * 1024)
  if raw == nil or raw == "" then return end
  local text = decodeUtf16Le(raw)
  local imported = 0
  for line in tostring(text):gmatch("[^\r\n]+") do
    local event = parseScumKillLogLine(line)
    if event ~= nil then
      local key = tostring(event.timestampUtc or "") .. "|" .. tostring(event.victimSteamId or event.victimName or "") ..
        "|" .. tostring(event.killerSteamId or event.killerUserId or event.killerName or "") .. "|" ..
        tostring(event.weapon or "") .. "|" .. tostring(event.distance or "")
      if key ~= "" and not SCUM_KILL_LOG_SEEN[key] then
        SCUM_KILL_LOG_SEEN[key] = os.clock()
        appendSavefileKillEvent(event, path)
        updateStatsFromSavefileKill(event)
        imported = imported + 1
      end
    end
  end
  local nowClock = os.clock()
  for key, seenAt in pairs(SCUM_KILL_LOG_SEEN) do
    if (nowClock - (tonumber(seenAt) or 0)) > 3600 then SCUM_KILL_LOG_SEEN[key] = nil end
  end
  if imported > 0 and not SCUM_KILL_LOG_IMPORT_LOGGED then
    SCUM_KILL_LOG_IMPORT_LOGGED = true
    appendLog("scum kill log import active path=" .. tostring(path) .. " imported=" .. tostring(imported))
  end
end

function chatIdentityKey(info, context)
  if info ~= nil then
    if tostring(info.steam or "") ~= "" then return "steam:" .. tostring(info.steam) end
    if tostring(info.userProfileId or info.serverUserProfileId or "") ~= "" then return "profile:" .. tostring(info.userProfileId or info.serverUserProfileId) end
    if tostring(info.name or "") ~= "" then return "name:" .. tostring(info.name):lower() end
    if tostring(info.runtimeKey or "") ~= "" then return "runtime:" .. tostring(info.runtimeKey) end
  end
  local key = objectKey(context)
  if key ~= "" then return "context:" .. key end
  return "unknown"
end

function playerInfoHasIdentity(info)
  if info == nil then return false end
  if looksLikeSteamId(tostring(info.steam or info.steamId or "")) then return true end
  local profile = cleanText(info.userProfileId or info.serverUserProfileId or info.profileId or "")
  if profile ~= "" and profile ~= "0" then return true end
  local runtimeKey = cleanText(info.runtimeKey or info.rpcKey or info.pcKey or info.psKey or info.pawnKey or "")
  if runtimeKey ~= "" then return true end
  local name = cleanText(info.name or "")
  if name ~= "" and name:lower() ~= "unknown" then return true end
  return false
end

function mergeRuntimeIntoIdentity(identity, runtimeInfo)
  if identity == nil then return runtimeInfo end
  if runtimeInfo == nil then return identity end
  local keys = {
    "steam", "name", "userProfileId", "serverUserProfileId",
    "pc", "ps", "pawn", "rpc",
    "pcKey", "psKey", "pawnKey", "rpcKey", "runtimeKey",
    "x", "y", "z", "ping", "score"
  }
  for _, key in ipairs(keys) do
    local current = identity[key]
    local incoming = runtimeInfo[key]
    local currentText = tostring(current or "")
    local incomingText = tostring(incoming or "")
    if incoming ~= nil and incomingText ~= "" and (current == nil or currentText == "" or currentText == "Unknown") then
      identity[key] = incoming
    end
  end
  local source = tostring(identity.source or "")
  local runtimeSource = tostring(runtimeInfo.source or "")
  if runtimeSource ~= "" and source:find(runtimeSource, 1, true) == nil then
    identity.source = (source ~= "" and (source .. "+") or "") .. runtimeSource
  end
  return identity
end

function attachChatRuntime(info, context, runtimeInfo)
  info = mergeRuntimeIntoIdentity(info, runtimeInfo)
  if info == nil then return nil end
  local contextObj = unwrapHookParam(context)
  if contextObj ~= nil and isValidObject(contextObj) then
    local className = objectClassFullName(contextObj) .. " " .. objectFullName(contextObj)
    if className:find("PlayerRpcChannel", 1, true) ~= nil or className:find("RpcChannel", 1, true) ~= nil then
      info.rpc = contextObj
      info.rpcKey = objectKey(contextObj)
      if tostring(info.runtimeKey or "") == "" then info.runtimeKey = info.rpcKey end
      local source = tostring(info.source or "")
      if source:find("chat-rpc", 1, true) == nil then
        info.source = (source ~= "" and (source .. "+") or "") .. "chat-rpc"
      end
    end
  end
  return info
end

function shouldAcceptChatEvent(info, context, message)
  local now = os.clock()
  for key, seenAt in pairs(CHAT_EVENT_DEDUP) do
    if (now - seenAt) > 4 then CHAT_EVENT_DEDUP[key] = nil end
  end
  local key = chatIdentityKey(info, context) .. "|" .. cleanText(message)
  local last = CHAT_EVENT_DEDUP[key]
  if last ~= nil and (now - last) < 1.25 then return false end
  CHAT_EVENT_DEDUP[key] = now
  return true
end

function commandTextFromHook(path, message)
  local commandMessage = chatCommandText(message)
  if commandMessage ~= "" then return commandMessage end
  if tostring(path or ""):find("ProcessAdminCommand", 1, true) == nil then return "" end
  local value = cleanText(message)
  if value == "" or value:sub(1, 1) == "#" then return "" end
  local synthetic = "/" .. value
  if commandKey((splitWords(synthetic)[1] or ""):lower()) ~= "" then return synthetic end
  return ""
end

function commandHookFallbackPlayer()
  local infos = PLAYER_INFO_CACHE or {}
  if #infos == 1 then return infos[1] end

  local snapshot = serverLogOnlineSnapshot()
  local presence = serverLogPresenceSnapshot()
  if presence == nil or tonumber(presence.activeCount or 0) ~= 1 then return nil end
  if snapshot ~= nil and tonumber(snapshot.playerCount or -1) > 1 then return nil end

  for key in pairs(presence.active or {}) do
    local steam = tostring(key or ""):match("^steam:(%d+)$") or ""
    if steam ~= "" then
      local identity = presence.knownBySteam[steam] or {}
      return {
        steam = steam,
        name = cleanText(identity.name or ""),
        userProfileId = cleanText(identity.profileId or ""),
        serverUserProfileId = cleanText(identity.profileId or ""),
        online = true,
        status = "online",
        source = "server-log"
      }
    end
    local profile = tostring(key or ""):match("^profile:(%d+)$") or ""
    if profile ~= "" then
      local identity = presence.knownByProfile[profile] or {}
      return {
        steam = cleanText(identity.steam or ""),
        name = cleanText(identity.name or ""),
        userProfileId = profile,
        serverUserProfileId = profile,
        online = true,
        status = "online",
        source = "server-log"
      }
    end
    local name = tostring(key or ""):match("^name:(.+)$") or ""
    if name ~= "" then
      local identity = presence.knownByName[name] or {}
      return {
        steam = cleanText(identity.steam or ""),
        name = cleanText(identity.name or name),
        userProfileId = cleanText(identity.profileId or ""),
        serverUserProfileId = cleanText(identity.profileId or ""),
        online = true,
        status = "online",
        source = "server-log"
      }
    end
  end
  return nil
end

function chatSenderNameFromText(text)
  local value = cleanText(text)
  if value == "" then return "" end
  value = value:gsub("^%[[^%]]+%]%s*", "")
  local sender = value:match("^([^:]{1,96}):%s*[/!]")
  if sender == nil then sender = value:match("^([^:]{1,96}):%s*#") end
  sender = cleanText(sender or "")
  if sender:lower() == "global" or sender:lower() == "local" or sender:lower() == "squad" then return "" end
  return sender
end

function findCachedPlayerByExactName(name)
  local wanted = cleanText(name):lower()
  if wanted == "" then return nil end
  local cacheTtl = math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 90))
  for _, info in ipairs(cachedPlayerInfos(cacheTtl) or {}) do
    local candidateName = cleanText(info.name or ""):lower()
    if candidateName ~= "" and candidateName == wanted then return enrichPlayerInfoFromServerLog(info) or info end
  end
  return nil
end

function resolveCommandPlayerFromChatText(message)
  local sender = chatSenderNameFromText(message)
  if sender == "" then return nil end
  local cached = findCachedPlayerByExactName(sender)
  if cached ~= nil then return cached end
  return resolvePlayerInfoFromServerLogTarget("", sender)
end

function resolveCommandHookPlayer(context, args, message, commandName)
  local runtimeInfo = enrichCommandPlayerIdentity(findPlayerByChatContextCached(context, args, message))
  if playerCommandIdentityReady(runtimeInfo, commandName) then return attachChatRuntime(runtimeInfo, context, nil) end

  local textInfo = enrichCommandPlayerIdentity(resolveCommandPlayerFromChatText(message))
  if playerCommandIdentityReady(textInfo, commandName) then return attachChatRuntime(textInfo, context, runtimeInfo) end
  runtimeInfo = enrichCommandPlayerIdentity(mergeRuntimeIntoIdentity(textInfo, runtimeInfo))

  local needsRuntimeRefresh = runtimeInfo == nil or not playerCommandIdentityReady(runtimeInfo, commandName)
  if needsRuntimeRefresh or (playerCommandRequiresResolvedSteam(commandName) and configBool("bridge-safety", { "AllowCommandRuntimeScan", "allowCommandRuntimeScan" }, false)) then
    refreshPlayerInfoCacheForCommand(commandName)
    local refreshedInfo = enrichCommandPlayerIdentity(findPlayerByChatContextCached(context, args, message))
    if playerCommandIdentityReady(refreshedInfo, commandName) then return attachChatRuntime(refreshedInfo, context, runtimeInfo) end
    local rescannedInfo = enrichCommandPlayerIdentity(findPlayerByChatContext(context, args, message))
    if playerCommandIdentityReady(rescannedInfo, commandName) then return attachChatRuntime(rescannedInfo, context, runtimeInfo) end
    runtimeInfo = enrichCommandPlayerIdentity(mergeRuntimeIntoIdentity(rescannedInfo, runtimeInfo))
  end

  local fallbackInfo = enrichCommandPlayerIdentity(commandHookFallbackPlayer())
  if playerCommandIdentityReady(fallbackInfo, commandName) then return attachChatRuntime(fallbackInfo, context, runtimeInfo) end

  return attachChatRuntime(enrichCommandPlayerIdentity(runtimeInfo), context, nil)
end

function registerCommandOnlyChatHook(path)
  if chatHookStatus[path] == true then return end
  if chatHookStatus[path] == false then return end
  local okHook, err = pcall(function()
    RegisterHook(path, function(context, ...)
      local args = {...}
      local commandMessage = ""
      local rawMessage = ""
      for i, arg in ipairs(args) do
        if i > 8 then break end
        local text = paramText(arg)
        local candidate = chatCommandText(text)
        if candidate ~= "" then
          commandMessage = candidate
          rawMessage = text
          break
        end
      end
      if commandMessage == "" then return end

      local commandName = (splitWords(commandMessage)[1] or ""):lower()
      if commandKey(commandName) == "" then return end

      local info = resolveCommandHookPlayer(context, args, rawMessage, commandName)
      if info == nil then
        local contextKey = objectKey(context)
        local contextName = objectFullName(context)
        local argsJson = chatArgSummary(args, 8)
        local playersJson = chatPlayersSummaryJson()
        appendActionEvent("player_command", false, {}, "sender unresolved",
          '{"command":' .. js(commandName) ..
          ',"path":' .. js(path) ..
          ',"contextKey":' .. js(contextKey) ..
          ',"context":' .. js(contextName) ..
          ',"message":' .. js(commandMessage) ..
          ',"args":' .. tostring(argsJson) ..
          ',"players":' .. tostring(playersJson) ..
          ',"source":"command-only-chat-hook"}')
        return
      end
      if not shouldAcceptChatEvent(info, nil, commandMessage) then return end

      enqueueChatEventWrite(commandMessage, info.name or "", info.steam or "", "command", path)
      local queued, queueResult, depth = enqueuePlayerCommand(info, commandMessage, path, false)
      if not queued then
        appendActionEvent("player_command_queue", false, info, tostring(queueResult or "Команда не поставлена в очередь."),
          '{"command":' .. js(commandName) .. ',"depth":' .. tostring(depth or 0) .. ',"source":"command-only-chat-hook"}')
        targetMessagePlayerCommandFailure(info, commandName, tostring(queueResult or "Команда не поставлена в очередь."))
      end
    end)
  end)
  if okHook then
    chatHookStatus[path] = true
    appendLog("command-only chat hook " .. tostring(path) .. "=ok")
    return
  end
  chatHookFailures[path] = (chatHookFailures[path] or 0) + 1
  if chatHookFailures[path] >= 90 then
    chatHookStatus[path] = false
    appendLog("command-only chat hook " .. tostring(path) .. "=unavailable after " .. tostring(chatHookFailures[path]) .. " retries")
    return
  end
  if chatHookFailures[path] == 1 or (chatHookFailures[path] % 30) == 0 then
    appendLog("command-only chat hook " .. tostring(path) .. "=pending retry " .. tostring(chatHookFailures[path]) .. " (" .. tostring(err) .. ")")
  end
end

function registerChatHook(path)
  if tostring(path or ""):find("BroadcastChatMessage", 1, true) ~= nil then
    registerCommandOnlyChatHook(path)
    return
  end
  if chatHookStatus[path] == true then return end
  if chatHookStatus[path] == false then return end
  local okHook, err = pcall(function()
    RegisterHook(path, function(context, ...)
      local args = {...}
      local message = ""
      local channel = ""
      local texts = {}
      for i, arg in ipairs(args) do
        local text = paramText(arg)
        if text ~= "" then table.insert(texts, text) end
      end
      for _, text in ipairs(texts) do
        if chatCommandText(text) ~= "" or text:sub(1, 1) == "#" then
          message = text
          break
        end
      end
      if message == "" then
        for _, text in ipairs(texts) do
          local lower = cleanText(text):lower()
          local channelToken = lower:match("^[0-4]$") ~= nil or
            lower == "local" or lower == "proximity" or lower == "vicinity" or
            lower == "squad" or lower == "team" or lower == "clan" or lower == "party" or
            lower == "global" or lower == "world" or lower == "admin" or lower == "server"
          if not channelToken then
            message = text
            break
          end
        end
      end
      if message == "" and #texts > 0 then message = texts[#texts] end
      for _, text in ipairs(texts) do
        if text ~= message and channel == "" then channel = text end
      end
      if message == "" then return end
      if message:sub(1, 1) == "#" then return end
      local commandMessage = commandTextFromHook(path, message)
      local isCommand = commandMessage ~= ""
      local info = findPlayerByChatContextCached(context, args, message)
      if isCommand then
        local commandName = (splitWords(commandMessage)[1] or ""):lower()
        info = resolveCommandHookPlayer(context, args, message, commandName)
      end
      if not shouldAcceptChatEvent(info, context, message) then return end
      local name = info and info.name or ""
      local steam = info and info.steam or ""
      enqueueChatEventWrite(message, name, steam, channel, path)
      if isCommand and info == nil then
        local commandName = (splitWords(commandMessage)[1] or ""):lower()
        chatUnresolvedCommandLogCount = (chatUnresolvedCommandLogCount or 0) + 1
        local contextObj = context
        local argsSnapshot = args
        local messageSnapshot = message
        local commandSnapshot = commandMessage
        deferGame(1, function()
          local resolved = resolveCommandHookPlayer(contextObj, argsSnapshot, messageSnapshot, commandName)
          if resolved ~= nil then
            local queued, queueResult, depth = enqueuePlayerCommand(resolved, commandSnapshot, path, false)
            if not queued then
              appendActionEvent("player_command_queue", false, resolved, tostring(queueResult or "Команда не поставлена в очередь."),
                '{"command":' .. js(commandName) .. ',"depth":' .. tostring(depth or 0) .. ',"source":"chat-hook-deferred-resolve"}')
              targetMessagePlayerCommandFailure(resolved, commandName, tostring(queueResult or "Команда не поставлена в очередь."))
            end
            return
          end
          local contextKey = objectKey(contextObj)
          local contextName = objectFullName(contextObj)
          local argsJson = chatArgSummary(argsSnapshot, 6)
          local playersJson = chatPlayersSummaryJson()
          if chatUnresolvedCommandLogCount <= 20 or (chatUnresolvedCommandLogCount % 25) == 0 then
            appendLog("chat command sender unresolved path=" .. tostring(path) ..
              " command=" .. tostring(commandName) ..
              " contextKey=" .. tostring(contextKey) ..
              " context=" .. tostring(contextName) ..
              " args=" .. tostring(argsJson))
          end
          appendActionEvent("player_command", false, {}, "sender unresolved",
            '{"command":' .. js(commandName) ..
            ',"path":' .. js(path) ..
            ',"contextKey":' .. js(contextKey) ..
            ',"message":' .. js(message) ..
            ',"args":' .. tostring(argsJson) ..
            ',"players":' .. tostring(playersJson) .. '}')
        end)
        return
      end
      if info ~= nil and isCommand then
        local commandName = (splitWords(commandMessage)[1] or ""):lower()
        local queued, queueResult, depth = enqueuePlayerCommand(info, commandMessage, path, true)
        if not queued then
          deferGame(1, function()
            appendActionEvent("player_command_queue", false, info, tostring(queueResult or "Команда не поставлена в очередь."),
              '{"command":' .. js(commandName) .. ',"depth":' .. tostring(depth or 0) .. ',"source":"chat-hook"}')
            targetMessagePlayerCommandFailure(info, commandName, tostring(queueResult or "Команда не поставлена в очередь."))
          end)
        end
      end
    end)
  end)
  if okHook then
    chatHookStatus[path] = true
    appendLog("chat hook " .. tostring(path) .. "=ok")
    return
  end
  chatHookFailures[path] = (chatHookFailures[path] or 0) + 1
  if chatHookFailures[path] >= 90 then
    chatHookStatus[path] = false
    appendLog("chat hook " .. tostring(path) .. "=unavailable after " .. tostring(chatHookFailures[path]) .. " retries")
    return
  end
  if chatHookFailures[path] == 1 or (chatHookFailures[path] % 30) == 0 then
    appendLog("chat hook " .. tostring(path) .. "=pending retry " .. tostring(chatHookFailures[path]) .. " (" .. tostring(err) .. ")")
  end
end

function setupChatHooks()
  local paths = {
    "/Script/SCUM.PlayerRpcChannel:Chat_Server_ProcessAdminCommand",
    "/Script/SCUM.PlayerRpcChannel:Chat_Server_BroadcastChatMessage",
    "/Script/SCUM.PlayerRpcChannel:Chat_Server_SendMessageToChat",
    "/Script/ConZ.PlayerRpcChannel:Chat_Server_ProcessAdminCommand",
    "/Script/ConZ.PlayerRpcChannel:Chat_Server_BroadcastChatMessage",
    "/Script/ConZ.PlayerRpcChannel:Chat_Server_SendMessageToChat"
  }
  for _, path in ipairs(paths) do registerChatHook(path) end
end

killHookStatus = {}
killHookFailures = {}
killEventDedup = {}

function registerKillHook(path)
  if killHookStatus[path] == true then return end
  if killHookStatus[path] == false then return end
  local okHook, err = pcall(function()
    RegisterHook(path, function(context, target, killer)
      local victimDbId = dbIdText(target)
      local killerDbId = dbIdText(killer)
      if victimDbId == "" or killerDbId == "" or victimDbId == "0" or killerDbId == "0" then
        appendLog("kill hook unresolved ids path=" .. tostring(path) .. " target=" .. paramText(target) .. " killer=" .. paramText(killer))
        return
      end

      local now = os.time()
      local duplicateWindow = math.max(1, configNumber("server-kill-feed", { "DuplicateWindowSeconds", "duplicateWindowSeconds" }, 8))
      local dedupKey = killerDbId .. ">" .. victimDbId
      if killEventDedup[dedupKey] ~= nil and (now - killEventDedup[dedupKey]) <= duplicateWindow then return end
      killEventDedup[dedupKey] = now

      deferGame(1, function()
        local killerInfo = findPlayerByDbId(killerDbId)
        local victimInfo = findPlayerByDbId(victimDbId)
        local handled = handleKillEvent(killerInfo, victimInfo, {
          source = path,
          killerDbId = killerDbId,
          victimDbId = victimDbId
        })
        appendLog("kill hook " .. tostring(path) .. " killerDbId=" .. tostring(killerDbId) .. " victimDbId=" .. tostring(victimDbId) .. " handled=" .. tostring(handled))
      end)
    end)
  end)
  if okHook then
    killHookStatus[path] = true
    appendLog("kill hook " .. tostring(path) .. "=ok")
    return
  end
  killHookFailures[path] = (killHookFailures[path] or 0) + 1
  if killHookFailures[path] >= 90 then
    killHookStatus[path] = false
    appendLog("kill hook " .. tostring(path) .. "=unavailable after " .. tostring(killHookFailures[path]) .. " retries")
    return
  end
  if killHookFailures[path] == 1 or (killHookFailures[path] % 30) == 0 then
    appendLog("kill hook " .. tostring(path) .. "=pending retry " .. tostring(killHookFailures[path]) .. " (" .. tostring(err) .. ")")
  end
end

function registerPlayerRpcKillHook(path)
  if killHookStatus[path] == true then return end
  if killHookStatus[path] == false then return end
  local okHook, err = pcall(function()
    RegisterHook(path, function(context, victimParam, killerParam, killerProfileParam)
      local victimObject = unwrapHookParam(victimParam)
      local killerObject = unwrapHookParam(killerParam)
      local victimKey = objectKey(victimObject)
      local killerKey = objectKey(killerObject)
      local killerProfileText = paramText(killerProfileParam)
      local now = os.time()
      local duplicateWindow = math.max(1, configNumber("server-kill-feed", { "DuplicateWindowSeconds", "duplicateWindowSeconds" }, 4))
      local dedupKey = "rpc:" .. tostring(killerKey) .. ">" .. tostring(victimKey)
      if dedupKey ~= "rpc:>" and killEventDedup[dedupKey] ~= nil and (now - killEventDedup[dedupKey]) <= duplicateWindow then return end
      killEventDedup[dedupKey] = now

      deferGame(1, function()
        local infos = cachedPlayerInfos(math.max(10, configNumber("bridge-safety", { "PlayerInfoCacheTtlSeconds", "playerInfoCacheTtlSeconds" }, 300))) or {}
        local victimInfo = findPlayerByLinkedObject(victimObject, infos)
        local killerInfo = findPlayerByLinkedObject(killerObject, infos)
        local handled = false
        if killerInfo ~= nil and victimInfo ~= nil and playerStateKey(killerInfo) ~= playerStateKey(victimInfo) then
          handled = handleKillEvent(killerInfo, victimInfo, { source = path, victimObjectKey = victimKey, killerObjectKey = killerKey, killerProfile = killerProfileText })
        else
          handled = handleDeathEvent(victimInfo, { source = path, victimObjectKey = victimKey, killerObjectKey = killerKey, killerProfile = killerProfileText })
        end
        appendLog("player-rpc kill hook " .. tostring(path) .. " killerKey=" .. tostring(killerKey) .. " victimKey=" .. tostring(victimKey) .. " handled=" .. tostring(handled))
      end)
    end)
  end)
  if okHook then
    killHookStatus[path] = true
    appendLog("player-rpc kill hook " .. tostring(path) .. "=ok")
    return
  end
  killHookFailures[path] = (killHookFailures[path] or 0) + 1
  if killHookFailures[path] >= 90 then
    killHookStatus[path] = false
    appendLog("player-rpc kill hook " .. tostring(path) .. "=unavailable after " .. tostring(killHookFailures[path]) .. " retries")
    return
  end
  if killHookFailures[path] == 1 or (killHookFailures[path] % 30) == 0 then
    appendLog("player-rpc kill hook " .. tostring(path) .. "=pending retry " .. tostring(killHookFailures[path]) .. " (" .. tostring(err) .. ")")
  end
end

function setupKillHooks()
  local useRuntimeHooks = configBool("server-kill-feed", { "UseRuntimeHooks", "useRuntimeHooks" }, false)
  if not useRuntimeHooks then
    if not KILL_HOOKS_DISABLED_LOGGED then
      appendLog("kill hooks disabled; server kill feed is expected to use native SaveFiles log parser")
      KILL_HOOKS_DISABLED_LOGGED = true
    end
    return
  end
  local paths = {
    "/Script/SCUM.ConZGameState:Multicast_AddToOrUpdatePrisonerKillRegistry",
    "/Script/SCUM.BP_ConZGameState_C:Multicast_AddToOrUpdatePrisonerKillRegistry",
    "/Script/ConZ.ConZGameState:Multicast_AddToOrUpdatePrisonerKillRegistry",
    "/Script/ConZ.BP_ConZGameState_C:Multicast_AddToOrUpdatePrisonerKillRegistry"
  }
  for _, path in ipairs(paths) do registerKillHook(path) end
  local rpcPaths = {
    "/Script/SCUM.PlayerRpcChannel:Misc_Server_LogKill",
    "/Script/ConZ.PlayerRpcChannel:Misc_Server_LogKill"
  }
  for _, path in ipairs(rpcPaths) do registerPlayerRpcKillHook(path) end
end

mkdir(BRIDGE_DIR)
mkdir(PRODUCT_DIR)
mkdir(STATE_DIR)
mkdir(CONFIG_DIR)
mkdir(CONFIG_LIVE_DIR)
mkdir(LANG_DIR)
ensureLanguageDefaults()
ensurePermissionDefaults()
appendLog("ScumNeDjinBridge started")
setupChatHooks()
setupKillHooks()

BRIDGE_LOOP_HANDLES = BRIDGE_LOOP_HANDLES or {}

function safeLoop(name, intervalMs, fn)
  local function runLoopBody()
    local okLoop, err = pcall(fn)
    if not okLoop then appendLog("loop " .. tostring(name) .. " error: " .. tostring(err)) end
  end

  if LoopInGameThreadWithDelay ~= nil then
    local okLoop, handleOrErr = pcall(function()
      return LoopInGameThreadWithDelay(intervalMs, runLoopBody)
    end)
    if okLoop then
      BRIDGE_LOOP_HANDLES[tostring(name)] = handleOrErr
      appendLog("loop " .. tostring(name) .. " started via LoopInGameThreadWithDelay")
      return true
    end
    appendLog("LoopInGameThreadWithDelay failed for " .. tostring(name) .. ": " .. tostring(handleOrErr))
  end

  LoopAsync(intervalMs, function()
    runLoopBody()
    return false
  end)
  appendLog("loop " .. tostring(name) .. " started via LoopAsync fallback")
  return true
end

function safeAsyncLoop(name, intervalMs, fn)
  local function runLoopBody()
    local okLoop, err = pcall(fn)
    if not okLoop then appendLog("async loop " .. tostring(name) .. " error: " .. tostring(err)) end
  end

  LoopAsync(intervalMs, function()
    runLoopBody()
    return false
  end)
  appendLog("async loop " .. tostring(name) .. " started via LoopAsync")
  return true
end

safeAsyncLoop("heartbeat", 2000, function()
  touchHeartbeat(true)
end)

if configBool("bridge-safety", { "EnableHookRefreshLoop", "enableHookRefreshLoop" }, false) then
  safeLoop("hook-refresh", 60000, function()
    setupChatHooks()
    setupKillHooks()
  end)
else
  appendLog("loop hook-refresh disabled by bridge-safety")
end

PLAYER_INFO_REFRESH_PENDING = PLAYER_INFO_REFRESH_PENDING or false

if configBool("bridge-safety", { "EnableRuntimeCacheLoop", "enableRuntimeCacheLoop" }, false) then
  PLAYER_INFO_CACHE_INTERVAL_MS = math.max(15000, configNumber("bridge-safety", { "RuntimeCacheIntervalMs", "runtimeCacheIntervalMs" }, 30000))
  safeLoop("player-info-cache", PLAYER_INFO_CACHE_INTERVAL_MS, function()
    if PLAYER_INFO_REFRESH_PENDING then return end
    PLAYER_INFO_REFRESH_PENDING = true
    deferGame(1, function()
      local okRefresh, refreshErr = pcall(refreshPlayerInfoCache)
      PLAYER_INFO_REFRESH_PENDING = false
      if not okRefresh then appendLog("player-info-cache refresh failed: " .. tostring(refreshErr)) end
    end)
  end)
else
  appendLog("loop player-info-cache disabled by bridge-safety")
end

if configBool("bridge-safety", { "EnableRentalCleanupLoop", "enableRentalCleanupLoop" }, false) then
  RENTAL_CLEANUP_INTERVAL_MS = math.max(30000, configNumber("bridge-safety", { "RentalCleanupIntervalMs", "rentalCleanupIntervalMs" }, 60000))
  safeLoop("rental-cleanup", RENTAL_CLEANUP_INTERVAL_MS, function()
    cleanupExpiredRentals()
  end)
else
  appendLog("loop rental-cleanup disabled by bridge-safety")
end

safeLoop("mutation-queue", 1000, function()
  drainMutationQueue()
end)

safeLoop("player-command-queue", 500, function()
  drainPlayerCommandQueue()
end)

safeAsyncLoop("chat-event-write-queue", 500, function()
  drainChatEventWriteQueue(10)
end)

safeAsyncLoop("scum-chat-log-import", 5000, function()
  importScumChatLog()
end)

safeAsyncLoop("scum-kill-log-import", math.max(3000, configNumber("server-kill-feed", { "ImportIntervalMs", "importIntervalMs", "KillLogImportIntervalMs", "killLogImportIntervalMs" }, 5000)), function()
  importScumKillLog()
end)

safeAsyncLoop("state-write-queue", 500, function()
  drainStateWriteQueue(10)
end)

COMMAND_POLL_BUSY = COMMAND_POLL_BUSY or false
safeAsyncLoop("command-poll", 1000, function()
  if COMMAND_POLL_BUSY then return end
  local text = readAll(COMMAND_FILE)
  if text ~= nil and #text > 0 then
    removeFile(COMMAND_FILE)
    COMMAND_POLL_BUSY = true
    deferGame(1, function()
      local okTask, taskErr = pcall(function()
        local okRoute, result = pcall(function() return route(text) end)
        if okRoute then
          if result ~= nil then writeAll(RESULT_FILE, result) end
        else
          appendLog("route error: " .. tostring(result))
          writeAll(RESULT_FILE, fail("unknown", tostring(result), CURRENT_BRIDGE_RESULT_ID))
        end
      end)
      COMMAND_POLL_BUSY = false
      if not okTask then
        appendLog("command-poll task failed: " .. tostring(taskErr))
        writeAll(RESULT_FILE, fail("unknown", tostring(taskErr), CURRENT_BRIDGE_RESULT_ID))
      end
    end)
  end
end)

