const state = {
  apiKey: localStorage.getItem('nedjin.apiKey.v2') || 'CHANGE_ME_STRONG_PANEL_KEY',
  apiBase: localStorage.getItem('nedjin.apiBase.v2') || '',
  page: 'servers',
  servers: [],
  players: [],
  squads: [],
  chat: [],
  kills: [],
  homes: [],
  welcomeTimers: [],
  welcomeClaims: [],
  downloads: [],
  items: [],
  vehicles: [],
  skillCatalog: [],
  itemIcons: {},
  itemIconLookup: new Map(),
  itemBatch: [],
  wargmItems: [],
  map: null,
  modules: [],
  selectedModule: null,
  moduleDraft: null,
  mapZoom: 1,
  mapSelection: null,
  selectedPlayerTarget: null,
  playerInventory: {},
  playerFacts: {},
  inventoryRefreshToken: 0,
  playersRefreshInFlight: null,
  playersLastRefreshedAt: 0,
  hiddenRuntimePlayers: 0,
  actionLog: [],
  lastCatalogInput: null,
  catalogMode: 'items',
  catalogSearch: '',
  catalogCategory: '',
  catalogPage: 0,
  catalogSelected: null,
  serviceTab: 'player',
  wargmRuleEditIndex: null,
  language: localStorage.getItem('nedjin.language.v1') || 'ru'
};

const STATIC_ASSET_VERSION = '20260510_player_rental_fix';

function normalizeApiBase(input) {
  let value = String(input || '').trim();
  if (!value) return '';
  if (!/^https?:\/\//i.test(value)) value = `http://${value}`;
  try {
    const url = new URL(value, window.location.origin);
    url.hash = '';
    url.search = '';
    url.pathname = url.pathname.replace(/\/(?:panel|index)\.html$/i, '/');
    url.pathname = url.pathname.replace(/\/+$/, '');
    return url.pathname && url.pathname !== '/' ? `${url.origin}${url.pathname}` : url.origin;
  } catch (_) {
    return '';
  }
}

state.apiBase = normalizeApiBase(state.apiBase);

const els = {};
for (const el of document.querySelectorAll('[id]')) els[el.id] = el;
if (!els.saveApiKey && els.connectBtn) els.saveApiKey = els.connectBtn;
if (els.serverHost && !els.serverHost.value) els.serverHost.value = state.apiBase || window.location.origin;

const panelI18n = {
  ru: {
    platform: 'Платформа',
    bridge: 'мост',
    players: 'игроки',
    checking: 'проверка...',
    online: 'в сети',
    offline: 'не в сети',
    noConnection: 'нет связи',
    readable: 'читается',
    missing: 'не найдена',
    connectedHost: 'подключённая площадка',
    pages: {
      servers: 'Серверы',
      players: 'Игроки',
      map: 'Живая карта',
      squads: 'Отряды',
      chat: 'Чат',
      kills: 'Убийства',
      modules: 'Плагины',
      services: 'Сервисы',
      console: 'Консоль',
      downloads: 'Загрузки',
      diagnostics: 'Диагностика'
    }
  },
  en: {
    platform: 'Platform',
    bridge: 'bridge',
    players: 'players',
    checking: 'checking...',
    online: 'online',
    offline: 'offline',
    noConnection: 'no connection',
    readable: 'readable',
    missing: 'missing',
    connectedHost: 'connected host',
    pages: {
      servers: 'Servers',
      players: 'Players',
      map: 'Live map',
      squads: 'Squads',
      chat: 'Chat',
      kills: 'Kills',
      modules: 'Plugins',
      services: 'Services',
      console: 'Console',
      downloads: 'Downloads',
      diagnostics: 'Diagnostics'
    }
  }
};

function t(key, fallback) {
  const lang = panelI18n[state.language] ? state.language : 'ru';
  const parts = String(key || '').split('.');
  let value = panelI18n[lang];
  for (const part of parts) value = value && value[part];
  if (value == null && lang !== 'ru') {
    value = panelI18n.ru;
    for (const part of parts) value = value && value[part];
  }
  return value == null ? (fallback || key) : value;
}

function setPanelLanguage(language) {
  state.language = panelI18n[language] ? language : 'ru';
  localStorage.setItem('nedjin.language.v1', state.language);
  document.documentElement.lang = state.language;
  if (els.panelLanguage) els.panelLanguage.value = state.language;
  const title = t(`pages.${state.page}`, state.page);
  if (els.pageTitle) els.pageTitle.textContent = title;
  if (els.crumb) els.crumb.textContent = `${t('platform', 'Платформа')} / ${title}`;
}

function api(path, opts = {}) {
  if (!hasUsableApiKey() && path !== '/api/health') {
    return Promise.reject(new Error('API ключ не задан.'));
  }
  const headers = Object.assign({ 'X-API-KEY': state.apiKey }, opts.headers || {});
  if (opts.body && !(opts.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const base = normalizeApiBase(state.apiBase);
  const url = base && /^https?:\/\//i.test(base) ? `${base}${path}` : path;
  return fetch(url, Object.assign({}, opts, { headers, cache: 'no-store' }))
    .then(async res => {
      const text = await res.text();
      const data = text ? JSON.parse(text) : {};
      if (!res.ok || data.ok === false) throw new Error(data.error || `${res.status} ${res.statusText}`);
      return data.data;
    });
}

function hasUsableApiKey() {
  return !!(state.apiKey && !/^CHANGE_ME/i.test(String(state.apiKey)));
}

function fetchStaticJson(path) {
  const separator = path.includes('?') ? '&' : '?';
  return fetch(`${path}${separator}v=${STATIC_ASSET_VERSION}`, { cache: 'force-cache' })
    .then(res => res.ok ? res.json() : null)
    .catch(() => null);
}

function showResult(el, value) {
  if (!el) return;
  if (typeof value === 'string') {
    el.textContent = value;
    return;
  }
  if (el.classList && el.classList.contains('profile-result') && value && typeof value === 'object') {
    const primary = value.message || value.error || value.result;
    if (primary) {
      el.textContent = String(primary);
      return;
    }
  }
  el.textContent = JSON.stringify(value, null, 2);
}

async function showActionResult(el, action) {
  try {
    showResult(el, 'Выполняется...');
    showResult(el, await action());
  } catch (err) {
    showResult(el, { ok: false, error: err && err.message ? err.message : String(err) });
  }
}

function sleep(ms) {
  return new Promise(resolve => window.setTimeout(resolve, ms));
}

function fmtTime(value) {
  if (!value) return '';
  const dt = new Date(value);
  return Number.isNaN(dt.getTime()) ? String(value) : dt.toLocaleString();
}

function unwrapCatalogData(data, key) {
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data[key])) return data[key];
  if (data && data.data && Array.isArray(data.data[key])) return data.data[key];
  if (data && data.payload && Array.isArray(data.payload[key])) return data.payload[key];
  return [];
}

function normalizeCatalogEntry(entry, kind) {
  const id = kind === 'vehicle'
    ? (entry.vehicleId || entry.assetName || entry.AssetName || entry.id || '')
    : (entry.itemId || entry.ItemId || entry.runtimeId || entry.id || entry.itemName || '');
  const name = entry.name || entry.displayName || entry.DisplayName || entry.itemName || id;
  const assetPath = entry.assetPath || entry.AssetPath || entry.relativePath || '';
  const classPath = entry.classPath || entry.ClassPath || '';
  const runtimeId = entry.runtimeId || entry.RuntimeId || classPath || id;
  return Object.assign({}, entry, {
    itemId: kind === 'item' ? id : undefined,
    vehicleId: kind === 'vehicle' ? id : undefined,
    assetPath,
    classPath,
    runtimeId,
    name,
    category: entry.category || entry.Category || (kind === 'vehicle' ? 'Транспорт' : 'Другое')
  });
}

function normalizeLookup(value) {
  return String(value || '')
    .trim()
    .replace(/^.*[:/\\]/, '')
    .replace(/^.*\./, '')
    .replace(/_C$/i, '')
    .replace(/_ES$/i, '')
    .replace(/[^a-z0-9]+/gi, '')
    .toLowerCase();
}

function iconLookupKeys(value) {
  const raw = String(value || '').trim();
  if (!raw) return [];
  const cleaned = cleanAssetId(raw);
  return Array.from(new Set([
    raw,
    raw.toLowerCase(),
    cleaned,
    cleaned.toLowerCase(),
    normalizeLookup(raw),
    normalizeLookup(cleaned)
  ].filter(Boolean)));
}

function buildItemIconLookup(manifest) {
  const icons = manifest && manifest.icons && typeof manifest.icons === 'object' ? manifest.icons : {};
  state.itemIcons = icons;
  state.itemIconLookup = new Map();
  for (const [key, url] of Object.entries(icons)) {
    if (!url) continue;
    for (const variant of iconLookupKeys(key)) {
      if (!state.itemIconLookup.has(variant)) state.itemIconLookup.set(variant, url);
    }
  }
}

function getItemIconUrl(value) {
  for (const key of iconLookupKeys(value)) {
    const url = state.itemIconLookup.get(key);
    if (url) return url;
  }
  return '';
}

function getCatalogIconUrl(entry, kind) {
  if (kind !== 'item') return '';
  const probes = [
    entry.itemId,
    entry.id,
    entry.runtimeId,
    entry.classPath,
    entry.assetPath,
    entry.itemClass,
    entry.name,
    entry.displayName
  ];
  for (const probe of probes) {
    const url = getItemIconUrl(probe);
    if (url) return url;
  }
  return '';
}

function cleanAssetId(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  return raw
    .replace(/^.*[:/\\]/, '')
    .replace(/^.*\./, '')
    .replace(/_C$/i, '')
    .replace(/_ES$/i, '');
}

function findCatalogMatch(value, kind = 'item') {
  const list = kind === 'vehicle' ? state.vehicles : state.items;
  const needle = normalizeLookup(value);
  if (!needle) return null;
  return (list || []).find(entry => {
    const id = kind === 'vehicle' ? (entry.vehicleId || entry.assetName || entry.AssetName || entry.id) : (entry.itemId || entry.runtimeId || entry.id);
    return [id, entry.name, entry.displayName, entry.runtimeId, entry.classPath]
      .some(candidate => normalizeLookup(candidate) === needle);
  }) || null;
}

function friendlyAssetName(value, kind = 'item') {
  const match = findCatalogMatch(value, kind);
  return match ? (match.name || match.displayName || value) : (cleanAssetId(value) || value || '-');
}

function catalogValue(entry, kind) {
  return kind === 'vehicle'
    ? (entry.vehicleId || entry.assetName || entry.AssetName || entry.id || '')
    : (entry.itemId || entry.runtimeId || entry.id || '');
}

function catalogIdFor(entry, kind) {
  return catalogValue(entry || {}, kind);
}

function shortCode(value, fallback = 'IT') {
  const words = String(value || fallback).replace(/[_-]+/g, ' ').trim().split(/\s+/).filter(Boolean);
  const code = words.length > 1 ? words.slice(0, 2).map(word => word[0]).join('') : String(words[0] || fallback).slice(0, 3);
  return code.toUpperCase();
}

const configLabels = {
  Enabled: 'Включено',
  RequiredPermission: 'Требуемое право',
  CooldownHours: 'Кулдаун, ч',
  SuccessMessage: 'Сообщение при успехе',
  SerializeClaimsGlobally: 'Выдавать по одному игроку за раз',
  InterItemDelayMs: 'Пауза между предметами, мс',
  Items: 'Предметы',
  ItemId: 'ID предмета',
  Quantity: 'Количество',
  DefaultAttributes: 'Атрибуты по умолчанию',
  Strength: 'Сила',
  Constitution: 'Телосложение',
  Dexterity: 'Ловкость',
  Intelligence: 'Интеллект',
  SkillPresets: 'Пресеты навыков',
  Packs: 'Пакеты персонажа',
  Actions: 'Действия',
  Name: 'Название',
  Description: 'Описание',
  Level: 'Уровень',
  Experience: 'Опыт',
  TransferCooldownMinutes: 'Кулдаун перемещения, мин',
  RatePerMeter: 'Цена за метр',
  FixedFare: 'Фиксированная цена',
  TeleportDelaySeconds: 'Задержка телепорта, сек',
  TravelConfirmationSeconds: 'Время подтверждения, сек',
  CancelMoveDistance: 'Отмена при движении, см',
  SuccessArrivalDistance: 'Радиус успешного прибытия',
  Outposts: 'Маршруты',
  DisplayName: 'Название',
  CommandAlias: 'Команда',
  CenterZone: 'Центр зоны',
  ArrivalPoint: 'Точка прибытия',
  Price: 'Цена маршрута',
  MaxHomes: 'Лимит домов',
  DefaultMaxHomes: 'Домов обычному игроку',
  VipMaxHomes: 'Домов VIP-игроку',
  VipPermission: 'Право VIP',
  HomeCooldownSeconds: 'Кулдаун дома, сек',
  Vehicles: 'Транспорт',
  Alias: 'Команда',
  AssetName: 'ID транспорта',
  PricePer10Minutes: 'Цена / 10 мин',
  InitialCharge: 'Стартовая цена',
  DefaultRentalMinutes: 'Время по умолчанию, мин',
  MinRentalMinutes: 'Минимальное время, мин',
  MaxRentalMinutes: 'Максимальное время, мин',
  DefaultMinutes: 'Время по умолчанию, мин',
  MinMinutes: 'Минимум минут',
  MaxMinutes: 'Максимум минут',
  ChargePenaltyOnMissingVehicle: 'Штрафовать за пропавший транспорт',
  DefaultMissingVehiclePenalty: 'Штраф по умолчанию',
  MissingVehiclePenalty: 'Штраф за продажу/потерю',
  WarningMinutesBeforeExpiry: 'Предупреждения до конца аренды, мин',
  ProjectId: 'ID проекта',
  ApiKey: 'API ключ',
  WargmServerId: 'ID сервера Wargm',
  PollIntervalSeconds: 'Интервал опроса, сек',
  DeliveryDelaySeconds: 'Задержка выдачи, сек',
  RetryDelaySeconds: 'Повтор через, сек',
  MaxDeliveryAttempts: 'Попыток выдачи',
  DeliveryFilter: 'Фильтр выдачи',
  RequireRecipientName: 'Требовать имя получателя',
  DeliverOnlyToOnlinePlayers: 'Выдавать только онлайн',
  AnnounceBeforeDelivery: 'Сообщать перед выдачей',
  AnnouncementTemplate: 'Шаблон объявления',
  BroadcastDeliveries: 'Сообщать всем о выдаче',
  AllowUnsafeCommandDelivery: 'Разрешить командную выдачу',
  UnsafeCommandInterItemDelayMs: 'Пауза между предметами, мс',
  UnsafeCommandInterOperationCooldownSeconds: 'Пауза между операциями, сек',
  UnsafeCommandMaxItemsPerOperation: 'Макс. предметов за операцию',
  UnsafeCommandMaxQuantityPerItem: 'Макс. количество предмета',
  UseClaimInsteadOfSuccess: 'Использовать claim вместо success',
  Rules: 'Правила',
  MatchOfferId: 'ID предложения',
  MatchTitleContains: 'Название содержит',
  DeliveryMode: 'Режим выдачи',
  DeliveryLabel: 'Метка выдачи',
  VehicleAsset: 'ID транспорта',
  Amount: 'Сумма',
  SkillName: 'Навык',
  SkillLevel: 'Уровень навыка',
  SkillExperience: 'Опыт навыка',
  CommandTemplate: 'Шаблон команды',
  ScanCost: 'Цена скана',
  CooldownSeconds: 'Кулдаун, сек',
  IncludeSelf: 'Считать самого игрока',
  IncludePlayerNames: 'Показывать имена игроков',
  MaxListedNames: 'Макс. имён в ответе',
  EmptyMessage: 'Сообщение пустого сектора',
  NotEnoughMoneyMessage: 'Сообщение нехватки денег',
  CooldownMessage: 'Сообщение кулдауна',
  BroadcastThreshold: 'Порог объявления',
  HeroThreshold: 'Порог героя',
  MaxBoardEntries: 'Строк в таблице',
  LeaderKillRewardMode: 'Режим награды за лидера',
  LeaderKillRewardAmount: 'Сумма награды за лидера',
  BroadcastLeaderKillReward: 'Объявлять награду за лидера',
  Prefix: 'Префикс сообщений',
  Source: 'Источник данных',
  UseRuntimeHooks: 'Использовать live-хуки',
  AnnounceSuicides: 'Показывать самоубийства',
  IncludeDistance: 'Показывать дистанцию',
  IncludeWeapon: 'Показывать оружие',
  FanoutToPlayers: 'Рассылать игрокам',
  TransportMode: 'Режим отправки',
  ServerLabel: 'Название сервера',
  GuildId: 'ID Discord-сервера',
  DefaultChannelId: 'Канал по умолчанию',
  PresenceChannelId: 'Канал входов/выходов',
  ChatChannelId: 'Канал чата',
  CombatChannelId: 'Канал боёв',
  SystemChannelId: 'Системный канал',
  DefaultWebhookUrl: 'Webhook по умолчанию',
  PresenceWebhookUrl: 'Webhook входов/выходов',
  ChatWebhookUrl: 'Webhook чата',
  CombatWebhookUrl: 'Webhook боёв',
  SystemWebhookUrl: 'Webhook системы',
  Username: 'Имя бота',
  AvatarUrl: 'Аватар',
  NotifyOnLoad: 'Сообщать о загрузке',
  NotifyPlayerConnected: 'Игрок вошёл',
  NotifyPlayerDisconnected: 'Игрок вышел',
  NotifyPlayerRespawned: 'Игрок возродился',
  NotifyPlayerChat: 'Писать чат',
  NotifyPlayerKills: 'Писать убийства',
  NotifyPlayerDeaths: 'Писать смерти',
  IncludeSteamId: 'Показывать SteamID',
  IgnoreSlashCommands: 'Игнорировать slash-команды',
  IgnoredChatPrefixes: 'Игнорируемые префиксы чата',
  ForwardLocalChat: 'Пересылать локальный чат',
  ForwardGlobalChat: 'Пересылать глобальный чат',
  ForwardSquadChat: 'Пересылать чат отряда',
  ForwardAdminChat: 'Пересылать админ-чат',
  MinPostIntervalMs: 'Минимальная пауза, мс',
  MaxQueueLength: 'Макс. очередь',
  DuplicateWindowSeconds: 'Окно дублей, сек',
  UsePermission: 'Проверять право',
  AllowPermission: 'Право доступа',
  UseCooldown: 'Включить кулдаун',
  CooldownTimeSeconds: 'Кулдаун, сек',
  EnableLogging: 'Вести лог',
  EnableHistory: 'Хранить историю',
  Permission: 'Право доступа',
  Aliases: 'Дополнительные команды',
  Type: 'Тип действия',
  Value: 'Команда или значение',
  StopOnFailure: 'Остановить при ошибке',
  TeleportCooldownMinutes: 'Кулдаун телепорта, мин',
  ImportSaveFileKillLog: 'Читать журнал убийств',
  KillLogImportIntervalMs: 'Проверять журнал, мс',
  IncludeLocations: 'Показывать координаты',
  HttpTimeoutSeconds: 'Таймаут HTTP, сек',
  EnableRuntimeVehicleReturnDestroy: 'Удалять при возврате',
  EnableRuntimeVehicleExpireDestroy: 'Удалять по окончании',
  EnableRuntimeVehicleTrackAfterSpawn: 'Отслеживать после спавна',
  CaptureVehiclesBeforeSpawn: 'Снимать снимок перед спавном',
  ExpireDestroyMaxAttempts: 'Попыток удаления',
  RuntimeDestroyResolveCooldownSeconds: 'Пауза поиска транспорта, сек',
  CleanupMaxPerRun: 'Удалений за проход',
  RefreshPlayerBeforeVehicleSpawn: 'Обновлять игрока перед спавном',
  GlobalSpawnCooldownSeconds: 'Общий кулдаун спавна, сек',
  PlayerSpawnCooldownSeconds: 'Кулдаун игрока, сек',
  MaxRunsPerTick: 'Макс. заданий за тик',
  Jobs: 'Задания',
  Points: 'Точки карты',
  ItemSets: 'Наборы предметов',
  Mode: 'Тип задания',
  IntervalMinutes: 'Период, мин',
  RunOnStartup: 'Запустить при старте',
  PointGroup: 'Группа точек',
  ItemSet: 'Набор предметов',
  Announcement: 'Сообщение в чат',
  MaxItemsPerRun: 'Макс. предметов за запуск',
  Group: 'Группа',
  X: 'X',
  Y: 'Y',
  Z: 'Z',
  Radius: 'Радиус',
  Weight: 'Вес выбора',
  ItemsText: 'Предметы набора'
};

const selectLabels = {
  SpawnItem: 'Предмет',
  Vehicle: 'Транспорт',
  Money: 'Баланс',
  Gold: 'Золото',
  Fame: 'Очки славы',
  Attributes: 'Атрибуты',
  Skill: 'Навык',
  AllSkills: 'Все навыки',
  PlayerCommand: 'Команда игроку',
  ServerCommand: 'Команда серверу',
  Airdrop: 'Cargo drop',
  SpawnItems: 'Спавн набора',
  Command: 'Админ-команда'
};

const FULL_SCUM_SKILLS = [
  { skill: 'Resistance', name: 'Resistance', category: 'Physical' },
  { skill: 'Brawling', name: 'Brawling', category: 'Combat' },
  { skill: 'Awareness', name: 'Awareness', category: 'Support' },
  { skill: 'Rifles', name: 'Rifles', category: 'Combat' },
  { skill: 'Sniping', name: 'Sniping', category: 'Combat' },
  { skill: 'Camouflage', name: 'Camouflage', category: 'Survival' },
  { skill: 'Survival', name: 'Survival', category: 'Survival' },
  { skill: 'Melee Weapons', name: 'Melee Weapons', category: 'Combat' },
  { skill: 'Handgun', name: 'Handgun', category: 'Combat' },
  { skill: 'Running', name: 'Running', category: 'Physical' },
  { skill: 'Endurance', name: 'Endurance', category: 'Physical' },
  { skill: 'Tactics', name: 'Tactics', category: 'Combat' },
  { skill: 'Cooking', name: 'Cooking', category: 'Survival' },
  { skill: 'Thievery', name: 'Thievery', category: 'Support' },
  { skill: 'Archery', name: 'Archery', category: 'Combat' },
  { skill: 'Driving', name: 'Driving', category: 'Vehicle' },
  { skill: 'Engineering', name: 'Engineering', category: 'Craft' },
  { skill: 'Demolition', name: 'Demolition', category: 'Craft' },
  { skill: 'Medical', name: 'Medical', category: 'Support' },
  { skill: 'Motorcycling', name: 'Motorcycling', category: 'Vehicle' },
  { skill: 'Stealth', name: 'Stealth', category: 'Physical' },
  { skill: 'Aviation', name: 'Aviation', category: 'Vehicle' },
  { skill: 'Farming', name: 'Farming', category: 'Survival' }
];

function mergeSkillCatalog(skills) {
  const rows = Array.isArray(skills) ? skills.slice() : [];
  const seen = new Set(rows.map(skill => String(skill.key || skill.skill || skill.name || '').toLowerCase().replace(/[\s_"'-]+/g, '')));
  for (const skill of FULL_SCUM_SKILLS) {
    const key = String(skill.skill || skill.name || '').toLowerCase().replace(/[\s_"'-]+/g, '');
    if (!seen.has(key)) {
      rows.push(skill);
      seen.add(key);
    }
  }
  return rows;
}

function isAllSkillsValue(value) {
  return ['allskills', 'allskill', 'fullskills', 'maxskills', 'всенавыки', 'все'].includes(
    String(value || '').trim().toLowerCase().replace(/[\s_"'.-]+/g, '')
  );
}

function skillOptionHtml(skill) {
  return `<option value="${escapeAttr(skill.key || skill.skill || skill.name || '')}">${escapeHtml(skill.name || skill.category || skill.key || '')}</option>`;
}

function configLabel(key) {
  if (configLabels[key]) return configLabels[key];
  const match = Object.keys(configLabels).find(labelKey => labelKey.toLowerCase() === String(key).toLowerCase());
  if (match) return configLabels[match];
  return humanConfigLabel(key);
}

const configWordLabels = {
  enabled: 'включено',
  enable: 'включить',
  disabled: 'выключено',
  name: 'название',
  title: 'название',
  description: 'описание',
  message: 'сообщение',
  success: 'успех',
  error: 'ошибка',
  warning: 'предупреждение',
  cooldown: 'кулдаун',
  delay: 'задержка',
  inter: 'между',
  interval: 'интервал',
  ms: 'мс',
  seconds: 'сек',
  second: 'сек',
  minutes: 'мин',
  minute: 'мин',
  hours: 'ч',
  hour: 'ч',
  max: 'макс.',
  min: 'мин.',
  default: 'по умолчанию',
  serialize: 'сохранять',
  globally: 'глобально',
  claim: 'получение',
  claims: 'получения',
  required: 'обязательно',
  permission: 'право',
  player: 'игрок',
  players: 'игроки',
  steam: 'Steam',
  steamid: 'SteamID',
  id: 'ID',
  api: 'API',
  key: 'ключ',
  token: 'токен',
  url: 'URL',
  http: 'HTTP',
  timeout: 'таймаут',
  webhook: 'Webhook',
  channel: 'канал',
  discord: 'Discord',
  server: 'сервер',
  source: 'источник',
  prefix: 'префикс',
  use: 'использовать',
  runtime: 'runtime',
  hook: 'хук',
  hooks: 'хуки',
  broadcast: 'объявлять',
  fanout: 'рассылка',
  duplicate: 'дубликат',
  window: 'окно',
  threshold: 'порог',
  board: 'таблица',
  entries: 'записи',
  entry: 'запись',
  hero: 'герой',
  leader: 'лидер',
  kill: 'убийство',
  kills: 'убийства',
  death: 'смерть',
  deaths: 'смерти',
  suicide: 'самоубийство',
  suicides: 'самоубийства',
  weapon: 'оружие',
  distance: 'дистанция',
  reward: 'награда',
  rewards: 'награды',
  item: 'предмет',
  items: 'предметы',
  vehicle: 'транспорт',
  vehicles: 'транспорт',
  amount: 'сумма',
  price: 'цена',
  cost: 'стоимость',
  money: 'деньги',
  gold: 'золото',
  skill: 'навык',
  skills: 'навыки',
  attributes: 'атрибуты',
  strength: 'сила',
  constitution: 'телосложение',
  dexterity: 'ловкость',
  intelligence: 'интеллект',
  command: 'команда',
  commands: 'команды',
  template: 'шаблон',
  queue: 'очередь',
  length: 'длина',
  limit: 'лимит',
  route: 'маршрут',
  routes: 'маршруты',
  point: 'точка',
  points: 'точки',
  home: 'дом',
  homes: 'дома',
  vip: 'VIP',
  rental: 'аренда',
  rent: 'аренда',
  penalty: 'штраф',
  missing: 'потеря',
  scan: 'скан',
  include: 'показывать',
  ignore: 'игнорировать',
  notify: 'уведомлять',
  forward: 'пересылать',
  filter: 'фильтр',
  mode: 'режим',
  type: 'тип',
  label: 'метка',
  count: 'количество',
  quantity: 'количество'
};

function humanConfigLabel(key) {
  const raw = String(key || '').trim();
  if (!raw) return '';
  const words = raw
    .replace(/\./g, ' ')
    .replace(/[_-]+/g, ' ')
    .replace(/([a-zа-я0-9])([A-ZА-Я])/g, '$1 $2')
    .split(/\s+/)
    .filter(Boolean);
  const translated = words.map(word => {
    const normalized = word.toLowerCase().replace(/[^a-zа-я0-9]/gi, '');
    return configWordLabels[normalized] || word;
  });
  return translated.join(' ').replace(/^./, letter => letter.toUpperCase());
}

function selectOptionLabel(value) {
  return selectLabels[value] || value;
}

function categorySymbol(entry, kind) {
  if (kind === 'vehicle') return 'CAR';
  const text = String(entry.category || entry.name || entry.itemId || '').toLowerCase();
  if (/weapon|rifle|pistol|shotgun|bow|melee/.test(text)) return 'WPN';
  if (/ammo|magazine|bullet|cartridge/.test(text)) return 'AMO';
  if (/food|drink|water|meat|fruit|vegetable/.test(text)) return 'FOD';
  if (/medical|bandage|pill|syringe|antibiotic/.test(text)) return 'MED';
  if (/clothing|jacket|pants|boots|helmet|vest/.test(text)) return 'EQP';
  if (/tool|repair|kit|lockpick/.test(text)) return 'TLS';
  return shortCode(entry.name || entry.itemId, 'IT');
}

function catalogIconHtml(entry, kind) {
  const url = getCatalogIconUrl(entry || {}, kind);
  const symbol = categorySymbol(entry || {}, kind);
  if (url) {
    return `<span class="catalog-icon ${escapeAttr(kind)} has-image"><img src="${escapeAttr(url)}" alt="" loading="lazy" /><span>${escapeHtml(symbol)}</span></span>`;
  }
  return `<span class="catalog-icon ${escapeAttr(kind)}">${escapeHtml(symbol)}</span>`;
}

function catalogTile(entry, kind) {
  const value = catalogValue(entry, kind);
  const name = entry.name || entry.displayName || value;
  return `<button type="button" class="catalog-tile" data-catalog-kind="${escapeAttr(kind)}" data-catalog-value="${escapeAttr(value)}" data-catalog-name="${escapeAttr(name)}" data-catalog-category="${escapeAttr(entry.category || '')}" title="${escapeAttr(value)}">
    ${catalogIconHtml(entry, kind)}
    <span class="catalog-text"><b>${escapeHtml(name)}</b><small>${escapeHtml(value)}</small></span>
    <span class="catalog-category">${escapeHtml(entry.category || '')}</span>
  </button>`;
}

function playerInventoryKey(steamId, name, runtimeKey = '') {
  return steamId || (name ? `name:${name}` : (runtimeKey ? `runtime:${runtimeKey}` : 'selected'));
}

function inventorySlotLabel(row) {
  const kind = String(row.slotKind || '').toLowerCase();
  if (kind === 'hands') return 'В руках';
  if (kind === 'equipped') return 'Экипировка';
  if (kind === 'container') return 'Контейнер';
  if (kind === 'root') return 'Корень';
  return row.slot == null ? '-' : `Слот ${row.slot}`;
}

function renderInventoryNode(row, childrenByContainer, depth = 0, visited = new Set()) {
  const entityId = String(row.entityId || '');
  if (visited.has(entityId)) return '';
  visited.add(entityId);
  const itemId = row.itemId || cleanAssetId(row.itemClass || row.itemEntitySetup || '');
  const display = friendlyAssetName(itemId || row.itemClass || row.itemEntitySetup, 'item');
  const iconEntry = {
    itemId,
    name: display,
    runtimeId: row.runtimeId || row.itemClass || row.itemEntitySetup || '',
    classPath: row.itemClass || '',
    assetPath: row.itemEntitySetup || '',
    category: row.category || ''
  };
  const children = childrenByContainer.get(entityId) || [];
  const indent = Math.min(depth, 5) * 14;
  const deleteButton = entityId ? `<button type="button" class="mini-action danger inventory-delete-btn"
        data-inventory-delete="${escapeAttr(entityId)}"
        data-inventory-item-id="${escapeAttr(itemId || '')}"
        data-inventory-class-path="${escapeAttr(row.itemClass || '')}"
        data-inventory-asset-path="${escapeAttr(row.itemEntitySetup || '')}">Удалить</button>` : '';
  return `<div class="inventory-node" style="--depth:${indent}px">
    <div class="inventory-node-main">
      ${catalogIconHtml(iconEntry, 'item')}
      <div><b>${escapeHtml(display)}</b><small>${escapeHtml(itemId || row.itemClass || '')}</small></div>
      <span class="inventory-chip">${escapeHtml(inventorySlotLabel(row))}</span>
      ${deleteButton}
    </div>
    ${children.length ? `<div class="inventory-children">${children.map(child => renderInventoryNode(child, childrenByContainer, depth + 1, new Set(visited))).join('')}</div>` : ''}
  </div>`;
}

function renderInventoryTree(rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  if (!safeRows.length) return '<div class="muted-line">Инвентарь пока не прочитан из SCUM.db.</div>';
  const playerEntityId = String(safeRows[0].playerEntityId || '');
  const byContainer = new Map();
  for (const row of safeRows) {
    const key = String(row.containerEntityId || '');
    if (!byContainer.has(key)) byContainer.set(key, []);
    byContainer.get(key).push(row);
  }
  const roots = byContainer.get(playerEntityId) || safeRows.filter(row => Number(row.depth || 0) === 0);
  return roots.length ? roots.map(row => renderInventoryNode(row, byContainer)).join('') : '<div class="muted-line">Корневые слоты не найдены.</div>';
}

function setPage(page, refresh = true) {
  if (page === 'map') {
    page = 'servers';
    toast('Карта отключена, чтобы не нагружать игровой сервер.');
  }
  if (page === 'diagnostics') {
    page = 'servers';
    toast('Диагностика отключена, чтобы не нагружать игровой сервер.');
  }
  if (page === 'economy') {
    page = 'players';
    toast('Отдельная экономика отключена. Баланс меняется из карточки игрока.');
  }
  state.page = page;
  document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.page === page));
  document.querySelectorAll('.page').forEach(section => section.classList.toggle('active', section.id === `page-${page}`));
  const title = t(`pages.${page}`, page);
  els.pageTitle.textContent = title;
  els.crumb.textContent = `${t('platform', 'Платформа')} / ${title}`;
  if (refresh) refreshCurrent();
}

function setServiceTab(tab) {
  state.serviceTab = tab || 'player';
  document.querySelectorAll('[data-service-tab]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.serviceTab === state.serviceTab);
  });
  document.querySelectorAll('[data-service-section]').forEach(section => {
    section.hidden = section.dataset.serviceSection !== state.serviceTab;
  });
}

function setEconomyTab(tab) {
  state.economyTab = tab || 'overview';
  document.querySelectorAll('[data-economy-tab]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.economyTab === state.economyTab);
  });
  document.querySelectorAll('[data-economy-section]').forEach(section => {
    section.hidden = section.dataset.economySection !== state.economyTab;
  });
}

async function refreshStatus() {
  const status = await api('/api/status');
  const bridgeOnline = status.bridge && status.bridge.online;
  els.bridgePill.textContent = `${t('bridge', 'мост')}: ${bridgeOnline ? t('online', 'в сети') : t('noConnection', 'нет связи')}`;
  els.bridgePill.className = `pill ${bridgeOnline ? 'good' : 'bad'}`;
  if (els.dashboardServerName) els.dashboardServerName.textContent = status.server || 'SCUM NEDJIN';
  if (els.dashboardStatusText) {
    els.dashboardStatusText.textContent = bridgeOnline ? `ONLINE (${state.players.length || 0} players)` : 'NO CONNECTION';
    els.dashboardStatusText.className = bridgeOnline ? 'dashboard-online' : 'dashboard-offline';
  }
  if (els.serverStatusDot) els.serverStatusDot.classList.toggle('online', !!bridgeOnline);
  if (els.serverStatusText) els.serverStatusText.textContent = bridgeOnline ? t('online', 'в сети') : t('offline', 'не в сети');
  const cards = [
    [t('bridge', 'Мост'), bridgeOnline ? t('online', 'в сети') : t('noConnection', 'нет связи'), status.bridge.message, bridgeOnline ? 'good' : 'bad'],
    ['SCUM.db', status.database.online ? t('readable', 'читается') : t('missing', 'не найдена'), status.database.path, status.database.online ? 'good' : 'warn'],
    ['SCUM.log', status.logs.online ? t('readable', 'читается') : t('missing', 'не найден'), status.logs.path, status.logs.online ? 'good' : 'warn'],
    [t('pages.servers', 'Сервер'), status.server || 'SCUM', t('connectedHost', 'подключённая площадка'), 'good']
  ];
  els.statusGrid.innerHTML = cards.map(([name, value, note, kind]) => `
    <article class="metric ${kind}">
      <span>${escapeHtml(name)}</span>
      <b>${escapeHtml(value)}</b>
      <span>${escapeHtml(note || '')}</span>
    </article>`).join('');
}

async function refreshServers() {
  const servers = await api('/api/servers').catch(() => []);
  state.servers = Array.isArray(servers) ? servers : [];
  const panelBase = state.apiBase || window.location.origin;
  const panelUrl = (() => {
    try { return new URL(panelBase); } catch (_) { return new URL(window.location.origin); }
  })();
  const isLoopbackPanel = panelUrl.hostname === '127.0.0.1' || panelUrl.hostname === 'localhost' || panelUrl.hostname === '::1';
  const formatGameEndpoint = server => {
    const host = server.gameHost || server.publicHost || server.host || server.address || (isLoopbackPanel ? '127.0.0.1' : panelUrl.hostname);
    const port = server.gamePort || server.serverPort || server.game_port || server.port || (isLoopbackPanel ? '7777' : '');
    return port ? `${host}:${port}` : host;
  };
  if (els.serverSelect) {
    els.serverSelect.innerHTML = state.servers.length
      ? state.servers.map(server => `<option value="${escapeAttr(server.id || server.name || '')}">${escapeHtml(server.name || server.server || 'SCUM сервер')}</option>`).join('')
      : '<option value="">SCUM сервер</option>';
  }
  if (els.serverList) {
    els.serverList.innerHTML = state.servers.length ? state.servers.map(server => `<article class="server-card">
      <div class="server-card-head">
        <b>${escapeHtml(server.name || server.server || 'SCUM сервер')}</b>
        <span class="pill ${server.online === false ? 'bad' : 'good'}">${server.online === false ? 'выключен' : 'работает'}</span>
      </div>
      <div class="server-kv">
        <span>Игровой сервер</span><b>${escapeHtml(formatGameEndpoint(server))}</b>
        <span>Панель / API</span><b>${escapeHtml(panelBase)}</b>
        <span>Доступ</span><b>${escapeHtml(isLoopbackPanel ? 'локально, только этот ПК' : 'сетевой адрес')}</b>
      </div>
      <div class="button-row">
        <button class="btn" data-server-action="players">Игроки</button>
        <button class="btn" data-server-action="modules">Плагины</button>
      </div>
    </article>`).join('') : `<article class="server-card">
      <div class="server-card-head"><b>SCUM сервер</b><span class="pill">настроен</span></div>
      <div class="server-kv">
        <span>API</span><b>${escapeHtml(state.apiBase || window.location.origin)}</b>
        <span>Ключ</span><b>${escapeHtml(state.apiKey ? 'задан' : 'не задан')}</b>
        <span>Мост</span><b>${escapeHtml(els.bridgePill ? els.bridgePill.textContent.replace('мост: ', '').replace('bridge: ', '') : '')}</b>
      </div>
    </article>`;
  }
}

async function refreshPlayers(options = {}) {
  if (state.playersRefreshInFlight) return state.playersRefreshInFlight;
  const force = Boolean(options && options.force);
  const staleMs = Date.now() - Number(state.playersLastRefreshedAt || 0);
  const query = force || staleMs > 60000 ? '?live=1&refresh=1' : '?live=1';
  state.playersRefreshInFlight = api(`/api/players${query}`).finally(() => {
    state.playersRefreshInFlight = null;
  });
  const data = await state.playersRefreshInFlight;
  const rawPlayers = playersFromPayload(data);
  const players = rawPlayers.filter(isRenderablePlayer);
  state.hiddenRuntimePlayers = rawPlayers.length - players.length;
  state.players = players;
  state.playersLastRefreshedAt = Date.now();
  if (state.selectedPlayerTarget) {
    const selected = state.selectedPlayerTarget;
    const matched = players.find(p => {
      const steamId = String(p.steamId || p.SteamId || p.steam || '');
      const name = String(p.name || p.Name || p.playerName || '');
      return (selected.steamId && steamId === selected.steamId) ||
        (selected.name && name.toLowerCase() === selected.name.toLowerCase());
    });
    if (matched) {
      selected.runtimeKey = matched.runtimeKey || matched.RuntimeKey || selected.runtimeKey || '';
      selected.steamId = matched.steamId || matched.SteamId || matched.steam || selected.steamId || '';
      selected.name = matched.name || matched.Name || matched.playerName || selected.name || '';
      selected.profileId = matched.profileId || matched.ProfileId || matched.userProfileId || matched.serverUserProfileId || selected.profileId || '';
    }
  }
  els.playersPill.textContent = `${t('players', 'игроки')}: ${players.length}`;
  renderPlayers();
}

function playersFromPayload(data) {
  if (Array.isArray(data)) return data;
  const payload = data && (data.payload || data.data || data);
  let players = [];
  if (Array.isArray(payload)) players = payload.slice();
  else if (payload && Array.isArray(payload.players)) players = payload.players.slice();
  else if (data && Array.isArray(data.players)) players = data.players.slice();

  return players;
}

function cleanPlayerString(value) {
  return String(value == null ? '' : value).trim();
}

function isPlaceholderPlayerName(name) {
  const value = cleanPlayerString(name).toLowerCase();
  return !value ||
    value === 'unknown' ||
    /^unknown\s+live(?:\s+#\d+)?$/i.test(value) ||
    /^live\s+#\d+$/i.test(value);
}

function isRuntimeOnlyPlayer(player) {
  if (!player) return false;
  const source = cleanPlayerString(pick(player, ['source', 'identitySource'], '')).toLowerCase();
  return Boolean(player.runtimeOnly) || source.includes('runtime-only');
}

function isRenderablePlayer(player) {
  if (!player) return false;
  const steamId = cleanPlayerString(pick(player, ['steamId', 'SteamId', 'steam'], ''));
  const name = cleanPlayerString(pick(player, ['name', 'Name', 'playerName'], ''));
  const profileId = cleanPlayerString(pick(player, ['userProfileId', 'serverUserProfileId', 'profileId', 'ProfileId'], ''));
  const hasSteam = Boolean(steamId && steamId !== '0');
  const hasProfile = Boolean(profileId && profileId !== '0');
  const hasName = Boolean(name && !isPlaceholderPlayerName(name));
  return hasSteam || hasProfile || hasName;
}

function playerHasMapPosition(player) {
  const source = String(pick(player, ['positionSource', 'source'], '') || '').toLowerCase();
  if (source.includes('no-location')) return false;
  const x = Number(pick(player, ['x', 'X', 'locationX', 'LocationX'], NaN));
  const y = Number(pick(player, ['y', 'Y', 'locationY', 'LocationY'], NaN));
  return Number.isFinite(x) && Number.isFinite(y) && Math.abs(x) + Math.abs(y) > 1;
}

function renderPlayers() {
  const q = (els.playerSearch.value || '').toLowerCase();
  const sort = els.playersSort ? els.playersSort.value : 'name';
  const filtered = state.players.filter(p => JSON.stringify(p).toLowerCase().includes(q));
  filtered.sort((a, b) => {
    if (sort === 'money') return Number(pick(b, ['walletBalance', 'money', 'balance'], 0)) - Number(pick(a, ['walletBalance', 'money', 'balance'], 0));
    if (sort === 'fame') return Number(pick(b, ['famePoints', 'fame'], 0)) - Number(pick(a, ['famePoints', 'fame'], 0));
    if (sort === 'login') return String(pick(b, ['lastLoginUtc', 'lastSeen', 'login'], '')).localeCompare(String(pick(a, ['lastLoginUtc', 'lastSeen', 'login'], '')));
    return String(pick(a, ['name', 'Name', 'playerName'], '')).localeCompare(String(pick(b, ['name', 'Name', 'playerName'], '')));
  });
  if (els.playersSummary) {
    const withPosition = state.players.filter(p => Number.isFinite(Number(p.x ?? p.X ?? p.locationX))).length;
    els.playersSummary.innerHTML = `
      <article class="summary-card"><b>${state.players.length}</b><span>онлайн</span></article>
      <article class="summary-card"><b>${withPosition}</b><span>с live-позицией</span></article>
      <article class="summary-card"><b>${filtered.length}</b><span>в фильтре</span></article>
      <article class="summary-card"><b>${state.hiddenRuntimePlayers || 0}</b><span>скрыто без SteamID</span></article>`;
  }
  els.playersList.innerHTML = filtered.length ? filtered.map(playerCard).join('') : '<div class="panel">Сейчас серверный лог не подтверждает игроков онлайн.</div>';
  syncPlayerProfile();
}

function playerCard(p) {
  const name = pick(p, ['name', 'Name', 'playerName'], 'Игрок');
  const steamId = pick(p, ['steamId', 'SteamId', 'steam'], '');
  const runtimeKey = pick(p, ['runtimeKey', 'RuntimeKey'], '');
  const userProfileId = pick(p, ['userProfileId', 'serverUserProfileId', 'profileId', 'ProfileId'], '');
  const initials = String(name || 'SC').slice(0, 2).toUpperCase();
  return `<article class="player player-row" tabindex="0" role="button" aria-label="Открыть управление игроком ${escapeAttr(name)}" data-steam="${escapeAttr(steamId)}" data-name="${escapeAttr(name)}" data-runtime="${escapeAttr(runtimeKey)}" data-profile="${escapeAttr(userProfileId)}">
    <div class="player-main">
      <div class="player-avatar">${escapeHtml(initials)}</div>
      <div class="player-title">
        <b class="player-name-link">${escapeHtml(name)}</b>
        <small>${escapeHtml(steamId || 'SteamID не найден')}</small>
      </div>
      <span class="pill good player-status">онлайн</span>
    </div>
    <div class="player-meta-grid">
      <span><b>Профиль</b>${escapeHtml(userProfileId || '-')}</span>
    </div>
    <div class="player-row-open">Открыть управление</div>
  </article>`;
}

function playerCoords(player) {
  const x = Number(player && (player.x ?? player.X ?? player.locationX ?? player.LocationX ?? 0));
  const y = Number(player && (player.y ?? player.Y ?? player.locationY ?? player.LocationY ?? 0));
  const z = Number(player && (player.z ?? player.Z ?? player.locationZ ?? player.LocationZ ?? 0));
  return {
    x: Number.isFinite(x) ? x : 0,
    y: Number.isFinite(y) ? y : 0,
    z: Number.isFinite(z) ? z : 0
  };
}

function findPlayerByIdentity(steamId, name, runtimeKey = '') {
  const steam = String(steamId || '');
  const playerName = String(name || '').toLowerCase();
  const runtime = String(runtimeKey || '');
  return state.players.find(p => {
    const pSteam = String(p.steamId || p.SteamId || p.steam || '');
    const pName = String(p.name || p.Name || p.playerName || '').toLowerCase();
    const pRuntime = String(p.runtimeKey || p.RuntimeKey || '');
    return (steam && pSteam === steam) ||
      (runtime && pRuntime === runtime) ||
      (playerName && pName === playerName);
  }) || null;
}

function setSelectedPlayerTarget(steamId, name, runtimeKey = '', profileId = '', player = null) {
  const livePlayer = player || findPlayerByIdentity(steamId, name, runtimeKey) || {};
  const coords = playerCoords(livePlayer);
  const selected = {
    steamId: steamId || pick(livePlayer, ['steamId', 'SteamId', 'steam'], '') || '',
    name: name || pick(livePlayer, ['name', 'Name', 'playerName'], '') || '',
    runtimeKey: runtimeKey || pick(livePlayer, ['runtimeKey', 'RuntimeKey'], '') || '',
    profileId: profileId || pick(livePlayer, ['userProfileId', 'serverUserProfileId', 'profileId', 'ProfileId'], '') || '',
    target: steamId || name || pick(livePlayer, ['steamId', 'SteamId', 'steam', 'name', 'Name', 'playerName'], '') || '',
    x: coords.x,
    y: coords.y,
    z: coords.z
  };
  state.selectedPlayerTarget = selected;
  const target = selected.target || selected.steamId || selected.name || '';
  if (els.playerActionTarget) els.playerActionTarget.value = target;
  if (els.itemTarget) els.itemTarget.value = target;
  if (els.actionTarget) els.actionTarget.value = target;
  if (els.serviceTarget) els.serviceTarget.value = target;
  if (els.economyTarget) els.economyTarget.value = target;
  if (els.playerActionX) els.playerActionX.value = Math.round(coords.x);
  if (els.playerActionY) els.playerActionY.value = Math.round(coords.y);
  if (els.playerActionZ) els.playerActionZ.value = Math.round(coords.z);
  return selected;
}

function openPlayerProfile(playerOrTarget, options = {}) {
  if (!els.playerProfile || !playerOrTarget) return;
  const player = playerOrTarget || {};
  const name = pick(player, ['name', 'Name', 'playerName'], 'Игрок');
  const steamId = pick(player, ['steamId', 'SteamId', 'steam'], '');
  const runtimeKey = pick(player, ['runtimeKey', 'RuntimeKey'], '');
  const profileId = pick(player, ['userProfileId', 'serverUserProfileId', 'profileId', 'ProfileId'], '');
  const selected = setSelectedPlayerTarget(steamId, name, runtimeKey, profileId, player);
  const coords = playerCoords(player);
  const initials = String(selected.name || 'SC').slice(0, 2).toUpperCase();
  if (els.profAvatar) els.profAvatar.textContent = initials;
  if (els.profName) els.profName.textContent = selected.name || 'Игрок';
  if (els.profSteamId) els.profSteamId.textContent = selected.steamId || 'SteamID не найден';
  if (els.profLocation) els.profLocation.textContent = selected.runtimeKey ? 'live runtime' : 'онлайн';
  if (els.profProfileId) els.profProfileId.textContent = selected.profileId || '-';
  if (els.profX) els.profX.value = Math.round(coords.x);
  if (els.profY) els.profY.value = Math.round(coords.y);
  if (els.profZ) els.profZ.value = Math.round(coords.z);
  if (els.profActionResult && options.clearResult !== false) els.profActionResult.textContent = '';
  els.playerProfile.classList.remove('hidden');
  els.playerProfile.setAttribute('aria-hidden', 'false');
  const playersPage = document.getElementById('page-players');
  if (playersPage) playersPage.classList.add('profile-open');
  if (options.scroll !== false) els.playerProfile.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function syncPlayerProfile() {
  if (!els.playerProfile || els.playerProfile.classList.contains('hidden') || !state.selectedPlayerTarget) return;
  const selected = state.selectedPlayerTarget;
  const player = findPlayerByIdentity(selected.steamId, selected.name, selected.runtimeKey);
  if (player) openPlayerProfile(player, { scroll: false, clearResult: false });
}

function closePlayerProfile() {
  if (!els.playerProfile) return;
  els.playerProfile.classList.add('hidden');
  els.playerProfile.setAttribute('aria-hidden', 'true');
  if (els.profileActionDock) {
    els.profileActionDock.classList.add('hidden');
    els.profileActionDock.setAttribute('aria-hidden', 'true');
  }
  const playersPage = document.getElementById('page-players');
  if (playersPage) playersPage.classList.remove('profile-open');
}

function openSelectedPlayerModal(tab = 'message') {
  const selected = state.selectedPlayerTarget;
  if (!selected) {
    toast('Сначала выбери игрока.');
    return;
  }
  openPlayerActionModal(selected.steamId, selected.name, selected.runtimeKey, tab, selected.profileId);
}

async function loadStaticMapChests() {
  try {
    const response = await fetch('/map-chests.json', { cache: 'no-store' });
    if (!response.ok) return [];
    const payload = await response.json();
    if (Array.isArray(payload)) return payload;
    if (payload && Array.isArray(payload.chests)) return payload.chests;
  } catch (_) {}
  return [];
}

async function refreshMap() {
  const mapData = await api('/api/map');
  state.map = mapData || {};
  const apiChests = Array.isArray(state.map.chests)
    ? state.map.chests
    : (Array.isArray(state.map.containers) ? state.map.containers : []);
  if (!apiChests.length) {
    const staticChests = await loadStaticMapChests();
    if (staticChests.length) {
      state.map.chests = staticChests;
      state.map.chestSource = 'SCUM.db snapshot';
    }
  }
  let livePlayers = Array.isArray(state.players) ? state.players.filter(playerHasMapPosition) : [];
  if (!livePlayers.length) {
    const playersAgeMs = Date.now() - Number(state.playersLastRefreshedAt || 0);
    if (playersAgeMs > 10000) {
      try {
        await refreshPlayers();
        livePlayers = Array.isArray(state.players) ? state.players.filter(playerHasMapPosition) : [];
      } catch (_) {}
    }
  }
  if (!Array.isArray(state.map.players) || !state.map.players.length) {
    state.map.players = livePlayers;
    state.map.playerSource = livePlayers.length ? 'cached players' : (state.map.playerSource || 'нет live-игроков');
  }
  els.mapImage.src = state.map.mapImageUrl || '';
  renderMap();
}

function renderMap() {
  if (!state.map) return;
  const bounds = state.map.bounds || {};
  renderMapSectors();
  const markers = [];
  const rawMapPlayers = Array.isArray(state.map.players) && state.map.players.length
    ? state.map.players
    : (Array.isArray(state.players) ? state.players.filter(playerHasMapPosition) : []);
  const mapPlayers = rawMapPlayers.filter(playerHasMapPosition);
  const mapChests = state.map.chests || state.map.containers || [];
  if (els.layerPlayers.checked) for (const p of mapPlayers) markers.push(markerFor(p, bounds, 'player', pick(p, ['name', 'Name'], 'игрок')));
  if (els.layerVehicles.checked) for (const v of state.map.vehicles || []) markers.push(markerFor(v, bounds, 'vehicle', pick(v, ['type', 'class', 'asset', '_table'], 'транспорт')));
  if (els.layerChests && els.layerChests.checked) for (const c of mapChests) markers.push(markerFor(c, bounds, 'chest', pick(c, ['type', 'class', 'asset', '_table'], 'сундук')));
  if (els.layerFlags.checked) for (const f of state.map.flags || []) markers.push(markerFor(f, bounds, 'flag', pick(f, ['ownerName', 'name', '_table'], 'флаг')));
  els.mapMarkers.innerHTML = markers.join('');
  applyMapZoom();
  els.mapStats.innerHTML = `
    <div>Игроки: ${mapPlayers.length}</div>
    <div>Транспорт: ${(state.map.vehicles || []).length}</div>
    <div>Сундуки: ${mapChests.length}</div>
    <div>Флаги: ${(state.map.flags || []).length}</div>
    <div>Источник игроков: ${escapeHtml(state.map.playerSource || (mapPlayers.length ? 'cached players' : ''))}</div>
    ${state.map.chestSource ? `<div>Источник сундуков: ${escapeHtml(state.map.chestSource)}</div>` : ''}`;
  renderMapSelection();
}

function renderMapSectors() {
  if (!els.mapSectors) return;
  const rows = ['D', 'C', 'B', 'A', 'Z'];
  const cols = ['4', '3', '2', '1', '0'];
  els.mapSectors.innerHTML = rows.flatMap(row => cols.map(col => `<div class="map-sector-cell"><span>${row}${col}</span></div>`)).join('');
}

function applyMapZoom() {
  const zoom = Math.max(0.6, Math.min(2.6, state.mapZoom || 1));
  state.mapZoom = zoom;
  if (els.mapImage) els.mapImage.style.transform = `scale(${zoom})`;
  if (els.mapMarkers) els.mapMarkers.style.transform = `scale(${zoom})`;
  if (els.mapSectors) els.mapSectors.style.transform = `scale(${zoom})`;
}

function markerFor(obj, bounds, kind, title) {
  const rawX = Number(pick(obj, ['x', 'X', 'locationX', 'LocationX'], NaN));
  const rawY = Number(pick(obj, ['y', 'Y', 'locationY', 'LocationY'], NaN));
  if (!Number.isFinite(rawX) || !Number.isFinite(rawY)) return '';
  let x = bounds.swapAxes ? rawY : rawX;
  let y = bounds.swapAxes ? rawX : rawY;
  const minX = Number(bounds.minX ?? -768000);
  const maxX = Number(bounds.maxX ?? 768000);
  const minY = Number(bounds.minY ?? -768000);
  const maxY = Number(bounds.maxY ?? 768000);
  let px = ((x - minX) / (maxX - minX)) * 100;
  let py = ((y - minY) / (maxY - minY)) * 100;
  if (bounds.invertX ?? true) px = 100 - px;
  if (bounds.invertY ?? true) py = 100 - py;
  if (px < -5 || px > 105 || py < -5 || py > 105) return '';
  const steamId = pick(obj, ['steamId', 'steam', 'userId'], '');
  const runtimeKey = pick(obj, ['runtimeKey'], '');
  const z = Number(pick(obj, ['z', 'Z', 'locationZ', 'LocationZ'], 0));
  const label = kind === 'player' ? `<span class="map-marker-label">${escapeHtml(title || pick(obj, ['name', 'Name'], 'игрок'))}</span>` : '';
  return `<span class="map-marker-wrap ${kind}" title="${escapeAttr(title)}" style="left:${px}%;top:${py}%"
    data-map-marker="1"
    data-kind="${escapeAttr(kind)}"
    data-title="${escapeAttr(title)}"
    data-steam="${escapeAttr(steamId)}"
    data-name="${escapeAttr(pick(obj, ['name', 'Name', 'ownerName'], title || ''))}"
    data-runtime="${escapeAttr(runtimeKey)}"
    data-x="${escapeAttr(rawX)}"
    data-y="${escapeAttr(rawY)}"
    data-z="${escapeAttr(Number.isFinite(z) ? z : 0)}">
      ${label}
      <button type="button" class="marker ${kind}" aria-label="${escapeAttr(title)}"></button>
    </span>`;
}

function setMapSelection(selection) {
  state.mapSelection = selection || null;
  renderMapSelection();
}

function renderMapSelection() {
  if (!els.mapSelection) return;
  const selected = state.mapSelection;
  if (!selected) {
    els.mapSelection.innerHTML = '<div>Ничего не выбрано.</div>';
    return;
  }
  const title = selected.title || selected.name || selected.kind || 'Точка';
  const x = Number(selected.x || 0);
  const y = Number(selected.y || 0);
  const z = Number(selected.z || 0);
  const canOpenPlayer = selected.kind === 'player' && (selected.steamId || selected.name);
  els.mapSelection.innerHTML = `
    <div><b>${escapeHtml(title)}</b></div>
    <div>${escapeHtml(selected.kind || 'точка')}</div>
    <div>X ${x.toFixed(0)} · Y ${y.toFixed(0)} · Z ${z.toFixed(0)}</div>
    <div class="button-row compact">
      <button class="btn" data-map-selection-action="use-coords">В телепорт</button>
      <button class="btn" data-map-selection-action="copy-coords">Копировать</button>
      ${canOpenPlayer ? '<button class="btn primary" data-map-selection-action="open-player">Открыть игрока</button>' : ''}
    </div>`;
}

function applySelectedMapCoords() {
  const selected = state.mapSelection;
  if (!selected) return;
  const x = Number(selected.x || 0).toFixed(0);
  const y = Number(selected.y || 0).toFixed(0);
  const z = Number(selected.z || 0).toFixed(0);
  if (els.teleportX) els.teleportX.value = x;
  if (els.teleportY) els.teleportY.value = y;
  if (els.teleportZ) els.teleportZ.value = z;
  if (els.playerActionX) els.playerActionX.value = x;
  if (els.playerActionY) els.playerActionY.value = y;
  if (els.playerActionZ) els.playerActionZ.value = z;
}

async function refreshEvents() {
  const [chatData, actionData] = await Promise.all([
    api('/api/chat').catch(() => []),
    api('/api/action-log?limit=30').catch(() => [])
  ]);
  const chat = Array.isArray(chatData) ? chatData : (chatData.recent || []);
  const actions = Array.isArray(actionData) ? actionData : [];
  const list = chat.concat(actions).sort((a, b) => eventTime(b) - eventTime(a));
  els.recentEvents.innerHTML = renderEvents(list.slice(0, 8));
}

function eventTime(event) {
  const raw = event && (event.timestampUtc || event.utc || event.time || event.at);
  if (typeof raw === 'number') return raw * 1000;
  const dt = new Date(raw || 0);
  return Number.isNaN(dt.getTime()) ? 0 : dt.getTime();
}

function renderEvents(list) {
  return list.length ? list.map(e => {
    const actor = e.source === 'panel' && (e.targetName || e.targetSteamId)
      ? `Панель -> ${e.targetName || e.targetSteamId}`
      : (e.name || e.steamId || e.source || '');
    const kind = e.action || e.type || '';
    const stamp = e.timestampUtc || e.utc || '';
    const message = e.message || e.result || (e.ok === false ? 'не выполнено' : '');
    return `<article class="event">
    <div class="meta"><span>${escapeHtml(kind)}</span><span>${fmtTime(stamp)}</span></div>
    ${actor ? `<small>${escapeHtml(actor)}</small>` : ''}
    <div>${escapeHtml(message)}</div>
  </article>`;
  }).join('') : '<div class="event">Событий пока нет.</div>';
}

function eventMatches(event, query) {
  if (!query) return true;
  return JSON.stringify(event || {}).toLowerCase().includes(query.toLowerCase());
}

async function refreshSquads() {
  const data = await api('/api/squads');
  const rows = Array.isArray(data) ? data : (Array.isArray(data.squads) ? data.squads : []);
  const grouped = new Map();
  for (const row of rows) {
    const id = pick(row, ['squadId', 'id'], '');
    const key = id || pick(row, ['squadName', 'name'], 'squad');
    if (!grouped.has(key)) grouped.set(key, Object.assign({}, row, { members: [] }));
    const squad = grouped.get(key);
    const memberName = pick(row, ['memberName', 'name'], '');
    const memberSteam = pick(row, ['memberSteamId', 'steamId'], '');
    if (memberName || memberSteam) squad.members.push({
      name: memberName,
      steamId: memberSteam,
      rank: pick(row, ['memberRank', 'rank'], '')
    });
  }
  state.squads = Array.from(grouped.values());
  renderSquads();
}

function renderSquads() {
  const q = els.squadSearch ? els.squadSearch.value.trim() : '';
  const list = state.squads.filter(item => eventMatches(item, q));
  if (els.squadsList) els.squadsList.className = 'squad-grid';
  const rankLabel = rank => {
    const value = Number(rank || 0);
    if (value >= 4) return 'Лидер';
    if (value === 3) return 'Заместитель';
    if (value === 2) return 'Офицер';
    if (value === 1) return 'Боец';
    return 'Участник';
  };
  const formatScore = value => {
    const number = Number(value || 0);
    return Number.isFinite(number) ? number.toLocaleString('ru-RU', { maximumFractionDigits: 1 }) : '-';
  };
  els.squadsList.innerHTML = list.length ? list.map(item => {
    const members = (item.members || []).slice().sort((a, b) =>
      Number(b.rank || 0) - Number(a.rank || 0) ||
      String(a.name || a.steamId || '').localeCompare(String(b.name || b.steamId || ''))
    );
    const name = pick(item, ['squadName', 'name', 'Name'], 'Отряд');
    const leader = members.find(member => Number(member.rank || 0) >= 4) || members[0] || {};
    const memberLimit = pick(item, ['memberLimit'], '');
    const lastSeen = pick(item, ['lastMemberLoginUtc', 'lastMemberLogoutUtc'], '');
    const description = pick(item, ['information', 'message'], '');
    return `<article class="squad-card">
      <div class="squad-header">
        <div class="squad-icon" aria-hidden="true">SQ</div>
        <div class="squad-title">
          <h3 class="squad-name">${escapeHtml(name)}</h3>
          <span class="squad-count">${members.length}${memberLimit ? ` / ${escapeHtml(memberLimit)}` : ''} участников</span>
        </div>
      </div>
      <div class="squad-kpis">
        <span><b>${escapeHtml(formatScore(pick(item, ['score'], 0)))}</b><small>очки</small></span>
        <span><b>${escapeHtml(leader.name || leader.steamId || '-')}</b><small>лидер</small></span>
        <span><b>${escapeHtml(lastSeen ? fmtTime(lastSeen) : '-')}</b><small>последняя активность</small></span>
      </div>
      ${description ? `<p class="squad-desc">${escapeHtml(description)}</p>` : ''}
      <div class="squad-body">
        ${members.length ? members.map(member => `<div class="member-row ${Number(member.rank || 0) >= 4 ? 'leader' : ''}">
          <span class="member-name">${escapeHtml(member.name || member.steamId || 'Участник')}</span>
          <span class="member-rank">${escapeHtml(rankLabel(member.rank))}</span>
        </div>`).join('') : '<div class="member-row"><span class="member-name">Участники не найдены</span><span class="member-rank">-</span></div>'}
      </div>
    </article>`;
  }).join('') : '<div class="empty-state">Данные по отрядам пока не найдены.</div>';
}

async function refreshChat() {
  const data = await api('/api/chat');
  state.chat = Array.isArray(data) ? data : (Array.isArray(data.recent) ? data.recent : []);
  renderChat();
}

function renderChat() {
  const q = els.chatSearch ? els.chatSearch.value.trim() : '';
  const channel = els.chatChannel ? els.chatChannel.value : 'global';
  const list = state.chat.filter(item => {
    const itemChannel = normalizeChatChannel(item);
    return itemChannel === channel && eventMatches(item, q);
  }).sort((a, b) => eventTime(b) - eventTime(a));
  if (els.chatList) els.chatList.classList.add('chat-container');
  els.chatList.innerHTML = renderChatMessages(list);
}

function fmtChatTime(event) {
  const raw = event && (event.timestampUtc || event.utc || event.time || event.at);
  if (!raw) return '';
  const dt = new Date(raw);
  if (Number.isNaN(dt.getTime())) return '';
  return dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function chatActor(event) {
  if (!event) return 'Сервер';
  if (event.source === 'panel' && (event.targetName || event.targetSteamId)) {
    return `Панель -> ${event.targetName || event.targetSteamId}`;
  }
  return event.name || event.player || event.playerName || event.nickname || event.steamId || event.source || 'Сервер';
}

function chatText(event) {
  if (!event) return '';
  return event.message || event.text || event.body || event.result || (event.ok === false ? 'не выполнено' : '');
}

function normalizeChatChannel(event) {
  const rawChannel = String(event && (event.channel || event.chatChannel || event.kind || '') || '').trim().toLowerCase();
  const source = String(event && (event.source || event.path || event.type || '') || '').toLowerCase();
  const text = String(chatText(event) || '').trim();
  const lowerText = text.toLowerCase();
  const numericChannels = {
    '0': 'local',
    '1': 'squad',
    '2': 'global',
    '3': 'admin',
    '4': 'command'
  };
  if (numericChannels[rawChannel]) return numericChannels[rawChannel];
  if (
    rawChannel.includes('command') ||
    source.includes('processadmincommand') ||
    source.includes('command-reply') ||
    text.startsWith('/') ||
    text.startsWith('#')
  ) return 'command';
  if (rawChannel.includes('local') || rawChannel.includes('proximity') || rawChannel.includes('vicinity') || rawChannel.includes('лок')) return 'local';
  if (rawChannel.includes('squad') || rawChannel.includes('team') || rawChannel.includes('clan') || rawChannel.includes('party') || rawChannel.includes('отряд')) return 'squad';
  if (rawChannel.includes('admin') || rawChannel.includes('moderator') || rawChannel.includes('админ')) return 'admin';
  if (rawChannel.includes('global') || rawChannel.includes('world') || rawChannel.includes('глоб')) return 'global';
  if (rawChannel === 'server' && (lowerText.startsWith('/') || source.includes('nedjin') || source.includes('command'))) return 'command';
  if (rawChannel === 'chat' || rawChannel === 'server' || !rawChannel) return 'global';
  return rawChannel;
}

function chatChannelLabel(channel) {
  const labels = {
    global: 'Глобальный',
    local: 'Локальный',
    squad: 'Отряд',
    admin: 'Админ',
    command: 'Команды'
  };
  return labels[channel] || channel || 'Чат';
}

function renderChatMessages(list) {
  if (!list.length) return '<div class="empty-state">Сообщений пока нет.</div>';
  return list.map(event => {
    const channel = normalizeChatChannel(event);
    return `<article class="chat-msg chat-msg-${escapeAttr(channel)}">
      <div class="chat-topline">
        <span class="chat-channel">${escapeHtml(chatChannelLabel(channel))}</span>
        <time class="chat-time">${escapeHtml(fmtChatTime(event))}</time>
      </div>
      <div class="chat-main">
        <span class="chat-author">${escapeHtml(chatActor(event))}</span>
        <span class="chat-text">${escapeHtml(chatText(event))}</span>
      </div>
    </article>`;
  }).join('');
}

function normalizeOutboundMessage(message) {
  return String(message || '').replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function announceMessageForChannel(channel, message) {
  const clean = normalizeOutboundMessage(message);
  if (!clean) return '';
  const normalized = String(channel || '').toLowerCase();
  return normalized === 'admin' ? `[Admin] ${clean}` : clean;
}

function announceCommandForChannel(channel, message) {
  const text = announceMessageForChannel(channel, message);
  return text ? `#Announce ${text}` : '';
}

async function sendPanelChat(body) {
  const payload = Object.assign({}, body || {});
  payload.message = normalizeOutboundMessage(payload.message);
  if (!payload.message) return { ok: false, success: false, error: 'Сообщение пустое.' };
  const hasTarget = !!(payload.targetSteamId || payload.targetName || payload.targetRuntimeKey || payload.steamId || payload.name || payload.runtimeKey);
  if (hasTarget) {
    return api('/api/chat', { method: 'POST', body: JSON.stringify(payload) });
  }
  return api('/api/chat', { method: 'POST', body: JSON.stringify(payload) });
}

async function refreshKills() {
  const data = await api('/api/kills');
  state.kills = Array.isArray(data) ? data : [];
  renderKills();
}

function renderKills() {
  const q = els.killsSearch ? els.killsSearch.value.trim() : '';
  const list = state.kills
    .filter(item => eventMatches(item, q))
    .sort((a, b) => eventTime(b) - eventTime(a));
  if (els.killsList) els.killsList.classList.add('kill-log-container');
  els.killsList.innerHTML = renderKillEvents(list);
}

function killEventTextBlob(event) {
  if (!event || typeof event !== 'object') return '';
  const chunks = [];
  Object.keys(event).forEach(key => {
    const value = event[key];
    if (value == null) return;
    if (typeof value === 'string' || typeof value === 'number') {
      chunks.push(String(value));
    } else if (typeof value === 'object' && key.toLowerCase().includes('raw')) {
      try { chunks.push(JSON.stringify(value)); } catch (_) {}
    }
  });
  return chunks.join(' ');
}

function parseKillDistance(event) {
  const direct = pick(event, ['distanceMeters', 'distanceM', 'distance', 'Distance'], '');
  if (direct !== '') {
    const value = Number(String(direct).replace(',', '.').replace(/[^\d.-]/g, ''));
    return Number.isFinite(value) ? value : '';
  }
  const raw = killEventTextBlob(event);
  const match = raw.match(/Distance\s*:\s*([0-9]+(?:[.,][0-9]+)?)\s*m/i) || raw.match(/([0-9]+(?:[.,][0-9]+)?)\s*m\b/i);
  if (!match) return '';
  const value = Number(String(match[1]).replace(',', '.'));
  return Number.isFinite(value) ? value : '';
}

function parseKillWeapon(event) {
  const direct = pick(event, ['weapon', 'weaponName', 'weaponRaw', 'item', 'Weapon'], '');
  if (direct) return cleanAssetId(direct) || direct;
  const raw = killEventTextBlob(event);
  const match = raw.match(/Weapon\s*:\s*([^,\]|]+)/i) || raw.match(/\b(Weapon_[A-Za-z0-9_]+)\b/);
  return match ? cleanAssetId(match[1].trim()) : '';
}

function parseKillCause(event) {
  const direct = pick(event, ['deathType', 'cause', 'damageType', 'kindOfDeath', 'DeathType'], '');
  if (direct) return String(direct).trim();
  const raw = killEventTextBlob(event);
  const bracket = raw.match(/\[([A-Za-z_ -]+)\]/);
  if (bracket) {
    const value = bracket[1].trim().toLowerCase();
    if (value === 'projectile') return 'пуля/снаряд';
    if (value === 'melee') return 'ближний бой';
    if (value === 'explosion') return 'взрыв';
    if (value === 'vehicle') return 'транспорт';
    if (value === 'fall') return 'падение';
    if (value === 'suicide') return 'самоубийство';
    return bracket[1].trim();
  }
  if (/npc|puppet|drifter|zombie|sentry/i.test(raw)) return 'NPC/PVE';
  return 'неизвестно';
}

function parseLocationValue(value) {
  if (!value) return null;
  if (typeof value === 'object') {
    const x = Number(value.x ?? value.X ?? value[0]);
    const y = Number(value.y ?? value.Y ?? value[1]);
    const z = Number(value.z ?? value.Z ?? value[2]);
    return [x, y, z].every(Number.isFinite) ? { x, y, z } : null;
  }
  const match = String(value).match(/(-?\d+(?:[.,]\d+)?)\s*,\s*(-?\d+(?:[.,]\d+)?)\s*,\s*(-?\d+(?:[.,]\d+)?)/);
  if (!match) return null;
  const nums = match.slice(1, 4).map(part => Number(String(part).replace(',', '.')));
  return nums.every(Number.isFinite) ? { x: nums[0], y: nums[1], z: nums[2] } : null;
}

function parseKillLocation(event, role) {
  const prefix = role === 'killer' ? 'killer' : 'victim';
  const direct = pick(event, [
    `${prefix}Location`,
    `${prefix}Loc`,
    `${prefix}Position`,
    `${prefix}Coords`,
    `${prefix}Coordinates`
  ], '');
  const directLocation = parseLocationValue(direct);
  if (directLocation) return directLocation;

  const x = pick(event, [`${prefix}X`, `${prefix}LocX`, `${prefix}LocationX`, `${prefix}_x`], '');
  const y = pick(event, [`${prefix}Y`, `${prefix}LocY`, `${prefix}LocationY`, `${prefix}_y`], '');
  const z = pick(event, [`${prefix}Z`, `${prefix}LocZ`, `${prefix}LocationZ`, `${prefix}_z`], '');
  const numeric = [x, y, z].map(part => Number(String(part).replace(',', '.')));
  if (numeric.every(Number.isFinite)) return { x: numeric[0], y: numeric[1], z: numeric[2] };

  const label = role === 'killer' ? 'Killer' : 'Victim';
  const raw = killEventTextBlob(event);
  const re = new RegExp(`${label}(?:Loc|Location)?\\s*:?\\s*(-?\\d+(?:[.,]\\d+)?)\\s*,\\s*(-?\\d+(?:[.,]\\d+)?)\\s*,\\s*(-?\\d+(?:[.,]\\d+)?)`, 'i');
  const match = raw.match(re);
  return match ? parseLocationValue(match.slice(1, 4).join(', ')) : null;
}

function fmtKillLocation(location) {
  if (!location) return 'координаты неизвестны';
  return `${Math.round(location.x)}, ${Math.round(location.y)}, ${Math.round(location.z)}`;
}

function killKind(event, killer, victim) {
  const type = String(pick(event, ['kind', 'type', 'source'], '')).toLowerCase();
  const killerSteam = String(pick(event, ['killerSteamId', 'attackerSteamId', 'sourceSteamId'], '')).trim();
  const victimSteam = String(pick(event, ['victimSteamId', 'targetSteamId'], '')).trim();
  const sameSteam = killerSteam && victimSteam && killerSteam === victimSteam;
  const sameName = String(killer || '').trim().toLocaleLowerCase() === String(victim || '').trim().toLocaleLowerCase();
  if (sameSteam || (killer && victim && sameName)) return 'self';
  if (type.includes('pve') || /zombie|puppet|animal|sentry|environment/i.test(`${killer} ${event && event.raw ? event.raw : ''}`)) return 'pve';
  return 'pvp';
}

function renderKillEvents(list) {
  if (!list.length) return '<div class="empty-state">Убийств пока нет.</div>';
  return list.map(event => {
    const killer = pick(event, ['killerName', 'killer', 'attackerName', 'attacker', 'sourceName'], 'Неизвестно');
    const victim = pick(event, ['victimName', 'victim', 'targetName', 'target'], 'Неизвестно');
    const weapon = parseKillWeapon(event) || 'без оружия';
    const cause = parseKillCause(event);
    const distance = parseKillDistance(event);
    const killerLocation = parseKillLocation(event, 'killer');
    const victimLocation = parseKillLocation(event, 'victim');
    const kind = killKind(event, killer, victim);
    const label = kind === 'self' ? 'SELF' : (kind === 'pve' ? 'PVE' : 'PVP');
    const message = event.message || '';
    return `<article class="kill-event ${escapeAttr(kind)}">
      <time class="kill-time">${escapeHtml(fmtChatTime(event))}</time>
      <div class="killer-name" title="${escapeAttr(killer)}">${escapeHtml(killer)}</div>
      <div class="kill-mid" aria-label="${escapeAttr(label)}">
        <span class="kill-icon">${escapeHtml(label)}</span>
        ${message ? `<small>${escapeHtml(message)}</small>` : ''}
      </div>
      <div class="victim-name" title="${escapeAttr(victim)}">${escapeHtml(victim)}</div>
      <div class="kill-details">
        <span class="weapon-name"><b>Оружие</b> ${escapeHtml(weapon)}</span>
        <span class="cause-tag"><b>Причина</b> ${escapeHtml(cause)}</span>
        <span class="distance-tag"><b>Дистанция</b> ${distance !== '' ? `${escapeHtml(distance.toFixed(1))} м` : 'неизвестна'}</span>
        <span class="location-tag"><b>Откуда</b> ${escapeHtml(fmtKillLocation(killerLocation))}</span>
        <span class="location-tag"><b>Точка смерти</b> ${escapeHtml(fmtKillLocation(victimLocation))}</span>
      </div>
    </article>`;
  }).join('');
}

async function refreshEconomy() {
  await ensureModulesLoaded().catch(() => {});
  const data = await api('/api/economy');
  state.economy = data || {};
  renderEconomy();
}

function renderEconomy() {
  const wallets = Array.isArray(state.economy.wallets) ? state.economy.wallets : [];
  const bank = Array.isArray(state.economy.bankAccounts) ? state.economy.bankAccounts : [];
  const recent = Array.isArray(state.economy.recent) ? state.economy.recent : (Array.isArray(state.economy) ? state.economy : []);
  const totalWallet = wallets.reduce((sum, w) => sum + Number(w.walletBalance || 0), 0);
  const totalFame = wallets.reduce((sum, w) => sum + Number(w.famePoints || 0), 0);
  const totalBank = bank.reduce((sum, b) => sum + Number(b.accountBalance || 0), 0);
  const walletHtml = wallets.slice(0, 80).map(w => `<article class="event economy-row">
    <div class="meta"><span>${escapeHtml(w.name || w.steamId || 'игрок')}</span><span>${fmtTime(w.lastLoginUtc)}</span></div>
    <div class="kv">
      <span>Кошелёк</span><b>${escapeHtml(w.walletBalance ?? 0)}</b>
      <span>Слава</span><b>${escapeHtml(w.famePoints ?? 0)}</b>
      <span>SteamID</span><b>${escapeHtml(w.steamId || '')}</b>
    </div>
  </article>`).join('');
  const bankHtml = bank.slice(0, 80).map(b => `<article class="event economy-row">
    <div class="meta"><span>${escapeHtml(b.ownerName || b.ownerSteamId || 'банковский счёт')}</span><span>${escapeHtml(b.accountNumber || '')}</span></div>
    <div class="kv">
      <span>Валюта</span><b>${escapeHtml(b.currencyType ?? '')}</b>
      <span>Баланс</span><b>${escapeHtml(b.accountBalance ?? 0)}</b>
      <span>Владелец</span><b>${escapeHtml(b.ownerSteamId || '')}</b>
    </div>
  </article>`).join('');
  const fastCfg = moduleConfig('fast-travel');
  const rentalCfg = moduleConfig('vehicle-rental');
  const scanCfg = moduleConfig('sector-scan');
  const outposts = Array.isArray(fastCfg.Outposts) ? fastCfg.Outposts : (Array.isArray(fastCfg.points) ? fastCfg.points : []);
  const vehicles = Array.isArray(rentalCfg.Vehicles) ? rentalCfg.Vehicles : (Array.isArray(rentalCfg.vehicles) ? rentalCfg.vehicles : []);
  const spendRows = []
    .concat(outposts.slice(0, 8).map(route => ({
      type: 'Телепорт',
      name: route.DisplayName || route.displayName || route.CommandAlias || route.commandAlias || 'маршрут',
      price: route.Price ?? route.price ?? fastCfg.FixedFare ?? 0,
      note: route.CommandAlias || route.commandAlias || ''
    })))
    .concat(vehicles.slice(0, 8).map(vehicle => ({
      type: 'Аренда',
      name: vehicle.DisplayName || vehicle.displayName || vehicle.Alias || vehicle.alias || vehicle.AssetName || vehicle.assetName || 'транспорт',
      price: vehicle.InitialCharge ?? vehicle.initialCharge ?? 0,
      note: `+ ${vehicle.PricePer10Minutes ?? vehicle.pricePer10Minutes ?? 0} / 10 мин`
    })))
    .concat(scanCfg.ScanCost != null || scanCfg.scanCost != null ? [{
      type: 'Скан',
      name: 'Скан сектора',
      price: scanCfg.ScanCost ?? scanCfg.scanCost ?? 0,
      note: 'команда /scan'
    }] : []);
  const spendHtml = spendRows.length ? spendRows.map(row => `<article class="economy-spend-row">
    <span>${escapeHtml(row.type)}</span>
    <b>${escapeHtml(row.name)}</b>
    <strong>${escapeHtml(row.price)}</strong>
    <em>${escapeHtml(row.note || '')}</em>
  </article>`).join('') : '<div class="event">Платные действия пока не найдены в конфигах плагинов.</div>';
  els.economyList.innerHTML = `
    <div class="economy-kpis" data-economy-section="overview">
      <article><span>Кошельков</span><b>${wallets.length}</b></article>
      <article><span>Всего в кошельках</span><b>${totalWallet}</b></article>
      <article><span>Всего в банке</span><b>${totalBank}</b></article>
      <article><span>Очков славы</span><b>${totalFame}</b></article>
    </div>
    <div class="economy-groups">
      <section class="economy-group" data-economy-section="overview">
        <div class="economy-group-head"><h3>Как пользоваться экономикой</h3><span>быстрая памятка</span></div>
        <div class="economy-help-grid">
          <article><b>Начислить игроку</b><span>Открой карточку игрока → Экономика → укажи сумму.</span></article>
          <article><b>Посмотреть расходы</b><span>Вкладка «Цены» показывает платные телепорты, аренду и скан.</span></article>
          <article><b>Проверить историю</b><span>Вкладка «Операции» показывает последние изменения денег.</span></article>
        </div>
      </section>
      <section class="economy-group" data-economy-section="prices" hidden>
        <div class="economy-group-head"><h3>Где списываются деньги</h3><span>цены из настроек плагинов</span></div>
        <div class="economy-spend-list">${spendHtml}</div>
      </section>
      <section class="economy-group" data-economy-section="wallets" hidden>
        <div class="economy-group-head"><h3>Кошельки игроков</h3><span>начисление делай из карточки игрока</span></div>
        ${walletHtml || '<div class="event">В базе пока нет кошельков игроков.</div>'}
      </section>
      <section class="economy-group" data-economy-section="bank" hidden>
        <div class="economy-group-head"><h3>Банковские счета</h3><span>балансы из SCUM.db</span></div>
        ${bankHtml || '<div class="event">В базе пока нет банковских счетов.</div>'}
      </section>
      <section class="economy-group" data-economy-section="recent" hidden>
        <div class="economy-group-head"><h3>Последние операции</h3><span>что недавно менялось</span></div>
        ${renderEvents(recent)}
      </section>
    </div>`;
  setEconomyTab(state.economyTab || 'overview');
}

async function refreshDownloads() {
  const data = await api('/api/downloads');
  state.downloads = Array.isArray(data) ? data : [];
  els.downloadsList.innerHTML = state.downloads.length ? state.downloads.map(file => `<article class="download">
    <b>${escapeHtml(file.name || file.path || 'файл')}</b>
    <span>${escapeHtml(file.description || '')}</span>
    <code>${escapeHtml(file.path || '')}</code>
  </article>`).join('') : '<div class="event">Список файлов недоступен.</div>';
}

async function refreshCatalogs() {
  const canUseApiCatalog = hasUsableApiKey();
  const [staticItems, staticVehicles, iconManifest] = await Promise.all([
    fetchStaticJson('/spawnable-items.json'),
    fetchStaticJson('/spawnable-vehicles.json'),
    fetchStaticJson('/item-icons-manifest.json')
  ]);
  const items = unwrapCatalogData(staticItems, 'items');
  const vehicles = unwrapCatalogData(staticVehicles, 'vehicles');
  const [apiItems, apiVehicles, skills] = await Promise.all([
    canUseApiCatalog && !items.length ? api('/api/catalog/items').catch(() => []) : Promise.resolve([]),
    canUseApiCatalog && !vehicles.length ? api('/api/catalog/vehicles').catch(() => []) : Promise.resolve([]),
    canUseApiCatalog ? api('/api/player/skill-catalog').catch(() => []) : Promise.resolve([])
  ]);
  buildItemIconLookup(iconManifest);
  state.items = (items.length ? items : unwrapCatalogData(apiItems, 'items')).map(entry => normalizeCatalogEntry(entry, 'item'));
  state.vehicles = (vehicles.length ? vehicles : unwrapCatalogData(apiVehicles, 'vehicles')).map(entry => normalizeCatalogEntry(entry, 'vehicle'));
  state.skillCatalog = mergeSkillCatalog(skills);
  if (els.itemCatalog) {
    els.itemCatalog.innerHTML = state.items.map(item => `<option value="${escapeAttr(item.itemId || item.id || '')}">${escapeHtml(item.name || item.category || '')}</option>`).join('');
  }
  if (els.vehicleCatalog) {
    els.vehicleCatalog.innerHTML = state.vehicles.map(vehicle => `<option value="${escapeAttr(vehicle.vehicleId || vehicle.id || '')}">${escapeHtml(vehicle.name || vehicle.category || '')}</option>`).join('');
  }
  refreshRentalVehicleCatalog();
  if (els.skillCatalog) {
    els.skillCatalog.innerHTML = [
      '<option value="allskills">Все навыки сразу - уровень из поля рядом</option>',
      '<option value="AllSkills">Все навыки сразу - режим Wargm</option>'
    ].concat(state.skillCatalog.map(skillOptionHtml)).join('');
  }
  renderCharacterPackCatalog();
  renderModuleCatalog();
}

async function refreshModules() {
  const modules = ensurePanelModules(await api('/api/plugins'));
  state.modules = await hydratePanelModules(modules);
  if (!state.selectedModule && state.modules.length) state.selectedModule = state.modules[0].key;
  refreshRentalVehicleCatalog();
  renderModules();
  renderCharacterPackCatalog();
}

function ensurePanelModules(modules) {
  const list = Array.isArray(modules) ? modules.slice() : [];
  const keys = new Set(list.map(m => String(m && m.key || '').toLowerCase()));
  if (!keys.has('daily-pack')) {
    list.push({
      key: 'daily-pack',
      name: 'Ежедневный пак',
      description: 'Ежедневная выдача предметов через безопасную очередь WelcomePack.',
      category: 'players',
      enabled: true,
      config: {
        Name: 'Ежедневный пак',
        Description: 'Ежедневная выдача предметов игроку через безопасную очередь WelcomePack.',
        Enabled: true,
        CooldownHours: 24,
        RequiredPermission: '',
        SuccessMessage: 'Ежедневный пак выдан.',
        Items: [
          { ItemId: 'Apple_2', Quantity: 2 },
          { ItemId: 'CannedGoulash', Quantity: 1 },
          { ItemId: 'Emergency_bandage_Big', Quantity: 1 }
        ]
      },
      synthetic: true
    });
  }
  return list;
}

async function hydratePanelModules(list) {
  await Promise.all(['daily-pack'].map(async key => {
    try {
      const data = await api(`/api/plugin-config?name=${encodeURIComponent(key)}`);
      const config = data && data.config ? data.config : null;
      if (!config) return;
      const existing = list.find(module => String(module && module.key || '').toLowerCase() === key);
      const module = existing || {
        key,
        name: config.Name || 'Ежедневный пак',
        description: config.Description || 'Ежедневная выдача предметов через безопасную очередь WelcomePack.',
        category: 'players'
      };
      module.config = config;
      module.name = config.Name || module.name || key;
      module.description = config.Description || module.description || '';
      module.enabled = moduleIsEnabled(module);
      module.synthetic = false;
      if (!existing) list.push(module);
    } catch (_) {
      // If the server does not expose this config endpoint, keep the local fallback.
    }
  }));
  return list;
}

function moduleConfig(key) {
  const mod = state.modules.find(item => item.key === key);
  return mod && mod.config ? mod.config : {};
}

function rentalVehiclesFromConfig() {
  const rental = moduleConfig('vehicle-rental');
  const rows = Array.isArray(rental.Vehicles) ? rental.Vehicles : (Array.isArray(rental.vehicles) ? rental.vehicles : []);
  const seen = new Set();
  return rows.map(vehicle => {
    const asset = String(vehicle.AssetName || vehicle.assetName || vehicle.vehicleId || '').trim();
    const alias = String(vehicle.Alias || vehicle.alias || '').trim();
    const key = (asset || alias).toLowerCase();
    if (!key || seen.has(key) || vehicle.Enabled === false || vehicle.enabled === false) return null;
    seen.add(key);
    return {
      raw: vehicle,
      asset,
      alias,
      label: vehicle.DisplayName || vehicle.displayName || asset || alias,
      defaultMinutes: vehicle.DefaultMinutes ?? vehicle.defaultMinutes ?? rental.DefaultRentalMinutes ?? rental.defaultRentalMinutes ?? 10,
      minMinutes: vehicle.MinMinutes ?? vehicle.minMinutes ?? rental.MinRentalMinutes ?? rental.minRentalMinutes ?? 10,
      maxMinutes: vehicle.MaxMinutes ?? vehicle.maxMinutes ?? rental.MaxRentalMinutes ?? rental.maxRentalMinutes ?? 60,
      penalty: vehicle.MissingVehiclePenalty ?? vehicle.missingVehiclePenalty ?? rental.DefaultMissingVehiclePenalty ?? rental.defaultMissingVehiclePenalty ?? 0
    };
  }).filter(Boolean);
}

function rentalVehicleByInput(value) {
  const wanted = String(value || '').trim().toLowerCase();
  if (!wanted) return null;
  return rentalVehiclesFromConfig().find(vehicle =>
    String(vehicle.asset || '').toLowerCase() === wanted ||
    String(vehicle.alias || '').toLowerCase() === wanted ||
    String(vehicle.label || '').toLowerCase() === wanted) || null;
}

function firstRentalVehicle() {
  return rentalVehiclesFromConfig()[0] || null;
}

function refreshRentalVehicleCatalog() {
  if (!els.rentalVehicleCatalog) return;
  const vehicles = rentalVehiclesFromConfig();
  els.rentalVehicleCatalog.innerHTML = vehicles
    .map(vehicle => `<option value="${escapeAttr(vehicle.asset || vehicle.alias)}">${escapeHtml(vehicle.label || vehicle.asset || vehicle.alias)}</option>`)
    .join('');
  if (els.playerActionRentalVehicleId && !rentalVehicleByInput(els.playerActionRentalVehicleId.value)) {
    els.playerActionRentalVehicleId.value = vehicles[0] ? (vehicles[0].asset || vehicles[0].alias) : '';
  }
}

function characterPackOptions() {
  const cfg = moduleConfig('character-packs');
  const packs = Array.isArray(cfg.Packs) ? cfg.Packs : [];
  const presets = Array.isArray(cfg.SkillPresets) ? cfg.SkillPresets : [];
  const items = packs.map(pack => ({
    value: pack.Name || '',
    label: pack.Description || pack.Name || 'пакет'
  })).concat(presets.map(preset => ({
    value: preset.Name || preset.Skill || '',
    label: preset.Description || preset.Skill || 'пресет навыка'
  }))).filter(entry => entry.value);
  if (!items.some(entry => String(entry.value).toLowerCase() === 'fullstats')) {
    items.unshift({ value: 'fullstats', label: 'Полный пресет атрибутов' });
  }
  return items;
}

function renderCharacterPackCatalog() {
  if (!els.characterPackCatalog) return;
  els.characterPackCatalog.innerHTML = characterPackOptions()
    .map(entry => `<option value="${escapeAttr(entry.value)}">${escapeHtml(entry.label || '')}</option>`)
    .join('');
}

async function ensureModulesLoaded() {
  if (!state.modules.length) {
    state.modules = ensurePanelModules(await api('/api/plugins'));
    renderCharacterPackCatalog();
  }
}

async function refreshHomes() {
  const data = await api('/api/home/list');
  state.homes = Array.isArray(data) ? data : [];
  renderHomes();
}

function renderHomes() {
  if (!els.homeList) return;
  els.homeList.innerHTML = state.homes.length ? state.homes.slice().reverse().slice(0, 12).map(home => `<article class="event home-row">
    <div class="meta"><span>${escapeHtml(home.label || 'home')}</span><span>${fmtTime(home.utc)}</span></div>
    <div>${escapeHtml(home.name || home.steamId || '')}: ${Number(home.x || 0).toFixed(0)}, ${Number(home.y || 0).toFixed(0)}, ${Number(home.z || 0).toFixed(0)}</div>
    <button class="btn" data-home-label="${escapeAttr(home.label || 'home')}" data-home-x="${escapeAttr(home.x || 0)}" data-home-y="${escapeAttr(home.y || 0)}" data-home-z="${escapeAttr(home.z || 0)}">Телепорт</button>
  </article>`).join('') : '<div class="event">Сохранённых точек пока нет.</div>';
}

async function refreshWelcomeTimers() {
  const [timers, claims] = await Promise.all([
    api('/api/welcome-pack/timers').catch(() => []),
    api('/api/module-state', { method: 'POST', body: JSON.stringify({ key: 'welcome-pack' }) }).catch(() => [])
  ]);
  state.welcomeTimers = Array.isArray(timers) ? timers : [];
  state.welcomeClaims = Array.isArray(claims) ? claims : [];
  renderWelcomeTimers();
}

function renderWelcomeTimers() {
  if (!els.welcomeTimers) return;
  const latestByPlayer = new Map();
  const keyFor = row => String(row.steamId || row.steam || row.name || row.userProfileId || 'unknown').toLowerCase();
  for (const timer of state.welcomeTimers || []) {
    const key = keyFor(timer);
    latestByPlayer.set(key, Object.assign({}, latestByPlayer.get(key) || {}, { timer }));
  }
  for (const claim of state.welcomeClaims || []) {
    const key = keyFor(claim);
    const current = latestByPlayer.get(key) || {};
    current.claims = current.claims || [];
    current.claims.push(claim);
    latestByPlayer.set(key, current);
  }
  const rows = Array.from(latestByPlayer.values()).map(entry => {
    const claims = (entry.claims || []).slice().sort((a, b) => String(b.utc || '').localeCompare(String(a.utc || '')));
    const claim = claims[0] || {};
    const timer = entry.timer || {};
    const result = claim.result && typeof claim.result === 'object' ? claim.result : null;
    const ok = claim.ok === true || (result && result.ok === true);
    const failed = claim.ok === false || (result && result.ok === false);
    return {
      steamId: claim.steamId || timer.steamId || '',
      name: claim.name || timer.name || '',
      ok,
      failed,
      claimUtc: claim.utc || timer.utc || '',
      expiresAtUtc: timer.expiresAtUtc || '',
      cooldownHours: timer.cooldownHours ?? '',
      message: claim.message || (result && result.error) || ''
    };
  }).sort((a, b) => String(b.claimUtc || '').localeCompare(String(a.claimUtc || '')));
  els.welcomeTimers.innerHTML = rows.length ? `<div class="welcome-claims">
    <div class="welcome-claims-head">
      <b>Игрок</b><b>SteamID</b><b>Получал</b><b>Следующий доступ</b><b></b>
    </div>
    ${rows.map(row => {
      const status = row.ok ? 'Получил' : (row.failed ? 'Ошибка' : 'Ожидает');
      const statusClass = row.ok ? 'good-text' : (row.failed ? 'bad-text' : 'muted-line');
      const resetTarget = row.steamId || row.name || '';
      return `<article class="welcome-claim-row">
        <span><b>${escapeHtml(row.name || 'игрок')}</b><small>${escapeHtml(row.message || '')}</small></span>
        <span>${escapeHtml(row.steamId || '-')}</span>
        <span class="${statusClass}">${escapeHtml(status)}${row.claimUtc ? `<small>${escapeHtml(fmtTime(row.claimUtc))}</small>` : ''}</span>
        <span>${row.expiresAtUtc ? escapeHtml(fmtTime(row.expiresAtUtc)) : (row.cooldownHours !== '' ? `${escapeHtml(row.cooldownHours)} ч.` : '-')}</span>
        <button class="mini-action danger" type="button"
          data-welcome-reset="${escapeAttr(resetTarget)}"
          data-welcome-steam="${escapeAttr(row.steamId || '')}"
          data-welcome-name="${escapeAttr(row.name || '')}">Сбросить</button>
      </article>`;
    }).join('')}
  </div>` : '<div class="event">Пока нет записей, кто получал стартовый набор.</div>';
}

async function refreshServices() {
  await refreshModules().catch(() => ensureModulesLoaded());
  if (!state.players.length) await refreshPlayers().catch(() => {});
  const fast = moduleConfig('fast-travel');
  const routes = Array.isArray(fast.Outposts) ? fast.Outposts : (Array.isArray(fast.outposts) ? fast.outposts : (Array.isArray(fast.points) ? fast.points : []));
  els.fastRoute.innerHTML = '<option value="">Координаты вручную</option>' + routes.map(route => {
    const pointValue = route.ArrivalPoint || route.arrivalPoint || route.point || [];
    const point = Array.isArray(pointValue) ? pointValue.join(',') : '';
    const alias = route.CommandAlias || route.commandAlias || route.alias || '';
    const price = route.Price ?? route.price ?? '';
    return `<option value="${escapeAttr(alias)}" data-point="${escapeAttr(point)}" data-price="${escapeAttr(price)}">${escapeHtml(route.DisplayName || route.displayName || alias || 'маршрут')}</option>`;
  }).join('');
  if (els.fastFare && !els.fastFare.value) {
    const fixedFare = fast.FixedFare ?? fast.fixedFare ?? fast.TravelCost ?? fast.travelCost ?? fast.Amount ?? fast.amount ?? '';
    els.fastFare.value = fixedFare;
  }
  updateFastTravelPricePreview();

  const vehicles = rentalVehiclesFromConfig();
  els.rentalVehicle.innerHTML = vehicles.length ? vehicles.map(vehicle =>
    `<option value="${escapeAttr(vehicle.asset)}" data-alias="${escapeAttr(vehicle.alias)}" data-default-minutes="${escapeAttr(vehicle.defaultMinutes)}" data-min-minutes="${escapeAttr(vehicle.minMinutes)}" data-max-minutes="${escapeAttr(vehicle.maxMinutes)}" data-penalty="${escapeAttr(vehicle.penalty)}">${escapeHtml(vehicle.label)}</option>`
  ).join('') : '<option value="" disabled selected>Транспорт в аренде не настроен</option>';
  applyRentalVehicleDefaults();
  await refreshWelcomeTimers().catch(toast);
  await refreshHomes().catch(toast);
}

function applyRentalVehicleDefaults() {
  if (!els.rentalVehicle || !els.rentalMinutes) return;
  const opt = els.rentalVehicle.selectedOptions[0];
  if (!opt) return;
  const min = Number(opt.dataset.minMinutes || 1);
  const max = Number(opt.dataset.maxMinutes || 1440);
  const value = Number(opt.dataset.defaultMinutes || els.rentalMinutes.value || min);
  els.rentalMinutes.min = String(min || 1);
  els.rentalMinutes.max = String(max || 1440);
  if (!els.rentalMinutes.value || Number(els.rentalMinutes.value) < min || Number(els.rentalMinutes.value) > max) {
    els.rentalMinutes.value = String(Math.min(Math.max(value || min, min), max));
  }
}

function moduleIsEnabled(module) {
  const config = module && module.config ? module.config : {};
  if (Object.prototype.hasOwnProperty.call(config, 'Enabled')) return config.Enabled !== false;
  if (Object.prototype.hasOwnProperty.call(config, 'enabled')) return config.enabled !== false;
  return module && module.enabled !== false;
}

function moduleCardCode(module) {
  const key = String(module && module.key || '').toLowerCase();
  const codes = {
    'welcome-pack': 'WP',
    'daily-pack': 'DP',
    'wargm-shop': 'WG',
    'vehicle-rental': 'VR',
    'fast-travel': 'FT',
    'home-system': 'HM',
    'character-packs': 'SK',
    'bounty-hunt': 'BH',
    'server-kill-feed': 'KF',
    'scheduled-events': 'EV',
    'sector-scan': 'SC',
    'private-messages': 'PM',
    'discord-log': 'DS'
  };
  return codes[key] || shortCode(module && (module.name || module.key), 'PL').slice(0, 3);
}

function moduleStatusLabel(module) {
  return moduleIsEnabled(module) ? 'Активен' : 'Отключен';
}

function renderModules() {
  document.body.dataset.selectedModule = state.selectedModule || '';
  els.moduleList.innerHTML = state.modules.map(m => `<article class="module-card module-item-card ${m.key === state.selectedModule ? 'active' : ''}" data-module="${escapeAttr(m.key)}">
    <div class="module-icon">${escapeHtml(moduleCardCode(m))}</div>
    <div class="module-meta">
      <h4>${escapeHtml(m.name || m.key)}</h4>
      <span>${escapeHtml(moduleStatusLabel(m))}</span>
      ${m.description ? `<p>${escapeHtml(m.description)}</p>` : ''}
    </div>
  </article>`).join('');
  const selected = state.modules.find(m => m.key === state.selectedModule);
  if (els.moduleSummary) {
    const enabled = state.modules.filter(moduleIsEnabled).length;
    els.moduleSummary.innerHTML = `
      <article class="summary-card"><b>${state.modules.length}</b><span>модулей</span></article>
      <article class="summary-card"><b>${enabled}</b><span>включено</span></article>
      <article class="summary-card"><b>${escapeHtml((selected && selected.name) || '-')}</b><span>выбран</span></article>`;
  }
  if (selected) {
    els.moduleTitle.innerHTML = `${escapeHtml(selected.name || selected.key)} <span class="status-badge ${moduleIsEnabled(selected) ? 'enabled' : 'disabled'}">${escapeHtml(moduleStatusLabel(selected))}</span>`;
    if (els.saveModule) els.saveModule.textContent = `Сохранить ${selected.name}`;
    state.moduleDraft = JSON.parse(JSON.stringify(selected.config || {}));
    setModuleDraftText();
    renderModuleActions(selected);
    renderModuleFields(state.moduleDraft);
  }
}

function moduleArrayActionFor(key) {
  const normalized = String(key || '').toLowerCase();
  const actions = {
    'welcome-pack': { arrayKey: 'Items', label: 'Добавить предмет', addId: 'welcomePackAddItemBtn', saveId: 'welcomePackSaveBtn' },
    'daily-pack': { arrayKey: 'Items', label: 'Добавить предмет', addId: 'dailyPackAddItemBtn', saveId: 'dailyPackSaveBtn' },
    'vehicle-rental': { arrayKey: 'Vehicles', label: 'Добавить транспорт', addId: 'vehicleRentalAddVehicleBtn', saveId: 'vehicleRentalSaveBtn' },
    'fast-travel': { arrayKey: 'Outposts', label: 'Добавить аванпост', addId: 'fastTravelAddOutpostBtn', saveId: 'fastTravelSaveBtn' },
    'wargm-shop': { arrayKey: 'Rules', label: 'Добавить правило', addId: 'wargmAddRuleBtn', saveId: 'wargmSaveBtn' },
    'character-packs': { arrayKey: 'SkillPresets', label: 'Добавить пресет навыков', addId: 'characterToolsAddSkillPresetBtn', saveId: 'characterToolsSaveBtn' },
    'home-system': { saveId: 'homeSystemSaveBtn' },
    'bounty-hunt': { saveId: 'bountyHuntSaveBtn' },
    'server-kill-feed': { saveId: 'serverKillFeedSaveBtn' },
    'scheduled-events': { arrayKey: 'Jobs', label: 'Добавить задание', addId: 'scheduledEventsAddJobBtn', saveId: 'scheduledEventsSaveBtn' },
    'sector-scan': { saveId: 'sectorScanSaveBtn' },
    'private-messages': { saveId: 'privateMessagesSaveBtn' },
    'discord-log': { saveId: 'discordSaveBtn' }
  };
  return actions[normalized] || { saveId: 'moduleQuickSaveBtn' };
}

function renderModuleActions(module) {
  if (!els.moduleActions) return;
  const action = moduleArrayActionFor(module && module.key);
  const stateKey = module ? module.key : '';
  els.moduleActions.innerHTML = `
    <button class="btn primary" id="${escapeAttr(action.saveId || 'moduleQuickSaveBtn')}" type="button" data-module-save>Сохранить изменения</button>
    ${action.arrayKey ? `<button class="btn" id="${escapeAttr(action.addId || 'moduleQuickAddBtn')}" type="button" data-module-add-array="${escapeAttr(action.arrayKey)}">${escapeHtml(action.label)}</button>` : ''}`;
}

function moduleUsesCatalog(moduleKey, draft) {
  const key = String(moduleKey || '').toLowerCase();
  if (['welcome-pack', 'daily-pack', 'wargm-shop', 'vehicle-rental', 'scheduled-events'].includes(key)) return true;
  const seen = new Set();
  const hasCatalogKey = value => /(^|_)(item|items|itemid|item_id|vehicle|vehicles|vehicleid|vehicle_id)(_|$)/i.test(String(value || ''));
  const scan = value => {
    if (value == null || typeof value !== 'object') return false;
    if (seen.has(value)) return false;
    seen.add(value);
    if (Array.isArray(value)) return value.some(scan);
    return Object.keys(value).some(childKey => hasCatalogKey(childKey) || scan(value[childKey]));
  };
  return scan(draft);
}

function updateModuleCatalogVisibility() {
  if (!els.moduleCatalog) return;
  const visible = moduleUsesCatalog(state.selectedModule, state.moduleDraft);
  els.moduleCatalog.hidden = !visible;
  if (visible) renderModuleCatalog();
}

function renderItemBatch() {
  if (!els.itemBatchList) return;
  els.itemBatchList.innerHTML = state.itemBatch.length
    ? state.itemBatch.map((item, index) => `<span>${escapeHtml(item.itemId)} x${escapeHtml(item.quantity)} <button class="mini-remove" data-batch-remove="${index}" title="Убрать">x</button></span>`).join('')
    : '<span>Список пуст</span>';
}

const arrayEditors = {
  Items: [
    ['ItemId', 'ID предмета', 'text', 'itemCatalog'],
    ['Quantity', 'Количество', 'number']
  ],
  Vehicles: [
    ['Alias', 'Команда', 'text'],
    ['DisplayName', 'Название', 'text'],
    ['AssetName', 'ID транспорта', 'text', 'vehicleCatalog'],
    ['PricePer10Minutes', 'Цена / 10 мин', 'number'],
    ['InitialCharge', 'Стартовая цена', 'number'],
    ['DefaultMinutes', 'Время, мин', 'number'],
    ['MaxMinutes', 'Макс. минут', 'number'],
    ['MissingVehiclePenalty', 'Штраф за продажу/потерю', 'number']
  ],
  Outposts: [
    ['DisplayName', 'Название', 'text'],
    ['CommandAlias', 'Команда', 'text'],
    ['ArrivalPoint.0', 'X', 'number'],
    ['ArrivalPoint.1', 'Y', 'number'],
    ['ArrivalPoint.2', 'Z', 'number'],
    ['Price', 'Цена маршрута', 'number']
  ],
  Rules: [
    ['Enabled', 'Вкл', 'checkbox'],
    ['MatchOfferId', 'ID предложения', 'text'],
    ['MatchTitleContains', 'Название содержит', 'text'],
    ['DeliveryMode', 'Режим', 'select:SpawnItem|Vehicle|Money|Gold|Fame|Attributes|Skill|AllSkills|PlayerCommand|ServerCommand'],
    ['DeliveryLabel', 'Метка', 'text'],
    ['ItemId', 'ID предмета', 'text', 'itemCatalog'],
    ['Quantity', 'Кол-во', 'number'],
    ['VehicleAsset', 'ID транспорта', 'text', 'vehicleCatalog'],
    ['Amount', 'Сумма', 'number'],
    ['SkillName', 'Навык', 'text', 'skillCatalog'],
    ['SkillLevel', 'Уровень', 'number'],
    ['SkillExperience', 'Опыт навыка', 'number'],
    ['Strength', 'Сила', 'number'],
    ['Constitution', 'Телосложение', 'number'],
    ['Dexterity', 'Ловкость', 'number'],
    ['Intelligence', 'Интеллект', 'number'],
    ['CommandTemplate', 'Шаблон команды', 'textarea'],
    ['SuccessMessage', 'Сообщение', 'text']
  ],
  SkillPresets: [
    ['Name', 'Название', 'text'],
    ['Skill', 'Навык', 'text'],
    ['Level', 'Уровень', 'number'],
    ['Experience', 'Опыт', 'number']
  ],
  Jobs: [
    ['Enabled', 'Вкл', 'checkbox'],
    ['Name', 'Название', 'text'],
    ['Mode', 'Тип', 'select:Airdrop|SpawnItems|Command'],
    ['IntervalMinutes', 'Период, мин', 'number'],
    ['RunOnStartup', 'Стартовать сразу', 'checkbox'],
    ['PointGroup', 'Группа точек', 'text'],
    ['ItemSet', 'Набор предметов', 'text'],
    ['CommandTemplate', 'Команда', 'textarea'],
    ['Announcement', 'Сообщение в чат', 'text'],
    ['MaxItemsPerRun', 'Лимит предметов', 'number']
  ],
  Points: [
    ['Name', 'Название', 'text'],
    ['Group', 'Группа', 'text'],
    ['X', 'X', 'number'],
    ['Y', 'Y', 'number'],
    ['Z', 'Z', 'number'],
    ['Radius', 'Разброс', 'number']
  ],
  ItemSets: [
    ['Name', 'Название', 'text'],
    ['Weight', 'Вес', 'number'],
    ['ItemsText', 'Предметы', 'textarea']
  ],
  Packs: [
    ['Name', 'Название', 'text'],
    ['Enabled', 'Вкл', 'checkbox'],
    ['Permission', 'Право доступа', 'text'],
    ['Description', 'Описание', 'text'],
    ['CooldownHours', 'Кулдаун, ч', 'number'],
    ['Attributes.Strength', 'Сила', 'number'],
    ['Attributes.Constitution', 'Телосложение', 'number'],
    ['Attributes.Dexterity', 'Ловкость', 'number'],
    ['Attributes.Intelligence', 'Интеллект', 'number'],
    ['Actions.0.Value', 'Команда 1', 'text'],
    ['SuccessMessage', 'Сообщение', 'text']
  ]
};
arrayEditors.items = arrayEditors.Items;
arrayEditors.vehicles = arrayEditors.Vehicles;
arrayEditors.rules = arrayEditors.Rules;
arrayEditors.points = arrayEditors.Outposts;
arrayEditors.outposts = arrayEditors.Outposts;
arrayEditors.skillPresets = arrayEditors.SkillPresets;
arrayEditors.jobs = arrayEditors.Jobs;
arrayEditors.itemSets = arrayEditors.ItemSets;
arrayEditors.warningMinutes = null;

function setModuleDraftText() {
  els.moduleConfig.value = JSON.stringify(state.moduleDraft || {}, null, 2);
}

function collectModuleDraftFromFields() {
  if (!els.moduleFields || !state.moduleDraft) return;
  els.moduleFields
    .querySelectorAll('[data-config-key], [data-array-key], [data-object-key], [data-rule-item-field]')
    .forEach(field => syncModuleField(field));
  setModuleDraftText();
}

function defaultArrayItem(key) {
  const normalized = key.toLowerCase();
  if (normalized === 'items') return key === 'items' ? { itemId: 'Apple_2', quantity: 1 } : { ItemId: 'Apple_2', Quantity: 1 };
  if (normalized === 'vehicles') return key === 'vehicles' ? { alias: 'vehicle', displayName: 'Транспорт', assetName: 'BPC_WolfsWagen', pricePer10Minutes: 0, initialCharge: 0, defaultMinutes: 10, maxMinutes: 60, missingVehiclePenalty: 0 } : { Alias: 'vehicle', DisplayName: 'Транспорт', AssetName: 'BPC_WolfsWagen', PricePer10Minutes: 0, InitialCharge: 0, DefaultMinutes: 10, MaxMinutes: 60, MissingVehiclePenalty: 0 };
  if (normalized === 'outposts') return key === 'outposts' ? { displayName: 'Новый маршрут', commandAlias: 'route', arrivalPoint: [0, 0, 50], price: 0 } : { DisplayName: 'Новый маршрут', CommandAlias: 'route', CenterZone: [0, 0], ArrivalPoint: [0, 0, 50], Price: 0 };
  if (normalized === 'rules') return key === 'rules' ? { enabled: true, matchOfferId: '', matchTitleContains: '', deliveryMode: 'SpawnItem', deliveryLabel: 'Выдача', itemId: 'Apple_2', items: [{ itemId: 'Apple_2', quantity: 1 }], quantity: 1, vehicleAsset: '', amount: 0, successMessage: 'Покупка выдана.' } : { Enabled: true, MatchOfferId: '', MatchTitleContains: '', DeliveryMode: 'SpawnItem', DeliveryLabel: 'Выдача', ItemId: 'Apple_2', Items: [{ ItemId: 'Apple_2', Quantity: 1 }], VehicleAsset: '', Quantity: 1, Amount: 0, SkillName: '', SkillLevel: 0, SkillExperience: 0, Strength: 0, Constitution: 0, Dexterity: 0, Intelligence: 0, CommandTemplate: '', SuccessMessage: 'Покупка выдана.' };
  if (normalized === 'skillpresets') return { Name: 'Навык', Skill: 'Survival', Level: 1, Experience: 0 };
  if (normalized === 'jobs') return { Enabled: true, Name: 'Новое событие', Mode: 'Airdrop', IntervalMinutes: 60, RunOnStartup: false, PointGroup: 'airdrop', ItemSet: '', CommandTemplate: 'ScheduleWorldEvent CargoDrop {X} {Y} {Z}', Announcement: '[Ивент] Cargo drop вызван в районе {Point}.', MaxItemsPerRun: 30 };
  if (normalized === 'points') return { Name: 'Новая точка', Group: 'airdrop', X: 0, Y: 0, Z: 20000, Radius: 150 };
  if (normalized === 'itemsets') return { Name: 'basic', Weight: 1, ItemsText: 'Apple_2|2;CannedGoulash|1' };
  if (normalized === 'packs') return { Name: 'fullstats', Enabled: true, Description: 'Быстрый пакет персонажа', CooldownHours: 0, Attributes: { Strength: 8, Constitution: 8, Dexterity: 8, Intelligence: 8 }, Actions: [{ Type: 'PlayerCommand', Value: 'SetAttributes 8 8 8 8', StopOnFailure: true }], Skills: [], SuccessMessage: 'Атрибуты персонажа обновлены.' };
  return {};
}

function getNestedValue(obj, path) {
  const parts = String(path).split('.');
  let cur = obj;
  for (const part of parts) {
    if (cur == null) return '';
    const actual = Object.prototype.hasOwnProperty.call(cur, part)
      ? part
      : Object.keys(cur).find(key => key.toLowerCase() === part.toLowerCase());
    cur = actual === undefined ? undefined : cur[actual];
  }
  return cur ?? '';
}

function setNestedValue(obj, path, value) {
  const parts = String(path).split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const part = Object.keys(cur).find(key => key.toLowerCase() === parts[i].toLowerCase()) || parts[i];
    const next = parts[i + 1];
    if (cur[part] == null) cur[part] = /^\d+$/.test(next) ? [] : {};
    cur = cur[part];
  }
  const last = Object.keys(cur).find(key => key.toLowerCase() === parts[parts.length - 1].toLowerCase()) || parts[parts.length - 1];
  cur[last] = value;
}

function renderArrayInput(arrayKey, index, field, label, kind, listId, row) {
  const value = getNestedValue(row, field);
  const base = `data-array-key="${escapeAttr(arrayKey)}" data-array-index="${index}" data-array-field="${escapeAttr(field)}"`;
  if (kind === 'checkbox') {
    return `<label class="mini-check"><input ${base} type="checkbox" ${value ? 'checked' : ''} /> ${escapeHtml(label)}</label>`;
  }
  if (kind.startsWith('select:')) {
    const options = kind.slice(7).split('|').map(opt => `<option value="${escapeAttr(opt)}" ${String(value) === opt ? 'selected' : ''}>${escapeHtml(selectOptionLabel(opt))}</option>`).join('');
    return `<label><span>${escapeHtml(label)}</span><select ${base}>${options}</select></label>`;
  }
  if (kind === 'textarea') {
    return `<label class="wide"><span>${escapeHtml(label)}</span><textarea ${base}>${escapeHtml(value)}</textarea></label>`;
  }
  const inputKind = kind === 'number' ? 'number' : 'text';
  const list = listId ? ` list="${escapeAttr(listId)}"` : '';
  return `<label><span>${escapeHtml(label)}</span><input ${base} type="${inputKind}"${list} value="${escapeAttr(value)}" /></label>`;
}

const wargmRuleModeMeta = {
  SpawnItem: {
    label: 'Предметы',
    help: 'Один товар Wargm может выдавать целый сет. Добавь несколько строк в набор ниже: каждая строка будет выдана после одной покупки.',
    fields: [['ItemId', 'ID предмета', 'text', 'itemCatalog'], ['Quantity', 'Кол-во', 'number']]
  },
  Vehicle: {
    label: 'Транспорт',
    help: 'Спавнит транспорт рядом с игроком через безопасную очередь.',
    fields: [['VehicleAsset', 'ID транспорта', 'text', 'vehicleCatalog'], ['Quantity', 'Кол-во', 'number']]
  },
  Money: {
    label: 'Деньги',
    help: 'Начисляет обычную валюту игроку. Для списания укажи отрицательное число.',
    fields: [['Amount', 'Сумма', 'number']]
  },
  Gold: {
    label: 'Золото',
    help: 'Начисляет золото игроку через тот же безопасный маршрут баланса. Для списания укажи отрицательное число.',
    fields: [['Amount', 'Сумма золота', 'number']]
  },
  Fame: {
    label: 'Очки славы',
    help: 'Начисляет очки славы игроку через ChangeFamePoints. Для списания укажи отрицательное число.',
    fields: [['Amount', 'Очки славы', 'number']]
  },
  Attributes: {
    label: 'Атрибуты',
    help: 'Выставляет STR / CON / DEX / INT выбранному игроку.',
    fields: [['Strength', 'Сила', 'number'], ['Constitution', 'Телосложение', 'number'], ['Dexterity', 'Ловкость', 'number'], ['Intelligence', 'Интеллект', 'number']]
  },
  Skill: {
    label: 'Навык',
    help: 'Выставляет один навык. Названия: Handgun, Melee Weapons, Rifles и другие из каталога.',
    fields: [['SkillName', 'Навык', 'text', 'skillCatalog'], ['SkillLevel', 'Уровень', 'number'], ['SkillExperience', 'Опыт', 'number']]
  },
  AllSkills: {
    label: 'Все навыки',
    help: 'Выставляет весь актуальный список навыков SCUM. Для максимума укажи уровень 4.',
    fields: [['SkillLevel', 'Уровень', 'number'], ['SkillExperience', 'Опыт', 'number']]
  },
  PlayerCommand: {
    label: 'Команда игрока',
    help: 'Редкий режим. Используй только проверенные команды.',
    fields: [['CommandTemplate', 'Шаблон команды', 'textarea']]
  },
  ServerCommand: {
    label: 'Команда сервера',
    help: 'Редкий режим. Используй только проверенные команды.',
    fields: [['CommandTemplate', 'Шаблон команды', 'textarea']]
  }
};

const wargmRuleModeAliases = {
  item: 'SpawnItem',
  items: 'SpawnItem',
  spawnitem: 'SpawnItem',
  vehicle: 'Vehicle',
  spawnvehicle: 'Vehicle',
  money: 'Money',
  currency: 'Money',
  balance: 'Money',
  gold: 'Gold',
  fame: 'Fame',
  famepoint: 'Fame',
  famepoints: 'Fame',
  changefame: 'Fame',
  changefamepoints: 'Fame',
  setfame: 'Fame',
  setfamepoints: 'Fame',
  attributes: 'Attributes',
  attribute: 'Attributes',
  stats: 'Attributes',
  skill: 'Skill',
  setskill: 'Skill',
  allskills: 'AllSkills',
  allskill: 'AllSkills',
  skillpack: 'AllSkills',
  skillspack: 'AllSkills',
  playercommand: 'PlayerCommand',
  servercommand: 'ServerCommand',
  command: 'PlayerCommand'
};

function wargmRuleValue(row, key, fallback = '') {
  if (!row) return fallback;
  const actual = Object.keys(row).find(item => item.toLowerCase() === key.toLowerCase());
  return actual ? row[actual] : fallback;
}

function wargmRuleMode(row) {
  const uiMode = String(wargmRuleValue(row, 'UiDeliveryMode', '') || '');
  if (wargmRuleModeMeta[uiMode]) return uiMode;
  const mode = String(wargmRuleValue(row, 'DeliveryMode', 'SpawnItem') || 'SpawnItem');
  if (wargmRuleModeMeta[mode]) return mode;
  const commandTemplate = String(wargmRuleValue(row, 'CommandTemplate', '') || '').toLowerCase();
  if (commandTemplate.includes('changefamepoints') || commandTemplate.includes('setfamepoints')) return 'Fame';
  const normalized = mode.toLowerCase().replace(/[\s_.-]+/g, '');
  return wargmRuleModeAliases[normalized] || 'SpawnItem';
}

function renderWargmRuleInput(arrayKey, index, row, field, label, kind, listId) {
  if (field === 'DeliveryMode') {
    return renderArrayInput(arrayKey, index, field, label, kind, listId, Object.assign({}, row || {}, { DeliveryMode: wargmRuleMode(row || {}) }));
  }
  return renderArrayInput(arrayKey, index, field, label, kind, listId, row || {});
}

function renderWargmRuleItems(arrayKey, index, row) {
  const items = Array.isArray(row && row.Items) ? row.Items : (Array.isArray(row && row.items) ? row.items : []);
  const total = items.reduce((sum, item) => sum + Math.max(1, Number(item.Quantity || item.quantity || 1)), 0);
  const rows = items.map((item, itemIndex) => `<div class="rule-item-row">
      <span class="rule-item-index">${itemIndex + 1}</span>
      <label><span>ID предмета</span><input data-rule-item-field="ItemId" data-array-key="${escapeAttr(arrayKey)}" data-array-index="${index}" data-rule-item-index="${itemIndex}" list="itemCatalog" value="${escapeAttr(item.ItemId || item.itemId || '')}" placeholder="Weapon_MK18" /></label>
      <label class="qty"><span>Кол-во</span><input data-rule-item-field="Quantity" data-array-key="${escapeAttr(arrayKey)}" data-array-index="${index}" data-rule-item-index="${itemIndex}" type="number" min="1" value="${escapeAttr(item.Quantity || item.quantity || 1)}" /></label>
      <button type="button" class="mini-action" data-wargm-rule-item-remove="${index}" data-rule-item-index="${itemIndex}">Удалить</button>
    </div>`).join('');
  return `<div class="wargm-rule-section nested-items">
    <div class="wargm-rule-section-head">
      <div>
        <h4>Набор предметов в одном товаре</h4>
        <p>${items.length ? `В сете ${items.length} строк, всего ${total} шт.` : 'Если список пустой, будет выдан одиночный предмет из поля выше.'}</p>
      </div>
      <div class="rule-item-actions">
        <button type="button" class="mini-action" data-wargm-rule-item-copy-single="${index}">Взять ID выше</button>
        <button type="button" class="mini-action primary" data-wargm-rule-item-add="${index}">Добавить строку</button>
      </div>
    </div>
    ${rows || '<div class="muted-line">Список пуст. Будет использован одиночный ID предмета выше.</div>'}
  </div>`;
}

function renderWargmRuleSummary(row) {
  const offer = wargmRuleValue(row, 'MatchOfferId', '');
  const title = wargmRuleValue(row, 'MatchTitleContains', '');
  const label = wargmRuleValue(row, 'DeliveryLabel', '');
  return [offer ? `offer ${offer}` : '', title ? `название: ${title}` : '', label || 'без метки'].filter(Boolean).join(' · ');
}

function wargmRuleItemCount(row) {
  const items = Array.isArray(row && row.Items) ? row.Items : (Array.isArray(row && row.items) ? row.items : []);
  return items.length;
}

function wargmRuleDeliverySummary(row, mode) {
  if (mode === 'SpawnItem') {
    const count = wargmRuleItemCount(row || {});
    return count > 0 ? `${count} предметов` : `${wargmRuleValue(row, 'ItemId', 'предмет не указан')} x${wargmRuleValue(row, 'Quantity', 1) || 1}`;
  }
  if (mode === 'Vehicle') return wargmRuleValue(row, 'VehicleAsset', '') || 'транспорт не указан';
  if (mode === 'Money') return `баланс: ${Number(wargmRuleValue(row, 'Amount', 0) || 0)}`;
  if (mode === 'Gold') return `золото: ${Number(wargmRuleValue(row, 'Amount', 0) || 0)}`;
  if (mode === 'Fame') return `слава: ${Number(wargmRuleValue(row, 'Amount', 0) || 0)}`;
  if (mode === 'Skill') return `${wargmRuleValue(row, 'SkillName', 'навык')} ур. ${wargmRuleValue(row, 'SkillLevel', 0) || 0}`;
  if (mode === 'AllSkills') return `все навыки ур. ${wargmRuleValue(row, 'SkillLevel', 4) || 4}`;
  if (mode === 'Attributes') return `STR ${wargmRuleValue(row, 'Strength', 0) || 0} / CON ${wargmRuleValue(row, 'Constitution', 0) || 0} / DEX ${wargmRuleValue(row, 'Dexterity', 0) || 0} / INT ${wargmRuleValue(row, 'Intelligence', 0) || 0}`;
  return wargmRuleValue(row, 'CommandTemplate', '') || 'команда не указана';
}

function renderWargmRuleEditorBody(key, index, row) {
  const mode = wargmRuleMode(row || {});
  const meta = wargmRuleModeMeta[mode] || wargmRuleModeMeta.SpawnItem;
  return `<div class="wargm-rule-layout">
        <section class="wargm-rule-section">
          <div class="wargm-rule-section-title">
            <div>
              <h4>1. Как найти покупку</h4>
              <p>ID предложения надёжнее названия. Название можно использовать как запасной вариант.</p>
            </div>
            ${renderWargmRuleInput(key, index, row, 'Enabled', 'Правило включено', 'checkbox')}
          </div>
          <div class="array-grid wargm-setup-grid">
            ${renderWargmRuleInput(key, index, row, 'MatchOfferId', 'ID предложения Wargm', 'text')}
            ${renderWargmRuleInput(key, index, row, 'MatchTitleContains', 'Название содержит', 'text')}
            ${renderWargmRuleInput(key, index, row, 'DeliveryLabel', 'Метка для логов', 'text')}
          </div>
        </section>

        <section class="wargm-rule-section">
          <h4>2. Что выдать</h4>
          <p>${escapeHtml(meta.help)}</p>
          <div class="array-grid wargm-delivery-grid">
            ${renderWargmRuleInput(key, index, row, 'DeliveryMode', 'Тип выдачи', 'select:SpawnItem|Vehicle|Money|Gold|Fame|Attributes|Skill|AllSkills|PlayerCommand|ServerCommand')}
            ${meta.fields.map(([field, label, kind, listId]) => renderWargmRuleInput(key, index, row, field, label, kind, listId)).join('')}
          </div>
          ${mode === 'SpawnItem' ? renderWargmRuleItems(key, index, row || {}) : ''}
        </section>

        <section class="wargm-rule-section">
          <h4>3. Что написать игроку</h4>
          <div class="array-grid">
            ${renderWargmRuleInput(key, index, row, 'SuccessMessage', 'Сообщение после выдачи', 'text')}
          </div>
        </section>
      </div>`;
}

function renderWargmRuleModal(key, index, row) {
  const mode = wargmRuleMode(row || {});
  const meta = wargmRuleModeMeta[mode] || wargmRuleModeMeta.SpawnItem;
  return `<div class="wargm-rule-modal" data-wargm-rule-overlay="true" role="dialog" aria-modal="true">
    <div class="wargm-rule-modal-card">
      <div class="wargm-rule-modal-head">
        <div>
          <span class="wargm-modal-kicker">Настройка товара</span>
          <h3>Правило #${index + 1}</h3>
          <p>${escapeHtml(renderWargmRuleSummary(row || {}))}</p>
        </div>
        <div class="wargm-rule-modal-actions">
          <span class="wargm-mode-pill">${escapeHtml(meta.label)}</span>
          <button type="button" class="mini-action" data-wargm-rule-close="true">Закрыть</button>
        </div>
      </div>
      ${renderWargmRuleEditorBody(key, index, row || {})}
    </div>
  </div>`;
}

function renderWargmRulesEditor(key, value) {
  const rows = Array.isArray(value) ? value : [];
  if (!Number.isInteger(state.wargmRuleEditIndex) || !rows[state.wargmRuleEditIndex]) state.wargmRuleEditIndex = rows.length ? 0 : null;
  const body = rows.map((row, index) => {
    const mode = wargmRuleMode(row || {});
    const meta = wargmRuleModeMeta[mode] || wargmRuleModeMeta.SpawnItem;
    const enabled = wargmRuleValue(row || {}, 'Enabled', true) !== false;
    const offer = wargmRuleValue(row || {}, 'MatchOfferId', '') || 'offer не указан';
    const title = wargmRuleValue(row || {}, 'MatchTitleContains', '') || 'название не указано';
    const label = wargmRuleValue(row || {}, 'DeliveryLabel', '') || 'без метки';
    return `<article class="wargm-rule-card ${state.wargmRuleEditIndex === index ? 'active' : ''}">
      <div class="wargm-rule-card-main">
        <div>
          <b>Правило #${index + 1}</b>
          <span>${escapeHtml(title)}</span>
        </div>
        <span class="wargm-rule-card-status ${enabled ? 'on' : 'off'}">${enabled ? 'вкл' : 'выкл'}</span>
      </div>
      <div class="wargm-rule-card-meta">
        <span>${escapeHtml(offer)}</span>
        <span>${escapeHtml(meta.label)}</span>
        <span>${escapeHtml(wargmRuleDeliverySummary(row || {}, mode))}</span>
        <span>${escapeHtml(label)}</span>
      </div>
      <div class="wargm-rule-card-actions">
        <button type="button" class="mini-action primary" data-wargm-rule-open="${index}">Настроить</button>
        <button type="button" class="mini-action danger" data-array-remove="${escapeAttr(key)}" data-array-index="${index}">Удалить</button>
      </div>
    </article>`;
  }).join('');
  const selectedIndex = state.wargmRuleEditIndex;
  const selectedRow = selectedIndex !== null ? rows[selectedIndex] : null;
  const selectedMode = selectedRow ? wargmRuleMode(selectedRow || {}) : 'SpawnItem';
  const selectedMeta = wargmRuleModeMeta[selectedMode] || wargmRuleModeMeta.SpawnItem;
  const workspace = selectedRow ? `<section class="wargm-rule-workspace">
      <div class="wargm-rule-workspace-head">
        <div>
          <span class="wargm-modal-kicker">Настройка товара</span>
          <h3>Правило #${selectedIndex + 1}</h3>
          <p>${escapeHtml(renderWargmRuleSummary(selectedRow || {}))}</p>
        </div>
        <span class="wargm-mode-pill">${escapeHtml(selectedMeta.label)}</span>
      </div>
      ${renderWargmRuleEditorBody(key, selectedIndex, selectedRow || {})}
    </section>` : `<section class="wargm-rule-workspace empty">
      <h3>Правил пока нет</h3>
      <p>Добавь правило и выбери, что выдавать после покупки: предметы, золото, очки славы, навыки или транспорт.</p>
    </section>`;
  return `<div class="field wide array-editor wargm-rules-editor">
    <div class="array-title">
      <div>
        <label>Правила Wargm</label>
        <p>Слева список товаров, справа настройка выбранного правила. Без простыни полей и без лишнего JSON перед глазами.</p>
      </div>
      <button type="button" class="mini-action" data-array-add="${escapeAttr(key)}">Добавить правило</button>
    </div>
    <div class="wargm-rules-shell">
      <aside class="wargm-rule-list">
        ${body || '<div class="muted-line">Правил пока нет. Нажми “Добавить правило”.</div>'}
      </aside>
      ${workspace}
    </div>
  </div>`;
}

function renderArrayEditor(key, value, fields) {
  if (String(key).toLowerCase() === 'rules') return renderWargmRulesEditor(key, value, fields);
  const rows = Array.isArray(value) ? value : [];
  const body = rows.map((row, index) => `<div class="array-row">
    <div class="array-row-head">
      <b>${escapeHtml(configLabel(key))} #${index + 1}</b>
      <button type="button" class="mini-action" data-array-remove="${escapeAttr(key)}" data-array-index="${index}">Удалить</button>
    </div>
    <div class="array-grid">
      ${fields.map(([field, label, kind, listId]) => renderArrayInput(key, index, field, label, kind, listId, row || {})).join('')}
    </div>
  </div>`).join('');
  return `<div class="field wide array-editor">
    <div class="array-title">
      <label>${escapeHtml(configLabel(key))}</label>
      <button type="button" class="mini-action" data-array-add="${escapeAttr(key)}">Добавить</button>
    </div>
    ${body || '<div class="muted-line">Пока пусто.</div>'}
  </div>`;
}

function renderPrimitiveArray(key, value) {
  const mode = key === 'WarningMinutesBeforeExpiry' ? 'number-list' : 'line-list';
  const text = Array.isArray(value) ? value.join(mode === 'number-list' ? ', ' : '\n') : '';
  return `<div class="field wide"><label>${escapeHtml(configLabel(key))}</label><textarea data-config-key="${escapeAttr(key)}" data-config-mode="${mode}">${escapeHtml(text)}</textarea></div>`;
}

function renderObjectEditor(key, value) {
  const object = value && typeof value === 'object' ? value : {};
  if (Object.values(object).every(v => typeof v === 'number')) {
    const inputs = Object.entries(object).map(([field, fieldValue]) => `<label><span>${escapeHtml(configLabel(field))}</span><input data-object-key="${escapeAttr(key)}" data-object-field="${escapeAttr(field)}" type="number" value="${escapeAttr(fieldValue)}" /></label>`).join('');
    return `<div class="field wide object-editor"><label>${escapeHtml(configLabel(key))}</label><div class="array-grid">${inputs}</div></div>`;
  }
  return `<div class="field wide"><label>${escapeHtml(configLabel(key))}</label><textarea data-config-key="${escapeAttr(key)}" spellcheck="false">${escapeHtml(JSON.stringify(object, null, 2))}</textarea></div>`;
}

const moduleFieldGroups = {
  'welcome-pack': [
    { title: 'Основное', keys: ['Enabled', 'RequiredPermission', 'CooldownHours', 'SuccessMessage'] },
    { title: 'Предметы набора', keys: ['Items'] },
    { title: 'Безопасная выдача', keys: ['SerializeClaimsGlobally', 'InterItemDelayMs'] }
  ],
  'daily-pack': [
    { title: 'Основное', keys: ['Enabled', 'Name', 'Description', 'RequiredPermission', 'CooldownHours', 'SuccessMessage'] },
    { title: 'Предметы набора', keys: ['Items'] }
  ],
  'character-packs': [
    { title: 'Основное', keys: ['Enabled', 'RequiredPermission'] },
    { title: 'Базовые атрибуты', keys: ['DefaultAttributes'] },
    { title: 'Пресеты навыков', keys: ['SkillPresets'] },
    { title: 'Пакеты команд', keys: ['Packs'] }
  ],
  'fast-travel': [
    { title: 'Цена и задержки', keys: ['Enabled', 'TransferCooldownMinutes', 'RatePerMeter', 'FixedFare', 'TeleportDelaySeconds', 'TravelConfirmationSeconds'] },
    { title: 'Безопасность телепорта', keys: ['CancelMoveDistance', 'SuccessArrivalDistance'] },
    { title: 'Маршруты', keys: ['Outposts'] }
  ],
  'vehicle-rental': [
    { title: 'Срок аренды', keys: ['Enabled', 'DefaultRentalMinutes', 'MinRentalMinutes', 'MaxRentalMinutes', 'WarningMinutesBeforeExpiry'] },
    { title: 'Оплата и штрафы', keys: ['ChargePenaltyOnMissingVehicle', 'DefaultMissingVehiclePenalty', 'GlobalSpawnCooldownSeconds', 'PlayerSpawnCooldownSeconds'] },
    { title: 'Транспорт', keys: ['Vehicles'] },
    { title: 'Автоочистка', keys: ['EnableRuntimeVehicleReturnDestroy', 'EnableRuntimeVehicleExpireDestroy', 'EnableRuntimeVehicleTrackAfterSpawn', 'CaptureVehiclesBeforeSpawn', 'ExpireDestroyMaxAttempts', 'RuntimeDestroyResolveCooldownSeconds', 'CleanupMaxPerRun', 'RefreshPlayerBeforeVehicleSpawn'] }
  ],
  'wargm-shop': [
    { title: 'Подключение', keys: ['Enabled', 'ProjectId', 'ApiKey', 'WargmServerId', 'PollIntervalSeconds'] },
    { title: 'Выдача', keys: ['DeliveryDelaySeconds', 'RetryDelaySeconds', 'MaxDeliveryAttempts', 'DeliveryFilter', 'RequireRecipientName', 'DeliverOnlyToOnlinePlayers'] },
    { title: 'Сообщения', keys: ['AnnounceBeforeDelivery', 'AnnouncementTemplate', 'BroadcastDeliveries'] },
    { title: 'Защита команд', keys: ['AllowUnsafeCommandDelivery', 'UnsafeCommandInterItemDelayMs', 'UnsafeCommandInterOperationCooldownSeconds', 'UnsafeCommandMaxItemsPerOperation', 'UnsafeCommandMaxQuantityPerItem', 'UseClaimInsteadOfSuccess'] },
    { title: 'Товары', keys: ['Rules'] }
  ],
  'scheduled-events': [
    { title: 'Основное', keys: ['Enabled', 'Name', 'Description', 'MaxRunsPerTick'] },
    { title: 'Задания', keys: ['Jobs'] },
    { title: 'Точки на карте', keys: ['Points'] },
    { title: 'Наборы предметов', keys: ['ItemSets'] }
  ],
  'discord-log': [
    { title: 'Подключение', keys: ['Enabled', 'TransportMode', 'ServerLabel', 'Username', 'AvatarUrl'] },
    { title: 'Webhook-адреса', keys: ['DefaultWebhookUrl', 'PresenceWebhookUrl', 'ChatWebhookUrl', 'CombatWebhookUrl', 'SystemWebhookUrl'] },
    { title: 'Что отправлять', keys: ['NotifyOnLoad', 'NotifyPlayerConnected', 'NotifyPlayerDisconnected', 'NotifyPlayerRespawned', 'NotifyPlayerChat', 'NotifyPlayerKills', 'NotifyPlayerDeaths'] },
    { title: 'Фильтры чата', keys: ['ForwardLocalChat', 'ForwardGlobalChat', 'ForwardSquadChat', 'ForwardAdminChat', 'IgnoreSlashCommands', 'IgnoredChatPrefixes'] },
    { title: 'Ограничения', keys: ['IncludeSteamId', 'MinPostIntervalMs', 'MaxQueueLength', 'DuplicateWindowSeconds', 'HttpTimeoutSeconds'] }
  ],
  'server-kill-feed': [
    { title: 'Основное', keys: ['Enabled', 'Prefix', 'Source'] },
    { title: 'Что показывать', keys: ['AnnounceSuicides', 'IncludeWeapon', 'IncludeDistance', 'IncludeLocations', 'FanoutToPlayers'] },
    { title: 'Журнал и дубли', keys: ['ImportSaveFileKillLog', 'KillLogImportIntervalMs', 'DuplicateWindowSeconds', 'UseRuntimeHooks'] }
  ],
  'bounty-hunt': [
    { title: 'Серии убийств', keys: ['Enabled', 'BroadcastThreshold', 'HeroThreshold', 'MaxBoardEntries'] },
    { title: 'Награда за лидера', keys: ['LeaderKillRewardMode', 'LeaderKillRewardAmount', 'BroadcastLeaderKillReward'] }
  ],
  'private-messages': [
    { title: 'Доступ', keys: ['Enabled', 'UsePermission', 'AllowPermission'] },
    { title: 'Ограничения', keys: ['UseCooldown', 'CooldownTimeSeconds', 'EnableLogging', 'EnableHistory'] }
  ],
  'sector-scan': [
    { title: 'Цена и доступ', keys: ['Enabled', 'RequiredPermission', 'ScanCost', 'CooldownSeconds'] },
    { title: 'Ответ игроку', keys: ['IncludeSelf', 'IncludePlayerNames', 'MaxListedNames', 'SuccessMessage', 'EmptyMessage', 'NotEnoughMoneyMessage', 'CooldownMessage'] }
  ],
  'home-system': [
    { title: 'Лимиты домов', keys: ['Enabled', 'DefaultMaxHomes', 'VipMaxHomes', 'VipPermission'] },
    { title: 'Телепорт домой', keys: ['TeleportDelaySeconds', 'TeleportCooldownMinutes', 'CancelMoveDistance', 'SuccessArrivalDistance'] }
  ]
};

const moduleHiddenConfigKeys = {
  'scheduled-events': ['Instructions']
};

function renderModuleField(key, value) {
  const safeKey = escapeAttr(key);
  const label = escapeHtml(configLabel(key));
  if (Array.isArray(value)) {
    if (arrayEditors[key]) return renderArrayEditor(key, value, arrayEditors[key]);
    return renderPrimitiveArray(key, value);
  }
  if (value && typeof value === 'object') {
    return renderObjectEditor(key, value);
  }
  if (typeof value === 'boolean') {
    return `<div class="field checkbox"><input data-config-key="${safeKey}" type="checkbox" ${value ? 'checked' : ''} /><label>${label}</label></div>`;
  }
  if (typeof value === 'number') {
    return `<div class="field"><label>${label}</label><input data-config-key="${safeKey}" type="number" value="${escapeAttr(value)}" /></div>`;
  }
  if (typeof value === 'string') {
    return `<div class="field"><label>${label}</label><input data-config-key="${safeKey}" value="${escapeAttr(value)}" /></div>`;
  }
  return `<div class="field wide"><label>${label}</label><textarea data-config-key="${safeKey}" spellcheck="false">${escapeHtml(JSON.stringify(value, null, 2))}</textarea></div>`;
}

function renderModuleFields(config) {
  const entries = Object.entries(config || {});
  const hidden = new Set(moduleHiddenConfigKeys[state.selectedModule] || []);
  const groups = moduleFieldGroups[state.selectedModule] || null;
  if (groups) {
    const used = new Set();
    const sections = groups.map(group => {
      const body = group.keys
        .filter(key => Object.prototype.hasOwnProperty.call(config || {}, key) && !hidden.has(key))
        .map(key => {
          used.add(key);
          return renderModuleField(key, config[key]);
        })
        .join('');
      if (!body) return '';
      return `<section class="module-field-section">
        <h3>${escapeHtml(group.title)}</h3>
        <div class="module-field-section-grid">${body}</div>
      </section>`;
    }).join('');
    const rest = entries
      .filter(([key]) => !used.has(key) && !hidden.has(key))
      .map(([key, value]) => renderModuleField(key, value))
      .join('');
    els.moduleFields.innerHTML = sections + (rest ? `<section class="module-field-section"><h3>Дополнительно</h3><div class="module-field-section-grid">${rest}</div></section>` : '');
  } else {
    els.moduleFields.innerHTML = entries
      .filter(([key]) => !hidden.has(key))
      .map(([key, value]) => renderModuleField(key, value))
      .join('');
  }
  updateModuleCatalogVisibility();
}

function renderModuleCatalog() {
  if (!els.moduleCatalogGrid) return;
  const mode = els.moduleCatalogMode ? els.moduleCatalogMode.value : state.catalogMode;
  const nextMode = mode === 'vehicles' ? 'vehicles' : 'items';
  const q = (els.moduleCatalogSearch ? els.moduleCatalogSearch.value : state.catalogSearch || '').trim().toLowerCase();
  if (state.catalogMode !== nextMode) {
    state.catalogCategory = '';
    state.catalogPage = 0;
  }
  if (state.catalogSearch !== q) state.catalogPage = 0;
  state.catalogMode = nextMode;
  state.catalogSearch = q;
  const kind = state.catalogMode === 'vehicles' ? 'vehicle' : 'item';
  const source = kind === 'vehicle' ? state.vehicles : state.items;
  const categories = Array.from(new Set((source || []).map(entry => entry.category || 'Другое').filter(Boolean))).sort((a, b) => a.localeCompare(b));
  if (els.moduleCatalogCategories) {
    els.moduleCatalogCategories.innerHTML = [`<button type="button" class="${state.catalogCategory ? '' : 'active'}" data-catalog-category="">Все</button>`]
      .concat(categories.slice(0, 26).map(category => `<button type="button" class="${state.catalogCategory === category ? 'active' : ''}" data-catalog-category="${escapeAttr(category)}">${escapeHtml(category)}</button>`))
      .join('');
  }
  const filtered = (source || []).filter(entry => {
    if (state.catalogCategory && entry.category !== state.catalogCategory) return false;
    if (!q) return true;
    return [catalogValue(entry, kind), entry.name, entry.displayName, entry.category, entry.runtimeId, entry.assetPath, entry.classPath, entry.searchText]
      .some(value => String(value || '').toLowerCase().includes(q));
  });
  const pageSize = 160;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  state.catalogPage = Math.max(0, Math.min(Number(state.catalogPage) || 0, pageCount - 1));
  const pageStart = state.catalogPage * pageSize;
  const visible = filtered.slice(pageStart, pageStart + pageSize);
  els.moduleCatalogGrid.innerHTML = visible.length
    ? visible.map(entry => catalogTile(entry, kind)).join('')
    : '<div class="muted-line">Ничего не найдено.</div>';
  if (els.moduleCatalogCount) {
    els.moduleCatalogCount.textContent = `${filtered.length} / ${(source || []).length}`;
  }
  if (els.moduleCatalogPage) {
    els.moduleCatalogPage.textContent = `${Math.min(state.catalogPage + 1, pageCount)} / ${pageCount}`;
  }
  if (els.moduleCatalogPrev) {
    els.moduleCatalogPrev.disabled = state.catalogPage <= 0;
  }
  if (els.moduleCatalogNext) {
    els.moduleCatalogNext.disabled = state.catalogPage >= pageCount - 1;
  }
  if (els.moduleCatalogSelected) {
    const selected = state.catalogSelected;
    els.moduleCatalogSelected.innerHTML = selected
      ? `<b>${escapeHtml(selected.name || selected.value)}</b><span>${escapeHtml(selected.value || '')}</span><small>${escapeHtml(selected.category || selected.kind || '')}</small>`
      : 'Ничего не выбрано.';
  }
}

function syncModuleField(target) {
  if (target.dataset.ruleItemField) {
    const key = target.dataset.arrayKey;
    const ruleIndex = Number(target.dataset.arrayIndex);
    const itemIndex = Number(target.dataset.ruleItemIndex);
    const field = target.dataset.ruleItemField;
    if (!state.moduleDraft || !Array.isArray(state.moduleDraft[key]) || !state.moduleDraft[key][ruleIndex]) return;
    const rule = state.moduleDraft[key][ruleIndex];
    const itemKey = Array.isArray(rule.items) && !Array.isArray(rule.Items) ? 'items' : 'Items';
    const fieldKey = itemKey === 'items' ? (field === 'ItemId' ? 'itemId' : 'quantity') : field;
    if (!Array.isArray(rule[itemKey])) rule[itemKey] = [];
    if (!rule[itemKey][itemIndex]) rule[itemKey][itemIndex] = itemKey === 'items' ? { itemId: '', quantity: 1 } : { ItemId: '', Quantity: 1 };
    rule[itemKey][itemIndex][fieldKey] = target.type === 'number' ? Number(target.value || 0) : target.value;
    setModuleDraftText();
    return;
  }

  if (target.dataset.arrayKey) {
    const key = target.dataset.arrayKey;
    const index = Number(target.dataset.arrayIndex);
    const field = target.dataset.arrayField;
    if (!state.moduleDraft || !Array.isArray(state.moduleDraft[key]) || !state.moduleDraft[key][index]) return;
    let value = target.type === 'checkbox' ? target.checked : target.value;
    if (target.type === 'number') value = Number(target.value || 0);
    setNestedValue(state.moduleDraft[key][index], field, value);
    if (field === 'DeliveryMode') {
      if (value === 'Fame') state.moduleDraft[key][index].UiDeliveryMode = 'Fame';
      else delete state.moduleDraft[key][index].UiDeliveryMode;
    }
    setModuleDraftText();
    return;
  }

  if (target.dataset.objectKey) {
    const key = target.dataset.objectKey;
    const field = target.dataset.objectField;
    if (!state.moduleDraft[key] || typeof state.moduleDraft[key] !== 'object') state.moduleDraft[key] = {};
    state.moduleDraft[key][field] = Number(target.value || 0);
    setModuleDraftText();
    return;
  }

  const key = target.dataset.configKey;
  if (!key || !state.moduleDraft) return;
  let value;
  if (target.type === 'checkbox') value = target.checked;
  else if (target.type === 'number') value = Number(target.value || 0);
  else if (target.dataset.configMode === 'number-list') value = target.value.split(',').map(x => Number(x.trim())).filter(Number.isFinite);
  else if (target.dataset.configMode === 'line-list') value = target.value.split(/\r?\n|,/).map(x => x.trim()).filter(Boolean);
  else if (target.tagName === 'TEXTAREA') value = target.value.trim() ? JSON.parse(target.value) : null;
  else value = target.value;
  state.moduleDraft[key] = value;
  setModuleDraftText();
}

function normalizeWargmConfigForSave(config) {
  const clone = JSON.parse(JSON.stringify(config || {}));
  const rulesKey = Array.isArray(clone.Rules) ? 'Rules' : (Array.isArray(clone.rules) ? 'rules' : '');
  if (!rulesKey) return clone;
  clone[rulesKey].forEach(rule => {
    if (!rule || typeof rule !== 'object') return;
    const mode = wargmRuleMode(rule);
    if (mode === 'Fame') {
      const amount = Number(wargmRuleValue(rule, 'Amount', 0) || 0);
      const command = `ChangeFamePoints ${amount} {steamId}`;
      if (Object.prototype.hasOwnProperty.call(rule, 'deliveryMode') && !Object.prototype.hasOwnProperty.call(rule, 'DeliveryMode')) {
        rule.uiDeliveryMode = 'Fame';
        rule.deliveryMode = 'ServerCommand';
        rule.commandTemplate = command;
      } else {
        rule.UiDeliveryMode = 'Fame';
        rule.DeliveryMode = 'ServerCommand';
        rule.CommandTemplate = command;
      }
    } else {
      delete rule.UiDeliveryMode;
      delete rule.uiDeliveryMode;
    }
  });
  return clone;
}

async function saveSelectedModule() {
  collectModuleDraftFromFields();
  const rawConfig = JSON.parse(els.moduleConfig.value);
  const config = state.selectedModule === 'wargm-shop' ? normalizeWargmConfigForSave(rawConfig) : rawConfig;
  els.moduleConfig.value = JSON.stringify(config, null, 2);
  state.moduleDraft = config;
  const data = await api('/api/plugin-config', { method: 'POST', body: JSON.stringify({ name: state.selectedModule, config }) });
  await refreshModules();
  return data;
}

async function refreshDiagnostics() {
  const status = { bridge: { online: false, message: 'diagnostics disabled' } };
  const queue = { available: false, depth: 0, pending: 0, message: 'diagnostics disabled' };
  renderDiagnosticSummary(status, queue);
  const text = 'Диагностика отключена, чтобы не читать тяжёлые логи и не поднимать пинг сервера.';
  if (els.queueStatus) els.queueStatus.textContent = text;
  if (els.traceLog) els.traceLog.textContent = text;
  if (els.serverLog) els.serverLog.textContent = text;
  if (els.runtimeLog) els.runtimeLog.textContent = text;
  if (els.actionLog) els.actionLog.textContent = text;
}

function renderDiagnosticSummary(status, queue) {
  const bridge = status && status.bridge ? status.bridge : {};
  const queueDepth = Number(queue && queue.depth || 0);
  const pending = Number(queue && queue.pending || 0);
  const current = queue && queue.current && queue.current.label ? queue.current.label : 'idle';
  const last = queue && queue.lastDelivery ? queue.lastDelivery : null;
  if (els.diagBridge) {
    els.diagBridge.textContent = bridge.online ? 'online' : 'offline';
    els.diagBridge.className = bridge.online ? 'ok-text' : 'bad-text';
  }
  if (els.diagHeartbeat) els.diagHeartbeat.textContent = bridge.heartbeatAgeSeconds == null ? '-' : `${bridge.heartbeatAgeSeconds}s`;
  if (els.diagQueue) els.diagQueue.textContent = `${queueDepth} / pending ${pending}`;
  if (els.diagCurrent) els.diagCurrent.textContent = current;
  if (els.diagLastDelivery) {
    if (last && typeof last === 'object') {
      els.diagLastDelivery.textContent = `${last.action || 'delivery'}: ${last.ok ? 'ok' : 'fail'} ${last.message || ''}`.trim();
      els.diagLastDelivery.className = last.ok ? 'ok-text' : 'bad-text';
    } else {
      els.diagLastDelivery.textContent = 'none';
      els.diagLastDelivery.className = '';
    }
  }
}

function smokeTargetBody(extra = {}) {
  return Object.assign(serviceTargetBody(), extra);
}

function refreshCurrent() {
  refreshStatus().catch(toast);
  if (state.page === 'servers') {
    refreshServers().catch(toast);
    refreshEvents().catch(toast);
  }
  if (state.page === 'players') refreshPlayers().catch(toast);
  if (state.page === 'services') refreshServices().catch(toast);
  if (state.page === 'squads') refreshSquads().catch(toast);
  if (state.page === 'chat') refreshChat().catch(toast);
  if (state.page === 'kills') refreshKills().catch(toast);
  if (state.page === 'modules') refreshModules().catch(toast);
  if (state.page === 'downloads') refreshDownloads().catch(toast);
}

function pick(obj, keys, fallback = '') {
  for (const key of keys) if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
  return fallback;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, '&#96;');
}

function toast(err) {
  const msg = err && err.message ? err.message : String(err);
  els.quickResult.textContent = msg;
}

function confirmDanger(message) {
  return window.confirm(message);
}

function normalizeTargetText(target) {
  const value = String(target || '').trim();
  const lower = value.toLowerCase();
  if (['name', 'steamid', 'steam_id', 'targetname', 'targetsteamid', 'player'].includes(lower)) return '';
  return value;
}

function playerTargetBody(target) {
  target = normalizeTargetText(target);
  const lowerTarget = target.toLowerCase();
  const matched = (state.players || []).find(p => {
    const steamId = String(p.steamId || p.SteamId || p.steam || '');
    const name = String(p.name || p.Name || p.playerName || '');
    const runtimeKey = String(p.runtimeKey || p.RuntimeKey || '');
    return target && (steamId === target || name.toLowerCase() === lowerTarget || runtimeKey === target);
  }) || null;
  return {
    steamId: matched ? (matched.steamId || matched.SteamId || matched.steam || null) : (/^\d{16,20}$/.test(target) ? target : null),
    name: matched ? (matched.name || matched.Name || matched.playerName || null) : (/^\d{16,20}$/.test(target) ? null : target),
    runtimeKey: matched ? (matched.runtimeKey || matched.RuntimeKey || null) : null
  };
}

function selectedPlayerBody() {
  if (!state.selectedPlayerTarget) return null;
  return {
    steamId: state.selectedPlayerTarget.steamId || null,
    name: state.selectedPlayerTarget.name || null,
    runtimeKey: state.selectedPlayerTarget.runtimeKey || null,
    profileId: state.selectedPlayerTarget.profileId || null,
    userProfileId: state.selectedPlayerTarget.profileId || null,
    serverUserProfileId: state.selectedPlayerTarget.profileId || null
  };
}

async function loadPlayerFacts(steamId, name, runtimeKey = '', force = false) {
  if (typeof runtimeKey === 'boolean') {
    force = runtimeKey;
    runtimeKey = '';
  }
  if (!els.playerFactsBody) return null;
  const key = playerInventoryKey(steamId, name, runtimeKey);
  const cached = state.playerFacts[key];
  if (cached && !force && !cached.loading) {
    renderPlayerFactsPanel();
    return cached;
  }
  state.playerFacts[key] = Object.assign({}, cached || {}, { loading: true, error: null });
  renderPlayerFactsPanel();
  const query = `steamId=${encodeURIComponent(steamId || '')}&name=${encodeURIComponent(name || '')}&runtimeKey=${encodeURIComponent(runtimeKey || '')}`;
  const [wallet, attributes] = await Promise.all([
    api(`/api/player/wallet?${query}`).catch(err => ({ error: err && err.message ? err.message : String(err) })),
    api(`/api/player/attributes?${query}`).catch(err => ({ error: err && err.message ? err.message : String(err) }))
  ]);
  state.playerFacts[key] = { loading: false, wallet, attributes, fetchedAt: new Date().toISOString() };
  renderPlayerFactsPanel();
  return state.playerFacts[key];
}

function renderPlayerFactsPanel() {
  if (!els.playerFactsBody || !state.selectedPlayerTarget) return;
  const { steamId, name, runtimeKey } = state.selectedPlayerTarget;
  const facts = state.playerFacts[playerInventoryKey(steamId, name, runtimeKey)];
  if (!facts || facts.loading) {
    els.playerFactsBody.innerHTML = '<div class="muted-line">Читаю кошелёк, славу и атрибуты из SCUM.db...</div>';
    return;
  }
  const wallet = facts.wallet || {};
  const attrs = facts.attributes || {};
  const walletError = wallet.error ? `<div class="inventory-errors"><span>Кошелёк: ${escapeHtml(wallet.error)}</span></div>` : '';
  const attrsError = attrs.error ? `<div class="inventory-errors"><span>Атрибуты: ${escapeHtml(attrs.error)}</span></div>` : '';
  els.playerFactsBody.innerHTML = `
    <div class="inventory-summary">
      <article><b>${escapeHtml(wallet.normalBalance ?? wallet.moneyBalance ?? '-')}</b><span>Баланс</span></article>
      <article><b>${escapeHtml(wallet.goldBalance ?? 0)}</b><span>Золото</span></article>
      <article><b>${escapeHtml(wallet.famePoints ?? '-')}</b><span>Слава</span></article>
      <article><b>${escapeHtml(attrs.strength ?? '-')} / ${escapeHtml(attrs.constitution ?? '-')} / ${escapeHtml(attrs.dexterity ?? '-')} / ${escapeHtml(attrs.intelligence ?? '-')}</b><span>STR CON DEX INT</span></article>
    </div>
    ${walletError}${attrsError}`;
}

async function loadPlayerInventory(steamId, name, runtimeKey = '', force = false) {
  if (typeof runtimeKey === 'boolean') {
    force = runtimeKey;
    runtimeKey = '';
  }
  const key = playerInventoryKey(steamId, name, runtimeKey);
  const cached = state.playerInventory[key];
  if (cached && !force && !cached.error && !cached.loading) {
    renderPlayerInventoryPanel();
    return cached;
  }
  state.playerInventory[key] = Object.assign({}, cached || {}, { loading: true, error: null });
  renderPlayerInventoryPanel();
  try {
    const params = new URLSearchParams({
      steamId: steamId || '',
      name: name || '',
      runtimeKey: runtimeKey || ''
    });
    if (force) params.set('_', String(Date.now()));
    const data = await api(`/api/player-inventory?${params.toString()}`);
    state.playerInventory[key] = Object.assign({}, data || {}, { loading: false, error: null, fetchedAt: new Date().toISOString() });
  } catch (err) {
    state.playerInventory[key] = { loading: false, error: err && err.message ? err.message : String(err), rows: [], quickSlots: [] };
  }
  renderPlayerInventoryPanel();
  return state.playerInventory[key];
}

function renderPlayerInventoryPanel() {
  if (!els.playerInventoryBody || !state.selectedPlayerTarget) return;
  const { steamId, name, runtimeKey } = state.selectedPlayerTarget;
  const inv = state.playerInventory[playerInventoryKey(steamId, name, runtimeKey)];
  if (!inv || inv.loading) {
    els.playerInventoryBody.innerHTML = '<div class="muted-line">Читаю SCUM.db...</div>';
    return;
  }
  if (inv.error) {
    els.playerInventoryBody.innerHTML = `<div class="event">${escapeHtml(inv.error)}</div>`;
    return;
  }
  const rows = Array.isArray(inv.rows) ? inv.rows : [];
  const quick = Array.isArray(inv.quickSlots) ? inv.quickSlots : [];
  const hands = rows.find(row => String(row.slotKind || '').toLowerCase() === 'hands');
  const containers = rows.filter(row => Number(row.hasInventory || 0) === 1).length;
  const topLevel = rows.filter(row => Number(row.depth || 0) === 0).length;
  const errors = Array.isArray(inv.errors) ? inv.errors : [];
  els.playerInventoryBody.innerHTML = `
    <div class="inventory-summary">
      <article><b>${rows.length}</b><span>Всего</span></article>
      <article><b>${containers}</b><span>Контейнеры</span></article>
      <article><b>${topLevel}</b><span>Верхний уровень</span></article>
      <article><b>${escapeHtml(inv.source || 'SCUM.db')}</b><span>Источник</span></article>
    </div>
    <div class="inventory-block">
      <h3>В руках</h3>
      ${hands ? renderInventoryNode(hands, new Map()) : '<div class="muted-line">Пусто или слот не сохранён в базе.</div>'}
    </div>
    <div class="inventory-block">
      <h3>Быстрые слоты</h3>
      <div class="quick-slots">${quick.length ? quick.map(slot => {
        const id = slot.itemId || slot.itemEntitySetup || slot.itemClass || '';
        return `<span><b>${escapeHtml(slot.slotIndex ?? '-')}</b> ${escapeHtml(friendlyAssetName(id, 'item'))}</span>`;
      }).join('') : '<span>Нет записей</span>'}</div>
    </div>
    <div class="inventory-block">
      <h3>Экипировка и контейнеры</h3>
      <div class="inventory-tree">${renderInventoryTree(rows)}</div>
    </div>
    ${errors.length ? `<div class="inventory-errors">${errors.map(err => `<span>${escapeHtml(err.area || 'db')}: ${escapeHtml(err.message || '')}</span>`).join('')}</div>` : ''}`;
}

function inventoryRefreshDelays(delay) {
  if (Array.isArray(delay)) {
    return Array.from(new Set(delay.map(value => Math.max(0, Number(value) || 0)))).sort((a, b) => a - b);
  }
  const requested = Number(delay);
  if (!Number.isFinite(requested)) return [150, 900, 2200];
  return Array.from(new Set([
    150,
    Math.min(Math.max(requested, 0), 700),
    Math.max(requested, 900),
    Math.max(requested + 900, 2200)
  ])).sort((a, b) => a - b);
}

function refreshSelectedInventorySoon(delay = [150, 900, 2200]) {
  const selected = state.selectedPlayerTarget;
  if (!selected) return;
  const token = ++state.inventoryRefreshToken;
  for (const waitMs of inventoryRefreshDelays(delay)) {
    window.setTimeout(() => {
      if (token !== state.inventoryRefreshToken) return;
      loadPlayerInventory(selected.steamId, selected.name, selected.runtimeKey, true).catch(toast);
    }, waitMs);
  }
}

function refreshSelectedFactsSoon(delay = 1200) {
  const selected = state.selectedPlayerTarget;
  if (!selected) return;
  window.setTimeout(() => loadPlayerFacts(selected.steamId, selected.name, selected.runtimeKey, true).catch(toast), delay);
}

function serviceTargetBody() {
  return playerTargetBody((els.serviceTarget && els.serviceTarget.value || '').trim());
}

function serviceTargetPlayer() {
  const target = normalizeTargetText((els.serviceTarget && els.serviceTarget.value || '').trim());
  const lower = target.toLowerCase();
  if (!target) return null;
  return (state.players || []).find(player => {
    const steamId = String(player.steamId || player.SteamId || player.steam || '');
    const name = String(player.name || player.Name || player.playerName || '');
    const runtimeKey = String(player.runtimeKey || player.RuntimeKey || '');
    return steamId === target || name.toLowerCase() === lower || runtimeKey === target;
  }) || null;
}

function numberFromKeys(obj, keys) {
  for (const key of keys) {
    const value = Number(obj && obj[key]);
    if (Number.isFinite(value)) return value;
  }
  return null;
}

function playerXY(player) {
  if (!player) return null;
  const x = numberFromKeys(player, ['x', 'X', 'locationX', 'LocationX']);
  const y = numberFromKeys(player, ['y', 'Y', 'locationY', 'LocationY']);
  return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
}

function distance2dClient(ax, ay, bx, by) {
  const dx = Number(ax) - Number(bx);
  const dy = Number(ay) - Number(by);
  return Math.sqrt(dx * dx + dy * dy);
}

function selectedFastRoutePoint() {
  const opt = els.fastRoute && els.fastRoute.selectedOptions ? els.fastRoute.selectedOptions[0] : null;
  const parts = opt && opt.dataset.point ? opt.dataset.point.split(',').map(Number) : [];
  const routeX = parts.length >= 2 && Number.isFinite(parts[0]) ? parts[0] : Number(els.fastX && els.fastX.value || 0);
  const routeY = parts.length >= 2 && Number.isFinite(parts[1]) ? parts[1] : Number(els.fastY && els.fastY.value || 0);
  return { option: opt, x: routeX, y: routeY };
}

function fastTravelConfiguredPrice(route) {
  const explicit = els.fastFare && els.fastFare.value.trim() !== '' ? Number(els.fastFare.value) : null;
  if (Number.isFinite(explicit) && explicit > 0) return Math.max(0, Math.floor(explicit));
  const optionPrice = route && route.option && route.option.dataset.price !== '' ? Number(route.option.dataset.price) : null;
  if (Number.isFinite(optionPrice) && optionPrice > 0) return Math.max(0, Math.floor(optionPrice));
  const fast = moduleConfig('fast-travel');
  const fixed = Number(fast.FixedFare ?? fast.fixedFare ?? fast.TravelCost ?? fast.travelCost ?? 0);
  if (Number.isFinite(fixed) && fixed > 0) return Math.max(0, Math.floor(fixed));
  return null;
}

function updateFastTravelPricePreview() {
  if (!els.fastPricePreview) return;
  const route = selectedFastRoutePoint();
  const fixedPrice = fastTravelConfiguredPrice(route);
  const player = serviceTargetPlayer();
  const position = playerXY(player);
  const routeName = route.option ? route.option.textContent.trim() : 'ручная точка';
  if (fixedPrice !== null) {
    els.fastPricePreview.textContent = `Цена до "${routeName}": ${fixedPrice}.`;
    return;
  }
  if (!position) {
    els.fastPricePreview.textContent = 'Цена считается от позиции игрока: укажи онлайн-игрока сверху.';
    return;
  }
  if (!Number.isFinite(route.x) || !Number.isFinite(route.y)) {
    els.fastPricePreview.textContent = 'Укажи маршрут или координаты точки.';
    return;
  }
  const fast = moduleConfig('fast-travel');
  const rate = Number(fast.RatePerMeter ?? fast.ratePerMeter ?? 0.5);
  const fare = Math.max(0, Math.floor(distance2dClient(position.x, position.y, route.x, route.y) * (Number.isFinite(rate) ? rate : 0.5) + 0.5));
  els.fastPricePreview.textContent = `Цена до "${routeName}": ${fare}. Расстояние: ${Math.floor(distance2dClient(position.x, position.y, route.x, route.y) + 0.5)} см.`;
}

const wargmModeMeta = {
  item: {
    label: 'Предметы',
    hint: 'Для кейса добавь несколько предметов в набор. Если набор пуст, выдастся один предмет из поля ID.'
  },
  vehicle: {
    label: 'Транспорт',
    hint: 'Выдача транспорта ставится в live-очередь и выполняется рядом с выбранным игроком.'
  },
  money: {
    label: 'Баланс',
    hint: 'Изменяет обычный баланс игрока через безопасный bridge route.'
  },
  gold: {
    label: 'Золото',
    hint: 'Начисляет или списывает золото игроку через безопасный bridge route.'
  },
  fame: {
    label: 'Очки славы',
    hint: 'Начисляет или списывает очки славы игроку через ChangeFamePoints.'
  },
  skill: {
    label: 'Навык',
    hint: 'Выбери навык из каталога или введи точное имя, например Handgun или Melee Weapons.'
  },
  allskills: {
    label: 'Все навыки',
    hint: 'Выдаёт весь список навыков SCUM выбранному игроку. Для полной прокачки оставь уровень 4.'
  },
  attributes: {
    label: 'Атрибуты',
    hint: 'Укажи четыре значения персонажа: сила, тело, ловкость и интеллект.'
  },
  command: {
    label: 'Команда',
    hint: 'Для редких случаев. Используй только проверенные SCUM-команды.'
  }
};

function findCatalogItemLabel(itemId) {
  const key = String(itemId || '').trim().toLowerCase();
  if (!key) return '';
  const item = (state.items || []).find(row => String(row.itemId || row.id || '').toLowerCase() === key);
  if (!item) return '';
  return item.name || item.category || '';
}

function wargmTargetLabel() {
  const target = (els.serviceTarget && els.serviceTarget.value || '').trim();
  return target || 'цель не указана';
}

function buildWargmPreview() {
  const mode = els.wargmMode ? els.wargmMode.value : 'item';
  if (mode === 'item') {
    const items = state.wargmItems.length
      ? state.wargmItems
      : ((els.wargmItemId && els.wargmItemId.value.trim()) ? [{ ItemId: els.wargmItemId.value.trim(), Quantity: Number(els.wargmQty && els.wargmQty.value || 1) }] : []);
    const count = items.reduce((sum, item) => sum + Math.max(1, Number(item.Quantity || 1)), 0);
    return items.length
      ? `К выдаче: ${items.length} строк, ${count} шт. Цель: ${wargmTargetLabel()}.`
      : `Выбери предмет или собери набор. Цель: ${wargmTargetLabel()}.`;
  }
  if (mode === 'vehicle') return `Транспорт: ${(els.wargmVehicleId && els.wargmVehicleId.value.trim()) || 'не выбран'}. Цель: ${wargmTargetLabel()}.`;
  if (mode === 'money') return `Баланс: ${Number(els.wargmAmount && els.wargmAmount.value || 0)}. Цель: ${wargmTargetLabel()}.`;
  if (mode === 'gold') return `Золото: ${Number(els.wargmAmount && els.wargmAmount.value || 0)}. Цель: ${wargmTargetLabel()}.`;
  if (mode === 'fame') return `Очки славы: ${Number(els.wargmAmount && els.wargmAmount.value || 0)}. Цель: ${wargmTargetLabel()}.`;
  if (mode === 'skill') return `Навык: ${(els.wargmSkill && els.wargmSkill.value.trim()) || 'не выбран'}, уровень ${Number(els.wargmSkillLevel && els.wargmSkillLevel.value || 0)}. Цель: ${wargmTargetLabel()}.`;
  if (mode === 'allskills') return `Все навыки: уровень ${Number(els.wargmAllSkillLevel && els.wargmAllSkillLevel.value || 4)}. Цель: ${wargmTargetLabel()}.`;
  if (mode === 'attributes') {
    return `Атрибуты: ${Number(els.wargmStrength && els.wargmStrength.value || 0)} / ${Number(els.wargmConstitution && els.wargmConstitution.value || 0)} / ${Number(els.wargmDexterity && els.wargmDexterity.value || 0)} / ${Number(els.wargmIntelligence && els.wargmIntelligence.value || 0)}. Цель: ${wargmTargetLabel()}.`;
  }
  return `Команда: ${(els.wargmCommand && els.wargmCommand.value.trim()) || 'не указана'}. Цель: ${wargmTargetLabel()}.`;
}

function updateWargmModeUi() {
  const mode = els.wargmMode ? els.wargmMode.value : 'item';
  const meta = wargmModeMeta[mode] || wargmModeMeta.item;
  document.querySelectorAll('[data-wargm-mode]').forEach(block => {
    const modes = String(block.dataset.wargmMode || '').split(/\s+/).filter(Boolean);
    block.hidden = !modes.includes(mode);
  });
  if (els.wargmModePill) els.wargmModePill.textContent = meta.label;
  if (els.wargmModeHint) els.wargmModeHint.textContent = meta.hint;
  if (els.wargmPreview) els.wargmPreview.textContent = buildWargmPreview();
  if (els.wargmDeliver) els.wargmDeliver.textContent = mode === 'item' ? 'Выдать предметы' : `Выдать: ${meta.label.toLowerCase()}`;
}

function validateWargmRequest() {
  const mode = els.wargmMode ? els.wargmMode.value : 'item';
  const target = (els.serviceTarget && els.serviceTarget.value || '').trim();
  if (!target) return 'Укажи SteamID или имя игрока в верхнем поле.';
  if (mode === 'item') {
    const hasSingle = !!(els.wargmItemId && els.wargmItemId.value.trim());
    if (!state.wargmItems.length && !hasSingle) return 'Добавь предмет в набор или укажи один ID предмета.';
  }
  if (mode === 'vehicle' && !(els.wargmVehicleId && els.wargmVehicleId.value.trim())) return 'Укажи ID транспорта.';
  if ((mode === 'money' || mode === 'gold' || mode === 'fame') && !Number(els.wargmAmount && els.wargmAmount.value || 0)) return 'Укажи ненулевую сумму.';
  if (mode === 'skill' && !(els.wargmSkill && els.wargmSkill.value.trim())) return 'Укажи навык.';
  if (mode === 'attributes') {
    const values = [els.wargmStrength, els.wargmConstitution, els.wargmDexterity, els.wargmIntelligence].map(input => Number(input && input.value || 0));
    if (values.every(value => value === 0)) return 'Укажи значения атрибутов.';
  }
  if (mode === 'command' && !(els.wargmCommand && els.wargmCommand.value.trim())) return 'Укажи команду.';
  return '';
}

function renderWargmItems() {
  if (!els.wargmItemsList) return;
  els.wargmItemsList.innerHTML = state.wargmItems.length
    ? state.wargmItems.map((item, index) => `<div class="mini-row">
        <span><b>${escapeHtml(item.ItemId)}</b>${findCatalogItemLabel(item.ItemId) ? ` <em>${escapeHtml(findCatalogItemLabel(item.ItemId))}</em>` : ''} x ${Number(item.Quantity || 1)}</span>
        <button class="mini-action" type="button" data-wargm-remove-item="${index}">Убрать</button>
      </div>`).join('')
    : '<span class="muted-line">Набор пуст. Добавь предметы для кейса или оставь один ID в поле выше.</span>';
  updateWargmModeUi();
}

function addWargmItemFromInputs() {
  const itemId = (els.wargmItemId && els.wargmItemId.value || '').trim();
  const quantity = Math.max(1, Number(els.wargmQty && els.wargmQty.value || 1));
  if (!itemId) {
    toast('Укажи ID предмета.');
    return;
  }
  state.wargmItems.push({ ItemId: itemId, Quantity: quantity });
  if (els.wargmItemId) els.wargmItemId.value = '';
  if (els.wargmQty) els.wargmQty.value = '1';
  renderWargmItems();
}

function resetSelectedPlayerDetailPanels() {
  if (els.playerFactsBody) {
    els.playerFactsBody.innerHTML = '<div class="muted-line">Данные игрока не читаются в фоне. Открой вкладку инвентаря или нажми обновление.</div>';
  }
  if (els.playerInventoryBody) {
    els.playerInventoryBody.innerHTML = '<div class="muted-line">Инвентарь не мониторится автоматически. Нажми "Обновить инвентарь", когда он реально нужен.</div>';
  }
}

function getPlayerActionCard() {
  return els.playerActionCard ||
    document.getElementById('playerActionCard') ||
    (els.playerActionModal && els.playerActionModal.querySelector('.modal-card')) ||
    (els.profileActionDock && els.profileActionDock.querySelector('.modal-card'));
}

function mountPlayerActionCard(inline = false) {
  const card = getPlayerActionCard();
  if (!card) return false;
  if (inline && els.profileActionDock) {
    if (card.parentNode !== els.profileActionDock) els.profileActionDock.appendChild(card);
    els.profileActionDock.classList.remove('hidden');
    els.profileActionDock.setAttribute('aria-hidden', 'false');
    if (els.playerActionModal) {
      els.playerActionModal.classList.add('hidden');
      els.playerActionModal.setAttribute('aria-hidden', 'true');
    }
    if (els.playerActionClose) els.playerActionClose.textContent = 'Скрыть';
    return true;
  }
  if (els.playerActionModal && card.parentNode !== els.playerActionModal) els.playerActionModal.appendChild(card);
  if (els.profileActionDock) {
    els.profileActionDock.classList.add('hidden');
    els.profileActionDock.setAttribute('aria-hidden', 'true');
  }
  if (els.playerActionClose) els.playerActionClose.textContent = '×';
  return false;
}

function isPlayerActionDocked() {
  const card = getPlayerActionCard();
  return Boolean(card && els.profileActionDock && card.parentNode === els.profileActionDock);
}

function openPlayerActionModal(steamId, name, runtimeKey = '', tab = 'message', profileId = '', options = {}) {
  if (['message', 'inventory', 'items', 'position', 'economy', 'character', 'vehicle', 'guard'].includes(runtimeKey)) {
    tab = runtimeKey;
    runtimeKey = '';
  }
  const selected = setSelectedPlayerTarget(steamId, name, runtimeKey, profileId);
  const target = selected.target || '';
  els.playerActionTarget.value = target;
  els.playerActionTitle.textContent = `${selected.name || 'Игрок'}${selected.steamId ? ` · ${selected.steamId}` : ''}${selected.profileId ? ` · профиль ${selected.profileId}` : ''}`;
  if (els.playerActionResult) els.playerActionResult.textContent = '';
  resetSelectedPlayerDetailPanels();
  if (els.playerActionVehicleId && !els.playerActionVehicleId.value) {
    const firstVehicle = (state.vehicles || [])[0];
    els.playerActionVehicleId.value = firstVehicle ? catalogIdFor(firstVehicle, 'vehicle') : 'BPC_WolfsWagen';
  }
  if (els.playerActionRentalVehicleId && !rentalVehicleByInput(els.playerActionRentalVehicleId.value)) {
    const rental = firstRentalVehicle();
    els.playerActionRentalVehicleId.value = rental ? (rental.asset || rental.alias) : '';
  }
  setPlayerActionTab(tab);
  const shouldDock = Boolean(options.inline || (els.playerProfile && !els.playerProfile.classList.contains('hidden')));
  if (mountPlayerActionCard(shouldDock)) return;
  els.playerActionModal.classList.remove('hidden');
  els.playerActionModal.setAttribute('aria-hidden', 'false');
}

function closePlayerActionModal() {
  if (isPlayerActionDocked()) {
    if (els.profileActionDock) {
      els.profileActionDock.classList.add('hidden');
      els.profileActionDock.setAttribute('aria-hidden', 'true');
    }
    return;
  }
  els.playerActionModal.classList.add('hidden');
  els.playerActionModal.setAttribute('aria-hidden', 'true');
}

function setPlayerActionTab(tab) {
  document.querySelectorAll('[data-player-tab]').forEach(btn => btn.classList.toggle('active', btn.dataset.playerTab === tab));
  document.querySelectorAll('[data-player-pane]').forEach(pane => pane.classList.toggle('active', pane.dataset.playerPane === tab));
  if (tab === 'vehicle' && els.playerActionVehicleId && !els.playerActionVehicleId.value) {
    const firstVehicle = (state.vehicles || [])[0];
    els.playerActionVehicleId.value = firstVehicle ? catalogIdFor(firstVehicle, 'vehicle') : 'BPC_WolfsWagen';
  }
  if (tab === 'vehicle' && els.playerActionRentalVehicleId && !rentalVehicleByInput(els.playerActionRentalVehicleId.value)) {
    const rental = firstRentalVehicle();
    els.playerActionRentalVehicleId.value = rental ? (rental.asset || rental.alias) : '';
  }
  if (tab === 'inventory' && state.selectedPlayerTarget) {
    loadPlayerFacts(state.selectedPlayerTarget.steamId, state.selectedPlayerTarget.name, state.selectedPlayerTarget.runtimeKey).catch(toast);
    loadPlayerInventory(state.selectedPlayerTarget.steamId, state.selectedPlayerTarget.name, state.selectedPlayerTarget.runtimeKey).catch(toast);
  }
}

function modalTargetBody() {
  const target = (els.playerActionTarget && els.playerActionTarget.value || '').trim();
  const selected = state.selectedPlayerTarget;
  if (selected && (target === selected.target || target === selected.steamId || target === selected.name)) {
    return selectedPlayerBody();
  }
  return playerTargetBody(target);
}

function uniqueInventoryEntityIds(rows) {
  const seen = new Set();
  return (Array.isArray(rows) ? rows : [])
    .filter(row => row && row.entityId)
    .sort((a, b) => Number(b.depth || 0) - Number(a.depth || 0))
    .map(row => String(row.entityId || '').trim())
    .filter(id => {
      if (!id || id === '0' || seen.has(id)) return false;
      seen.add(id);
      return true;
    });
}

async function destroyInventoryEntitiesFast(ids, target) {
  const cleanIds = uniqueInventoryEntityIds((ids || []).map(id => ({ entityId: id })));
  if (!cleanIds.length) throw new Error('Нет EntityID для удаления.');
  const chunks = [];
  for (let i = 0; i < cleanIds.length; i += 6) chunks.push(cleanIds.slice(i, i + 6));
  const result = { ok: true, requested: cleanIds.length, batch: true, chunks: chunks.length, queued: 0, failed: [] };
  for (let i = 0; i < chunks.length; i += 1) {
    const chunk = chunks[i];
    try {
      const batch = await api('/api/player/destroy-inventory-entities', {
        method: 'POST',
        body: JSON.stringify(Object.assign({}, target, {
          targetSteamId: target.steamId,
          targetName: target.name,
          targetRuntimeKey: target.runtimeKey,
          entityIds: chunk,
          entitiesText: chunk.join(' ')
        }))
      });
      const batchData = batch && (batch.payload || batch.data || batch);
      const payload = batchData && (batchData.payload || batchData.data || batchData);
      const batchOk = batch && batch.ok !== false && (!batchData || batchData.ok !== false) && (!payload || payload.ok !== false);
      if (!batchOk) {
        const failedText = (payload && (payload.error || payload.message || payload.failed)) ||
          (batchData && (batchData.error || batchData.message || batchData.failed)) ||
          (batch && (batch.error || batch.message || batch.failed)) ||
          'команда не выполнена';
        result.ok = false;
        result.failed.push(`batch ${i + 1}: ${Array.isArray(failedText) ? failedText.join('; ') : failedText}`);
      } else {
        result.queued += Number((payload && (payload.batchSize || payload.requested)) || chunk.length || 0);
      }
    } catch (err) {
      result.ok = false;
      result.failed.push(`batch ${i + 1}: ${err && err.message ? err.message : String(err)}`);
    }
    if (i < chunks.length - 1) await sleep(220);
  }
  return result;
}

async function grantAllSkillsToSelectedPlayer() {
  const level = Math.max(0, Math.min(4, Number(els.playerActionSkillLevel && els.playerActionSkillLevel.value || 4)));
  const experience = 0;
  const target = modalTargetBody();
  const skills = mergeSkillCatalog(state.skillCatalog || FULL_SCUM_SKILLS)
    .map(skill => String(skill.skill || skill.key || skill.name || '').trim())
    .filter(Boolean)
    .filter(skill => !isAllSkillsValue(skill))
    .filter((skill, index, list) => list.findIndex(item => item.toLowerCase() === skill.toLowerCase()) === index);

  if (!skills.length) throw new Error('Каталог навыков пуст.');
  if (!window.confirm(`Поставить ${skills.length} навыка(ов) в безопасную очередь уровнем ${level}?`)) {
    return { ok: false, cancelled: true };
  }

  if (els.playerActionResult) {
    showResult(els.playerActionResult, `Ставлю ${skills.length} навыка(ов) в безопасную очередь. Сервер выдаст их по одному.`);
  }
  const response = await api('/api/player/set-skill', {
    method: 'POST',
    body: JSON.stringify(Object.assign({}, target, { skill: 'allskills', skillName: 'allskills', allSkills: true, AllSkills: true, level, experience }))
  });
  refreshSelectedFactsSoon(1500);
  return Object.assign({ ok: true, queued: true, level, total: skills.length }, response || {});
}

document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', () => setPage(btn.dataset.page)));
document.querySelectorAll('[data-event-tab]').forEach(btn => btn.addEventListener('click', () => {
  state.eventTab = btn.dataset.eventTab;
  document.querySelectorAll('[data-event-tab]').forEach(tab => tab.classList.toggle('active', tab === btn));
  refreshEvents().catch(toast);
}));
document.querySelectorAll('[data-service-tab]').forEach(btn => btn.addEventListener('click', () => setServiceTab(btn.dataset.serviceTab)));
document.querySelectorAll('[data-economy-tab]').forEach(btn => btn.addEventListener('click', () => setEconomyTab(btn.dataset.economyTab)));

els.apiKey.value = state.apiKey;
if (els.serverHost) els.serverHost.value = state.apiBase || window.location.origin;
setPanelLanguage(state.language);
if (els.panelLanguage) {
  els.panelLanguage.addEventListener('change', () => {
    setPanelLanguage(els.panelLanguage.value);
    setPage(state.page, false);
    refreshStatus().catch(toast);
    if (state.page === 'players') renderPlayers();
  });
}
els.saveApiKey.addEventListener('click', () => {
  state.apiKey = els.apiKey.value.trim();
  if (els.serverHost) {
    const rawBase = normalizeApiBase(els.serverHost.value);
    state.apiBase = rawBase && rawBase !== window.location.origin ? rawBase : '';
    localStorage.setItem('nedjin.apiBase.v2', state.apiBase);
  }
  localStorage.setItem('nedjin.apiKey.v2', state.apiKey);
  localStorage.setItem('nedjin.apiKey', state.apiKey);
  refreshCatalogs().catch(toast);
  refreshCurrent();
});
function openSupportModal() {
  if (!els.supportModal) return;
  els.supportModal.classList.remove('hidden');
  els.supportModal.setAttribute('aria-hidden', 'false');
}

function closeSupportModal() {
  if (!els.supportModal) return;
  els.supportModal.classList.add('hidden');
  els.supportModal.setAttribute('aria-hidden', 'true');
}

if (els.supportAuthorBtn) els.supportAuthorBtn.addEventListener('click', openSupportModal);
if (els.supportClose) els.supportClose.addEventListener('click', closeSupportModal);
if (els.supportModal) els.supportModal.addEventListener('click', evt => {
  if (evt.target === els.supportModal) closeSupportModal();
});
if (els.supportCopy) els.supportCopy.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText('2202206875705381');
    toast('Номер Сбер скопирован');
  } catch (_) {
    toast('2202206875705381 Сбер');
  }
});
if (els.createServerBtn) els.createServerBtn.addEventListener('click', () => showResult(els.quickResult, { ok: true, message: 'Сервер добавляется через подключение к URL и API ключу.' }));
if (els.serverList) els.serverList.addEventListener('click', evt => {
  const btn = evt.target.closest('[data-server-action]');
  if (!btn) return;
  setPage(btn.dataset.serverAction);
});
els.refreshBtn.addEventListener('click', refreshCurrent);
els.refreshEventsSmall.addEventListener('click', () => refreshEvents().catch(toast));
els.refreshPlayers.addEventListener('click', () => refreshPlayers().catch(toast));
els.playerSearch.addEventListener('input', renderPlayers);
if (els.playersSort) els.playersSort.addEventListener('change', renderPlayers);
els.refreshSquads.addEventListener('click', () => refreshSquads().catch(toast));
els.squadSearch.addEventListener('input', renderSquads);
els.refreshChat.addEventListener('click', () => refreshChat().catch(toast));
els.chatSearch.addEventListener('input', renderChat);
els.chatChannel.addEventListener('change', renderChat);
els.refreshKills.addEventListener('click', () => refreshKills().catch(toast));
els.killsSearch.addEventListener('input', renderKills);
els.refreshEconomy.addEventListener('click', () => refreshEconomy().catch(toast));
els.refreshDownloads.addEventListener('click', () => refreshDownloads().catch(toast));
els.homeListRefresh.addEventListener('click', () => refreshHomes().catch(toast));
if (els.refreshMap) els.refreshMap.addEventListener('click', () => refreshMap().catch(toast));
els.layerPlayers.addEventListener('change', renderMap);
els.layerVehicles.addEventListener('change', renderMap);
if (els.layerChests) els.layerChests.addEventListener('change', renderMap);
els.layerFlags.addEventListener('change', renderMap);
if (els.mapZoomIn) els.mapZoomIn.addEventListener('click', () => { state.mapZoom += 0.2; applyMapZoom(); });
if (els.mapZoomOut) els.mapZoomOut.addEventListener('click', () => { state.mapZoom -= 0.2; applyMapZoom(); });
if (els.mapReset) els.mapReset.addEventListener('click', () => { state.mapZoom = 1; applyMapZoom(); setMapSelection(null); });
if (els.mapImage) els.mapImage.addEventListener('click', evt => {
  if (!state.map || !els.mapSelection) return;
  const rect = els.mapImage.getBoundingClientRect();
  let px = (evt.clientX - rect.left) / rect.width;
  let py = (evt.clientY - rect.top) / rect.height;
  const bounds = state.map.bounds || {};
  const minX = Number(bounds.minX ?? -768000);
  const maxX = Number(bounds.maxX ?? 768000);
  const minY = Number(bounds.minY ?? -768000);
  const maxY = Number(bounds.maxY ?? 768000);
  if (bounds.invertX ?? true) px = 1 - px;
  if (bounds.invertY ?? true) py = 1 - py;
  const worldX = minX + (maxX - minX) * px;
  const worldY = minY + (maxY - minY) * py;
  const x = bounds.swapAxes ? worldY : worldX;
  const y = bounds.swapAxes ? worldX : worldY;
  setMapSelection({ kind: 'точка', title: 'Выбранная точка', x, y, z: 0 });
});
if (els.mapMarkers) els.mapMarkers.addEventListener('click', evt => {
  const marker = evt.target.closest('[data-map-marker]');
  if (!marker) return;
  setMapSelection({
    kind: marker.dataset.kind || '',
    title: marker.dataset.title || marker.dataset.name || '',
    steamId: marker.dataset.steam || '',
    name: marker.dataset.name || '',
    runtimeKey: marker.dataset.runtime || '',
    x: Number(marker.dataset.x || 0),
    y: Number(marker.dataset.y || 0),
    z: Number(marker.dataset.z || 0)
  });
});
if (els.mapSelection) els.mapSelection.addEventListener('click', async evt => {
  const action = evt.target.closest('[data-map-selection-action]');
  if (!action || !state.mapSelection) return;
  if (action.dataset.mapSelectionAction === 'use-coords') {
    applySelectedMapCoords();
    toast('Координаты вставлены в поля телепорта.');
  } else if (action.dataset.mapSelectionAction === 'copy-coords') {
    const s = state.mapSelection;
    const text = `${Number(s.x || 0).toFixed(0)} ${Number(s.y || 0).toFixed(0)} ${Number(s.z || 0).toFixed(0)}`;
    if (navigator.clipboard) await navigator.clipboard.writeText(text);
    toast('Координаты скопированы.');
  } else if (action.dataset.mapSelectionAction === 'open-player') {
    const s = state.mapSelection;
    openPlayerActionModal(s.steamId || '', s.name || '', s.runtimeKey || '', 'position');
    applySelectedMapCoords();
  }
});
els.refreshTrace.addEventListener('click', () => refreshDiagnostics().catch(toast));
if (els.refreshQueueStatus) els.refreshQueueStatus.addEventListener('click', () => refreshDiagnostics().catch(toast));
els.refreshServerLog.addEventListener('click', () => refreshDiagnostics().catch(toast));
if (els.refreshRuntimeLog) els.refreshRuntimeLog.addEventListener('click', () => refreshDiagnostics().catch(toast));
if (els.refreshActionLog) els.refreshActionLog.addEventListener('click', () => refreshDiagnostics().catch(toast));
if (els.smokeBridge) els.smokeBridge.addEventListener('click', async () => {
  await showActionResult(els.quickResult, async () => {
    return { ok: false, message: 'Диагностика отключена, чтобы не нагружать сервер.' };
  });
});
if (els.smokeApple) els.smokeApple.addEventListener('click', async () => {
  await showActionResult(els.quickResult, () => api('/api/player/grant-item', {
    method: 'POST',
    body: JSON.stringify(smokeTargetBody({ itemId: 'Apple_2', quantity: 1 }))
  }));
});
if (els.smokeWeapon) els.smokeWeapon.addEventListener('click', async () => {
  await showActionResult(els.quickResult, () => api('/api/player/grant-item', {
    method: 'POST',
    body: JSON.stringify(smokeTargetBody({ itemId: 'Weapon_MK18', quantity: 1 }))
  }));
});
if (els.smokeVehicle) els.smokeVehicle.addEventListener('click', async () => {
  const vehicleId = (els.rentalVehicle && els.rentalVehicle.value) || 'BPC_WolfsWagen';
  await showActionResult(els.quickResult, () => api('/api/player/spawn-vehicle', {
    method: 'POST',
    body: JSON.stringify(smokeTargetBody({ vehicleId }))
  }));
});

els.quickBroadcast.addEventListener('click', async () => {
  await showActionResult(els.quickResult, () => sendPanelChat({ message: els.quickMessage.value, channel: 'global' }));
  refreshChat().catch(() => {});
});
els.quickCommandRun.addEventListener('click', async () => {
  await showActionResult(els.quickResult, () => api('/api/rcon', { method: 'POST', body: JSON.stringify({ command: els.quickCommand.value }) }));
});
els.welcomeClaim.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, async () => {
    const result = await api('/api/welcome-pack/claim', { method: 'POST', body: JSON.stringify(serviceTargetBody()) });
    await refreshWelcomeTimers();
    return result;
  });
});
els.welcomeReset.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, async () => {
    const result = await api('/api/welcome-pack/reset-timer', { method: 'POST', body: JSON.stringify(serviceTargetBody()) });
    await refreshWelcomeTimers();
    return result;
  });
});
if (els.welcomeTimers) els.welcomeTimers.addEventListener('click', async evt => {
  const btn = evt.target.closest('[data-welcome-reset]');
  if (!btn) return;
  const label = btn.dataset.welcomeSteam || btn.dataset.welcomeName || btn.dataset.welcomeReset || 'игрок';
  if (!confirmDanger(`Сбросить стартовый набор для ${label}? Игрок сможет получить его заново.`)) return;
  await showActionResult(els.serviceResult, async () => {
    const result = await api('/api/welcome-pack/reset-timer', {
      method: 'POST',
      body: JSON.stringify({
        steamId: btn.dataset.welcomeSteam || null,
        name: btn.dataset.welcomeName || null,
        targetSteamId: btn.dataset.welcomeSteam || null,
        targetName: btn.dataset.welcomeName || null
      })
    });
    await refreshWelcomeTimers();
    return result;
  });
});
els.homeSet.addEventListener('click', async () => {
  const body = Object.assign(serviceTargetBody(), { label: els.homeLabel.value.trim() || 'home' });
  await showActionResult(els.serviceResult, async () => {
    const result = await api('/api/home/set', { method: 'POST', body: JSON.stringify(body) });
    await refreshHomes();
    return result;
  });
});
els.homeList.addEventListener('click', async evt => {
  const btn = evt.target.closest('button[data-home-x]');
  if (!btn) return;
  const body = Object.assign(serviceTargetBody(), {
    label: btn.dataset.homeLabel || '',
    x: Number(btn.dataset.homeX || 0),
    y: Number(btn.dataset.homeY || 0),
    z: Number(btn.dataset.homeZ || 0)
  });
  await showActionResult(els.serviceResult, () => api('/api/home/teleport', { method: 'POST', body: JSON.stringify(body) }));
});
els.fastRoute.addEventListener('change', () => {
  const opt = els.fastRoute.selectedOptions[0];
  const parts = opt && opt.dataset.point ? opt.dataset.point.split(',') : [];
  if (parts.length >= 3) {
    els.fastX.value = parts[0];
    els.fastY.value = parts[1];
    els.fastZ.value = parts[2];
  }
  if (els.fastFare && opt && opt.dataset.price !== undefined && opt.dataset.price !== '') {
    els.fastFare.value = opt.dataset.price;
  }
  updateFastTravelPricePreview();
});
[
  els.serviceTarget,
  els.fastFare,
  els.fastX,
  els.fastY,
  els.fastZ
].forEach(input => {
  if (input) input.addEventListener('input', updateFastTravelPricePreview);
});
els.fastTravelGo.addEventListener('click', async () => {
  const body = Object.assign(serviceTargetBody(), {
    alias: els.fastRoute.value,
    x: Number(els.fastX.value || 0),
    y: Number(els.fastY.value || 0),
    z: Number(els.fastZ.value || 0)
  });
  const fareText = els.fastFare ? els.fastFare.value.trim() : '';
  if (fareText !== '') {
    body.amount = Number(fareText || 0);
    body.fare = Number(fareText || 0);
  }
  await showActionResult(els.serviceResult, () => api('/api/fast-travel/go', { method: 'POST', body: JSON.stringify(body) }));
});
if (els.rentalVehicle) els.rentalVehicle.addEventListener('change', applyRentalVehicleDefaults);
els.rentVehicle.addEventListener('click', async () => {
  const opt = els.rentalVehicle.selectedOptions[0];
  if (!opt || !els.rentalVehicle.value) {
    toast('Добавь хотя бы один транспорт в настройках аренды.');
    return;
  }
  const body = Object.assign(serviceTargetBody(), {
    vehicleId: els.rentalVehicle.value,
    alias: opt ? opt.dataset.alias : '',
    minutes: Number(els.rentalMinutes && els.rentalMinutes.value || 10)
  });
  await showActionResult(els.serviceResult, () => api('/api/vehicle-rental/rent', { method: 'POST', body: JSON.stringify(body) }));
});
if (els.rentalCleanup) els.rentalCleanup.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, () => api('/api/vehicle-rental/cleanup', { method: 'POST', body: JSON.stringify({}) }));
});
els.scanSector.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, () => api('/api/sector-scan', { method: 'POST', body: JSON.stringify(serviceTargetBody()) }));
});
if (els.wargmSync) els.wargmSync.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, () => api('/api/wargm/sync', { method: 'POST', body: JSON.stringify({}) }));
});
if (els.wargmConfirm) els.wargmConfirm.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, () => api('/api/wargm/confirm-delivered', { method: 'POST', body: JSON.stringify({}) }));
});
if (els.discordStatus) els.discordStatus.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, () => api('/api/discord/status'));
});
if (els.discordTest) els.discordTest.addEventListener('click', async () => {
  await showActionResult(els.serviceResult, () => api('/api/discord/test', {
    method: 'POST',
    body: JSON.stringify({
      route: els.discordRoute ? els.discordRoute.value : 'system',
      message: els.discordMessage ? els.discordMessage.value : ''
    })
  }));
});
if (els.wargmAddItem) els.wargmAddItem.addEventListener('click', addWargmItemFromInputs);
if (els.wargmClearItems) els.wargmClearItems.addEventListener('click', () => {
  state.wargmItems = [];
  renderWargmItems();
});
if (els.wargmMode) els.wargmMode.addEventListener('change', updateWargmModeUi);
[
  els.serviceTarget,
  els.wargmItemId,
  els.wargmQty,
  els.wargmVehicleId,
  els.wargmAmount,
    els.wargmSkill,
    els.wargmSkillLevel,
    els.wargmSkillExperience,
    els.wargmAllSkillLevel,
    els.wargmAllSkillExperience,
    els.wargmStrength,
  els.wargmConstitution,
  els.wargmDexterity,
  els.wargmIntelligence,
  els.wargmCommand
].forEach(input => {
  if (input) input.addEventListener('input', updateWargmModeUi);
});
if (els.wargmItemsList) els.wargmItemsList.addEventListener('click', evt => {
  const btn = evt.target.closest('[data-wargm-remove-item]');
  if (!btn) return;
  state.wargmItems.splice(Number(btn.dataset.wargmRemoveItem), 1);
  renderWargmItems();
});
els.wargmDeliver.addEventListener('click', async () => {
  const validationMessage = validateWargmRequest();
  if (validationMessage) {
    toast(validationMessage);
    if (els.wargmPreview) els.wargmPreview.textContent = validationMessage;
    return;
  }
  const selectedMode = els.wargmMode.value;
  const amount = Number(els.wargmAmount.value || 0);
  const items = state.wargmItems.length
    ? state.wargmItems
    : (els.wargmItemId.value.trim() ? [{ ItemId: els.wargmItemId.value.trim(), Quantity: Number(els.wargmQty.value || 1) }] : []);
  const isAllSkills = selectedMode === 'allskills';
  const skillLevel = isAllSkills
    ? Number(els.wargmAllSkillLevel && els.wargmAllSkillLevel.value || 4)
    : Number(els.wargmSkillLevel && els.wargmSkillLevel.value || 0);
  const skillExperience = isAllSkills
    ? Number(els.wargmAllSkillExperience && els.wargmAllSkillExperience.value || 0)
    : Number(els.wargmSkillExperience && els.wargmSkillExperience.value || 0);
  const body = Object.assign(serviceTargetBody(), {
    mode: selectedMode === 'fame' ? 'command' : selectedMode,
    itemId: els.wargmItemId.value.trim(),
    quantity: Number(els.wargmQty.value || 1),
    Items: items,
    vehicleId: els.wargmVehicleId.value.trim(),
    amount,
    currency: selectedMode === 'gold' ? 'Gold' : 'Normal',
    skill: isAllSkills ? 'allskills' : (els.wargmSkill ? els.wargmSkill.value.trim() : ''),
    skillName: isAllSkills ? 'allskills' : (els.wargmSkill ? els.wargmSkill.value.trim() : ''),
    allSkills: isAllSkills,
    AllSkills: isAllSkills,
    level: skillLevel,
    skillLevel,
    experience: skillExperience,
    skillExperience,
    strength: Number(els.wargmStrength && els.wargmStrength.value || 0),
    constitution: Number(els.wargmConstitution && els.wargmConstitution.value || 0),
    dexterity: Number(els.wargmDexterity && els.wargmDexterity.value || 0),
    intelligence: Number(els.wargmIntelligence && els.wargmIntelligence.value || 0),
    command: selectedMode === 'fame' ? `ChangeFamePoints ${amount} {steamId}` : (els.wargmCommand ? els.wargmCommand.value.trim() : '')
  });
  await showActionResult(els.serviceResult, () => api('/api/wargm/manual-deliver', { method: 'POST', body: JSON.stringify(body) }));
});
els.sendChat.addEventListener('click', async () => {
  const target = playerTargetBody(els.chatTarget.value.trim());
  const body = { channel: els.chatSendChannel.value, message: els.chatMessage.value };
  if (target.steamId || target.name || target.runtimeKey) {
    Object.assign(body, target, {
      targetSteamId: target.steamId,
      targetName: target.name,
      targetRuntimeKey: target.runtimeKey
    });
  }
  await showActionResult(els.chatResult, () => sendPanelChat(body));
  refreshChat().catch(() => {});
});
els.economyApply.addEventListener('click', async () => {
  const body = Object.assign(playerTargetBody(els.economyTarget.value.trim()), {
    currency: els.economyCurrency.value,
    amount: Number(els.economyAmount.value || 0)
  });
  await showActionResult(els.economyResult, () => api('/api/player/change-money', { method: 'POST', body: JSON.stringify(body) }));
});
els.fameApply.addEventListener('click', async () => {
  const body = Object.assign(playerTargetBody(els.economyTarget.value.trim()), { amount: Number(els.fameAmount.value || 0) });
  await showActionResult(els.economyResult, () => api('/api/player/set-fame', { method: 'POST', body: JSON.stringify(body) }));
});
els.runConsole.addEventListener('click', async () => {
  await showActionResult(els.consoleResult, () => api('/api/rcon', { method: 'POST', body: JSON.stringify({ command: els.consoleCommand.value }) }));
});
els.grantItem.addEventListener('click', async () => {
  const target = els.itemTarget.value.trim();
  const body = Object.assign(playerTargetBody(target), { itemId: els.itemId.value.trim(), quantity: Number(els.itemQty.value || 1) });
  await showActionResult(els.consoleResult, () => api('/api/player/grant-item', { method: 'POST', body: JSON.stringify(body) }));
});
els.equipItem.addEventListener('click', async () => {
  const target = els.itemTarget.value.trim();
  const body = Object.assign(playerTargetBody(target), { itemId: els.itemId.value.trim(), quantity: Number(els.itemQty.value || 1), equip: true });
  await showActionResult(els.consoleResult, () => api('/api/player/equip-item', { method: 'POST', body: JSON.stringify(body) }));
});
els.prewarmItem.addEventListener('click', async () => {
  const body = { itemId: els.itemId.value.trim(), quantity: Number(els.itemQty.value || 1) };
  await showActionResult(els.consoleResult, () => api('/api/items/prewarm', { method: 'POST', body: JSON.stringify(body) }));
});
els.addItemBatch.addEventListener('click', () => {
  const itemId = els.itemId.value.trim();
  if (!itemId) return;
  state.itemBatch.push({ itemId, quantity: Number(els.itemQty.value || 1) });
  renderItemBatch();
});
els.grantItemBatch.addEventListener('click', async () => {
  const target = els.itemTarget.value.trim();
  const body = Object.assign(playerTargetBody(target), { Items: state.itemBatch.map(item => ({ ItemId: item.itemId, Quantity: item.quantity })) });
  await showActionResult(els.consoleResult, async () => {
    const result = await api('/api/player/item-batch', { method: 'POST', body: JSON.stringify(body) });
    state.itemBatch = [];
    renderItemBatch();
    return result;
  });
});
els.itemBatchList.addEventListener('click', evt => {
  const btn = evt.target.closest('[data-batch-remove]');
  if (!btn) return;
  state.itemBatch.splice(Number(btn.dataset.batchRemove), 1);
  renderItemBatch();
});
els.teleportPlayer.addEventListener('click', async () => {
  const body = Object.assign(playerTargetBody(els.actionTarget.value.trim()), {
    x: Number(els.teleportX.value || 0),
    y: Number(els.teleportY.value || 0),
    z: Number(els.teleportZ.value || 0)
  });
  await showActionResult(els.consoleResult, () => api('/api/player/teleport', { method: 'POST', body: JSON.stringify(body) }));
});
els.changeMoney.addEventListener('click', async () => {
  const body = Object.assign(playerTargetBody(els.actionTarget.value.trim()), { currency: els.moneyCurrency.value, amount: Number(els.moneyAmount.value || 0) });
  await showActionResult(els.consoleResult, () => api('/api/player/change-money', { method: 'POST', body: JSON.stringify(body) }));
});
els.spawnVehicle.addEventListener('click', async () => {
  const body = Object.assign(playerTargetBody(els.actionTarget.value.trim()), {
    vehicleId: els.vehicleId.value.trim(),
    minutes: Number(els.vehicleMinutes && els.vehicleMinutes.value || 0)
  });
  await showActionResult(els.consoleResult, () => api('/api/player/spawn-vehicle', { method: 'POST', body: JSON.stringify(body) }));
});
els.playersList.addEventListener('click', async evt => {
  const btn = evt.target.closest('button[data-act]');
  if (!btn) {
    const card = evt.target.closest('.player[data-steam], .player[data-name]');
    if (!card) return;
    const player = findPlayerByIdentity(card.dataset.steam || '', card.dataset.name || '', card.dataset.runtime || '') || {
      steamId: card.dataset.steam || '',
      name: card.dataset.name || '',
      runtimeKey: card.dataset.runtime || '',
      profileId: card.dataset.profile || ''
    };
    openPlayerProfile(player);
    return;
  }
  const steamId = btn.dataset.steam || null;
  const name = btn.dataset.name || null;
  const runtimeKey = btn.dataset.runtime || '';
  const profileId = btn.dataset.profile || '';
  if (btn.dataset.act === 'open-card') {
    const player = findPlayerByIdentity(steamId, name, runtimeKey) || { steamId, name, runtimeKey, profileId };
    openPlayerProfile(player);
    return;
  }
  if (btn.dataset.act === 'details') {
    openPlayerActionModal(steamId, name, runtimeKey, 'inventory', profileId);
    await showActionResult(els.playerActionResult || els.quickResult, () => api(`/api/player-details?steamId=${encodeURIComponent(steamId || '')}&name=${encodeURIComponent(name || '')}&runtimeKey=${encodeURIComponent(runtimeKey || '')}`));
    return;
  }
  if (btn.dataset.act === 'modal') {
    openPlayerActionModal(steamId, name, runtimeKey, btn.dataset.tab || 'message', profileId);
  }
});
els.playerActionClose.addEventListener('click', closePlayerActionModal);
els.playerActionModal.addEventListener('click', evt => {
  if (evt.target === els.playerActionModal) closePlayerActionModal();
});
if (els.profClose) els.profClose.addEventListener('click', closePlayerProfile);
if (els.playerProfile) els.playerProfile.addEventListener('click', evt => {
  const preset = evt.target.closest('[data-profile-preset]');
  if (!preset || !els.profItemSearch) return;
  els.profItemSearch.value = preset.dataset.profilePreset || '';
  els.profItemSearch.focus();
});
if (els.playersList) els.playersList.addEventListener('keydown', evt => {
  if (evt.key !== 'Enter' && evt.key !== ' ') return;
  const card = evt.target.closest('.player[data-steam], .player[data-name]');
  if (!card) return;
  evt.preventDefault();
  const player = findPlayerByIdentity(card.dataset.steam || '', card.dataset.name || '', card.dataset.runtime || '') || {
    steamId: card.dataset.steam || '',
    name: card.dataset.name || '',
    runtimeKey: card.dataset.runtime || '',
    profileId: card.dataset.profile || ''
  };
  openPlayerProfile(player);
});
if (els.profSpawnBtn) els.profSpawnBtn.addEventListener('click', async () => {
  if (!state.selectedPlayerTarget) {
    toast('Сначала выбери игрока.');
    return;
  }
  const itemId = (els.profItemSearch && els.profItemSearch.value || '').trim();
  if (!itemId) {
    showResult(els.profActionResult, { ok: false, error: 'Укажи ID предмета.' });
    return;
  }
  const quantity = Math.max(1, Number(els.profItemAmount && els.profItemAmount.value || 1));
  const body = Object.assign(selectedPlayerBody(), { itemId, quantity });
  await showActionResult(els.profActionResult, () => api('/api/player/grant-item', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedInventorySoon();
});
if (els.profTeleportBtn) els.profTeleportBtn.addEventListener('click', async () => {
  if (!state.selectedPlayerTarget) {
    toast('Сначала выбери игрока.');
    return;
  }
  const body = Object.assign(selectedPlayerBody(), {
    x: Number(els.profX && els.profX.value || 0),
    y: Number(els.profY && els.profY.value || 0),
    z: Number(els.profZ && els.profZ.value || 0)
  });
  await showActionResult(els.profActionResult, () => api('/api/player/teleport', { method: 'POST', body: JSON.stringify(body) }));
});
if (els.profOpenPositionBtn) els.profOpenPositionBtn.addEventListener('click', () => openSelectedPlayerModal('position'));
if (els.profInventoryBtn) els.profInventoryBtn.addEventListener('click', () => openSelectedPlayerModal('inventory'));
if (els.profBalanceBtn) els.profBalanceBtn.addEventListener('click', () => openSelectedPlayerModal('economy'));
if (els.profCharacterBtn) els.profCharacterBtn.addEventListener('click', () => openSelectedPlayerModal('character'));
if (els.profVehicleBtn) els.profVehicleBtn.addEventListener('click', () => openSelectedPlayerModal('vehicle'));
if (els.profKickBtn) els.profKickBtn.addEventListener('click', async () => {
  if (!state.selectedPlayerTarget) {
    toast('Сначала выбери игрока.');
    return;
  }
  if (!confirmDanger('Кикнуть выбранного игрока с сервера?')) return;
  const body = Object.assign(selectedPlayerBody(), { reason: (els.profReason && els.profReason.value || '').trim() || 'действие администратора через панель' });
  await showActionResult(els.profActionResult, () => api('/api/player/kick', { method: 'POST', body: JSON.stringify(body) }));
});
if (els.profBanBtn) els.profBanBtn.addEventListener('click', async () => {
  if (!state.selectedPlayerTarget) {
    toast('Сначала выбери игрока.');
    return;
  }
  if (!confirmDanger('Забанить выбранного игрока?')) return;
  const body = Object.assign(selectedPlayerBody(), { reason: (els.profReason && els.profReason.value || '').trim() || 'действие администратора через панель' });
  await showActionResult(els.profActionResult, () => api('/api/player/ban', { method: 'POST', body: JSON.stringify(body) }));
});
document.querySelectorAll('[data-player-tab]').forEach(btn => {
  btn.addEventListener('click', () => setPlayerActionTab(btn.dataset.playerTab));
});
if (els.playerInventoryRefresh) els.playerInventoryRefresh.addEventListener('click', () => {
  if (!state.selectedPlayerTarget) return;
  loadPlayerFacts(state.selectedPlayerTarget.steamId, state.selectedPlayerTarget.name, state.selectedPlayerTarget.runtimeKey, true).catch(toast);
  loadPlayerInventory(state.selectedPlayerTarget.steamId, state.selectedPlayerTarget.name, state.selectedPlayerTarget.runtimeKey, true).catch(toast);
});
if (els.playerInventoryBody) els.playerInventoryBody.addEventListener('click', async evt => {
  const btn = evt.target.closest('[data-inventory-delete]');
  if (!btn || !state.selectedPlayerTarget) return;
  const entityId = btn.dataset.inventoryDelete || '';
  const itemId = btn.dataset.inventoryItemId || '';
  const label = itemId || entityId || 'предмет';
  if (!entityId) {
    toast('У предмета нет EntityID, удалить его точечно нельзя.');
    return;
  }
  if (!confirmDanger(`Удалить предмет ${label} у выбранного игрока?`)) return;
  const target = modalTargetBody();
  await showActionResult(els.playerActionResult, async () => {
    const queued = await destroyInventoryEntitiesFast([entityId], target);
    refreshSelectedInventorySoon(1600);
    const ok = queued && queued.ok !== false;
    return {
      ok,
      message: ok
        ? `Удаление отправлено: ${label}. Инвентарь обновится автоматически после ответа SCUM.db.`
        : `Удаление не выполнено: ${(queued && queued.failed && queued.failed.join('; ')) || 'мост вернул ошибку'}`,
      queued
    };
  });
});
els.playerActionSendMessage.addEventListener('click', async () => {
  const target = modalTargetBody();
  await showActionResult(els.playerActionResult, () => api('/api/chat', { method: 'POST', body: JSON.stringify({ targetSteamId: target.steamId, targetName: target.name, targetRuntimeKey: target.runtimeKey, runtimeKey: target.runtimeKey, message: els.playerActionMessage.value, channel: 'server' }) }));
  refreshChat().catch(() => {});
});
els.playerActionGrantItem.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { itemId: els.playerActionItemId.value.trim(), quantity: Number(els.playerActionItemQty.value || 1) });
  await showActionResult(els.playerActionResult, () => api('/api/player/grant-item', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedInventorySoon();
});
els.playerActionEquipItem.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { itemId: els.playerActionItemId.value.trim(), quantity: Number(els.playerActionItemQty.value || 1), equip: true });
  await showActionResult(els.playerActionResult, () => api('/api/player/equip-item', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedInventorySoon();
});
els.playerActionPrewarmItem.addEventListener('click', async () => {
  const body = { itemId: els.playerActionItemId.value.trim(), quantity: Number(els.playerActionItemQty.value || 1) };
  await showActionResult(els.playerActionResult, () => api('/api/items/prewarm', { method: 'POST', body: JSON.stringify(body) }));
});
els.playerActionWelcome.addEventListener('click', async () => {
  await showActionResult(els.playerActionResult, () => api('/api/welcome-pack/claim', { method: 'POST', body: JSON.stringify(modalTargetBody()) }));
  refreshSelectedInventorySoon(2200);
});
els.playerActionClearInventory.addEventListener('click', async () => {
  if (!confirmDanger('Очистить инвентарь выбранного игрока?')) return;
  await showActionResult(els.playerActionResult, async () => {
    const target = modalTargetBody();
    const inventory = await loadPlayerInventory(target.steamId, target.name, target.runtimeKey, true);
    const rows = Array.isArray(inventory && inventory.rows) ? inventory.rows : [];
    const items = rows
      .filter(row => row && row.entityId)
      .sort((a, b) => Number(b.depth || 0) - Number(a.depth || 0));
    if (!items.length) {
      return { ok: false, error: 'В панели нет списка предметов для удаления. Обнови инвентарь или попроси игрока открыть его.' };
    }
    const sentIds = uniqueInventoryEntityIds(items);
    const failed = [];
    let sent = 0;
    let destroyResult = null;
    try {
      destroyResult = await destroyInventoryEntitiesFast(sentIds, target);
      sent = sentIds.length;
    } catch (err) {
      failed.push(err && err.message ? err.message : String(err));
    }
    refreshSelectedInventorySoon(Math.min(3500, 1200 + Number((destroyResult && destroyResult.chunks) || 1) * 350));
    const ok = failed.length === 0 && (!destroyResult || destroyResult.ok !== false);
    return {
      ok,
      message: ok
        ? `Команды очистки отправлены: ${sent}/${items.length}. Инвентарь перечитается автоматически после обновления SCUM.db.`
        : `Очистка не выполнена: ${[...failed, ...((destroyResult && destroyResult.failed) || [])].join('; ') || 'мост вернул ошибку'}`,
      failed: [...failed, ...((destroyResult && destroyResult.failed) || [])]
    };
  });
});
els.playerActionTeleport.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { x: Number(els.playerActionX.value || 0), y: Number(els.playerActionY.value || 0), z: Number(els.playerActionZ.value || 0) });
  await showActionResult(els.playerActionResult, () => api('/api/player/teleport', { method: 'POST', body: JSON.stringify(body) }));
});
els.playerActionSetHome.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { label: els.playerActionHomeLabel.value.trim() || 'home' });
  await showActionResult(els.playerActionResult, () => api('/api/home/set', { method: 'POST', body: JSON.stringify(body) }));
  refreshHomes().catch(() => {});
});
els.playerActionMoney.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { currency: els.playerActionCurrency.value, amount: Number(els.playerActionAmount.value || 0) });
  if (!Number.isFinite(body.amount) || body.amount === 0) {
    toast('Укажи ненулевую сумму изменения баланса.');
    return;
  }
  await showActionResult(els.playerActionResult, () => api('/api/player/change-money', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedFactsSoon();
});
els.playerActionFame.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { amount: Number(els.playerActionAmount.value || 0) });
  await showActionResult(els.playerActionResult, () => api('/api/player/set-fame', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedFactsSoon();
});
els.playerActionAttributes.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), {
    strength: Number(els.playerActionStrength.value || 0),
    constitution: Number(els.playerActionConstitution.value || 0),
    dexterity: Number(els.playerActionDexterity.value || 0),
    intelligence: Number(els.playerActionIntelligence.value || 0)
  });
  await showActionResult(els.playerActionResult, () => api('/api/player/set-attributes', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedFactsSoon();
});
if (els.playerActionCharacterPackApply) els.playerActionCharacterPackApply.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), { pack: (els.playerActionCharacterPack && els.playerActionCharacterPack.value.trim()) || 'fullstats' });
  await showActionResult(els.playerActionResult, () => api('/api/player/apply-character-pack', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedFactsSoon(1800);
});
if (els.playerActionFullStats) els.playerActionFullStats.addEventListener('click', async () => {
  if (els.playerActionCharacterPack) els.playerActionCharacterPack.value = 'fullstats';
  const body = Object.assign(modalTargetBody(), { pack: 'fullstats' });
  await showActionResult(els.playerActionResult, () => api('/api/player/apply-character-pack', { method: 'POST', body: JSON.stringify(body) }));
  refreshSelectedFactsSoon(1800);
});
els.playerActionSkillApply.addEventListener('click', async () => {
  if (isAllSkillsValue(els.playerActionSkill.value)) {
    await showActionResult(els.playerActionResult, grantAllSkillsToSelectedPlayer);
    return;
  }
  const body = Object.assign(modalTargetBody(), { skill: els.playerActionSkill.value.trim(), level: Number(els.playerActionSkillLevel.value || 0) });
  await showActionResult(els.playerActionResult, () => api('/api/player/set-skill', { method: 'POST', body: JSON.stringify(body) }));
});
if (els.playerActionAllSkills) els.playerActionAllSkills.addEventListener('click', async () => {
  await showActionResult(els.playerActionResult, grantAllSkillsToSelectedPlayer);
});
els.playerActionSpawnVehicle.addEventListener('click', async () => {
  const vehicleId = els.playerActionVehicleId.value.trim();
  if (!vehicleId) {
    toast('Выбери транспорт из каталога или введи ID транспорта.');
    return;
  }
  const body = Object.assign(modalTargetBody(), {
    vehicleId,
    minutes: Number(els.playerActionRentalMinutes && els.playerActionRentalMinutes.value || 0)
  });
  await showActionResult(els.playerActionResult, async () => {
    const result = await api('/api/player/spawn-vehicle', { method: 'POST', body: JSON.stringify(body) });
    const entityId = result && (result.entityId || (result.data && result.data.entityId));
    if (entityId && els.playerActionVehicleEntityId) els.playerActionVehicleEntityId.value = entityId;
    return result;
  });
});
els.playerActionRentVehicle.addEventListener('click', async () => {
  const rental = rentalVehicleByInput((els.playerActionRentalVehicleId && els.playerActionRentalVehicleId.value) || els.playerActionVehicleId.value);
  if (!rental) {
    toast('Этот транспорт не включён в настройках аренды.');
    return;
  }
  const body = Object.assign(modalTargetBody(), {
    vehicleId: rental.asset,
    alias: rental.alias,
    minutes: Number(els.playerActionRentalMinutes && els.playerActionRentalMinutes.value || 10)
  });
  await showActionResult(els.playerActionResult, async () => {
    const result = await api('/api/vehicle-rental/rent', { method: 'POST', body: JSON.stringify(body) });
    if (result && result.entityId && els.playerActionVehicleEntityId) els.playerActionVehicleEntityId.value = result.entityId;
    refreshSelectedFactsSoon(1800);
    return result;
  });
});
if (els.playerActionDestroyVehicle) els.playerActionDestroyVehicle.addEventListener('click', async () => {
  const body = Object.assign(modalTargetBody(), {
    entityId: (els.playerActionVehicleEntityId && els.playerActionVehicleEntityId.value || '').trim(),
    reason: 'panel-player-card'
  });
  await showActionResult(els.playerActionResult, () => api('/api/vehicle/destroy', { method: 'POST', body: JSON.stringify(body) }));
});
els.playerActionKick.addEventListener('click', async () => {
  if (!confirmDanger('Кикнуть выбранного игрока с сервера?')) return;
  const body = Object.assign(modalTargetBody(), { reason: els.playerActionReason.value.trim() || 'действие администратора через панель' });
  await showActionResult(els.playerActionResult, () => api('/api/player/kick', { method: 'POST', body: JSON.stringify(body) }));
});
els.playerActionBan.addEventListener('click', async () => {
  if (!confirmDanger('Забанить выбранного игрока?')) return;
  const body = Object.assign(modalTargetBody(), { reason: els.playerActionReason.value.trim() || 'действие администратора через панель' });
  await showActionResult(els.playerActionResult, () => api('/api/player/ban', { method: 'POST', body: JSON.stringify(body) }));
});
els.moduleList.addEventListener('click', evt => {
  const card = evt.target.closest('[data-module]');
  if (!card) return;
  state.selectedModule = card.dataset.module;
  renderModules();
});
els.moduleFields.addEventListener('click', evt => {
  const openRule = evt.target.closest('[data-wargm-rule-open]');
  const closeRule = evt.target.closest('[data-wargm-rule-close]');
  const overlay = evt.target && evt.target.dataset && evt.target.dataset.wargmRuleOverlay === 'true';
  const add = evt.target.closest('[data-array-add]');
  const remove = evt.target.closest('[data-array-remove]');
  const addRuleItem = evt.target.closest('[data-wargm-rule-item-add]');
  const copySingleRuleItem = evt.target.closest('[data-wargm-rule-item-copy-single]');
  const removeRuleItem = evt.target.closest('[data-wargm-rule-item-remove]');
  if (closeRule || overlay) {
    state.wargmRuleEditIndex = null;
    renderModuleFields(state.moduleDraft);
    return;
  }
  if (openRule) {
    state.wargmRuleEditIndex = Number(openRule.dataset.wargmRuleOpen);
    renderModuleFields(state.moduleDraft);
    return;
  }
  if (addRuleItem) {
    const index = Number(addRuleItem.dataset.wargmRuleItemAdd);
    const key = 'Rules';
    const actualKey = state.moduleDraft && Array.isArray(state.moduleDraft.Rules) ? 'Rules' : 'rules';
    if (!state.moduleDraft || !Array.isArray(state.moduleDraft[actualKey]) || !state.moduleDraft[actualKey][index]) return;
    const rule = state.moduleDraft[actualKey][index];
    const itemKey = Array.isArray(rule.items) && !Array.isArray(rule.Items) ? 'items' : 'Items';
    if (!Array.isArray(rule[itemKey])) rule[itemKey] = [];
    rule[itemKey].push(itemKey === 'items' ? { itemId: 'Apple_2', quantity: 1 } : { ItemId: 'Apple_2', Quantity: 1 });
    setModuleDraftText();
    renderModuleFields(state.moduleDraft);
    return;
  }
  if (copySingleRuleItem) {
    const index = Number(copySingleRuleItem.dataset.wargmRuleItemCopySingle);
    const actualKey = state.moduleDraft && Array.isArray(state.moduleDraft.Rules) ? 'Rules' : 'rules';
    if (!state.moduleDraft || !Array.isArray(state.moduleDraft[actualKey]) || !state.moduleDraft[actualKey][index]) return;
    const rule = state.moduleDraft[actualKey][index];
    const itemKey = Array.isArray(rule.items) && !Array.isArray(rule.Items) ? 'items' : 'Items';
    const id = wargmRuleValue(rule, 'ItemId', 'Apple_2') || 'Apple_2';
    const quantity = Math.max(1, Number(wargmRuleValue(rule, 'Quantity', 1) || 1));
    if (!Array.isArray(rule[itemKey])) rule[itemKey] = [];
    rule[itemKey].push(itemKey === 'items' ? { itemId: id, quantity } : { ItemId: id, Quantity: quantity });
    setModuleDraftText();
    renderModuleFields(state.moduleDraft);
    return;
  }
  if (removeRuleItem) {
    const index = Number(removeRuleItem.dataset.wargmRuleItemRemove);
    const itemIndex = Number(removeRuleItem.dataset.ruleItemIndex);
    const actualKey = state.moduleDraft && Array.isArray(state.moduleDraft.Rules) ? 'Rules' : 'rules';
    if (state.moduleDraft && Array.isArray(state.moduleDraft[actualKey]) && state.moduleDraft[actualKey][index]) {
      const rule = state.moduleDraft[actualKey][index];
      const itemKey = Array.isArray(rule.items) && !Array.isArray(rule.Items) ? 'items' : 'Items';
      if (!Array.isArray(rule[itemKey])) return;
      rule[itemKey].splice(itemIndex, 1);
      setModuleDraftText();
      renderModuleFields(state.moduleDraft);
    }
    return;
  }
  if (add) {
    const key = add.dataset.arrayAdd;
    if (!Array.isArray(state.moduleDraft[key])) state.moduleDraft[key] = [];
    state.moduleDraft[key].push(defaultArrayItem(key));
    if (String(key).toLowerCase() === 'rules') state.wargmRuleEditIndex = state.moduleDraft[key].length - 1;
    setModuleDraftText();
    renderModuleFields(state.moduleDraft);
  }
  if (remove) {
    const key = remove.dataset.arrayRemove;
    const index = Number(remove.dataset.arrayIndex);
    if (Array.isArray(state.moduleDraft[key])) state.moduleDraft[key].splice(index, 1);
    if (String(key).toLowerCase() === 'rules') {
      if (state.wargmRuleEditIndex === index) state.wargmRuleEditIndex = null;
      else if (state.wargmRuleEditIndex > index) state.wargmRuleEditIndex -= 1;
    }
    setModuleDraftText();
    renderModuleFields(state.moduleDraft);
  }
});
els.moduleFields.addEventListener('input', evt => {
  try { syncModuleField(evt.target); } catch (err) { toast(err); }
});
els.moduleFields.addEventListener('focusin', evt => {
  if (evt.target.matches('input[list="itemCatalog"], input[list="vehicleCatalog"], input[list="skillCatalog"]')) {
    state.lastCatalogInput = evt.target;
  }
});
els.moduleFields.addEventListener('change', evt => {
  try {
    syncModuleField(evt.target);
  if (evt.target && evt.target.dataset && evt.target.dataset.arrayField === 'DeliveryMode') {
      if (evt.target.value === 'AllSkills') {
        const key = evt.target.dataset.arrayKey;
        const index = Number(evt.target.dataset.arrayIndex);
        const row = state.moduleDraft && Array.isArray(state.moduleDraft[key]) ? state.moduleDraft[key][index] : null;
        if (row && !Number(row.SkillLevel || row.skillLevel || 0)) row.SkillLevel = 4;
      }
      if ((evt.target.value === 'Gold' || evt.target.value === 'Fame') && state.moduleDraft) {
        const key = evt.target.dataset.arrayKey;
        const index = Number(evt.target.dataset.arrayIndex);
        const row = Array.isArray(state.moduleDraft[key]) ? state.moduleDraft[key][index] : null;
        if (row && !Number(row.Amount || row.amount || 0)) row.Amount = 1000;
      }
      renderModuleFields(state.moduleDraft);
    }
  } catch (err) { toast(err); }
});
document.addEventListener('focusin', evt => {
  if (evt.target.matches('input[list="itemCatalog"], input[list="vehicleCatalog"], input[list="skillCatalog"]')) {
    state.lastCatalogInput = evt.target;
  }
});
if (els.moduleCatalogSearch) els.moduleCatalogSearch.addEventListener('input', renderModuleCatalog);
if (els.moduleCatalogMode) els.moduleCatalogMode.addEventListener('change', renderModuleCatalog);
if (els.moduleCatalogCategories) els.moduleCatalogCategories.addEventListener('click', evt => {
  const btn = evt.target.closest('[data-catalog-category]');
  if (!btn) return;
  state.catalogCategory = btn.dataset.catalogCategory || '';
  state.catalogPage = 0;
  renderModuleCatalog();
});
if (els.moduleCatalogPrev) els.moduleCatalogPrev.addEventListener('click', () => {
  state.catalogPage = Math.max(0, (Number(state.catalogPage) || 0) - 1);
  renderModuleCatalog();
});
if (els.moduleCatalogNext) els.moduleCatalogNext.addEventListener('click', () => {
  state.catalogPage = (Number(state.catalogPage) || 0) + 1;
  renderModuleCatalog();
});
if (els.moduleCatalogGrid) els.moduleCatalogGrid.addEventListener('click', evt => {
  const tile = evt.target.closest('[data-catalog-value]');
  if (!tile) return;
  const value = tile.dataset.catalogValue || '';
  state.catalogSelected = {
    kind: tile.dataset.catalogKind || '',
    value,
    name: tile.dataset.catalogName || value,
    category: tile.dataset.catalogCategory || ''
  };
  const input = state.lastCatalogInput && document.contains(state.lastCatalogInput) ? state.lastCatalogInput : null;
  if (input) {
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.focus();
  }
  renderModuleCatalog();
});
if (els.moduleActions) els.moduleActions.addEventListener('click', async evt => {
  const save = evt.target.closest('[data-module-save]');
  const add = evt.target.closest('[data-module-add-array]');
  const stateBtn = evt.target.closest('[data-module-state]');
  if (save) {
    await showActionResult(els.quickResult, saveSelectedModule);
  }
  if (add) {
    const key = add.dataset.moduleAddArray;
    if (!Array.isArray(state.moduleDraft[key])) state.moduleDraft[key] = [];
    state.moduleDraft[key].push(defaultArrayItem(key));
    if (String(key).toLowerCase() === 'rules') state.wargmRuleEditIndex = state.moduleDraft[key].length - 1;
    setModuleDraftText();
    renderModuleFields(state.moduleDraft);
  }
  if (stateBtn) {
    const key = stateBtn.dataset.moduleState || state.selectedModule || '';
    await showActionResult(els.quickResult, () => api(`/api/module-state?key=${encodeURIComponent(key)}`));
  }
});
els.moduleConfig.addEventListener('change', () => {
  try {
    state.moduleDraft = JSON.parse(els.moduleConfig.value);
    renderModuleFields(state.moduleDraft);
  } catch {}
});
if (els.saveModule) els.saveModule.addEventListener('click', async () => {
  await showActionResult(els.quickResult, saveSelectedModule);
});
if (els.reloadModules) els.reloadModules.addEventListener('click', async () => {
  await showActionResult(els.quickResult, async () => {
    const data = await api('/api/status');
    await refreshModules();
    return {
      ok: true,
      message: 'Безопасное обновление выполнено: панель перечитала состояние и конфиги. Серверный процесс не перезапускался.',
      status: data.data || data
    };
  });
});
if (els.deleteModule) els.deleteModule.addEventListener('click', async () => {
  const key = state.selectedModule || '';
  await showActionResult(els.quickResult, async () => {
    const data = await api('/api/plugin-state', { method: 'POST', body: JSON.stringify({ key, enabled: false }) });
    await refreshModules();
    return data;
  });
});

refreshCatalogs().then(() => {
  renderWargmItems();
  updateWargmModeUi();
}).catch(toast);
renderWargmItems();
setServiceTab(state.serviceTab);
setEconomyTab(state.economyTab);
setPage('servers');

const PASSIVE_STATUS_REFRESH_MS = 300000;
window.setInterval(() => {
  if (document.hidden) return;
  if (state.page === 'servers') refreshStatus().catch(() => {});
  if (state.page === 'players') refreshPlayers().catch(() => {});
  if (state.page === 'services') refreshServices().catch(() => {});
  if (state.page === 'chat') refreshChat().catch(() => {});
}, PASSIVE_STATUS_REFRESH_MS);

